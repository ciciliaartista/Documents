package br.com.uolmais.video;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
  TestChrome.class,
  TestFirefox.class,
})
public class AllTests {

}
