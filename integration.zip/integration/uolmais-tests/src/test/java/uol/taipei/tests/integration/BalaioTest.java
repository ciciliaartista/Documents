/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         30/09/2014 Criacao inicial
 */

package uol.taipei.tests.integration;

import static org.testng.AssertJUnit.assertTrue;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertFalse;

import java.io.IOException;

import org.apache.http.client.ClientProtocolException;
import org.json.JSONException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import uol.taipei.request.FacileRequest;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.cacheproxy.Balaio;

/**
 * @author tsardinha
 * 
 *         mvn integration-test -Pbalaio
 */

@Test(groups = "balaio")
public class BalaioTest extends AbstractTest
{
    private Balaio balaio = null;
    private static FacileRequest request = null;

    @BeforeClass
    public void init() throws ClientProtocolException, IllegalStateException, IOException, JSONException
    {
        setUp(ENVIRONMENT);

        balaio = new Balaio();
        request = new FacileRequest();
    }

    @AfterClass
    public void finish()
    {
        request = null;
        balaio = null;
    }

    @Test
    public void probe()
    {
        try
        {
            assertNotNull(balaio.probe());
        }
        catch (Exception e)
        {
            assertNotNull(e.getMessage(), null);
        }
    }

    @Test
    public void downloadVideo()
    {
        try
        {
            assertTrue(balaio.downloadVideo());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void downloadPodcast()
    {
        try
        {
            assertTrue(balaio.downloadPodcast());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void downloadPodcastMobile()
    {
        try
        {
            assertTrue(balaio.downloadPodcastMobile());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void restrictNobodyViewVideo()
    {
        try
        {
            assertTrue(balaio.restrictNobodyViewVideo(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void restrictProductVideo()
    {
        try
        {
            assertTrue(balaio.restrictProductVideo(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void restrictRemovedStatusVideo()
    {
        try
        {
            assertTrue(balaio.restrictRemovedStatusVideo(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void restrictSubscriberVideo()
    {
        try
        {
            assertTrue(balaio.restrictSubscriberVideo(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void noUri()
    {
        try
        {
            assertTrue(balaio.noUri(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void noExtension()
    {
        try
        {
            assertTrue(balaio.noExtension(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void invalidFile()
    {
        try
        {
            assertTrue(balaio.invalidFile(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void post()
    {
        try
        {
            assertTrue(balaio.post(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void head()
    {
        try
        {
            assertTrue(balaio.head(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void video()
    {
        try
        {
            assertTrue(balaio.video(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void videoStart()
    {
        try
        {
            assertTrue(balaio.videoStart(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void videoUAWinChrome()
    {
        try
        {
            assertTrue(balaio.videoUAWinChrome(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void videoUAMacSafari()
    {
        try
        {
            assertTrue(balaio.videoUAMacSafari(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void videoNoReferer()
    {
        try
        {
            assertTrue(balaio.videoNoReferer(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void videoWithWildcard()
    {
        try
        {
            assertTrue(balaio.videoWithWildcard(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void videoWithWildcardNoUseragent()
    {
        try
        {
            assertTrue(balaio.videoWithWildcardNoUseragent(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }
}
