package uol.taipei.tests.integration;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.LoginCookie;
import uol.taipei.tests.notificationsIntegration.NotificationsIntegration;

/**
 * @author jmoraes
 * 
 * <br>
 * <br>
 *         <b>Command</b>: mvn integration-test -Pnotifications
 * 
 */
@Test(groups = "notifications")
public class NotificationsIntegrationTest extends AbstractTest
{
    private NotificationsIntegration notificationsIntegration = null;

    private LoginCookie login = null;

    @BeforeClass
    public void init() throws Exception
    {
        setUp(ENVIRONMENT);

        notificationsIntegration = new NotificationsIntegration();
        login = new LoginCookie(envConfig().getUser(), envConfig().getPass());
    }

    @AfterClass
    public void finish()
    {
        login = null;
        notificationsIntegration = null;
    }

    public void resetFollowableViewedCounter()
    {
        try
        {
            assertTrue(notificationsIntegration.resetFollowableViewedCounter(login));
        }
        catch (Exception e)
        {
            assertNotNull(e.getMessage(), null);
        }
    }

}
