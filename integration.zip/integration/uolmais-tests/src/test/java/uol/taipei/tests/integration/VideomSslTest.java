/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         20/08/2014 Criacao inicial
 */

package uol.taipei.tests.integration;

import static org.testng.AssertJUnit.assertTrue;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import uol.taipei.request.FacileRequest;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.ssl.VideomSsl;
import uol.taipei.tests.util.RequestUtil;

@Test(groups = "video.mssl")
public class VideomSslTest extends AbstractTest
{
    private VideomSsl videomSsl = null;
    private FacileRequest request = null;
    private String mediaId = null;

    @BeforeClass
    public void init() throws Exception
    {
        setUp(ENVIRONMENT);

        videomSsl = new VideomSsl();
        request = new FacileRequest();
        request.configureSSL();

        mediaId = RequestUtil.mediaIdPublic("V");
    }

    @AfterClass
    public void finish()
    {
        request = null;
        mediaId = null;
        videomSsl = null;
    }

    @Test
    public void probe()
    {
        try
        {
            assertNotNull(videomSsl.probe());
        }
        catch (Exception e)
        {
            assertNotNull(e.getMessage(), null);
        }
    }

    @Test
    public void videomMobile()
    {
        try
        {
            assertTrue(videomSsl.videomMobile(request, mediaId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void videomMobileNoFormat9()
    {
        try
        {
            assertTrue(videomSsl.videomMobileNoFormat9(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void videomNoReferer()
    {
        try
        {
            assertTrue(videomSsl.videomNoReferer(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void videomWithWildcard()
    {
        try
        {
            assertTrue(videomSsl.videomWithWildcard(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void videomWithWildcardNoUseragent()
    {
        try
        {
            assertTrue(videomSsl.videomWithWildcardNoUseragent(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "videomWithWildcard", "videomWithWildcardNoUseragent", "videomNoReferer", "videomMobileNoFormat9", "videomMobile" })
    public void podcastMobile()
    {
        try
        {
            mediaId = RequestUtil.mediaIdPublic("P");
            assertTrue(videomSsl.podcastMobile(request, mediaId));
        }
        catch (Exception e)
        {
            e.printStackTrace();
            assertFalse(e.getMessage(), true);
        }
    }
}
