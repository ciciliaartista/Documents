/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         22/07/2014 Criacao inicial
 */

package uol.taipei.tests.integration;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;

import org.json.JSONObject;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import uol.taipei.request.UsefulRequest;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.LoginCookie;
import uol.taipei.tests.rating.ApiRating;
import uol.taipei.tests.util.JsonUtil;

public class ApiRatingTest extends AbstractTest
{
    private ApiRating apiRating = null;
    private UsefulRequest login = null;
    private JSONObject media = null;

    @BeforeClass
    public void init() throws Exception
    {
        setUp(ENVIRONMENT);

        apiRating = new ApiRating();
        login = new LoginCookie(envConfig().getUser(), envConfig().getPass());
        media = JsonUtil.mediaNoRestrict("V");
    }

    @AfterClass
    public void finish()
    {
        login = null;
        media = null;
        apiRating = null;
    }

    @Test
    public void noLoggedAdd()
    {
        try
        {
            assertNotNull(apiRating.noLoggedAdd(media));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void loggedAdd()
    {
        try
        {
            assertNotNull(apiRating.loggedAdd(login, media));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }
}
