/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         02/09/2014 Criacao inicial
 */

package uol.taipei.tests.integration;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import uol.taipei.request.FacileRequest;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.gibraltar.ApiPublishGibraltar;
import uol.taipei.tests.util.JsonUtil;
import uol.taipei.tests.util.RequestUtil;
import uol.taipei.webServiceClient.WSReturn;

@Test(groups = "publish_service")
public class ApiPublishGibraltarTest extends AbstractTest
{
    private ApiPublishGibraltar apiPublishGibraltar = null;
    private WSReturn wsprofile = null;
    private Long codProfileHash = null;
    private String mediaId = null;
    private FacileRequest request = null;

    @BeforeClass
    public void init() throws Exception
    {
        setUp(ENVIRONMENT);

        apiPublishGibraltar = new ApiPublishGibraltar();
        request = new FacileRequest();

        availability(request, "http://beta.mais.uol.com.br/probe");

        wsprofile = JsonUtil.profile(envConfig().getUser());
        codProfileHash = Long.valueOf(wsprofile.getObjResponse().getString("codProfileHash"));
        mediaId = RequestUtil.mediaId("V", codProfileHash);
    }

    @AfterClass
    public void finish()
    {
        try
        {
            updateContentStatus(Long.valueOf(mediaId), 10, 2);
        }
        catch (Exception e)
        {

        }

        wsprofile = null;
        codProfileHash = null;
        mediaId = null;
        request = null;
        apiPublishGibraltar = null;
    }

    @Test
    public void uploadVideo()
    {
        try
        {
            assertNotNull(apiPublishGibraltar.uploadVideo(codProfileHash));
        }
        catch (Exception e)
        {
            assertNotNull(e.getMessage(), null);
        }
    }

    @Test
    public void uploadPodcast()
    {
        try
        {
            assertNotNull(apiPublishGibraltar.uploadPodcast(codProfileHash));
        }
        catch (Exception e)
        {
            assertNotNull(e.getMessage(), null);
        }
    }

//    @Test
//    public void uploadErrIvalidProfile()
//    {
//        try
//        {
//            assertTrue(apiPublishGibraltar.uploadErrIvalidProfile());
//        }
//        catch (Exception e)
//        {
//        	assertFalse(e.getMessage(), true);
//        }
//    }

//    @Test
//    public void uploadErrNoProfile()
//    {
//        try
//        {
//            assertTrue(apiPublishGibraltar.uploadErrNoProfile());
//        }
//        catch (Exception e)
//        {
//        	assertFalse(e.getMessage(), true);
//        }
//    }

    @Test
    public void notPublishVideoNoAuth()
    {
        try
        {
            assertTrue(apiPublishGibraltar.notPublishVideoNoAuth(request, codProfileHash));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void notPublishAudioNoAuth()
    {
        try
        {
            assertTrue(apiPublishGibraltar.notPublishAudioNoAuth(request, codProfileHash));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void statusVideo()
    {
        try
        {
            assertNotNull(apiPublishGibraltar.statusVideo(codProfileHash, Long.valueOf(mediaId)));
        }
        catch (Exception e)
        {
            assertNotNull(e.getMessage(), null);
        }
    }

    @Test
    public void statusAudio()
    {
        try
        {
            assertNotNull(apiPublishGibraltar.statusAudio(codProfileHash));
        }
        catch (Exception e)
        {
            assertNotNull(e.getMessage(), null);
        }
    }

    @Test
    public void publishThumb()
    {
        try
        {
            assertNotNull(apiPublishGibraltar.publishThumb());
        }
        catch (Exception e)
        {
            assertNotNull(e.getMessage(), null);
        }
    }

    @Test
    public void statusErrInvalidOwner()
    {
        try
        {
            assertTrue(apiPublishGibraltar.statusErrInvalidOwner(codProfileHash, Long.valueOf(mediaId)));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void updateMediaErrInvalidOwner()
    {
        try
        {
            assertTrue(apiPublishGibraltar.updateMediaErrInvalidOwner(codProfileHash, Long.valueOf(mediaId)));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void updateMedia()
    {
        try
        {
            assertNotNull(apiPublishGibraltar.updateMedia(Long.valueOf(mediaId)));
        }
        catch (Exception e)
        {
            assertNotNull(e.getMessage(), null);
        }
    }
}
