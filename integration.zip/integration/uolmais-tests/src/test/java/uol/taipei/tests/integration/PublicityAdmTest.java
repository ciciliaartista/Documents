/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         03/09/2014 Criacao inicial
 */

package uol.taipei.tests.integration;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import uol.taipei.request.FacileRequest;
import uol.taipei.request.UsefulRequest;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.LogErrorTest;
import uol.taipei.tests.LoginCookie;
import uol.taipei.tests.LoginRadius;
import uol.taipei.tests.moderation.PublicityAdm;

public class PublicityAdmTest extends AbstractTest
{
    static final Logger logger = LoggerFactory.getLogger(PublicityAdmTest.class);

    private PublicityAdm publicityAdm = null;
    private LoginCookie login = null;
    private UsefulRequest loginR = null;
    private FacileRequest request = null;
    private Long idtTag = null;

    @BeforeClass
    public void init() throws Exception
    {
        setUp(ENVIRONMENT);

        publicityAdm = new PublicityAdm();
        loginR = new LoginRadius(envConfig().getUserRadius(), envConfig().getPassRadius());
        login = new LoginCookie(envConfig().getUser(), envConfig().getPass());

        request = new FacileRequest();

        availability(request, "http://videos.intranet.uol.com.br/probe");

        try
        {
            loginR.get("http://videos.intranet.uol.com.br/maisAdm/publicityAdm");
            idtTag = publicityAdm.getIdtTag(login, loginR);
        }
        catch (Exception e)
        {
            logger.error(e.getMessage());
            LogErrorTest.error(e);
        }
    }

    @AfterClass
    public void finish() throws Exception
    {
        login = null;
        loginR = null;
        request = null;
        idtTag = null;
        publicityAdm = null;
    }

    @Test(testName = "listDfp", groups = { "publicityAdm" })
    public void listDfp()
    {
        try
        {
            assertNotNull(publicityAdm.listDfp(loginR, login.getJsonProfile().getJSONObject("item").getString("codProfile")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "addDfp", groups = { "publicityAdm" })
    public void addDfp()
    {
        try
        {
            assertNotNull(publicityAdm.addDfp(loginR, login.getJsonProfile().getJSONObject("item").getString("codProfile")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "blacklistTagDfp", dependsOnMethods = { "addTagDfp" }, groups = { "publicityAdm" })
    public void blacklistTagDfp()
    {
        try
        {
            assertNotNull(publicityAdm.blacklistTagDfp(loginR));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "addTagDfp", groups = { "publicityAdm" })
    public void addTagDfp()
    {
        try
        {
            assertNotNull(publicityAdm.addTagDfp(loginR, idtTag));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "removeTagDfp", dependsOnMethods = { "addTagDfp", "blacklistTagDfp" }, groups = { "publicityAdm" })
    public void removeTagDfp()
    {
        try
        {
            assertNotNull(publicityAdm.removeTagDfp(loginR, idtTag));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }
}
