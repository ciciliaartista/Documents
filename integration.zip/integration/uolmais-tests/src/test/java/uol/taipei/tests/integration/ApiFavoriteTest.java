/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         11/06/2014 Criacao inicial
 */

package uol.taipei.tests.integration;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.json.JSONObject;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.LoginCookie;
import uol.taipei.tests.favorite.ApiFavorite;

public class ApiFavoriteTest extends AbstractTest
{
    private ApiFavorite apiFavorite = null;
    private LoginCookie login = null;
    private JSONObject media = null;
    private JSONObject mediaAdm = null;

    @BeforeClass
    public void init() throws Exception
    {
        setUp(ENVIRONMENT);

        apiFavorite = new ApiFavorite();
        login = new LoginCookie(envConfig().getUser(), envConfig().getPass());
        media = apiFavorite.mediaNotFavorited(login);
        mediaAdm = apiFavorite.mediaAdmNotFavorited(login);
    }

    @AfterClass
    public void finish()
    {
        login = null;
        media = null;
        mediaAdm = null;
        apiFavorite = null;
    }

    @Test(testName = "addErr", groups = { "CRUD Favorite Err" })
    public void addErr()
    {
        try
        {
            assertNotNull(apiFavorite.addErr(login));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "add", groups = { "CRUD Favorite" })
    public void add()
    {
        try
        {
            if (apiFavorite.isFavorited(login, mediaAdm.getLong("mediaId")))
            {
                mediaAdm = apiFavorite.mediaAdmNotFavorited(login);
            }

            assertNotNull(apiFavorite.add(login, mediaAdm));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "addPublicMedia", groups = { "CRUD Favorite" })
    public void addPublicMedia()
    {
        try
        {
            if (apiFavorite.isFavorited(login, media.getLong("mediaId")))
            {
                media = apiFavorite.mediaNotFavorited(login);
            }

            assertNotNull(apiFavorite.addPublicMedia(login, media));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "loggedList", dependsOnMethods = { "add" }, groups = { "CRUD Favorite" })
    public void loggedList()
    {
        try
        {
            assertNotNull(apiFavorite.loggedList(login));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "list", dependsOnMethods = { "addPublicMedia" }, groups = { "CRUD Favorite" })
    public void list()
    {
        try
        {
            assertNotNull(apiFavorite.list(login.getJsonProfile().getJSONObject("item").getString("codProfile")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "listWithCodProfileErr", groups = { "CRUD Favorite Err" })
    public void listWithCodProfileErr()
    {
        try
        {
            assertTrue(apiFavorite.listWithCodProfileErr());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "listWithCurrentPageErr", groups = { "CRUD Favorite Err" })
    public void listWithCurrentPageErr()
    {
        try
        {
            assertTrue(apiFavorite.listWithCurrentPageErr(login.getJsonProfile().getJSONObject("item")
                    .getString("codProfile")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "listWithItemsPerPageErr", groups = { "CRUD Favorite Err" })
    public void listWithItemsPerPageErr()
    {
        try
        {
            assertTrue(apiFavorite.listWithItemsPerPageErr(login.getJsonProfile().getJSONObject("item")
                    .getString("codProfile")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "listWithSortErr", groups = { "CRUD Favorite Err" })
    public void listWithSortErr()
    {
        try
        {
            assertTrue(apiFavorite
                    .listWithSortErr(login.getJsonProfile().getJSONObject("item").getString("codProfile")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "listWithTypesErr", groups = { "CRUD Favorite Err" })
    public void listWithTypesErr()
    {
        try
        {
            assertTrue(apiFavorite.listWithTypesErr(login.getJsonProfile().getJSONObject("item")
                    .getString("codProfile")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "updateErr", groups = { "CRUD Favorite Err" })
    public void updateErr()
    {
        try
        {
            assertNotNull(apiFavorite.updateErr(login, media));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "update", dependsOnMethods = { "addPublicMedia" }, groups = {"CRUD Favorite"})
    public void update()
    {
        try
        {
            if (!apiFavorite.isFavorited(login, media.getLong("mediaId")))
            {
                apiFavorite.addPublicMedia(login, media);
            }

            assertNotNull(apiFavorite.update(login, media));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "removeErr", groups = { "CRUD Favorite Err" })
    public void removeErr()
    {
        try
        {
            assertNotNull(apiFavorite.removeErr(login));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "remove", dependsOnMethods = { "add" }, groups = {"CRUD Favorite"})
    public void remove()
    {
        try
        {
            if (!apiFavorite.isFavorited(login, mediaAdm.getLong("mediaId")))
            {
                apiFavorite.add(login, mediaAdm);
            }

            assertNotNull(apiFavorite.remove(login, mediaAdm));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }
}
