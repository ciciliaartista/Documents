/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         10/06/2014 Criacao inicial
 */

package uol.taipei.tests.integration;

import static org.junit.Assert.*;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import uol.taipei.tests.player.ApiPlayer;
import uol.taipei.tests.util.RequestUtil;

@Test(groups = "player_api")
public class ApiPlayerTest
{
    private ApiPlayer apiPlayer = null;
    private String mediaId = null;

    @BeforeClass
    public void init() throws Exception
    {
        apiPlayer = new ApiPlayer();
        mediaId = RequestUtil.mediaIdPublic("V");
    }

    @AfterClass
    public void finish()
    {
        mediaId = null;
        apiPlayer = null;
    }

    @Test
    public void crossdomain()
    {
        try
        {
            assertTrue(apiPlayer.crossdomain());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void showVideo()
    {
        try
        {
            assertNotNull(apiPlayer.show(mediaId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void mediaView()
    {
        try
        {
            assertNotNull(apiPlayer.mediaView(mediaId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "showVideo", "mediaView", "media", "related", "notifyMediaView" })
    public void showAudio()
    {
        try
        {
            mediaId = RequestUtil.mediaIdPublic("P");
            assertNotNull(apiPlayer.show(mediaId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void media()
    {
        try
        {
            assertNotNull(apiPlayer.media(mediaId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void related()
    {
        try
        {
            assertNotNull(apiPlayer.related(mediaId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void notifyMediaView()
    {
        try
        {
            assertNotNull(apiPlayer.notifyMediaView(mediaId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }
}
