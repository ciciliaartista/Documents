/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         10/06/2014 Criacao inicial
 */

package uol.taipei.tests.integration;

import static org.junit.Assert.*;

import org.json.JSONObject;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.LogErrorTest;
import uol.taipei.tests.content.View;
import uol.taipei.tests.util.JsonUtil;

@Test(groups = "view")
public class ViewTest extends AbstractTest
{
    private View view = null;
    private JSONObject media = null;

    @BeforeClass
    public void init() throws Exception
    {
        view = new View();
        media = JsonUtil.mediaDecored(10, "V", "T", false, false, false, false, false);
    }

    @AfterClass
    public void finish()
    {
        media = null;
        view = null;
    }

    @Test
    public void viewErr()
    {
        try
        {
            assertTrue(view.viewErr());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void viewSubscriber()
    {
        try
        {
            assertTrue(view.viewSubscriber());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void types()
    {
        try
        {
            assertNotNull(view.types());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void viewShortVideo()
    {
        try
        {
            assertTrue(view.viewShort(media));
        }
        catch (Exception e)
        {
            LogErrorTest.error(e);
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "viewShortVideo" })
    public void viewLongVideo()
    {
        try
        {
            assertNotNull(view.viewLong(media.getString("codProfile"), media.getString("id")));
        }
        catch (Exception e)
        {
            LogErrorTest.error(e);
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "viewLongVideo" })
    public void viewShortAudio()
    {
        try
        {
            media = JsonUtil.mediaDecored(10, "P", "T", false, false, false, false, false);

            assertTrue(view.viewShort(media));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "viewShortAudio" })
    public void viewLongAudio()
    {
        try
        {
            assertNotNull(view.viewLong(media.getString("codProfile"), media.getString("id")));
        }
        catch (Exception e)
        {
            LogErrorTest.error(e);
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "viewLongAudio" })
    public void viewVideoHot()
    {
        try
        {
            media = JsonUtil.media(10, "V", "T", false, false, true, false, false);

            assertTrue(view.viewHot(media.getString("idt_media")));
        }
        catch (Exception e)
        {
            LogErrorTest.error(e);
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "viewVideoHot" })
    public void viewAudioHot()
    {
        try
        {
            media = JsonUtil.media(10, "P", "T", false, false, true, false, false);

            assertTrue(view.viewHot(media.getString("idt_media")));
        }
        catch (Exception e)
        {
            LogErrorTest.error(e);
            assertFalse(e.getMessage() + " - " + media, true);
        }
    }
}
