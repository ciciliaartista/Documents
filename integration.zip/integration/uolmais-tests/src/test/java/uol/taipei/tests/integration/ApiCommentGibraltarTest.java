/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         11/09/2014 Criacao inicial
 */

package uol.taipei.tests.integration;

import static org.junit.Assert.assertNotNull;

import org.json.JSONObject;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.gibraltar.ApiCommentGibraltar;
import uol.taipei.tests.util.JsonUtil;

public class ApiCommentGibraltarTest extends AbstractTest
{
    private ApiCommentGibraltar apiCommentGibraltar = null;
    private JSONObject media = null;

    @BeforeClass
    public void init() throws Exception
    {
        setUp(ENVIRONMENT);

        apiCommentGibraltar = new ApiCommentGibraltar();
        media = JsonUtil.mediaIdtSubject(false);
    }

    @AfterClass
    public void finish()
    {
        media = null;
        apiCommentGibraltar = null;
    }

    @Test
    public void topicLink()
    {
        try
        {
            Long idtMedia = Long.parseLong(JsonUtil.getParam(media, "idt_media").toString());
            assertNotNull(apiCommentGibraltar.topicLink(idtMedia));
        }
        catch (Exception e)
        {
            assertNotNull(e.getMessage(), null);
        }
    }

    //@Test
    public void topicLinkNoModeration()
    {
        try
        {
            assertNotNull(apiCommentGibraltar.topicLinkNoModeration());
        }
        catch (Exception e)
        {
            assertNotNull(e.getMessage(), null);
        }
    }
}
