package uol.taipei.tests.integration;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.IOException;

import org.apache.http.client.ClientProtocolException;
import org.json.JSONException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import uol.taipei.request.FacileRequest;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.content.ApiContentErr;

public class ApiContentErrTest extends AbstractTest
{
    private ApiContentErr apiContentErr = null;
    private FacileRequest request = null;

    @BeforeClass
    public void init() throws ClientProtocolException, IllegalStateException, IOException, JSONException
    {
        setUp(ENVIRONMENT);

        apiContentErr = new ApiContentErr();
        request = new FacileRequest();
    }

    @AfterClass
    public void finish()
    {
        request = null;
        apiContentErr = null;
    }

    @Test
    public void listWithAdultFilterParam()
    {
        try
        {
            assertTrue(apiContentErr.listWithAdultFilterParam(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void listWithCodProfileParam()
    {
        try
        {
            assertTrue(apiContentErr.listWithCodProfileParam(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void listWithCurrentPageParam()
    {
        try
        {
            assertTrue(apiContentErr.listWithCurrentPageParam(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void listWithEdFilterParam()
    {
        try
        {
            assertTrue(apiContentErr.listWithEdFilterParam(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void listWithEditorParam()
    {
        try
        {
            assertTrue(apiContentErr.listWithEditorParam(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void listWithFormatParam()
    {
        try
        {
            assertTrue(apiContentErr.listWithFormatParam(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void listWithItemsPerPageParam()
    {
        try
        {
            assertTrue(apiContentErr.listWithItemsPerPageParam(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void listWithRelatedIdParam()
    {
        try
        {
            assertTrue(apiContentErr.listWithRelatedIdParam(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void listWithRelatedListParam()
    {
        try
        {
            assertTrue(apiContentErr.listWithRelatedListParam(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void listWithTimeParam()
    {
        try
        {
            assertTrue(apiContentErr.listWithTimeParam(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void detail()
    {
        try
        {
            assertTrue(apiContentErr.detail(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void detailWithoutParam()
    {
        try
        {
            assertTrue(apiContentErr.detailWithoutParam(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void detailWithoutMediaId()
    {
        try
        {
            assertTrue(apiContentErr.detailWithoutMediaId(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void recommendedWithCurrentPageParam()
    {
        try
        {
            assertTrue(apiContentErr.recommendedWithCurrentPageParam(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void recommendedWithItemsPerPageParam()
    {
        try
        {
            assertTrue(apiContentErr.recommendedWithItemsPerPageParam(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }
}
