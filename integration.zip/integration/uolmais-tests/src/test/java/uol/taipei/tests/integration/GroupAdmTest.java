/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         03/09/2014 Criacao inicial
 */

package uol.taipei.tests.integration;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;

import java.util.HashMap;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import uol.taipei.request.FacileRequest;
import uol.taipei.request.UsefulRequest;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.LoginCookie;
import uol.taipei.tests.LoginRadius;
import uol.taipei.tests.moderation.GroupAdm;
//import uol.taipei.tests.util.TestUtil;

public class GroupAdmTest extends AbstractTest
{
    private GroupAdm groupAdm = null;
    private LoginCookie login = null;
    private UsefulRequest loginR = null;
    private FacileRequest request = null;
    private String groupName = null;
    private HashMap<String, String> group = null;

    @BeforeClass
    public void init() throws Exception
    {
        setUp(ENVIRONMENT);

        groupAdm = new GroupAdm();
        loginR = new LoginRadius(envConfig().getUserRadius(), envConfig().getPassRadius());
        login = new LoginCookie(envConfig().getUser(), envConfig().getPass());

        // groupName = TestUtil.randomString(5);

        request = new FacileRequest();

        availability(request, "http://videos.intranet.uol.com.br/probe");

        try
        {
            loginR.get("http://videos.intranet.uol.com.br/maisAdm/mediaAdmEditor");
        }
        catch (Exception e)
        {

        }

        group = groupAdm.getGroupMap(loginR);
    }

    @AfterClass
    public void finish() throws Exception
    {
        login = null;
        loginR = null;
        request = null;
        groupName = null;
        group = null;
        groupAdm = null;
    }

    // @Test(testName = "create", groups = { "groupAdm" })
    public void create()
    {
        try
        {
            assertNotNull(groupAdm.create(loginR, groupName));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "list", groups = { "groupAdm" })
    public void list()
    {
        try
        {
            assertNotNull(groupAdm.list(loginR));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    // @Test(testName = "remove", dependsOnMethods = { "create", "list", "usersFromGroup" }, groups = { "groupAdm" })
    public void remove()
    {
        try
        {
            assertNotNull(groupAdm.remove(loginR, groupName));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "groupsFromUser", groups = { "groupAdm" })
    public void groupsFromUser()
    {
        try
        {
            assertNotNull(groupAdm.groupsFromUser(loginR, login.getJsonProfile().getJSONObject("item").getString("codProfile")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "usersFromGroup", groups = { "groupAdm" })
    public void usersFromGroup()
    {
        try
        {
            assertNotNull(groupAdm.usersFromGroup(loginR, Integer.parseInt(group.get("idtEditorType"))));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    //@Test(testName = "addUser", groups = { "groupAdm" })
    public void addUser()
    {
        try
        {
            assertNotNull(groupAdm.addUser(loginR, Integer.parseInt(group.get("idtEditorType")),
                login.getJsonProfile().getJSONObject("item").getString("codProfile")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    //@Test(testName = "removeUser", dependsOnMethods = { "addUser", "groupsFromUser", "groupsFromUser" }, groups = { "groupAdm" })
    public void removeUser()
    {
        try
        {
            assertNotNull(groupAdm.removeUser(loginR, Integer.parseInt(group.get("idtEditorType")),
                login.getJsonProfile().getJSONObject("item").getString("codProfile")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }
}
