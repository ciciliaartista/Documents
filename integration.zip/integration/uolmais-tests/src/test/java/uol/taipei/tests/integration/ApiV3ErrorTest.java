/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         09/08/2016 Criacao inicial
 */

package uol.taipei.tests.integration;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.drakkar.ApiV3Error;

public class ApiV3ErrorTest extends AbstractTest
{
    private ApiV3Error apiV3Err = null;

    @BeforeClass
    public void init() throws Exception
    {
        setUp(ENVIRONMENT);

        apiV3Err = new ApiV3Error(false, false);
    }

    @AfterClass
    public void finish()
    {
        apiV3Err = null;
    }

    @Test
    public void detailInvalidParam()
    {
        try
        {
            assertTrue(apiV3Err.detailInvalidParam());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void detailNoParam()
    {
        try
        {
            assertTrue(apiV3Err.detailNoParam());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void detailNotFound()
    {
        try
        {
            assertTrue(apiV3Err.detailNotFound());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void detailQsInvalidParam()
    {
        try
        {
            assertTrue(apiV3Err.detailQsInvalidParam());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void detailQsNoParam()
    {
        try
        {
            assertTrue(apiV3Err.detailQsNoParam());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void detailQsNotFound()
    {
        try
        {
            assertTrue(apiV3Err.detailQsNotFound());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void formatsInvalidParam()
    {
        try
        {
            assertTrue(apiV3Err.formatsInvalidParam());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void formatsNoParam()
    {
        try
        {
            assertTrue(apiV3Err.formatsNoParam());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void formatsNotFound()
    {
        try
        {
            assertTrue(apiV3Err.formatsNotFound());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void formatsQsInvalidParam()
    {
        try
        {
            assertTrue(apiV3Err.formatsQsInvalidParam());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void formatsQsNoParam()
    {
        try
        {
            assertTrue(apiV3Err.formatsQsNoParam());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void formatsQsNotFound()
    {
        try
        {
            assertTrue(apiV3Err.formatsQsNotFound());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void listAdultInvalidParam()
    {
        try
        {
            assertTrue(apiV3Err.listAdultInvalidParam());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void listAdultNoParam()
    {
        try
        {
            assertTrue(apiV3Err.listAdultNoParam());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void listCodProfileNoParam()
    {
        try
        {
            assertTrue(apiV3Err.listCodProfileNoParam());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void listCodProfileNotFound()
    {
        try
        {
            assertTrue(apiV3Err.listCodProfileNotFound());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void listDateInvalidParam()
    {
        try
        {
            assertTrue(apiV3Err.listDateInvalidParam());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void listDateNoParam()
    {
        try
        {
            assertTrue(apiV3Err.listDateNoParam());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void listEditorialStatusInvalidParam()
    {
        try
        {
            assertTrue(apiV3Err.listEditorialStatusInvalidParam());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void listEditorialStatusNoParam()
    {
        try
        {
            assertTrue(apiV3Err.listEditorialStatusNoParam());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void listFollowableInvalidParam()
    {
        try
        {
            assertTrue(apiV3Err.listFollowableInvalidParam());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void listFollowableNoParam()
    {
        try
        {
            assertTrue(apiV3Err.listFollowableNoParam());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void listFormatInvalidParam()
    {
        try
        {
            assertTrue(apiV3Err.listFormatInvalidParam());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void listFormatNoParam()
    {
        try
        {
            assertTrue(apiV3Err.listFormatNoParam());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void listCurrentPageInvalidParam()
    {
        try
        {
            assertTrue(apiV3Err.listCurrentPageInvalidParam());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void listCurrentPageNoParam()
    {
        try
        {
            assertTrue(apiV3Err.listCurrentPageNoParam());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void listItemsPerPageInvalidParam()
    {
        try
        {
            assertTrue(apiV3Err.listItemsPerPageInvalidParam());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void listItemsPerPageNoParam()
    {
        try
        {
            assertTrue(apiV3Err.listItemsPerPageNoParam());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void listPublisherTypeInvalidParam()
    {
        try
        {
            assertTrue(apiV3Err.listPublisherTypeInvalidParam());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void listPublisherTypeNoParam()
    {
        try
        {
            assertTrue(apiV3Err.listPublisherTypeNoParam());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void listRelatedInvalidParam()
    {
        try
        {
            assertTrue(apiV3Err.listRelatedInvalidParam());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void listRelatedNoParam()
    {
        try
        {
            assertTrue(apiV3Err.listRelatedNoParam());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void listSortInvalidParam()
    {
        try
        {
            assertTrue(apiV3Err.listSortInvalidParam());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void listSortNoParam()
    {
        try
        {
            assertTrue(apiV3Err.listSortNoParam());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void listSubscriberInvalidParam()
    {
        try
        {
            assertTrue(apiV3Err.listSubscriberInvalidParam());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void listSubscriberNoParam()
    {
        try
        {
            assertTrue(apiV3Err.listSubscriberNoParam());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void listTagIdsInvalidParam()
    {
        try
        {
            assertTrue(apiV3Err.listTagIdsInvalidParam());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void listTagIdsNoParam()
    {
        try
        {
            assertTrue(apiV3Err.listTagIdsNoParam());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void listTagNamesNotFound()
    {
        try
        {
            assertTrue(apiV3Err.listTagNamesNotFound());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void listTagNamesNoParam()
    {
        try
        {
            assertTrue(apiV3Err.listTagNamesNoParam());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void listTagServiceNotFound()
    {
        try
        {
            assertTrue(apiV3Err.listTagServiceNotFound());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void listTagServiceNoParam()
    {
        try
        {
            assertTrue(apiV3Err.listTagServiceNoParam());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void listTypesInvalidParam()
    {
        try
        {
            assertTrue(apiV3Err.listTypesInvalidParam());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void listTypesNoParam()
    {
        try
        {
            assertTrue(apiV3Err.listTypesNoParam());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void listMediaRelatedIdNoParam()
    {
        try
        {
            assertTrue(apiV3Err.listMediaRelatedIdNoParam());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void listModerationGroupNoParam()
    {
        try
        {
            assertTrue(apiV3Err.listModerationGroupNoParam());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void listDurationNoParam()
    {
        try
        {
            assertTrue(apiV3Err.listDurationNoParam());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void listPeriodStartNoParam()
    {
        try
        {
            assertTrue(apiV3Err.listPeriodStartNoParam());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void listPeriodEndNoParam()
    {
        try
        {
            assertTrue(apiV3Err.listPeriodEndNoParam());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void listEditorGroupNoParam()
    {
        try
        {
            assertTrue(apiV3Err.listEditorGroupNoParam());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void listQryTagNoParam()
    {
        try
        {
            assertTrue(apiV3Err.listQryTagNoParam());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void listPublishIntervalNoParam()
    {
        try
        {
            assertTrue(apiV3Err.listPublishIntervalNoParam());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void listQryTagSrvNoParam()
    {
        try
        {
            assertTrue(apiV3Err.listQryTagSrvNoParam());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }
}
