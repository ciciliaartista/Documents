package uol.taipei.tests.integration;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;

import org.json.JSONObject;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.task.Task;
import uol.taipei.tests.util.JsonUtil;
import uol.taipei.tests.util.RequestUtil;
import uol.taipei.util.hash.HashCode;

public class TaskTest extends AbstractTest
{
    private Task taskInit = null;
    private String mediaId = null;

    @BeforeClass
    public void init() throws Exception
    {
        setUp(ENVIRONMENT);

        taskInit = new Task();
    }

    @AfterClass
    public void finish()
    {
        mediaId = null;
    }
/*
    @Test
    public void getContent()
    {
        try
        {
            mediaId = RequestUtil.mediaIdPublic("V");
            assertNotNull(taskInit.getContent(mediaId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void getContentBySubject()
    {
        try
        {
            JSONObject media = JsonUtil.mediaIdtSubject(false);
            Long idtSubject = Long.parseLong(JsonUtil.getParam(media, "idt_subject").toString());

            assertNotNull(taskInit.getContentBySubject(idtSubject));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void getContentNoCache()
    {
        try
        {
            mediaId = RequestUtil.mediaIdPublic("V");
            assertNotNull(taskInit.getContentNoCache(mediaId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void getJobEnconding()
    {
        try
        {
            // assertNotNull(taskInit.getMediaList());
        }
        catch (Exception e)
        {
            // assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void getMediaList()
    {
        try
        {
            assertNotNull(taskInit.getMediaList());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void getMediasByDescription()
    {
        try
        {
            assertNotNull(taskInit.getMediasByDescription());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void getPublicMedias()
    {
        try
        {
            assertNotNull(taskInit.getPublicMedias());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void getMediasResumed()
    {
        try
        {
            assertNotNull(taskInit.getMediasResumed());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void getDocumentList()
    {
        try
        {
            assertNotNull(taskInit.getDocumentList(HashCode.encode(JsonUtil.codProfile())));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void getMediasModeration()
    {
        try
        {
            assertNotNull(taskInit.getMediasModeration());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void getMediasFeatured()
    {
        try
        {
            assertNotNull(taskInit.getMediasFeatured());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void getMediasFavoriteByProfile()
    {
        try
        {
            assertNotNull(taskInit.getMediasFavoriteByProfile(HashCode.encode(JsonUtil.codProfile())));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void getPublicMediasResumed()
    {
        try
        {
            assertNotNull(taskInit.getPublicMediasResumed(HashCode.encode(JsonUtil.codProfile())));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }*/
}
