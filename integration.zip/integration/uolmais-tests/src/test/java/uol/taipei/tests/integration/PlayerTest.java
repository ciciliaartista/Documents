/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         08/06/2015 Criacao inicial
 */

package uol.taipei.tests.integration;

import static org.junit.Assert.*;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import uol.taipei.tests.player.Player;
import uol.taipei.tests.util.RequestUtil;

@Test(groups = "player")
public class PlayerTest
{
    private Player player = null;
    private String mediaId = null;

    @BeforeClass
    public void init() throws Exception
    {
        player = new Player();
        mediaId = RequestUtil.mediaIdPublic("V");
    }

    @AfterClass
    public void finish()
    {
        mediaId = null;
        player = null;
    }

    @Test
    public void playerhtml5()
    {
        try
        {
            assertTrue(player.playerhtml5(Long.parseLong(mediaId)));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void player()
    {
        try
        {
            assertTrue(player.player(Long.parseLong(mediaId), 0));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void playerV5()
    {
        try
        {
            assertTrue(player.playerV5(Long.parseLong(mediaId), 0));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void playerThumb()
    {
        try
        {
            assertTrue(player.playerThumb(Long.parseLong(mediaId), 0));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void playerBand()
    {
        try
        {
            assertTrue(player.playerBand(Long.parseLong(mediaId)));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void embed()
    {
        try
        {
            assertTrue(player.embed(Long.parseLong(mediaId)));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void embedV2()
    {
        try
        {
            assertTrue(player.embedV2(Long.parseLong(mediaId)));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void embedReduzido()
    {
        try
        {
            assertTrue(player.embedReduzido(Long.parseLong(mediaId)));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void embedReduzidoV2()
    {
        try
        {
            assertTrue(player.embedReduzidoV2(Long.parseLong(mediaId)));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void embedV2ssl()
    {
        try
        {
            assertTrue(player.embedV2ssl(Long.parseLong(mediaId)));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "embedV2ssl", "embedReduzidoV2", "embedReduzido", "embedV2", "embed",
                              "playerBand", "playerThumb", "playerV5", "player", "playerhtml5" })
    public void playerAudio()
    {
        try
        {
            mediaId = RequestUtil.mediaIdPublic("P");
            assertTrue(player.playerAudio());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "playerAudio" })
    public void embedAudio2()
    {
        try
        {
            assertTrue(player.embedAudio2(mediaId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "playerAudio" })
    public void embedAudio280()
    {
        try
        {
            assertTrue(player.embedAudio280(mediaId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "playerAudio" })
    public void playerhtml5Audio()
    {
        try
        {
            assertTrue(player.playerhtml5Audio(mediaId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }
}
