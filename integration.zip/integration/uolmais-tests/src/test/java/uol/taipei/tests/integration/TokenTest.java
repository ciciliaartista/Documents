/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         30/06/2014 Criacao inicial
 */

package uol.taipei.tests.integration;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;

import org.json.JSONObject;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.LoginCookie;
import uol.taipei.tests.token.Token;

public class TokenTest extends AbstractTest
{
    private Token token = null;
    private LoginCookie login = null;
    private JSONObject uploadToken = null;

    @BeforeClass
    public void init() throws Exception
    {
        setUp(ENVIRONMENT);

        token = new Token();
        login = new LoginCookie(envConfig().getUser(), envConfig().getPass());
        uploadToken = token.create(login);
    }

    @AfterClass
    public void finish()
    {
        login = null;
        uploadToken = null;
        token = null;
    }

    @Test
    public void create()
    {
        try
        {
            if (uploadToken == null)
            {
                uploadToken = token.create(login);
            }

            assertNotNull(uploadToken);
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void refresh()
    {
        try
        {
            assertNotNull(token.refresh(login, uploadToken.getString("token")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }
}
