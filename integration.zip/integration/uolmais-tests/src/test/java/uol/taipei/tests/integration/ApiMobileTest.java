/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         26/05/2014 Criacao inicial
 */

package uol.taipei.tests.integration;

import static org.junit.Assert.*;

import org.json.JSONObject;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.LoginCookie;
import uol.taipei.tests.mobile.ApiMobile;
import uol.taipei.tests.util.RequestUtil;

public class ApiMobileTest extends AbstractTest
{
    private ApiMobile apiMobile = null;
    private LoginCookie login = null;
    private JSONObject profile = null;
    private String mediaId = null;

    @BeforeClass
    public void init() throws Exception
    {
        setUp(ENVIRONMENT);

        apiMobile = new ApiMobile();
        login = new LoginCookie(envConfig().getUser(), envConfig().getPass());
        profile = login.getJsonProfile();
        mediaId = RequestUtil.mediaIdPublic("V");
    }

    @AfterClass
    public void finish()
    {
        login = null;
        profile = null;
        mediaId = null;
        apiMobile = null;
    }

    @Test
    public void profile()
    {
        try
        {
            assertNotNull(apiMobile.profile(login));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void profileCodProfile()
    {
        try
        {
            assertNotNull(apiMobile.profile(profile.getJSONObject("item").getString("codProfile")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void profileCodProfileQS()
    {
        try
        {
            assertNotNull(apiMobile.profileQS(profile.getJSONObject("item").getString("codProfile")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void medias()
    {
        try
        {
            assertNotNull(apiMobile.medias(login));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void mediasProfile()
    {
        try
        {
            assertNotNull(apiMobile.medias(profile));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void mediasLogginProfile()
    {
        try
        {
            assertNotNull(apiMobile.medias(login, profile));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void media()
    {
        try
        {
            assertNotNull(apiMobile.media(mediaId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void mediaQS()
    {
        try
        {
            assertNotNull(apiMobile.mediaQS(mediaId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }
}
