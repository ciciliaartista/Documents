/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         02/08/2016 Criacao inicial
 */

package uol.taipei.tests.integration;

import static org.junit.Assert.*;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import uol.taipei.request.FacileRequest;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.drakkar.ApiV3Player;
import uol.taipei.tests.util.RequestUtil;

@Test(groups = "api_v3_player_ssl")
public class ApiV3PlayerSslTest extends AbstractTest
{
    private ApiV3Player apiV3Player = null;
    private FacileRequest request = null;
    private String mediaId = null;

    @BeforeClass
    public void init() throws Exception
    {
        setUp(ENVIRONMENT);

        apiV3Player = new ApiV3Player(true);
        mediaId = RequestUtil.mediaIdPublic("V");
        request = new FacileRequest();

        request.configureSSL();
    }

    @AfterClass
    public void finish()
    {
        mediaId = null;
        apiV3Player = null;
        request = null;
    }

    @Test
    public void playerVideo()
    {
        try
        {
            assertNotNull(apiV3Player.player(mediaId, request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void videoViewNotify()
    {
        try
        {
            assertNotNull(apiV3Player.viewNotify(mediaId, request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "playerVideo", "videoViewNotify" })
    public void playerAudio()
    {
        try
        {
            mediaId = RequestUtil.mediaIdPublic("P");
            assertNotNull(apiV3Player.player(mediaId, request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "playerAudio" })
    public void audioViewNotify()
    {
        try
        {
            assertNotNull(apiV3Player.viewNotify(mediaId, request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }
}
