/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         29/07/2016 Criacao inicial
 */

package uol.taipei.tests.integration;

import static org.junit.Assert.*;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import uol.taipei.request.FacileRequest;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.croupier.Croupier;
import uol.taipei.tests.util.RequestUtil;

public class CroupierSslTest extends AbstractTest
{
    private Croupier croupier = null;

    private FacileRequest request = null;

    private String mediaId = null;

    @BeforeClass
    public void init() throws Exception
    {
        setUp(ENVIRONMENT);

        croupier = new Croupier(true, false);
        request = new FacileRequest();

        availability(request, "https://croupier.mais.uol.com.br/probe");
    }

    @AfterClass
    public void finish()
    {
        mediaId = null;
        request = null;
        croupier = null;
    }

    @Test
    public void video()
    {
        try
        {
            mediaId = RequestUtil.mediaIdPublic("V");
            assertNotNull(croupier.video(mediaId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void showVideo()
    {
        try
        {
            mediaId = RequestUtil.mediaIdPublic("V");
            assertNotNull(croupier.show(mediaId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void showAudio()
    {
        try
        {
            mediaId = RequestUtil.mediaIdPublic("P");
            assertNotNull(croupier.show(mediaId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void v3mediaVideo()
    {
        try
        {
            mediaId = RequestUtil.mediaIdPublic("V");
            assertNotNull(croupier.v3media(mediaId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void v3mediaAudio()
    {
        try
        {
            mediaId = RequestUtil.mediaIdPublic("P");
            assertNotNull(croupier.v3media(mediaId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }
}
