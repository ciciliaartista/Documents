/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         26/06/2015 Criacao inicial
 */

package uol.taipei.tests.integration;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.json.JSONObject;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.ssl.PlayerSsl;
import uol.taipei.tests.util.JsonUtil;
import uol.taipei.tests.util.RequestUtil;

public class PlayerSslTest extends AbstractTest
{
    private PlayerSsl playerSsl = null;
    private JSONObject media = null;
    private String mediaId = null;

    @BeforeClass
    public void init() throws Exception
    {
        setUp(ENVIRONMENT);

        playerSsl = new PlayerSsl();
        media = JsonUtil.mediaNoRestrict("V");
        mediaId = RequestUtil.mediaIdPublic("P");
    }

    @AfterClass
    public void finish()
    {
        media = null;
        mediaId = null;
        playerSsl = null;
    }

    @Test
    public void playerhtml5()
    {
        try
        {
            assertTrue(playerSsl.playerhtml5(media.getLong("mediaId")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void player()
    {
        try
        {
            assertTrue(playerSsl.player(media.getLong("mediaId"), media.getInt("thumbVersion")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void playerV3()
    {
        try
        {
            assertTrue(playerSsl.playerV3(media.getLong("mediaId"), media.getInt("thumbVersion")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void playerV5()
    {
        try
        {
            assertTrue(playerSsl.playerV5(media.getLong("mediaId"), media.getInt("thumbVersion")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void playerThumb()
    {
        try
        {
            assertTrue(playerSsl.playerThumb(media.getLong("mediaId"), media.getInt("thumbVersion")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void playerhtml5Audio()
    {
        try
        {
            assertTrue(playerSsl.playerhtml5Audio(mediaId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void playerAudio()
    {
        try
        {
            assertTrue(playerSsl.playerAudio());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void embedAudio2()
    {
        try
        {
            assertTrue(playerSsl.embedAudio2(mediaId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void embedAudio280()
    {
        try
        {
            assertTrue(playerSsl.embedAudio280(mediaId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }
}
