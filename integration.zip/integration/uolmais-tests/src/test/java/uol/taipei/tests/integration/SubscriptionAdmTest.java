/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         25/06/2014 Criacao inicial
 */

package uol.taipei.tests.integration;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import uol.taipei.request.UsefulRequest;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.LoginCookie;
import uol.taipei.tests.LoginRadius;
import uol.taipei.tests.moderation.SubscriptionAdm;
import uol.taipei.tests.subscription.ApiSubscription;

@Test(groups = "subscription_adm")
public class SubscriptionAdmTest extends AbstractTest
{
    private SubscriptionAdm subscriptionAdm = null;
    private ApiSubscription apiSubscription = null;
    private UsefulRequest loginR = null;
    private LoginCookie login = null;

    @BeforeClass
    public void init() throws Exception
    {
        setUp(ENVIRONMENT);

        subscriptionAdm = new SubscriptionAdm();
        apiSubscription = new ApiSubscription();
        loginR = new LoginRadius(envConfig().getUserRadius(), envConfig().getPassRadius());

        try
        {
            login = new LoginCookie(envConfig().getUser(), envConfig().getPass());
            apiSubscription.subscribeByProfile(login);

            loginR.get("http://videos.intranet.uol.com.br/maisAdm/subscriptionAdm/home");
        }
        catch (Exception e)
        {

        }
    }

    @AfterClass
    public void finish()
    {
        loginR = null;
        login = null;
        subscriptionAdm = null;
        apiSubscription = null;
    }

    @Test
    public void saveError()
    {
        try
        {
            assertNotNull(subscriptionAdm.saveError(loginR));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void saveTagService()
    {
        try
        {
            assertNotNull(subscriptionAdm.saveTagService(loginR));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void saveTag()
    {
        try
        {
            assertNotNull(subscriptionAdm.saveTag(loginR));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void saveEditorType()
    {
        try
        {
            assertNotNull(subscriptionAdm.saveEditorType(loginR));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void saveCodProfileError()
    {
        try
        {
            assertNotNull(subscriptionAdm.saveCodProfileError(loginR));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void list()
    {
        try
        {
            assertNotNull(subscriptionAdm.list(loginR));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void previewUser()
    {
        try
        {
            assertNotNull(subscriptionAdm.previewUser(loginR));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void previewTag()
    {
        try
        {
            assertNotNull(subscriptionAdm.previewTag(loginR));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void remove()
    {
        try
        {
            assertNotNull(subscriptionAdm.remove(loginR));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }
}
