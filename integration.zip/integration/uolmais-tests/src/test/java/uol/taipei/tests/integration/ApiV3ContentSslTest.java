/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         29/07/2016 Criacao inicial
 */

package uol.taipei.tests.integration;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertNotNull;

import java.util.HashMap;

import org.json.JSONObject;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.LoginCookie;
import uol.taipei.tests.drakkar.ApiV3Content;
import uol.taipei.tests.util.JsonUtil;

@Test(groups = "api_v3_content_ssl")
public class ApiV3ContentSslTest extends AbstractTest
{
    private ApiV3Content apiV3Content = null;

    private LoginCookie login = null;

    private JSONObject media = null;

    private HashMap<String, JSONObject> mapMedias = null;

    @BeforeClass
    public void init() throws Exception
    {
        setUp(ENVIRONMENT);

        apiV3Content = new ApiV3Content(true, false);
        login = new LoginCookie(envConfig().getUser(), envConfig().getPass());
        mapMedias = new HashMap<String, JSONObject>();
    }

    @AfterClass
    public void finish()
    {
        login = null;
        mapMedias = null;
        media = null;
        apiV3Content = null;
    }

    @Test
    public void crossdomain()
    {
        try
        {
            assertTrue(apiV3Content.crossdomain());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void list()
    {
        try
        {
            assertNotNull(apiV3Content.list());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void detailVideo()
    {
        try
        {
            media = JsonUtil.mediaDecored(10, "V", "T", false, false, false, false, false);
            mapMedias.put("V", media);
            assertNotNull(apiV3Content.detailQs(mapMedias.get("V").getString("idt_media"), "V"));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "detailVideo" })
    public void detailVideoByHash()
    {
        try
        {
            assertNotNull(apiV3Content.detailQs(mapMedias.get("V").getString("id"), "V"));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void detailAudio()
    {
        try
        {
            media = JsonUtil.mediaDecored(10, "P", "T", false, false, false, false, false);
            mapMedias.put("P", media);
            assertNotNull(apiV3Content.detailQs(mapMedias.get("P").getString("idt_media"), "P"));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "detailAudio" })
    public void detailAudioByHash()
    {
        try
        {
            assertNotNull(apiV3Content.detailQs(mapMedias.get("P").getString("id"), "P"));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "detailVideo" })
    public void detailVideoRest()
    {
        try
        {
            assertNotNull(apiV3Content.detail(mapMedias.get("V").getString("idt_media"), "V"));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "detailVideo" })
    public void detailVideoByHashRest()
    {
        try
        {
            assertNotNull(apiV3Content.detail(mapMedias.get("V").getString("id"), "V"));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "detailAudio" })
    public void detailAudioRest()
    {
        try
        {
            assertNotNull(apiV3Content.detail(mapMedias.get("P").getString("idt_media"), "P"));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "detailAudio" })
    public void detailAudioByHashRest()
    {
        try
        {
            assertNotNull(apiV3Content.detail(mapMedias.get("P").getString("id"), "P"));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "detailVideo" })
    public void apacheCache()
    {
        try
        {
            assertTrue(apiV3Content.apacheCache(mapMedias.get("V").getString("idt_media")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "apacheCache" })
    public void apacheCacheQs()
    {
        try
        {
            assertTrue(apiV3Content.apacheCacheQs(mapMedias.get("V").getString("idt_media")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "apacheCacheQs" })
    public void apacheCacheByHash()
    {
        try
        {
            assertTrue(apiV3Content.apacheCacheQs(mapMedias.get("V").getString("id")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "apacheCacheByHash" })
    public void apacheCacheByHashQs()
    {
        try
        {
            assertTrue(apiV3Content.apacheCacheQs(mapMedias.get("V").getString("id")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "detailVideo" })
    public void related()
    {
        try
        {
            assertNotNull(apiV3Content.related(mapMedias.get("V").getString("idt_media")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void codProfile()
    {
        try
        {
            assertNotNull(
                apiV3Content.codProfile(login.getJsonProfile().getJSONObject("item").getString("codProfile")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void itemsPerPage()
    {
        try
        {
            assertNotNull(apiV3Content.itemsPerPage(4));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void currentPage()
    {
        try
        {
            assertNotNull(apiV3Content.currentPage(2));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void types()
    {
        try
        {
            assertNotNull(apiV3Content.types());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void publisherType()
    {
        try
        {
            assertNotNull(apiV3Content.publisherType());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void adult()
    {
        try
        {
            assertNotNull(apiV3Content.adult());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void subscriber()
    {
        try
        {
            assertNotNull(apiV3Content.subscriber());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void format()
    {
        try
        {
            assertNotNull(apiV3Content.format());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void tagNames()
    {
        try
        {
            assertNotNull(apiV3Content.tagNames("teste"));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void tagIds()
    {
        try
        {
            assertNotNull(apiV3Content.tagIds("1", false));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void tagService()
    {
        try
        {
            assertNotNull(apiV3Content.tagService("1010", false));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void sort()
    {
        try
        {
            assertNotNull(apiV3Content.sort());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void editorialStatus()
    {
        try
        {
            assertNotNull(apiV3Content.editorialStatus());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void formats()
    {
        try
        {
            assertNotNull(apiV3Content.formats(mapMedias.get("V").getString("idt_media")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void paging()
    {
        try
        {
            assertNotNull(apiV3Content.paging());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void followable()
    {
        try
        {
            assertNotNull(apiV3Content.followable());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void date()
    {
        try
        {
            assertNotNull(apiV3Content.date());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }
}
