/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         09/03/2015 Criacao inicial
 */

package uol.taipei.tests.integration;

import static org.junit.Assert.*;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import uol.taipei.request.FacileRequest;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.moderation.MediaProxy;

public class MediaProxyTest extends AbstractTest
{
    private MediaProxy mediaProxy = null;
    private FacileRequest request = null;

    @BeforeClass
    public void init() throws Exception
    {
        setUp(ENVIRONMENT);

        mediaProxy = new MediaProxy();
        request = new FacileRequest();
    }

    @AfterClass
    public void finish()
    {
        request = null;
        mediaProxy = null;
    }

    @Test
    public void restrictNobodyViewVideo()
    {
        try
        {
            assertTrue(mediaProxy.restrictNobodyViewVideo(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void restrictRemovedStatusVideo()
    {
        try
        {
            assertTrue(mediaProxy.restrictRemovedStatusVideo(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void restrictDraftVideo()
    {
        try
        {
            assertTrue(mediaProxy.restrictDraftVideo(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void restrictSubscriberVideo()
    {
        try
        {
            assertTrue(mediaProxy.restrictSubscriberVideo(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void restrictProductVideo()
    {
        try
        {
            assertTrue(mediaProxy.restrictProductVideo(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void restrictNobodyViewAudio()
    {
        try
        {
            assertTrue(mediaProxy.restrictNobodyViewAudio(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void restrictRemovedStatusAudio()
    {
        try
        {
            assertTrue(mediaProxy.restrictRemovedStatusAudio(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void restrictNobodyViewThumbVideo()
    {
        try
        {
            assertTrue(mediaProxy.restrictNobodyViewThumbVideo(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void restrictRemovedStatusThumbVideo()
    {
        try
        {
            assertTrue(mediaProxy.restrictRemovedStatusThumbVideo(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void restrictDraftThumbVideo()
    {
        try
        {
            assertTrue(mediaProxy.restrictDraftThumbVideo(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void restrictSubscriberThumbVideo()
    {
        try
        {
            assertTrue(mediaProxy.restrictSubscriberThumbVideo(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void restrictProductThumbVideo()
    {
        try
        {
            assertTrue(mediaProxy.restrictProductThumbVideo(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }
}
