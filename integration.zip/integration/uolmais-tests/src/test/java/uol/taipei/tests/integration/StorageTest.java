/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         12/08/2014 Criacao inicial
 */

package uol.taipei.tests.integration;

import static org.testng.AssertJUnit.assertTrue;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import uol.taipei.request.FacileRequest;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.storage.Storage;
import uol.taipei.tests.util.RequestUtil;

@Test(groups = "storage")
public class StorageTest extends AbstractTest
{
    private Storage storage = null;
    private FacileRequest request = null;
    private String mediaId = null;

    @BeforeClass
    public void init() throws Exception
    {
        setUp(ENVIRONMENT);

        storage = new Storage();
        request = new FacileRequest();

        mediaId = RequestUtil.mediaIdPublic("V");
    }

    @AfterClass
    public void finish()
    {
        request = null;
        mediaId = null;
        storage = null;
    }

    @Test
    public void probe()
    {
        try
        {
            assertNotNull(storage.probe());
        }
        catch (Exception e)
        {
            assertNotNull(e.getMessage(), null);
        }
    }

    @Test
    public void storageVideo()
    {
        try
        {
            assertTrue(storage.storageVideo(request, mediaId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void videoNoReferer()
    {
        try
        {
            assertTrue(storage.videoNoReferer(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void videoWithWildcard()
    {
        try
        {
            assertTrue(storage.videoWithWildcard(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void videoWithWildcardNoUseragent()
    {
        try
        {
            assertTrue(storage.videoWithWildcardNoUseragent(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void storagePlayer()
    {
        try
        {
            assertTrue(storage.storagePlayer(request, mediaId, 0));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void storagePlayerV5()
    {
        try
        {
            assertTrue(storage.storagePlayerV5(request, mediaId, 0));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void storagePlayerBand()
    {
        try
        {
            assertTrue(storage.storagePlayerBand(request, mediaId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void storagePlayerThumb()
    {
        try
        {
            assertTrue(storage.storagePlayerThumb(request, mediaId, 0));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void storageEmbed()
    {
        try
        {
            assertTrue(storage.storageEmbed(request, mediaId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void storageEmbedV2()
    {
        try
        {
            assertTrue(storage.storageEmbedV2(request, mediaId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void storageEmbedReduzido()
    {
        try
        {
            assertTrue(storage.storageEmbedReduzido(request, mediaId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void storageEmbedReduzidoV2()
    {
        try
        {
            assertTrue(storage.storageEmbedReduzidoV2(request, mediaId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void storageEmbedV2ssl()
    {
        try
        {
            assertTrue(storage.storageEmbedV2ssl(request, mediaId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void storageThumbVideo()
    {
        try
        {
            assertTrue(storage.storageThumbVideo(request, mediaId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "storageVideo", "storagePlayer", "videoNoReferer", "videoWithWildcard", "videoWithWildcardNoUseragent", "storagePlayerV5", "storagePlayerBand", "storagePlayerThumb",
                              "storageEmbed", "storageEmbedV2", "storageEmbedReduzido", "storageEmbedReduzidoV2", "storageEmbedV2ssl", 
                              "storageThumbVideo" })
    public void storagePodcast()
    {
        try
        {
            mediaId = RequestUtil.mediaIdPublic("P");
            assertTrue(storage.storagePodcast(request, mediaId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void storagePlayerAudio()
    {
        try
        {
            assertTrue(storage.storagePlayerAudio(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "storagePodcast" })
    public void storageEmbedAudio2()
    {
        try
        {
            assertTrue(storage.storageEmbedAudio2(request, mediaId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "storagePodcast" })
    public void storageEmbedAudio280()
    {
        try
        {
            assertTrue(storage.storageEmbedAudio280(request, mediaId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }
}
