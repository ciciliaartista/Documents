/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         08/08/2016 Criacao inicial
 */

package uol.taipei.tests.integration;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;

import java.util.HashMap;

import org.json.JSONObject;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.drakkar.ApiContentDeprecated;
import uol.taipei.tests.util.JsonUtil;

@Test(groups = "api_content_deprecated")
public class ApiContentDeprecatedTest extends AbstractTest
{
    private ApiContentDeprecated apiContentDeprecated = null;

    private JSONObject media = null;

    private HashMap<String, JSONObject> mapMedias = null;

    @BeforeClass
    public void init() throws Exception
    {
        setUp(ENVIRONMENT);

        apiContentDeprecated = new ApiContentDeprecated();
        mapMedias = new HashMap<String, JSONObject>();
    }

    @AfterClass
    public void finish()
    {
        mapMedias = null;
        media = null;
        apiContentDeprecated = null;
    }

    @Test
    public void listV1()
    {
        try
        {
            assertNotNull(apiContentDeprecated.listV1());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void listV2()
    {
        try
        {
            assertNotNull(apiContentDeprecated.listV2());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void detailVideo()
    {
        try
        {
            media = JsonUtil.mediaDecored(10, "V", "T", false, false,
                false, false, false);
            mapMedias.put("V", media);
            assertNotNull(apiContentDeprecated.detailsQs(mapMedias.get("V").getString("idt_media")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "detailVideo" })
    public void detailVideoByHash()
    {
        try
        {
            assertNotNull(apiContentDeprecated.detailsQs(mapMedias.get("V").getString("id")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "detailVideo" })
    public void detailVideoByHashWithoutHyphen()
    {
        try
        {
            String hashId = mapMedias.get("V").getString("id");
            String hashIdWithoutHyphen = hashId.substring(hashId.lastIndexOf("-") + 1);
            assertNotNull(apiContentDeprecated.detailsQs(hashIdWithoutHyphen));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "detailVideo" })
    public void detailVideoRest()
    {
        try
        {
            assertNotNull(apiContentDeprecated.details(mapMedias.get("V").getString("idt_media")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "detailVideo" })
    public void detailVideoByHashRest()
    {
        try
        {
            assertNotNull(apiContentDeprecated.details(mapMedias.get("V").getString("id")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "detailVideo" })
    public void detailVideoByHashWithoutHyphenRest()
    {
        try
        {
            String hashId = mapMedias.get("V").getString("id");
            String hashIdWithoutHyphen = hashId.substring(hashId.lastIndexOf("-") + 1);
            assertNotNull(apiContentDeprecated.details(hashIdWithoutHyphen));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "detailVideo" })
    public void chooseVideoId()
    {
        try
        {
            assertNotNull(apiContentDeprecated.chooseContents(mapMedias.get("V").getString("idt_media"),
                "media"));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "detailVideo" })
    public void chooseVideoHash()
    {
        try
        {
            assertNotNull(apiContentDeprecated.chooseContents(mapMedias.get("V").getString("id"), "hash"));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "detailVideo" })
    public void chooseVideoHashWithoutHyphen()
    {
        try
        {
            String hashId = mapMedias.get("V").getString("id");
            String hashIdWithoutHyphen = hashId.substring(hashId.lastIndexOf("-") + 1);
            assertNotNull(apiContentDeprecated.chooseContents(hashIdWithoutHyphen, "hash"));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void detailAudio()
    {
        try
        {
            media = JsonUtil.mediaDecored(10, "P", "T", false, false,
                false, false, false);
            mapMedias.put("P", media);
            assertNotNull(apiContentDeprecated.detailsQs(mapMedias.get("P").getString("idt_media")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "detailAudio" })
    public void detailAudioByHash()
    {
        try
        {
            assertNotNull(apiContentDeprecated.detailsQs(mapMedias.get("P").getString("id")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "detailAudio" })
    public void detailAudioByHashWithoutHyphen()
    {
        try
        {
            String hashId = mapMedias.get("P").getString("id");
            String hashIdWithoutHyphen = hashId.substring(hashId.lastIndexOf("-") + 1);
            assertNotNull(apiContentDeprecated.detailsQs(hashIdWithoutHyphen));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "detailAudio" })
    public void detailAudioRest()
    {
        try
        {
            assertNotNull(apiContentDeprecated.details(mapMedias.get("P").getString("idt_media")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "detailAudio" })
    public void detailAudioByHashRest()
    {
        try
        {
            assertNotNull(apiContentDeprecated.details(mapMedias.get("P").getString("id")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "detailAudio" })
    public void detailAudioByHashRestWithoutHyphen()
    {
        try
        {
            String hashId = mapMedias.get("P").getString("id");
            String hashIdWithoutHyphen = hashId.substring(hashId.lastIndexOf("-") + 1);
            assertNotNull(apiContentDeprecated.details(hashIdWithoutHyphen));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "detailAudio" })
    public void chooseAudioId()
    {
        try
        {
            assertNotNull(apiContentDeprecated.chooseContents(mapMedias.get("P").getString("idt_media"),
                "media"));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "detailAudio" })
    public void chooseAudioHash()
    {
        try
        {
            assertNotNull(apiContentDeprecated
                    .chooseContents(mapMedias.get("P").getString("id"), "hash"));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "detailAudio" })
    public void chooseAudioHashWithoutHyphen()
    {
        try
        {
            String hashId = mapMedias.get("P").getString("id");
            String hashIdWithoutHyphen = hashId.substring(hashId.lastIndexOf("-") + 1);
            assertNotNull(apiContentDeprecated.chooseContents(hashIdWithoutHyphen, "hash"));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "detailVideo", "detailVideoByHash", "detailVideoByHashWithoutHyphen", "detailVideoRest",
                              "detailVideoByHashRest", "detailVideoByHashWithoutHyphenRest", "chooseVideoId",
                              "chooseVideoHash", "chooseVideoHashWithoutHyphen", "detailAudio", "detailAudioByHash",
                              "detailAudioByHashWithoutHyphen", "detailAudioRest", "detailAudioByHashRest",
                              "chooseAudioId", "chooseAudioHash", "chooseAudioHashWithoutHyphen" })
    public void detailsQs()
    {
        try
        {
            assertNotNull(apiContentDeprecated.detailsQs(apiContentDeprecated.listMediaId(mapMedias)));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "detailsQs" })
    public void detailsQsHash()
    {
        try
        {
            assertNotNull(apiContentDeprecated.detailsQs(apiContentDeprecated.listId(mapMedias)));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "detailsQs" })
    public void detailsQsHashWithoutHyphen()
    {
        try
        {
            assertNotNull(apiContentDeprecated.detailsQs(apiContentDeprecated.listIdWithoutHyphen(mapMedias)));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "detailsQs" })
    public void details()
    {
        try
        {
            assertNotNull(apiContentDeprecated.details(apiContentDeprecated.listMediaId(mapMedias)));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "detailsQs" })
    public void detailsHash()
    {
        try
        {
            assertNotNull(apiContentDeprecated.details(apiContentDeprecated.listId(mapMedias)));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "detailsQs" })
    public void detailsHashWithoutHyphen()
    {
        try
        {
            assertNotNull(apiContentDeprecated.details(apiContentDeprecated.listIdWithoutHyphen(mapMedias)));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "detailsQs" })
    public void chooseListIds()
    {
        try
        {
            assertNotNull(apiContentDeprecated.chooseContents(apiContentDeprecated.listMediaId(mapMedias), "media"));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "detailsQs" })
    public void chooseListHashes()
    {
        try
        {
            assertNotNull(apiContentDeprecated.chooseContents(apiContentDeprecated.listId(mapMedias), "hash"));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "detailsQs" })
    public void chooseListHashesWithoutHyphen()
    {
        try
        {
            assertNotNull(apiContentDeprecated.chooseContents(apiContentDeprecated.listIdWithoutHyphen(mapMedias),
                "hash"));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }
}
