/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         17/12/2015 Criacao inicial
 */

package uol.taipei.tests.integration;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.encoder.HealthCheckEncoder;

@Test(groups = "health_check_encoder")
public class HealthCheckEncoderTest extends AbstractTest
{
    private HealthCheckEncoder healthCheckEncoder = null;

    @BeforeClass
    public void init() throws Exception
    {
        setUp(ENVIRONMENT);
    }

    @AfterClass
    public void finish()
    {
        healthCheckEncoder = null;
    }

    @Test
    public void probe()
    {
        try
        {
            for (String hostName : envConfig().getHostsEncoders().split(","))
            {
                healthCheckEncoder = new HealthCheckEncoder(hostName);
                assertTrue(healthCheckEncoder.probe());
            }
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }
}
