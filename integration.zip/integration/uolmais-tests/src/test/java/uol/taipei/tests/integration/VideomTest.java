/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         12/08/2014 Criacao inicial
 */

package uol.taipei.tests.integration;

import static org.testng.AssertJUnit.assertTrue;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import uol.taipei.request.FacileRequest;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.croupier.Videom;
import uol.taipei.tests.util.RequestUtil;

@Test(groups = "video.m")
public class VideomTest extends AbstractTest
{
    private Videom videom = null;
    private FacileRequest request = null;
    private String mediaId = null;

    @BeforeClass
    public void init() throws Exception
    {
        setUp(ENVIRONMENT);

        videom = new Videom();
        request = new FacileRequest();

        mediaId = RequestUtil.mediaIdPublic("V");
    }

    @AfterClass
    public void finish()
    {
        request = null;
        mediaId = null;
        videom = null;
    }

    @Test
    public void probe()
    {
        try
        {
            assertNotNull(videom.probe());
        }
        catch (Exception e)
        {
            assertNotNull(e.getMessage(), null);
        }
    }

    @Test
    public void videoMobile()
    {
        try
        {
            assertTrue(videom.videoMobile(request, mediaId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void videoMobileNoFormat9()
    {
        try
        {
            assertTrue(videom.videoMobileNoFormat9(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void videoNoReferer()
    {
        try
        {
            assertTrue(videom.videoNoReferer(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void videoWithWildcard()
    {
        try
        {
            assertTrue(videom.videoWithWildcard(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void videoWithWildcardNoUseragent()
    {
        try
        {
            assertTrue(videom.videoWithWildcardNoUseragent(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "videoNoReferer", "videoWithWildcard", "videoWithWildcardNoUseragent", "videoMobileNoFormat9", "videoMobile" })
    public void podcastMobile()
    {
        try
        {
            mediaId = RequestUtil.mediaIdPublic("P");
            assertTrue(videom.podcastMobile(request, mediaId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }
}
