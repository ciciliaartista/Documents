/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         10/06/2014 Criacao inicial
 */

package uol.taipei.tests.integration;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;

import org.json.JSONObject;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import uol.taipei.request.FacileRequest;
import uol.taipei.request.UsefulRequest;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.LoginCookie;
import uol.taipei.tests.content.ApiSearch;

public class ApiSearchTest extends AbstractTest
{
    private ApiSearch apiSearch = null;
    private UsefulRequest login = null;
    private JSONObject media = null;
    private FacileRequest request = null;

    @BeforeClass
    public void init() throws Exception
    {
        setUp(ENVIRONMENT);

        apiSearch = new ApiSearch();
        request = new FacileRequest();

        availability(request, "http://mais.b.uol.com.br/probe");

        login = new LoginCookie(envConfig().getUser(), envConfig().getPass());
        media = apiSearch.getValidMedia();
    }

    @AfterClass
    public void finish()
    {
        login = null;
        media = null;
        request = null;
        apiSearch = null;
    }

    @Test
    public void list()
    {
        try
        {
            assertNotNull(apiSearch.list());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void types()
    {
        try
        {
            assertNotNull(apiSearch.types());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void codProfile()
    {
        try
        {
            assertNotNull(apiSearch.codProfile(media));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void safeSearch()
    {
        try
        {
            assertNotNull(apiSearch.safeSearch());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void order()
    {
        try
        {
            assertNotNull(apiSearch.order());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void edFilter()
    {
        try
        {
            assertNotNull(apiSearch.edFilter());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void loggedList()
    {
        try
        {
            assertNotNull(apiSearch.loggedList(login));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void loggedCodProfile()
    {
        try
        {
            assertNotNull(apiSearch.loggedCodProfile(login, media));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void aleatorySearch()
    {
        try
        {
            assertNotNull(apiSearch.aleatorySearch());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void exactSearch()
    {
        try
        {
            assertNotNull(apiSearch.exactSearch());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void emptyQuery()
    {
        try
        {
            assertNotNull(apiSearch.emptyQuery());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }
}
