/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         22/09/2017 Criacao inicial
 */

package uol.taipei.tests.integration;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.json.JSONObject;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import uol.taipei.request.FacileRequest;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.basicauth.ApiPublishBasicAuth;
import uol.taipei.tests.util.JsonUtil;
import uol.taipei.tests.util.RequestUtil;

@Test(groups = "publish_service")
public class ApiPublishBasicAuthTest extends AbstractTest
{
    private ApiPublishBasicAuth apiPublishBasicauth = null;
    private JSONObject profile = null;
    private String mediaId = null;
    private FacileRequest request = null;

    @BeforeClass
    public void init() throws Exception
    {
        setUp(ENVIRONMENT);

        apiPublishBasicauth = new ApiPublishBasicAuth();
        request = new FacileRequest();

        availability(request, "http://beta.mais.uol.com.br/probe");

        profile = JsonUtil.fullProfileLogin(envConfig().getUser());
        mediaId = RequestUtil.mediaId("V", Long.valueOf(profile.getJSONObject("profile").getString("codProfileHash")));
    }

    @AfterClass
    public void finish()
    {
        try
        {
            updateContentStatus(Long.valueOf(mediaId), 10, 2);
        }
        catch (Exception e)
        {

        }

        profile = null;
        mediaId = null;
        request = null;
        apiPublishBasicauth = null;
    }

    @Test
    public void uploadVideo()
    {
        try
        {
            assertNotNull(apiPublishBasicauth.uploadVideo(profile.getString("codProfile"), profile.getJSONObject("mediaConfig").getString("passphrase")));
        }
        catch (Exception e)
        {
            assertNotNull(e.getMessage(), null);
        }
    }

    @Test
    public void uploadPodcast()
    {
        try
        {
            assertNotNull(apiPublishBasicauth.uploadPodcast(profile.getString("codProfile"), profile.getJSONObject("mediaConfig").getString("passphrase")));
        }
        catch (Exception e)
        {
            assertNotNull(e.getMessage(), null);
        }
    }

    

//    @Test
//    public void uploadErrIvalidProfile()
//    {
//        try
//        {
//            assertTrue(apiPublishBasicauth.uploadErrIvalidProfile(profile.getString("codProfile"), profile.getJSONObject("mediaConfig").getString("passphrase")));
//        }
//        catch (Exception e)
//        {
//        	assertFalse(e.getMessage(), true);
//        }
//    }

//    @Test
//    public void uploadErrNoProfile()
//    {
//        try
//        {
//            assertTrue(apiPublishBasicauth.uploadErrNoProfile(profile.getString("codProfile"), profile.getJSONObject("mediaConfig").getString("passphrase")));
//        }
//        catch (Exception e)
//        {
//        	assertFalse(e.getMessage(), true);
//        }
//    }

    @Test
    public void notPublishVideoNoAuth()
    {
        try
        {
            assertTrue(apiPublishBasicauth.notPublishVideoNoAuth(request, profile.getString("codProfile")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void notPublishAudioNoAuth()
    {
        try
        {
            assertTrue(apiPublishBasicauth.notPublishAudioNoAuth(request, profile.getString("codProfile")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void statusVideo()
    {
        try
        {
            assertNotNull(apiPublishBasicauth.statusVideo(profile.getString("codProfile"), profile.getJSONObject("mediaConfig").getString("passphrase"), Long.valueOf(mediaId)));
        }
        catch (Exception e)
        {
            assertNotNull(e.getMessage(), null);
        }
    }

    @Test
    public void statusAudio()
    {
        try
        {
            assertNotNull(apiPublishBasicauth.statusAudio(profile.getString("codProfile"), profile.getJSONObject("mediaConfig").getString("passphrase")));
        }
        catch (Exception e)
        {
            assertNotNull(e.getMessage(), null);
        }
    }

    @Test
    public void publishThumb()
    {
        try
        {
            assertNotNull(apiPublishBasicauth.publishThumb(profile.getString("codProfile"), profile.getJSONObject("mediaConfig").getString("passphrase"), Long.valueOf(mediaId)));
        }
        catch (Exception e)
        {
            assertNotNull(e.getMessage(), null);
        }
    }

    @Test
    public void statusErrInvalidOwner()
    {
        try
        {
            assertTrue(apiPublishBasicauth.statusErrInvalidOwner(profile.getString("codProfile"), profile.getJSONObject("mediaConfig").getString("passphrase"), Long.valueOf(mediaId)));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void updateMediaErrInvalidOwner()
    {
        try
        {
            assertTrue(apiPublishBasicauth.updateMediaErrInvalidOwner(profile.getString("codProfile"), profile.getJSONObject("mediaConfig").getString("passphrase"), Long.valueOf(mediaId)));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void updateMedia()
    {
        try
        {
            assertNotNull(apiPublishBasicauth.updateMedia(profile.getString("codProfile"), profile.getJSONObject("mediaConfig").getString("passphrase"), Long.valueOf(mediaId)));
        }
        catch (Exception e)
        {
            assertNotNull(e.getMessage(), null);
        }
    }
}
