/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         12/08/2014 Criacao inicial
 */

package uol.taipei.tests.integration;

import static org.testng.AssertJUnit.assertTrue;
import static org.junit.Assert.assertFalse;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import uol.taipei.request.FacileRequest;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.storage.Thumb;

@Test(groups = "thumb")
public class ThumbTest extends AbstractTest
{
    private Thumb thumb = null;
    private FacileRequest request = null;

    @BeforeClass
    public void init() throws Exception
    {
        setUp(ENVIRONMENT);

        thumb = new Thumb();
        request = new FacileRequest();
    }

    @AfterClass
    public void finish()
    {
        request = null;
        thumb = null;
    }

    @Test
    public void noUri()
    {
        try
        {
            assertTrue(thumb.noUri(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void noExtension()
    {
        try
        {
            assertTrue(thumb.noExtension(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void invalidExtension()
    {
        try
        {
            assertTrue(thumb.invalidExtension(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void probe()
    {
        try
        {
            assertTrue(thumb.probe(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void crossdomain()
    {
        try
        {
            assertTrue(thumb.crossdomain(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void thumbVideo()
    {
        try
        {
            assertTrue(thumb.thumbVideo(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void thumbPodcast()
    {
        try
        {
            assertTrue(thumb.thumbPodcast(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }
}
