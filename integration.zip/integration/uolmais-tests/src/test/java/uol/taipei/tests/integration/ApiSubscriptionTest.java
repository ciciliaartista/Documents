/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         24/07/2014 Criacao inicial
 */

package uol.taipei.tests.integration;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import uol.taipei.request.FacileRequest;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.LoginCookie;
import uol.taipei.tests.subscription.ApiSubscription;

@Test(groups = "subscription")
public class ApiSubscriptionTest extends AbstractTest
{
    private ApiSubscription apiSubscription = null;
    private static FacileRequest request = null;
    private LoginCookie login = null;
    private Integer idtFollowable = null;

    @BeforeClass
    public void init() throws Exception
    {
        setUp(ENVIRONMENT);

        apiSubscription = new ApiSubscription();
        request = new FacileRequest();
        login = new LoginCookie(envConfig().getUser(), envConfig().getPass());
        idtFollowable = apiSubscription.notFollowable(login);
    }

    @AfterClass
    public void finish()
    {
        login = null;
        idtFollowable = null;
        apiSubscription = null;
    }

    @Test(dependsOnMethods = { "unsubscribe" })
    public void subscribeByProfile()
    {
        try
        {
            assertNotNull(apiSubscription.subscribeByProfile(login));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void subscribeById()
    {
        try
        {
            assertNotNull(apiSubscription.subscribeById(login, idtFollowable));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "subscribeById" })
    public void verify()
    {
        try
        {
            assertNotNull(apiSubscription.verify(login, idtFollowable));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "verify" })
    public void notViewedCount()
    {
        try
        {
            assertNotNull(apiSubscription.notViewedCount(login, idtFollowable));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "notViewedCount" })
    public void lastViewedDate()
    {
        try
        {
            assertNotNull(apiSubscription.lastViewedDate(login, idtFollowable));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "lastViewedDate" })
    public void lastViewedDateUpdate()
    {
        try
        {
            assertNotNull(apiSubscription.lastViewedDateUpdate(login, idtFollowable));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void list()
    {
        try
        {
            assertNotNull(apiSubscription.list());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void listWithItemsPerPageErr()
    {
        try
        {
            assertNotNull(apiSubscription.listWithItemsPerPageErr(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void listWithCurrentPageErr()
    {
        try
        {
            assertNotNull(apiSubscription.listWithCurrentPageErr(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void listByUser()
    {
        try
        {
            assertNotNull(apiSubscription.listByUser(login));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void listByUserSort()
    {
        try
        {
            assertNotNull(apiSubscription.listByUserSort(login));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "unsubscribe", dependsOnMethods = { "lastViewedDateUpdate" })
    public void unsubscribe()
    {
        try
        {
            assertNotNull(apiSubscription.unsubscribe(login, idtFollowable));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void subscribers()
    {
        try
        {
            assertNotNull(apiSubscription.subscribers(login));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void subscribeError()
    {
        try
        {
            assertNotNull(apiSubscription.subscribeError(login));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void subscribeByProfileError()
    {
        try
        {
            assertNotNull(apiSubscription.subscribeByProfileError(login));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void subscribeByIdError()
    {
        try
        {
            assertNotNull(apiSubscription.subscribeByIdError(login));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void verifyError()
    {
        try
        {
            assertNotNull(apiSubscription.verifyError(login));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void unsubscribeError()
    {
        try
        {
            assertNotNull(apiSubscription.unsubscribeError(login));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void verifyNotFound()
    {
        try
        {
            assertNotNull(apiSubscription.verifyNotFound(login));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void subscribersNotFound()
    {
        try
        {
            assertNotNull(apiSubscription.subscribersNotFound(login));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void unsubscribeNotFound()
    {
        try
        {
            assertNotNull(apiSubscription.unsubscribeNotFound(login));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }
}
