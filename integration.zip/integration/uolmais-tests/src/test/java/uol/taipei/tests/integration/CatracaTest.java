/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         20/06/2014 Criacao inicial
 */

package uol.taipei.tests.integration;

import static org.junit.Assert.assertFalse;
import static org.testng.AssertJUnit.assertTrue;

import java.io.IOException;

import org.apache.http.client.ClientProtocolException;
import org.json.JSONException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import uol.taipei.request.FacileRequest;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.task.Catraca;

public class CatracaTest extends AbstractTest
{
    private Catraca catraca = null;
    private FacileRequest request = null;

    @BeforeClass
    public void init() throws ClientProtocolException, IllegalStateException, IOException, JSONException
    {
        setUp(ENVIRONMENT);

        catraca = new Catraca();
        request = new FacileRequest();
    }

    @AfterClass
    public void finish()
    {
        request = null;
        catraca = null;
    }

    @Test
    public void probe()
    {
        try
        {
            assertTrue(catraca.probe(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void publicVideo()
    {
        try
        {
            assertTrue(catraca.publicVideo(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void publicPoscast()
    {
        try
        {
            assertTrue(catraca.publicPoscast(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void restrictNobodyViewVideo()
    {
        try
        {
            assertTrue(catraca.restrictNobodyViewVideo(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void restrictRemovedStatusVideo()
    {
        try
        {
            assertTrue(catraca.restrictRemovedStatusVideo(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    //@Test
    public void restrictDraftVideo()
    {
        try
        {
            assertTrue(catraca.restrictDraftVideo(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void restrictSubscriberVideo()
    {
        try
        {
            assertTrue(catraca.restrictSubscriberVideo(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void restrictProductVideo()
    {
        try
        {
            assertTrue(catraca.restrictProductVideo(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void publicThumbVideo()
    {
        try
        {
            assertTrue(catraca.publicThumbVideo(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void restrictNobodyViewThumbVideo()
    {
        try
        {
            assertTrue(catraca.restrictNobodyViewThumbVideo(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void restrictRemovedStatusThumbVideo()
    {
        try
        {
            assertTrue(catraca.restrictRemovedStatusThumbVideo(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    //@Test
    public void restrictDraftThumbVideo()
    {
        try
        {
            assertTrue(catraca.restrictDraftThumbVideo(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void restrictSubscriberThumbVideo()
    {
        try
        {
            assertTrue(catraca.restrictSubscriberThumbVideo(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void errorMediaNotFound()
    {
        try
        {
            assertTrue(catraca.errorMediaNotFound(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void errorNotFound()
    {
        try
        {
            assertTrue(catraca.errorNotFound(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }
}
