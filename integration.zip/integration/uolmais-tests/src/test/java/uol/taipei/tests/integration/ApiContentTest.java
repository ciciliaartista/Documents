/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         10/06/2014 Criacao inicial
 */

package uol.taipei.tests.integration;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;

import java.util.HashMap;

import org.json.JSONObject;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.LoginCookie;
import uol.taipei.tests.content.ApiContent;
import uol.taipei.tests.util.JsonUtil;

public class ApiContentTest extends AbstractTest
{
    private ApiContent apiContent = null;
    private LoginCookie login = null;
    private JSONObject media = null;
    private HashMap<String, JSONObject> mapMedias = null;

    @BeforeClass
    public void init() throws Exception
    {
        setUp(ENVIRONMENT);

        apiContent = new ApiContent();
        login = new LoginCookie(envConfig().getUser(), envConfig().getPass());
        mapMedias = new HashMap<String, JSONObject>();
    }

    @AfterClass
    public void finish()
    {
        login = null;
        mapMedias = null;
        media = null;
        apiContent = null;
    }

    @Test(groups = "content")
    public void list()
    {
        try
        {
            assertNotNull(apiContent.list());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(groups = "content")
    public void detailVideo()
    {
        try
        {
            media = JsonUtil.mediaDecored(10, "V", "T", false, false, false, false, false);
            mapMedias.put("V", media);
            assertNotNull(apiContent.detailQs(mapMedias.get("V").getString("idt_media"), "V"));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "detailVideo" }, groups = "content")
    public void detailVideoByHash()
    {
        try
        {
            assertNotNull(apiContent.detailQs(mapMedias.get("V").getString("id"), "V"));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "detailVideo" }, groups = "content")
    public void detailsVideo()
    {
        try
        {
            assertNotNull(apiContent.detailsQs(mapMedias.get("V").getString("idt_media")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "detailVideo" }, groups = "content")
    public void detailsVideoByhash()
    {
        try
        {
            assertNotNull(apiContent.detailsQs(mapMedias.get("V").getString("id")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(groups = "content")
    public void detailAudio()
    {
        try
        {
            media = JsonUtil.mediaDecored(10, "P", "T", false, false, false, false, false);
            mapMedias.put("P", media);
            assertNotNull(apiContent.detailQs(mapMedias.get("P").getString("idt_media"), "P"));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "detailAudio" }, groups = "content")
    public void detailAudioByHash()
    {
        try
        {
            assertNotNull(apiContent.detailQs(mapMedias.get("P").getString("id"), "P"));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "detailAudio" }, groups = "content")
    public void detailsAudio()
    {
        try
        {
            assertNotNull(apiContent.detailsQs(mapMedias.get("P").getString("idt_media")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "detailAudio" }, groups = "content")
    public void detailsAudioByhash()
    {
        try
        {
            assertNotNull(apiContent.detailsQs(mapMedias.get("P").getString("id")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "detailVideo", "detailVideoByHash", "detailsVideo", "detailsVideoByhash", "detailAudio",
                               "detailAudioByHash", "detailsAudio", "detailsAudioByhash" }, groups = "content")
    public void details()
    {
        try
        {
            assertNotNull(apiContent.detailsQs(apiContent.listMediaId(mapMedias)));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "detailVideo", "detailVideoByHash", "detailsVideo", "detailsVideoByhash", "detailAudio",
                               "detailAudioByHash", "detailsAudio", "detailsAudioByhash" }, groups = "content")
    public void detailsByHash()
    {
        try
        {
            assertNotNull(apiContent.detailsQs(apiContent.listId(mapMedias)));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "detailVideo" }, groups = "content")
    public void detailVideoRest()
    {
        try
        {
            assertNotNull(apiContent.detail(mapMedias.get("V").getString("idt_media"), "V"));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "detailVideo" }, groups = "content")
    public void detailVideoByHashRest()
    {
        try
        {
            assertNotNull(apiContent.detail(mapMedias.get("V").getString("id"), "V"));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "detailVideo" }, groups = "content")
    public void detailsVideoRest()
    {
        try
        {
            assertNotNull(apiContent.details(mapMedias.get("V").getString("idt_media")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "detailVideo" }, groups = "content")
    public void detailsVideoByhashRest()
    {
        try
        {
            assertNotNull(apiContent.details(mapMedias.get("V").getString("id")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "detailAudio" }, groups = "content")
    public void detailAudioRest()
    {
        try
        {
            assertNotNull(apiContent.detail(mapMedias.get("P").getString("idt_media"), "P"));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "detailAudio" }, groups = "content")
    public void detailAudioByHashRest()
    {
        try
        {
            assertNotNull(apiContent.detail(mapMedias.get("P").getString("id"), "P"));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "detailAudio" }, groups = "content")
    public void detailsAudioRest()
    {
        try
        {
            assertNotNull(apiContent.details(mapMedias.get("P").getString("idt_media")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "detailAudio" }, groups = "content")
    public void detailsAudioByhashRest()
    {
        try
        {
            assertNotNull(apiContent.details(mapMedias.get("P").getString("id")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "details" }, groups = "content")
    public void detailsRest()
    {
        try
        {
            assertNotNull(apiContent.details(apiContent.listMediaId(mapMedias)));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "detailsByHash" }, groups = "content")
    public void detailsByHashRest()
    {
        try
        {
            assertNotNull(apiContent.details(apiContent.listId(mapMedias)));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "details" }, groups = "content")
    public void apacheCache()
    {
        try
        {
            assertNotNull(apiContent.apacheCache(mapMedias.get("V").getString("idt_media")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "apacheCache" }, groups = "content")
    public void apacheCacheQs()
    {
        try
        {
            assertNotNull(apiContent.apacheCacheQs(mapMedias.get("V").getString("idt_media")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "apacheCacheQs" }, groups = "content")
    public void apacheCacheByHash()
    {
        try
        {
            assertNotNull(apiContent.apacheCacheQs(mapMedias.get("V").getString("id")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "apacheCacheByHash" }, groups = "content")
    public void apacheCacheByHashQs()
    {
        try
        {
            assertNotNull(apiContent.apacheCacheQs(mapMedias.get("V").getString("id")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "detailVideo" }, groups = "content")
    public void related()
    {
        try
        {
            assertNotNull(apiContent.related(mapMedias.get("V").getString("idt_media")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(groups = "content")
    public void codProfile()
    {
        try
        {
            assertNotNull(apiContent.codProfile(login.getJsonProfile().getJSONObject("item").getString("codProfile")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    // @Test(groups = "content") falha muito
    public void itemsPerPage()
    {
        try
        {
            assertNotNull(apiContent.itemsPerPage(2));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(groups = "content")
    public void currentPage()
    {
        try
        {
            assertNotNull(apiContent.currentPage(2));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(groups = "content")
    public void types()
    {
        try
        {
            assertNotNull(apiContent.types());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(groups = "content")
    public void edFilter()
    {
        try
        {
            assertNotNull(apiContent.edFilter());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(groups = "content")
    public void adultFilter()
    {
        try
        {
            assertNotNull(apiContent.adultFilter());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(groups = "content")
    public void subscriberMedia()
    {
        try
        {
            assertNotNull(apiContent.subscriberMedia());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    // @Test(groups = "content")
    public void format()
    {
        try
        {
            assertNotNull(apiContent.format());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(groups = "content")
    public void tagNames()
    {
        try
        {
            assertNotNull(apiContent.tagNames("teste"));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(groups = "content")
    public void tagIds()
    {
        try
        {
            assertNotNull(apiContent.tagIds("1", false));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(groups = "content")
    public void idtTagService()
    {
        try
        {
            assertNotNull(apiContent.idtTagService("1010", false));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(groups = "content")
    public void sort()
    {
        try
        {
            assertNotNull(apiContent.sort());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    // @Test(groups = "content") falha muito
    public void editorialStatus()
    {
        try
        {
            assertNotNull(apiContent.editorialStatus());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(groups = "content")
    public void history()
    {
        try
        {
            assertNotNull(apiContent.history());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(groups = "content")
    public void recommended()
    {
        try
        {
            assertNotNull(apiContent.recommended());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    // @Test(groups = "content")
    public void formats()
    {
        try
        {
            assertNotNull(apiContent.formats());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    // @Test(groups = "content")
    public void paging()
    {
        try
        {
            assertNotNull(apiContent.paging());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(groups = "content")
    public void followable()
    {
        try
        {
            assertNotNull(apiContent.followable());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(groups = "content")
    public void date()
    {
        try
        {
            assertNotNull(apiContent.date());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }
}
