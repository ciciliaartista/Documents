/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         20/08/2014 Criacao inicial
 */

package uol.taipei.tests.integration;

import static org.testng.AssertJUnit.assertTrue;
import static org.junit.Assert.assertFalse;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import uol.taipei.request.FacileRequest;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.ssl.ThumbSsl;

@Test(groups = "thumbssl")
public class ThumbSslTest extends AbstractTest
{
    private ThumbSsl thumbSsl = null;
    private FacileRequest request = null;

    @BeforeClass
    public void init() throws Exception
    {
        setUp(ENVIRONMENT);

        thumbSsl = new ThumbSsl();
        request = new FacileRequest();
        request.configureSSL();
    }

    @AfterClass
    public void finish()
    {
        request = null;
        thumbSsl = null;
    }

    @Test
    public void noUri()
    {
        try
        {
            assertTrue(thumbSsl.noUri(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void noExtension()
    {
        try
        {
            assertTrue(thumbSsl.noExtension(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void invalidExtension()
    {
        try
        {
            assertTrue(thumbSsl.invalidExtension(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void probe()
    {
        try
        {
            assertTrue(thumbSsl.probe(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void crossdomain()
    {
        try
        {
            assertTrue(thumbSsl.crossdomain(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void thumbVideo()
    {
        try
        {
            assertTrue(thumbSsl.thumbVideo(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }
}
