/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         11/06/2014 Criacao inicial
 */

package uol.taipei.tests.integration;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;

import org.json.JSONObject;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.LoginCookie;
import uol.taipei.tests.comment.ApiComment;
import uol.taipei.tests.util.JsonUtil;

@Test(groups = "comment_api")
public class ApiCommentTest extends AbstractTest
{
    private ApiComment apiComment = null;
    private LoginCookie login = null;
    private JSONObject media = null;

    @BeforeClass
    public void init() throws Exception
    {
        setUp(ENVIRONMENT);

        apiComment = new ApiComment();
        login = new LoginCookie(envConfig().getUser(), envConfig().getPass());
        media = JsonUtil.mediaIdtSubject(false);
    }

    @AfterClass
    public void finish()
    {
        media = null;
        apiComment = null;
    }

    @Test
    public void topicLink()
    {
        try
        {
            Long idtMedia = Long.parseLong(JsonUtil.getParam(media, "idt_media").toString());
            assertNotNull(apiComment.topicLink(login, idtMedia));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "topicLink" })
    public void topicLinkNoModeration()
    {
        try
        {
            assertNotNull(apiComment.topicLinkNoModeration(login));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "topicLinkNoModeration" })
    public void topicMedia()
    {
        try
        {
            media = JsonUtil.mediaIdtSubject(true);
            Long idtSubject = Long.parseLong(JsonUtil.getParam(media, "idt_subject").toString());

            assertNotNull(apiComment.topicMedia(idtSubject));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "topicMedia" })
    public void topicTheme()
    {
        try
        {
            assertNotNull(apiComment.topicTheme());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }
}
