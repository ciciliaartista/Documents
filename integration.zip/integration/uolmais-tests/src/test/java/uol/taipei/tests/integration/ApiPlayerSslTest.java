/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         10/06/2014 Criacao inicial
 */

package uol.taipei.tests.integration;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.ssl.ApiPlayerSsl;
import uol.taipei.tests.util.RequestUtil;

public class ApiPlayerSslTest extends AbstractTest
{
    private ApiPlayerSsl apiPlayerSsl = null;
    private String mediaId = null;

    @BeforeClass
    public void init() throws Exception
    {
        setUp(ENVIRONMENT);

        apiPlayerSsl = new ApiPlayerSsl();
        mediaId = RequestUtil.mediaIdPublic("V");
    }

    @AfterClass
    public void finish()
    {
        mediaId = null;
        apiPlayerSsl = null;
    }

    @Test
    public void crossdomain()
    {
        try
        {
            assertTrue(apiPlayerSsl.crossdomain());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void mediaViewVideo()
    {
        try
        {
            assertNotNull(apiPlayerSsl.mediaView(mediaId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void playerMediaVideo()
    {
        try
        {
            assertNotNull(apiPlayerSsl.playerMedia(mediaId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "mediaViewVideo", "playerMediaVideo", "media", "related", "notifyMediaView" })
    public void playerMediaAudio()
    {
        try
        {
            mediaId = RequestUtil.mediaIdPublic("P");
            assertNotNull(apiPlayerSsl.playerMedia(mediaId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void media()
    {
        try
        {
            assertNotNull(apiPlayerSsl.media(mediaId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void related()
    {
        try
        {
            assertNotNull(apiPlayerSsl.related(mediaId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void notifyMediaView()
    {
        try
        {
            assertNotNull(apiPlayerSsl.notifyMediaView(mediaId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }
}
