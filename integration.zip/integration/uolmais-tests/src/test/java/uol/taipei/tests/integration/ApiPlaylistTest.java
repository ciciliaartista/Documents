/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         11/06/2014 Criacao inicial
 */

package uol.taipei.tests.integration;

import static org.junit.Assert.*;

import org.json.JSONObject;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.LoginCookie;
import uol.taipei.tests.playlist.ApiPlaylist;
import uol.taipei.tests.util.JsonUtil;

public class ApiPlaylistTest extends AbstractTest
{
    private ApiPlaylist apiPlaylist = null;
    private LoginCookie login = null;
    private JSONObject playlist = null;
    private JSONObject media = null;
    private String listId = null;

    @BeforeClass
    public void init() throws Exception
    {
        setUp(ENVIRONMENT);

        apiPlaylist = new ApiPlaylist();
        login = new LoginCookie(envConfig().getUser(), envConfig().getPass());
    }

    @AfterClass
    public void finish()
    {
        login = null;
        playlist = null;
        media = null;
        apiPlaylist = null;
    }

    @Test(testName = "notCreatePublic", groups = { "playlist" })
    public void notCreatePublic()
    {
        try
        {
            assertNotNull(apiPlaylist.notCreatePublic());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "create", dependsOnMethods = { "notCreatePublic" }, groups = { "playlist" })
    public void create()
    {
        try
        {
            assertNotNull(apiPlaylist.create(login));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "createCharset", dependsOnMethods = { "notCreatePublic" }, groups = { "playlist" })
    public void createCharset()
    {
        try
        {
            assertNotNull(apiPlaylist.createCharset(login));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "listPublic", dependsOnMethods = { "create" }, groups = { "playlist" })
    public void listPublic()
    {
        try
        {
            assertNotNull(apiPlaylist.listPublic(login.getJsonProfile().getJSONObject("item").getString("codProfile")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "list", dependsOnMethods = { "create" }, groups = { "playlist" })
    public void list()
    {
        try
        {
            assertNotNull(apiPlaylist.list(login, login.getJsonProfile().getJSONObject("item").getString("codProfile")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "update", dependsOnMethods = { "create" }, groups = { "playlist" })
    public void update()
    {
        try
        {
            playlist = JsonUtil.playlist(login.getJsonProfile().getJSONObject("item").getLong("codProfileHash"), 0);

            assertNotNull(apiPlaylist.update(login, playlist.getString("idt_playlist")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "notUpdatePublic", dependsOnMethods = { "create", "update" }, groups = { "playlist" })
    public void notUpdatePublic()
    {
        try
        {
            assertNotNull(apiPlaylist.notUpdatePublic(playlist.getString("idt_playlist")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "updateCharset", dependsOnMethods = { "createCharset", "update" }, groups = { "playlist" })
    public void updateCharset()
    {
        try
        {
            assertNotNull(apiPlaylist.updateCharset(login, playlist.getString("idt_playlist")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "detail", dependsOnMethods = { "update", "detailQs" }, groups = { "playlist" })
    public void detail()
    {
        try
        {
            assertNotNull(apiPlaylist.detail(login, playlist.getString("idt_playlist")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "detailQs", dependsOnMethods = { "update" }, groups = { "playlist" })
    public void detailQs()
    {
        try
        {
            assertNotNull(apiPlaylist.detailQs(login, playlist.getString("idt_playlist")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "detailPublic", dependsOnMethods = { "update", "detailPublicQs" }, groups = { "playlist" })
    public void detailPublic()
    {
        try
        {
            assertNotNull(apiPlaylist.detailPublic(playlist.getString("idt_playlist")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "detailPublicQs", dependsOnMethods = { "update" }, groups = { "playlist" })
    public void detailPublicQs()
    {
        try
        {
            assertNotNull(apiPlaylist.detailPublicQs(playlist.getString("idt_playlist")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "details", dependsOnMethods = { "update", "detailsQs" }, groups = { "playlist" })
    public void details()
    {
        try
        {
            listId = apiPlaylist.listPlaylistId(3);
            assertNotNull(apiPlaylist.details(login, listId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "detailsQs", dependsOnMethods = { "update" }, groups = { "playlist" })
    public void detailsQs()
    {
        try
        {
            listId = apiPlaylist.listPlaylistId(3);
            assertNotNull(apiPlaylist.detailsQs(login, listId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "detailsPublic", dependsOnMethods = { "update", "details", "detailsPublicQs" }, groups = { "playlist" })
    public void detailsPublic()
    {
        try
        {
            assertNotNull(apiPlaylist.detailsPublic(listId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "detailsPublicQs", dependsOnMethods = { "update", "details" }, groups = { "playlist" })
    public void detailsPublicQs()
    {
        try
        {
            assertNotNull(apiPlaylist.detailsPublicQs(listId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "apacheCache", dependsOnMethods = { "detail", "detailPublic", "detailPublicQs", "details", "detailsPublic" }, groups = { "playlist" })
    public void apacheCache()
    {
        try
        {
            assertTrue(apiPlaylist.apacheCache(login, playlist.getString("idt_playlist")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    //@Test(testName = "apacheCacheQs", dependsOnMethods = { "apacheCache" }, groups = { "playlist" })
    public void apacheCacheQs()
    {
        try
        {
            assertTrue(apiPlaylist.apacheCacheQs(login, playlist.getString("idt_playlist")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "notAddMediaPublic", dependsOnMethods = { "update" }, groups = { "playlist" })
    public void notAddMediaPublic()
    {
        try
        {
            media = apiPlaylist.mediaNotAdd(playlist.getString("idt_playlist"));
            assertNotNull(apiPlaylist.notAddMediaPublic(playlist.getString("idt_playlist"), Long.valueOf(media.getString("idt_media"))));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "addMedia", dependsOnMethods = { "update", "notAddMediaPublic" }, groups = { "playlist" })
    public void addMedia()
    {
        try
        {
            assertNotNull(apiPlaylist.addMedia(login, playlist.getString("idt_playlist"), Long.valueOf(media.getString("idt_media"))));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "listMediaPublic", dependsOnMethods = { "addMedia" }, groups = { "playlist" })
    public void listMediaPublic()
    {
        try
        {
            assertNotNull(apiPlaylist.listMediaPublic(playlist.getString("idt_playlist")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "listMedia", dependsOnMethods = { "addMedia" }, groups = { "playlist" })
    public void listMedia()
    {
        try
        {
            assertNotNull(apiPlaylist.listMedia(login, playlist.getString("idt_playlist")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "notMoveMediaPublic", dependsOnMethods = { "listMedia" }, groups = { "playlist" })
    public void notMoveMediaPublic()
    {
        try
        {
            assertNotNull(apiPlaylist.notMoveMediaPublic(login, playlist.getString("idt_playlist")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "moveMedia", dependsOnMethods = { "listMedia", "notMoveMediaPublic" }, groups = { "playlist" })
    public void moveMedia()
    {
        try
        {
            assertNotNull(apiPlaylist.moveMedia(login, playlist.getString("idt_playlist")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "addMedia", "listMedia", "moveMedia" }, groups = { "playlist" })
    public void notRemoveMediaPublic()
    {
        try
        {
            assertNotNull(apiPlaylist.notRemoveMediaPublic(playlist.getString("idt_playlist"), Long.valueOf(media.getString("idt_media"))));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "addMedia", "listMedia", "moveMedia", "notRemoveMediaPublic" }, groups = { "playlist" })
    public void removeMedia()
    {
        try
        {
            assertNotNull(apiPlaylist.removeMedia(login, playlist.getString("idt_playlist"), Long.valueOf(media.getString("idt_media"))));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "updateCharset", "update", "list", "detail", "details", "removeMedia" }, groups = { "playlist" })
    public void notRemovePublic()
    {
        try
        {
            assertNotNull(apiPlaylist.notRemovePublic(playlist.getString("idt_playlist")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "updateCharset", "update", "list", "detail", "details", "removeMedia", "notRemovePublic" }, groups = { "playlist" })
    public void remove()
    {
        try
        {
            assertNotNull(apiPlaylist.remove(login, playlist.getString("idt_playlist")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    // @Test demora muito
    public void createFull()
    {
        try
        {
            assertTrue(apiPlaylist.createFull(login));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }
}
