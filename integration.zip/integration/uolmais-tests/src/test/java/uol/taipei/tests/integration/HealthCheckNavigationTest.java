/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         18/02/2015 Criacao inicial
 */

package uol.taipei.tests.integration;

import static org.junit.Assert.*;

import org.testng.annotations.*;

import uol.taipei.request.FacileRequest;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.content.HealthCheckNavigation;

@Test(groups = "health_check_navigation")
public class HealthCheckNavigationTest extends AbstractTest
{
    private HealthCheckNavigation healthCheckContent = null;
    private FacileRequest request = null;

    @BeforeClass
    public void init() throws Exception
    {
        setUp(ENVIRONMENT);

        healthCheckContent = new HealthCheckNavigation();
        request = new FacileRequest();
    }

    @AfterClass
    public void finish()
    {
        request = null;
        healthCheckContent = null;
    }

    @Test
    public void probe()
    {
        try
        {
            assertTrue(healthCheckContent.probe(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }
}
