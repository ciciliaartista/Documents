/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * pcassiano                        	 19 de jun de 2017	Criacao inicial
 */

package uol.taipei.tests.integration;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import uol.taipei.request.FacileRequest;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.drakkar.ApiV4Player;
import uol.taipei.tests.util.RequestUtil;

@Test(groups = "api_v4_player_ssl")
public class ApiV4PlayerSslTest extends AbstractTest
{
    private ApiV4Player apiV4Player = null;

    private FacileRequest request = null;

    private String mediaId = null;

    @BeforeClass
    public void init() throws Exception
    {
        setUp(ENVIRONMENT);

        apiV4Player = new ApiV4Player(true);
        mediaId = RequestUtil.mediaIdPublic("V");
        request = new FacileRequest();

        request.configureSSL();
    }

    @AfterClass
    public void finish()
    {
        apiV4Player = null;
        request = null;
        mediaId = null;
    }

    @Test
    public void configPlayerVideo()
    {
        try
        {
            assertNotNull(apiV4Player.configPlayer(mediaId, request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void dataPlayerVideo()
    {
        try
        {
            assertNotNull(apiV4Player.dataPlayer(mediaId, request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void publicPermission()
    {
        try
        {
            assertNotNull(apiV4Player.publicPermission(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void restrictNobodyViewPermission()
    {
        try
        {
            assertNotNull(apiV4Player.restrictNobodyViewPermission(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void restrictFriendViewPermission()
    {
        try
        {
            assertNotNull(apiV4Player.restrictFriendViewPermission(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void restrictDraftPermission()
    {
        try
        {
            assertNotNull(apiV4Player.restrictDraftPermission(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void restrictSubscriberPermission()
    {
        try
        {
            assertNotNull(apiV4Player.restrictSubscriberPermission(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void restrictProductPermission()
    {
        try
        {
            assertNotNull(apiV4Player.restrictProductPermission(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void restrictRemovedPermission()
    {
        try
        {
            assertNotNull(apiV4Player.restrictRemovedPermission(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }
}
