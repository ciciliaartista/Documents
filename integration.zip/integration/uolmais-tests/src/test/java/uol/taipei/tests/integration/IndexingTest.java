/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         26/09/2014 Criacao inicial
 */

package uol.taipei.tests.integration;

import static org.junit.Assert.*;

import org.json.JSONObject;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.indexer.Indexing;
import uol.taipei.tests.util.JsonUtil;
import uol.taipei.tests.util.RequestUtil;
import uol.taipei.webServiceClient.WSReturn;

/**
 * @author tsardinha
 * 
 *         mvn integration-test -Pindexing
 */

@Test(groups = "indexing")
public class IndexingTest extends AbstractTest
{
    private Indexing indexing = null;
    private String mediaId = null;

    @BeforeClass
    public void init() throws Exception
    {
        setUp(ENVIRONMENT);

        indexing = new Indexing();
        WSReturn wsprofile = JsonUtil.profile(envConfig().getUser());

        if (wsprofile != null && wsprofile.getObjResponse() != null)
        {
            mediaId = RequestUtil.mediaIdPublic("V", wsprofile.getObjResponse().getLong("codProfileHash"));
        }

        if (mediaId == null)
        {
            JSONObject ret = JsonUtil.publicProfileLogin(envConfig().getUser());

            if (ret != null && ret.has("codProfileHash"))
            {
                mediaId = RequestUtil.mediaIdPublic("V", ret.getLong("codProfileHash"));
            }
        }

        if (mediaId == null)
        {
            mediaId = RequestUtil.mediaIdPublic("V");
        }
    }

    @AfterClass
    public void finish()
    {
        mediaId = null;
        indexing = null;
    }

    @Test(testName = "getDocument", groups = { "indexing" })
    public void getDocument()
    {
        try
        {
            assertNotNull(indexing.getDocument(Long.valueOf(mediaId)));
        }
        catch (Exception e)
        {
            assertNotNull(e.getMessage(), null);
        }
    }

    @Test(testName = "removeDocument", dependsOnMethods = { "getDocument" }, groups = { "indexing" })
    public void removeDocument()
    {
        try
        {
            assertTrue(indexing.removeDocument(Long.valueOf(mediaId)));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "addDocument", dependsOnMethods = { "getDocument", "removeDocument" }, groups = { "indexing" })
    public void addDocument()
    {
        try
        {
            assertTrue(indexing.addDocument(Long.valueOf(mediaId)));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "removeMedia", dependsOnMethods = { "getDocument", "removeDocument", "addDocument" }, groups = { "indexing" })
    public void removeMedia()
    {
        try
        {
            assertTrue(indexing.removeMedia(Long.valueOf(mediaId)));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "addMedia", dependsOnMethods = { "removeMedia" }, groups = { "indexing" })
    public void addMedia()
    {
        try
        {
            assertTrue(indexing.addMedia(Long.valueOf(mediaId)));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }
}
