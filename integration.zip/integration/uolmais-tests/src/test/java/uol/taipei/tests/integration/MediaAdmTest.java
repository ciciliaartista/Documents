/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         21/07/2014 Criacao inicial
 */

package uol.taipei.tests.integration;

import static org.junit.Assert.*;

import org.json.JSONObject;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import uol.taipei.request.FacileRequest;
import uol.taipei.request.UsefulRequest;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.LoginCookie;
import uol.taipei.tests.LoginRadius;
import uol.taipei.tests.moderation.MediaAdm;
import uol.taipei.tests.util.JsonUtil;

@Test(groups = "media_adm")
public class MediaAdmTest extends AbstractTest
{
    private MediaAdm mediaAdm = null;
    private LoginCookie login = null;
    private UsefulRequest loginR = null;
    private JSONObject media = null;
    private FacileRequest request = null;

    @BeforeClass
    public void init() throws Exception
    {
        setUp(ENVIRONMENT);

        mediaAdm = new MediaAdm();
        loginR = new LoginRadius(envConfig().getUserRadius(), envConfig().getPassRadius());
        login = new LoginCookie(envConfig().getUser(), envConfig().getPass());

        media = JsonUtil.mediaNoRestrictByParam("types=V&codProfile=" + login.getJsonProfile().getJSONObject("item").getString("codProfile"));

        if (media == null)
        {
            media = JsonUtil.mediaNoRestrict("V");
        }

        request = new FacileRequest();

        availability(request, "http://videos.intranet.uol.com.br/probe");

        try
        {
            loginR.get("http://videos.intranet.uol.com.br/maisAdm/mediaAdm");
        }
        catch (Exception e)
        {

        }
    }

    @AfterClass
    public void finish() throws Exception
    {
        updateContentStatus(media.getLong("mediaId"), 10, 2);

        login = null;
        loginR = null;
        media = null;
        request = null;
        mediaAdm = null;
    }

    @Test
    public void home()
    {
        try
        {
            assertNotNull(mediaAdm.home(loginR));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void show()
    {
        try
        {
            assertNotNull(mediaAdm.show(loginR));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void media()
    {
        try
        {
            assertNotNull(mediaAdm.media(loginR, String.valueOf(media.getLong("mediaId")), false));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void mediaByHashId()
    {
        try
        {
            assertNotNull(mediaAdm.media(loginR, media.getString("id"), true));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void codProfile()
    {
        try
        {
            assertNotNull(mediaAdm.codProfile(loginR, login.getJsonProfile()));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "updateEditorialStatus", groups = {"media_adm"})
    public void updateEditorialStatus()
    {
        try
        {
            assertNotNull(mediaAdm.updateEditorialStatus(loginR, media.getLong("mediaId")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "reprove", groups = {"media_adm"})
    public void reprove()
    {
        try
        {
            assertNotNull(mediaAdm.reprove(loginR, media.getLong("mediaId")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void updateHot()
    {
        try
        {
            assertNotNull(mediaAdm.updateHot(loginR, media.getLong("mediaId")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void updateFeatured()
    {
        try
        {
            assertNotNull(mediaAdm.updateFeatured(loginR, media.getLong("mediaId")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "fileBlock", dependsOnMethods = { "updateEditorialStatus", "reprove" }, groups = {"media_adm"})
    public void fileBlock()
    {
        try
        {
            assertNotNull(mediaAdm.fileBlock(loginR, media.getLong("mediaId")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }
}
