package uol.taipei.tests.integration;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.LoginCookie;
import uol.taipei.tests.playlist.ApiPlaylistErr;

public class ApiPlaylistErrTest extends AbstractTest
{
    private ApiPlaylistErr apiPlaylistErr = null;
    private LoginCookie login = null;

    @BeforeClass
    public void init() throws Exception
    {
        setUp(ENVIRONMENT);

        apiPlaylistErr = new ApiPlaylistErr();
        login = new LoginCookie(envConfig().getUser(), envConfig().getPass());
    }

    @AfterClass
    public void finish()
    {
        login = null;
        apiPlaylistErr = null;
    }

    @Test(testName = "invalidUrl", groups = { "CRUD Playlist Err" })
    public void invalidUrl()
    {
        try
        {
            assertTrue(apiPlaylistErr.invalidUrl());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "detailWithoutParam", groups = { "CRUD Playlist Err" })
    public void detailWithoutParam()
    {
        try
        {
            assertTrue(apiPlaylistErr.detailWithoutParam());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "detailWithInvalidPlaylistId", groups = { "CRUD Playlist Err" })
    public void detailWithInvalidPlaylistId()
    {
        try
        {
            assertTrue(apiPlaylistErr.detailWithInvalidPlaylistId());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "listWithoutParam", groups = { "CRUD Playlist Err" })
    public void listWithoutParam()
    {
        try
        {
            assertTrue(apiPlaylistErr.listWithoutParam());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "listWithInvalidMedia", groups = { "CRUD Playlist Err" })
    public void listWithInvalidMedia()
    {
        try
        {
            assertTrue(apiPlaylistErr.listWithInvalidMedia(login.getJsonProfile().getJSONObject("item").getString("codProfile")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "listWithInvalidIndexParam", groups = { "CRUD Playlist Err" })
    public void listWithInvalidIndexParam()
    {
        try
        {
            assertTrue(apiPlaylistErr.listWithInvalidIndexParam(login.getJsonProfile().getJSONObject("item").getString("codProfile")));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "createWithoutParam", groups = { "CRUD Playlist Err" })
    public void createWithoutParam()
    {
        try
        {
            assertNotNull(apiPlaylistErr.createWithoutParam(login));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "updateWithInvalidPlaylistId", groups = { "CRUD Playlist Err" })
    public void updateWithInvalidPlaylistId()
    {
        try
        {
            assertNotNull(apiPlaylistErr.updateWithInvalidPlaylistId(login));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "removeWithInvalidPlaylistId", groups = { "CRUD Playlist Err" })
    public void removeWithInvalidPlaylistId()
    {
        try
        {
            assertNotNull(apiPlaylistErr.removeWithInvalidPlaylistId(login));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "listMediaWithInvalidPlaylistId", groups = { "CRUD Playlist Err" })
    public void listMediaWithInvalidPlaylistId()
    {
        try
        {
            assertNotNull(apiPlaylistErr.listMediaWithInvalidPlaylistId(login));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "addMediaWithInvalidPlaylistId", groups = { "CRUD Playlist Err" })
    public void addMediaWithInvalidPlaylistId()
    {
        try
        {
            assertNotNull(apiPlaylistErr.addMediaWithInvalidPlaylistId(login));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "moveMediaWithInvalidPlaylistId", groups = { "CRUD Playlist Err" })
    public void moveMediaWithInvalidPlaylistId()
    {
        try
        {
            assertNotNull(apiPlaylistErr.moveMediaWithInvalidPlaylistId(login));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(testName = "removeMediaWithInvalidPlaylistId", groups = { "CRUD Playlist Err" })
    public void removeMediaWithInvalidPlaylistId()
    {
        try
        {
            assertNotNull(apiPlaylistErr.removeMediaWithInvalidPlaylistId(login));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

}
