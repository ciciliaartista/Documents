/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         10/06/2014 Criacao inicial
 */

package uol.taipei.tests.integration;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import uol.taipei.request.FacileRequest;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.LoginCookie;
import uol.taipei.tests.publish.ApiPublish;
import uol.taipei.tests.util.RequestUtil;

@Test(groups = "publish")
public class ApiPublishTest extends AbstractTest
{
    private ApiPublish apiPublish = null;
    private LoginCookie login = null;
    private String mediaId = null;
    private FacileRequest request = null;

    @BeforeClass
    public void init() throws Exception
    {
        setUp(ENVIRONMENT);

        apiPublish = new ApiPublish();
        request = new FacileRequest();

        availability(request, "http://beta.mais.uol.com.br/probe");

        login = new LoginCookie(envConfig().getUser(), envConfig().getPass());
        mediaId = RequestUtil.mediaId("V", login.getJsonProfile().getJSONObject("item").getLong("codProfileHash"));
    }

    @AfterClass
    public void finish() throws Exception
    {
        updateContentStatus(Long.valueOf(mediaId), 10, 2);

        login = null;
        mediaId = null;
        request = null;
        apiPublish = null;
    }

    @Test
    public void publishErr()
    {
        try
        {
            assertNotNull(apiPublish.publishErr(login));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void noLoggedUpVidRedir()
    {
        try
        {
            assertTrue(apiPublish.noLoggedUpVidRedir());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void noLoggedUpPodRedir()
    {
        try
        {
            assertTrue(apiPublish.noLoggedUpPodRedir());
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void notPublishVideoNoLogged()
    {
        try
        {
            assertTrue(apiPublish.notPublishVideoNoLogged(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void notPublishAudioNoLogged()
    {
        try
        {
            assertTrue(apiPublish.notPublishAudioNoLogged(request));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void publishVideo()
    {
        try
        {
            assertNotNull(apiPublish.publishVideo(login));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void publishAudio()
    {
        try
        {
            assertNotNull(apiPublish.publishAudio(login));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void publishThumb()
    {
        try
        {
            assertNotNull(apiPublish.publishThumb(login));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void authorTags()
    {
        try
        {
            assertNotNull(apiPublish.authorTags(login));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void adminPage()
    {
        try
        {
            assertNotNull(apiPublish.adminPage(login));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void statusVideo()
    {
        try
        {
            assertNotNull(apiPublish.statusVideo(login, mediaId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void statusAudio()
    {
        try
        {
            assertNotNull(apiPublish.statusAudio(login));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void statusErrInvalidOwner()
    {
        try
        {
            assertTrue(apiPublish.statusErrInvalidOwner(login));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void updateErrInvalidOwner()
    {
        try
        {
            assertTrue(apiPublish.updateErrInvalidOwner(login));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void update()
    {
        try
        {
            assertNotNull(apiPublish.update(login, mediaId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test(dependsOnMethods = { "statusVideo", "updateData", "updateCharset", "updateSpecialCharacters", "updateVisible", "updateHot",
                              "updateCountry", "updateProduct", "updateInfos", "updateAuthorizeList", "updateSubscriber", "updateEmbed", "update" })
    public void remove()
    {
        try
        {
            assertNotNull(apiPublish.remove(login, mediaId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void updateData()
    {
        try
        {
            assertNotNull(apiPublish.updateData(login, mediaId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void updateCharset()
    {
        try
        {
            assertNotNull(apiPublish.updateCharset(login, mediaId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void updateSpecialCharacters()
    {
        try
        {
            assertNotNull(apiPublish.updateSpecialCharacters(login, mediaId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void updateVisible()
    {
        try
        {
            assertNotNull(apiPublish.updateVisible(login, mediaId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void updateHot()
    {
        try
        {
            assertNotNull(apiPublish.updateHot(login, mediaId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void updateCountry()
    {
        try
        {
            assertNotNull(apiPublish.updateCountry(login, mediaId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void updateProduct()
    {
        try
        {
            assertNotNull(apiPublish.updateProduct(login, mediaId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void updateInfos()
    {
        try
        {
            assertNotNull(apiPublish.updateInfos(login, mediaId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void updateAuthorizeList()
    {
        try
        {
            assertNotNull(apiPublish.updateAuthorizeList(login, mediaId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void updateSubscriber()
    {
        try
        {
            assertNotNull(apiPublish.updateSubscriber(login, mediaId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void updateEmbed()
    {
        try
        {
            assertNotNull(apiPublish.updateEmbed(login, mediaId));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void defaultConfig()
    {
        try
        {
            assertNotNull(apiPublish.defaultConfig(login));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }

    @Test
    public void presetVideo()
    {
        try
        {
            assertNotNull(apiPublish.presetVideo(login));
        }
        catch (Exception e)
        {
            assertFalse(e.getMessage(), true);
        }
    }
}
