/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         25/07/2016 Criacao inicial
 */

package uol.taipei.tests.drakkar;

import java.security.KeyManagementException;

import org.apache.http.HttpStatus;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uol.taipei.request.FacileRequest;
import uol.taipei.request.FacileResponse;
import uol.taipei.request.JsonRequest;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.util.JsonUtil;
import uol.taipei.tests.util.TestUtil;

public class ApiV3Error extends AbstractTest
{
    static final Logger logger = LoggerFactory.getLogger(ApiV3Error.class);

    public static void main(String[] args)
    {
        if (!verifyParams(args))
        {
            return;
        }

        setUp(args[0]);

        if (envConfig().getUser() == null || envConfig().getUser().equals("") || envConfig().getPass() == null
                || envConfig().getPass().equals(""))
        {
            System.err.println("Invalid user " + envConfig().getUser());
            return;
        }

        logger.debug("-------------------------------------------------");
        logger.debug("tests api v3 error");

        try
        {
            ApiV3Error apiV3Err = new ApiV3Error(false, false);

            apiV3Err.detailQsNoParam();
            apiV3Err.detailNoParam();
            apiV3Err.detailQsInvalidParam();
            apiV3Err.detailInvalidParam();
            apiV3Err.detailNotFound();
            apiV3Err.detailQsNotFound();
            
            apiV3Err.formatsInvalidParam();
            apiV3Err.formatsQsInvalidParam();
            apiV3Err.formatsNoParam();
            apiV3Err.formatsQsNoParam();
            apiV3Err.formatsNotFound();
            apiV3Err.formatsQsNotFound();

            apiV3Err.listCodProfileNoParam();
            apiV3Err.listCodProfileNotFound();
            apiV3Err.listCurrentPageInvalidParam();
            apiV3Err.listCurrentPageNoParam();
            apiV3Err.listItemsPerPageInvalidParam();
            apiV3Err.listItemsPerPageNoParam();
            apiV3Err.listTypesInvalidParam();
            apiV3Err.listTypesNoParam();
            apiV3Err.listPublisherTypeInvalidParam();
            apiV3Err.listPublisherTypeNoParam();
            apiV3Err.listAdultInvalidParam();
            apiV3Err.listAdultNoParam();
            apiV3Err.listRelatedInvalidParam();
            apiV3Err.listRelatedNoParam();
            apiV3Err.listSubscriberInvalidParam();
            apiV3Err.listSubscriberNoParam();
            apiV3Err.listFormatInvalidParam();
            apiV3Err.listFormatNoParam();
            apiV3Err.listTagNamesNotFound();
            apiV3Err.listTagNamesNoParam();
            apiV3Err.listTagIdsInvalidParam();
            apiV3Err.listTagIdsNoParam();
            apiV3Err.listTagServiceNotFound();
            apiV3Err.listTagServiceNoParam();
            apiV3Err.listSortInvalidParam();
            apiV3Err.listSortNoParam();
            apiV3Err.listEditorialStatusInvalidParam();
            apiV3Err.listEditorialStatusNoParam();
            apiV3Err.listDateInvalidParam();
            apiV3Err.listDateNoParam();
            apiV3Err.listFollowableInvalidParam();
            apiV3Err.listFollowableNoParam();
            apiV3Err.listPublishIntervalNoParam();
            apiV3Err.listMediaRelatedIdNoParam();
            apiV3Err.listModerationGroupNoParam();
            apiV3Err.listDurationNoParam();
            apiV3Err.listPeriodStartNoParam();
            apiV3Err.listPeriodEndNoParam();
            apiV3Err.listEditorGroupNoParam();
            apiV3Err.listQryTagNoParam();
            apiV3Err.listQryTagSrvNoParam();

        }
        catch (Exception e)
        {
            logger.error(e.getMessage());
        }
    }

    private static FacileRequest request = null;

    /**
     * construtor
     * 
     * @param isSSL define http ou https
     * @param useSRV dominio interno ou publico
     * @throws Exception
     * @throws KeyManagementException
     */
    public ApiV3Error(boolean isSSL, boolean useSRV) throws Exception
    {
        this.isSSL = isSSL;
        this.host = "http" + (isSSL ? "s" : "") + "://"
                + (useSRV ? envConfig().getGlobal().getUrlapisrv() : envConfig().getGlobal().getUrlapi());

        if (isSSL)
        {
            request = new FacileRequest();
            request.configureSSL();
        }
    }

    /**
     * construtor
     * 
     * @param url dominio para executar testes
     */
    public ApiV3Error(String url)
    {
        this.host = url;
    }

    public boolean detailQsNoParam() throws Exception
    {
        JSONObject jsonResponse = execRequest(host + "/apiuol/v3/media/detail?mediaId=");

        if (!validateResponseNotOKJson(jsonResponse, HttpStatus.SC_BAD_REQUEST))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean detailNoParam() throws Exception
    {
        JSONObject jsonResponse = execRequest(host + "/apiuol/v3/media/detail/");

        if (!validateResponseNotOKJson(jsonResponse, HttpStatus.SC_BAD_REQUEST))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean detailQsInvalidParam() throws Exception
    {
        JSONObject jsonResponse = execRequest(host + "/apiuol/v3/media/detail?mediaId=x");

        if (!validateResponseNotOKJson(jsonResponse, HttpStatus.SC_BAD_REQUEST))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean detailInvalidParam() throws Exception
    {
        JSONObject jsonResponse = execRequest(host + "/apiuol/v3/media/detail/x");

        if (!validateResponseNotOKJson(jsonResponse, HttpStatus.SC_BAD_REQUEST))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean detailNotFound() throws Exception
    {
        JSONObject jsonResponse = execRequest(host + "/apiuol/v3/media/detail/0");

        if (!validateResponseNotOKJson(jsonResponse, HttpStatus.SC_NOT_FOUND))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean detailQsNotFound() throws Exception
    {
        JSONObject jsonResponse = execRequest(host + "/apiuol/v3/media/detail?mediaId=0");

        if (!validateResponseNotOKJson(jsonResponse, HttpStatus.SC_NOT_FOUND))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean formatsNoParam() throws Exception
    {
        JSONObject jsonResponse = execRequest(host + "/apiuol/v3/media/format/");

        if (!validateResponseNotOKJson(jsonResponse, HttpStatus.SC_BAD_REQUEST))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean formatsQsNoParam() throws Exception
    {
        JSONObject jsonResponse = execRequest(host + "/apiuol/v3/media/format?mediaId=");

        if (!validateResponseNotOKJson(jsonResponse, HttpStatus.SC_BAD_REQUEST))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean formatsNotFound() throws Exception
    {
        JSONObject jsonResponse = execRequest(host + "/apiuol/v3/media/format/0");

        if (!validateResponseNotOKJson(jsonResponse, HttpStatus.SC_NOT_FOUND))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean formatsQsNotFound() throws Exception
    {
        JSONObject jsonResponse = execRequest(host + "/apiuol/v3/media/format?mediaId=0");

        if (!validateResponseNotOKJson(jsonResponse, HttpStatus.SC_NOT_FOUND))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean formatsInvalidParam() throws Exception
    {
        JSONObject jsonResponse = execRequest(host + "/apiuol/v3/media/format/x");

        if (!validateResponseNotOKJson(jsonResponse, HttpStatus.SC_BAD_REQUEST))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean formatsQsInvalidParam() throws Exception
    {
        JSONObject jsonResponse = execRequest(host + "/apiuol/v3/media/format?mediaId=x");

        if (!validateResponseNotOKJson(jsonResponse, HttpStatus.SC_BAD_REQUEST))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean listCodProfileNoParam() throws Exception
    {
        JSONObject jsonResponse = execRequest(host + "/apiuol/v3/media/list?codProfile=");

        if (!validateResponseNotOKJson(jsonResponse, HttpStatus.SC_BAD_REQUEST))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean listCodProfileNotFound() throws Exception
    {
        JSONObject jsonResponse = execRequest(host + "/apiuol/v3/media/list?codProfile=xxxxxxxxxxxx");

        if (!validateResponseNotOKJson(jsonResponse, HttpStatus.SC_NOT_FOUND))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean listItemsPerPageNoParam() throws Exception
    {
        JSONObject jsonResponse = execRequest(host + "/apiuol/v3/media/list?itemsPerPage=");

        if (!validateResponseNotOKJson(jsonResponse, HttpStatus.SC_BAD_REQUEST))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean listItemsPerPageInvalidParam() throws Exception
    {
        JSONObject jsonResponse = execRequest(host + "/apiuol/v3/media/list?itemsPerPage=x");

        if (!validateResponseNotOKJson(jsonResponse, HttpStatus.SC_BAD_REQUEST))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean listCurrentPageNoParam() throws Exception
    {
        JSONObject jsonResponse = execRequest(host + "/apiuol/v3/media/list/page/");

        if (!validateResponseNotOKJson(jsonResponse, HttpStatus.SC_BAD_REQUEST))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean listCurrentPageInvalidParam() throws Exception
    {
        JSONObject jsonResponse = execRequest(host + "/apiuol/v3/media/list/page/x");

        if (!validateResponseNotOKJson(jsonResponse, HttpStatus.SC_BAD_REQUEST))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean listTypesInvalidParam() throws Exception
    {
        JSONObject jsonResponse = execRequest(host + "/apiuol/v3/media/list?types=x");

        if (!validateResponseNotOKJson(jsonResponse, HttpStatus.SC_BAD_REQUEST))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean listTypesNoParam() throws Exception
    {
        JSONObject jsonResponse = execRequest(host + "/apiuol/v3/media/list?types=");

        if (!validateResponseNotOKJson(jsonResponse, HttpStatus.SC_BAD_REQUEST))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean listPublisherTypeInvalidParam() throws Exception
    {
        JSONObject jsonResponse = execRequest(host + "/apiuol/v3/media/list?publisherType=x");

        if (!validateResponseNotOKJson(jsonResponse, HttpStatus.SC_BAD_REQUEST))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean listPublisherTypeNoParam() throws Exception
    {
        JSONObject jsonResponse = execRequest(host + "/apiuol/v3/media/list?publisherType=");

        if (!validateResponseNotOKJson(jsonResponse, HttpStatus.SC_BAD_REQUEST))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean listAdultInvalidParam() throws Exception
    {
        JSONObject jsonResponse = execRequest(host + "/apiuol/v3/media/list?adult=x");

        if (!validateResponseNotOKJson(jsonResponse, HttpStatus.SC_BAD_REQUEST))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean listAdultNoParam() throws Exception
    {
        JSONObject jsonResponse = execRequest(host + "/apiuol/v3/media/list?adult=");

        if (!validateResponseNotOKJson(jsonResponse, HttpStatus.SC_BAD_REQUEST))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean listRelatedInvalidParam()
    {
        try
        {
            JSONObject jsonResponse = execRequest(host + "/apiuol/v3/media/list?relatedList=true&mediaRelatedId=x");

            if (!validateResponseNotOKJson(jsonResponse, HttpStatus.SC_BAD_REQUEST))
            {
                logger.error("ERROR - return not valid - " + jsonResponse);
                return false;
            }

            logger.debug("SUCCESS");

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return false;
        }
    }

    public boolean listRelatedNoParam()
    {
        try
        {

            JSONObject jsonResponse = execRequest(host + "/apiuol/v3/media/list?relatedList=true&mediaRelatedId=");

            if (!validateResponseNotOKJson(jsonResponse, HttpStatus.SC_BAD_REQUEST))
            {
                logger.error("ERROR - return not valid - " + jsonResponse);
                return false;
            }

            logger.debug("SUCCESS");

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return false;
        }
    }

    public boolean listSubscriberInvalidParam() throws Exception
    {
        JSONObject jsonResponse = execRequest(host + "/apiuol/v3/media/list?subscriber=x");

        if (!validateResponseNotOKJson(jsonResponse, HttpStatus.SC_BAD_REQUEST))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean listSubscriberNoParam() throws Exception
    {
        JSONObject jsonResponse = execRequest(host + "/apiuol/v3/media/list?subscriber=");

        if (!validateResponseNotOKJson(jsonResponse, HttpStatus.SC_BAD_REQUEST))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean listFormatInvalidParam() throws Exception
    {
        JSONObject jsonResponse = execRequest(host + "/apiuol/v3/media/list?format=x");

        if (!validateResponseNotOKJson(jsonResponse, HttpStatus.SC_BAD_REQUEST))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean listFormatNoParam() throws Exception
    {
        JSONObject jsonResponse = execRequest(host + "/apiuol/v3/media/list?format=");

        if (!validateResponseNotOKJson(jsonResponse, HttpStatus.SC_BAD_REQUEST))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean listTagNamesNotFound() throws Exception
    {
        String tagName = TestUtil.randomString(6);
        JSONArray jsonTag = JsonUtil.tag(tagName);

        while (jsonTag != null)
        {
            tagName = TestUtil.randomString(6);
            jsonTag = JsonUtil.tag(tagName);
        }

        JSONObject jsonResponse = execRequest(host + "/apiuol/v3/media/list?tagNames=" + tagName);

        if (!validateResponseNotOKJson(jsonResponse, HttpStatus.SC_NOT_FOUND))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean listTagNamesNoParam() throws Exception
    {
        JSONObject jsonResponse = execRequest(host + "/apiuol/v3/media/list?tagNames=");

        if (!validateResponseNotOKJson(jsonResponse, HttpStatus.SC_BAD_REQUEST))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean listTagIdsInvalidParam() throws Exception
    {
        JSONObject jsonResponse = execRequest(host + "/apiuol/v3/media/list?tagIds=x");

        if (!validateResponseNotOKJson(jsonResponse, HttpStatus.SC_BAD_REQUEST))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean listTagIdsNoParam() throws Exception
    {
        JSONObject jsonResponse = execRequest(host + "/apiuol/v3/media/list?tagIds=");

        if (!validateResponseNotOKJson(jsonResponse, HttpStatus.SC_BAD_REQUEST))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean listTagServiceNotFound() throws Exception
    {
        JSONObject jsonResponse = execRequest(host + "/apiuol/v3/media/list?tagSrvIds=x");

        if (!validateResponseNotOKJson(jsonResponse, HttpStatus.SC_NOT_FOUND))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean listTagServiceNoParam() throws Exception
    {
        JSONObject jsonResponse = execRequest(host + "/apiuol/v3/media/list?tagSrvIds=");

        if (!validateResponseNotOKJson(jsonResponse, HttpStatus.SC_BAD_REQUEST))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean listSortInvalidParam() throws Exception
    {
        JSONObject jsonResponse = execRequest(host + "/apiuol/v3/media/list?sort=x");

        if (!validateResponseNotOKJson(jsonResponse, HttpStatus.SC_BAD_REQUEST))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean listSortNoParam() throws Exception
    {
        JSONObject jsonResponse = execRequest(host + "/apiuol/v3/media/list?sort=");

        if (!validateResponseNotOKJson(jsonResponse, HttpStatus.SC_BAD_REQUEST))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean listEditorialStatusInvalidParam() throws Exception
    {
        JSONObject jsonResponse = execRequest(host + "/apiuol/v3/media/list?editorialStatus=x");

        if (!validateResponseNotOKJson(jsonResponse, HttpStatus.SC_BAD_REQUEST))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean listEditorialStatusNoParam() throws Exception
    {
        JSONObject jsonResponse = execRequest(host + "/apiuol/v3/media/list?editorialStatus=");

        if (!validateResponseNotOKJson(jsonResponse, HttpStatus.SC_BAD_REQUEST))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean listDateInvalidParam() throws Exception
    {
        JSONObject jsonResponse = execRequest(host + "/apiuol/v3/media/list?date=x");

        if (!validateResponseNotOKJson(jsonResponse, HttpStatus.SC_BAD_REQUEST))
        {
            logger.error("ERROR - json not valid from media list - " + jsonResponse);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean listDateNoParam() throws Exception
    {
        JSONObject jsonResponse = execRequest(host + "/apiuol/v3/media/list?date=");

        if (!validateResponseNotOKJson(jsonResponse, HttpStatus.SC_BAD_REQUEST))
        {
            logger.error("ERROR - json not valid from media list - " + jsonResponse);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean listFollowableInvalidParam() throws Exception
    {
        JSONObject jsonResponse = execRequest(host + "/apiuol/v3/media/list?followableId=x");

        if (!validateResponseNotOKJson(jsonResponse, HttpStatus.SC_BAD_REQUEST))
        {
            logger.error("ERROR - json not valid from media list - " + jsonResponse);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean listFollowableNoParam() throws Exception
    {
        JSONObject jsonResponse = execRequest(host + "/apiuol/v3/media/list?followableId=");

        if (!validateResponseNotOKJson(jsonResponse, HttpStatus.SC_BAD_REQUEST))
        {
            logger.error("ERROR - json not valid from media list - " + jsonResponse);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean listQryTagSrvNoParam() throws Exception
    {
        JSONObject jsonResponse = execRequest(host + "/apiuol/v3/media/list?tagSrvIds=1&qryTagSrv=");

        if (!validateResponseNotOKJson(jsonResponse, HttpStatus.SC_BAD_REQUEST))
        {
            logger.error("ERROR - json not valid from media list - " + jsonResponse);
            return false;
        }

        logger.debug("SUCCESS");

        return true;

    }

    public boolean listQryTagNoParam() throws Exception
    {
        JSONObject jsonResponse = execRequest(host + "/apiuol/v3/media/list?tagIds=1&qryTag=");

        if (!validateResponseNotOKJson(jsonResponse, HttpStatus.SC_BAD_REQUEST))
        {
            logger.error("ERROR - json not valid from media list - " + jsonResponse);
            return false;
        }

        logger.debug("SUCCESS");

        return true;

    }

    public boolean listEditorGroupNoParam() throws Exception
    {
        JSONObject jsonResponse = execRequest(host + "/apiuol/v3/media/list?editorGroup=");

        if (!validateResponseNotOKJson(jsonResponse, HttpStatus.SC_BAD_REQUEST))
        {
            logger.error("ERROR - json not valid from media list - " + jsonResponse);
            return false;
        }

        logger.debug("SUCCESS");

        return true;

    }

    public boolean listPeriodEndNoParam() throws Exception
    {
        JSONObject jsonResponse = execRequest(host + "/apiuol/v3/media/list?periodEnd=");

        if (!validateResponseNotOKJson(jsonResponse, HttpStatus.SC_BAD_REQUEST))
        {
            logger.error("ERROR - json not valid from media list - " + jsonResponse);
            return false;
        }

        logger.debug("SUCCESS");

        return true;

    }

    public boolean listPeriodStartNoParam() throws Exception
    {
        JSONObject jsonResponse = execRequest(host + "/apiuol/v3/media/list?periodStart=");

        if (!validateResponseNotOKJson(jsonResponse, HttpStatus.SC_BAD_REQUEST))
        {
            logger.error("ERROR - json not valid from media list - " + jsonResponse);
            return false;
        }

        logger.debug("SUCCESS");

        return true;

    }

    public boolean listDurationNoParam() throws Exception
    {
        JSONObject jsonResponse = execRequest(host + "/apiuol/v3/media/list?duration=");

        if (!validateResponseNotOKJson(jsonResponse, HttpStatus.SC_BAD_REQUEST))
        {
            logger.error("ERROR - json not valid from media list - " + jsonResponse);
            return false;
        }

        logger.debug("SUCCESS");

        return true;

    }

    public boolean listModerationGroupNoParam() throws Exception
    {
        JSONObject jsonResponse = execRequest(host + "/apiuol/v3/media/list?moderationGroup=");

        if (!validateResponseNotOKJson(jsonResponse, HttpStatus.SC_BAD_REQUEST))
        {
            logger.error("ERROR - json not valid from media list - " + jsonResponse);
            return false;
        }

        logger.debug("SUCCESS");

        return true;

    }

    public boolean listMediaRelatedIdNoParam() throws Exception
    {
        JSONObject jsonResponse = execRequest(host + "/apiuol/v3/media/list?mediaRelatedId=");

        if (!validateResponseNotOKJson(jsonResponse, HttpStatus.SC_BAD_REQUEST))
        {
            logger.error("ERROR - json not valid from media list - " + jsonResponse);
            return false;
        }

        logger.debug("SUCCESS");

        return true;

    }

    public boolean listPublishIntervalNoParam() throws Exception
    {
        JSONObject jsonResponse = execRequest(host + "/apiuol/v3/media/list?publishInterval=");

        if (!validateResponseNotOKJson(jsonResponse, HttpStatus.SC_BAD_REQUEST))
        {
            logger.error("ERROR - json not valid from media list - " + jsonResponse);
            return false;
        }

        logger.debug("SUCCESS");

        return true;

    }

    private JSONObject execRequest(String url) throws Exception
    {
        if (isSSL)
        {
            FacileResponse response = request.get(url);

            return response.getJson();
        }
        else
        {
            return JsonRequest.get(url);
        }
    }

    private boolean validateResponseNotOKJson(JSONObject json, int httpStatus)
    {
        try
        {
            json.getJSONObject("response");
            json.getJSONObject("response").getInt("code");
            json.getJSONObject("response").getString("description");
            json.getJSONObject("response").getString("originalRequest");

            if (!json.has("error"))
            {
                logger.error("ERROR - response invalid - no error - " + json);
                return false;
            }

            if (!json.isNull("error"))
            {
                json.getJSONObject("error");
                json.getJSONObject("error").getString("message");
            }

            if (json.getJSONObject("response").getInt("code") != httpStatus)
            {
                logger.error("ERROR - response invalid - wrong code " + json);
                return false;
            }

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - response invalid - " + e.getMessage() + " - " + json);
            return false;
        }
    }
}
