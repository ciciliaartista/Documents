/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         04/04/2014 Criacao inicial
 */

package uol.taipei.tests;

import java.security.GeneralSecurityException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.net.ssl.SSLContext;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.client.CookieStore;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.cookie.Cookie;
import org.apache.http.cookie.CookieOrigin;
import org.apache.http.cookie.CookieSpec;
import org.apache.http.cookie.CookieSpecProvider;
import org.apache.http.cookie.MalformedCookieException;
import org.apache.http.impl.client.BasicCookieStore;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.cookie.DefaultCookieSpec;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HttpContext;
import org.apache.http.ssl.SSLContextBuilder;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uol.taipei.request.UsefulRequest;

public class LoginCookie extends UsefulRequest
{
    static final Logger logger = LoggerFactory.getLogger(LoginCookie.class);

    private JSONObject jsonProfile = null;
    private HashMap<String, String> headers = new HashMap<String, String>();
    private StringBuilder cookies = new StringBuilder();
    private int retry = 3;

    public LoginCookie(String user, String pass) throws Exception
    {
        createClientSSL(30);

        int i = 0;

        while (!isAuthenticated() && i < retry)
        {
            authenticate("https://acesso.uol.com.br/login.html?skin=uolmais", user, pass);
            i++;
        }

        if (!isAuthenticated())
        {
            logger.warn("try to login no skin");

            i = 0;

            while (!isAuthenticated() && i < retry)
            {
                authenticate("https://acesso.uol.com.br/login.html?dest=REDIR%7Chttp://mais.uol.com.br/sys/myPage",
                    user, pass);
                i++;
            }
        }

        if (!isAuthenticated())
        {
            logger.warn("try to login no redir");

            i = 0;

            while (!isAuthenticated() && i < retry)
            {
                authenticate("https://acesso.uol.com.br/login.html", user, pass);
                i++;
            }
        }
    }

    public String toString()
    {
        return "logged " + jsonProfile;
    }

    /**
     * configura ssl
     * 
     * @param timeout
     * @throws KeyStoreException
     * @throws NoSuchAlgorithmException
     * @throws KeyManagementException
     * @throws GeneralSecurityException
     */
    private void createClientSSL(int timeout) throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException
    {
        CookieStore cookieStore = new BasicCookieStore();
        Registry<CookieSpecProvider> r = RegistryBuilder.<CookieSpecProvider> create()
                .register("easy", new EasySpecProvider()).build();
        SSLContext sslContext = new SSLContextBuilder().loadTrustMaterial(null, (certificate, authType) -> true)
                .build();
        RequestConfig config = RequestConfig.custom().setCookieSpec("easy").setConnectTimeout(timeout * 1000)
                .setConnectionRequestTimeout(timeout * 1000).setSocketTimeout(timeout * 1000).build();
        client = HttpClients.custom().setDefaultCookieStore(cookieStore).setDefaultCookieSpecRegistry(r)
                .setDefaultRequestConfig(config).setSSLContext(sslContext)
                .setSSLHostnameVerifier(new NoopHostnameVerifier()).build();
    }

    class EasyCookieSpec extends DefaultCookieSpec
    {
        @Override
        public void validate(Cookie arg0, CookieOrigin arg1) throws MalformedCookieException
        {
            // allow all cookies
        }
    }

    class EasySpecProvider implements CookieSpecProvider
    {
        @Override
        public CookieSpec create(HttpContext context)
        {
            return new EasyCookieSpec();
        }
    }

    private void authenticate(String url, String user, String pass)
    {
        try
        {
            cookies.delete(0, cookies.length());
            headers.clear();

            HttpPost authPost = new HttpPost(url);
            List<BasicNameValuePair> nvps = new ArrayList<BasicNameValuePair>();

            nvps.add(new BasicNameValuePair("user", user));
            nvps.add(new BasicNameValuePair("pass", pass));

            authPost.setEntity(new UrlEncodedFormEntity(nvps, "UTF-8"));

            authPost.setHeader("Origin", "https://acesso.uol.com.br");
            authPost.setHeader("Accept-Encoding", "gzip,deflate,sdch");
            authPost.setHeader("Host", "acesso.uol.com.br");
            authPost.setHeader("Accept-Language", "en-US,en;q=0.8,pt;q=0.6");
            authPost.setHeader("User-Agent", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36");
            authPost.setHeader("Content-Type", "application/x-www-form-urlencoded");
            authPost.setHeader("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
            authPost.setHeader("Cache-Control", "max-age=0");
            authPost.setHeader("Referer", "https://acesso.uol.com.br/login.html?skin=uolmais&dest=REDIR|http://mais.uol.com.br/sys/myPage");

            HttpResponse responseLogin = client.execute(authPost);

            if (responseLogin == null)
            {
                logger.error("fail login");
            }

            final Header[] cookieHeaders = responseLogin.getHeaders("Set-Cookie");

            if (ArrayUtils.isEmpty(cookieHeaders))
            {
                logger.warn("no cookie");
            }

            for (Header h : cookieHeaders)
            {
                cookies.append(cookies.length() > 0 ? ";" : "");

                if (h.getValue().trim().startsWith("CAUBR01"))
                {
                    cookies.append(
                        StringUtils.substringBefore(h.getValue(), ";").replaceFirst("CAUBR01=", "CAUBR01=\"") + "\"");
                }
                else
                {
                    // cookies.append(StringUtils.substringBefore(h.getValue(), ";"));
                }
            }

            headers.put("Accept-Encoding", "gzip,deflate,sdch");
            headers.put("Host", "mais.uol.com.br");
            headers.put("Accept-Language", "en-US,en;q=0.8,pt;q=0.6");
            headers.put("User-Agent", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36");
            headers.put("Accept", "application/json, text/plain, */*");
            headers.put("Referer", "http://mais.uol.com.br/sys/myPage");
            headers.put("Connection", "keep-alive");
            headers.put("Cookie", cookies.toString());

            client = HttpClients.createDefault();

            if (isAuthenticated())
            {
                jsonProfile = getJson("http://mais.uol.com.br/apiuol/mobile/profile", headers);
            }
            else
            {
                logger.warn("could not authenticate " + user);
            }

            authPost.abort();
        }
        catch (Exception e)
        {
            logger.error(e.getMessage(), e);
        }
    }

    public boolean isAuthenticated()
    {
        JSONObject jsonResponse = null;

        try
        {
            jsonResponse = getJson("http://mais.uol.com.br/apiuol/v2/auth", headers);

            if (jsonResponse.has("response"))
            {
                return jsonResponse.getBoolean("authenticated");
            }
            else
            {
                logger.warn("json auth " + jsonResponse);
            }
        }
        catch (Exception e)
        {
            logger.error(e.getMessage() + " - " + jsonResponse, e);
            return false;
        }

        return false;
    }

    public JSONObject getJsonProfile()
    {
        return jsonProfile;
    }

    public JSONObject getjson(String url) throws Exception
    {
        return getJson(url, headers);
    }

    public JSONObject postjson(String url, HashMap<String, String> params) throws Exception
    {
        return postJson(url, headers, params, null);
    }

    public JSONObject postjson(String url, HashMap<String, String> params, java.io.File file) throws Exception
    {
        return postJson(url, headers, params, file);
    }

    public JSONObject postdatajson(String url, HashMap<String, String> params) throws Exception
    {
        return postDataJson(url, headers, params);
    }
}
