/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         19/03/2015 Criacao inicial
 */

package uol.taipei.tests;

public class GlobalConfig
{
    private int retry;
    private String urlnav;
    private String urlnavsrv;
    private String urlbus;
    private String urlbussrv;
    private String urlpub;
    private String urladm;
    private String urlmax;
    private String urlcro;
    private String urlcrosrv;
    private String urlapi;
    private String urlapisrv;
    private String urltask;

    public int getRetry()
    {
        return retry;
    }

    public void setRetry(int retry)
    {
        this.retry = retry;
    }

    public String getUrlnav()
    {
        return urlnav;
    }

    public void setUrlnav(String urlnav)
    {
        this.urlnav = urlnav;
    }

    public String getUrlnavsrv()
    {
        return urlnavsrv;
    }

    public void setUrlnavsrv(String urlnavsrv)
    {
        this.urlnavsrv = urlnavsrv;
    }

    public String getUrlbus()
    {
        return urlbus;
    }

    public String getUrlbussrv()
    {
        return urlbussrv;
    }

    public void setUrlbussrv(String urlbussrv)
    {
        this.urlbussrv = urlbussrv;
    }

    public void setUrlbus(String urlbus)
    {
        this.urlbus = urlbus;
    }

    public String getUrlpub()
    {
        return urlpub;
    }

    public void setUrlpub(String urlpub)
    {
        this.urlpub = urlpub;
    }

    public String getUrladm()
    {
        return urladm;
    }

    public void setUrladm(String urladm)
    {
        this.urladm = urladm;
    }

    public String getUrlmax()
    {
        return urlmax;
    }

    public void setUrlmax(String urlmax)
    {
        this.urlmax = urlmax;
    }

    public String getUrlcro()
    {
        return urlcro;
    }

    public void setUrlcro(String urlcro)
    {
        this.urlcro = urlcro;
    }

    public String getUrlcrosrv()
    {
        return urlcrosrv;
    }

    public void setUrlcrosrv(String urlcrosrv)
    {
        this.urlcrosrv = urlcrosrv;
    }

    public String getUrlapi()
    {
        return urlapi;
    }

    public void setUrlapi(String urlapi)
    {
        this.urlapi = urlapi;
    }

    public String getUrlapisrv()
    {
        return urlapisrv;
    }

    public void setUrlapisrv(String urlapisrv)
    {
        this.urlapisrv = urlapisrv;
    }
    
    public String getUrltask()
    {
        return urltask;
    }

    public void setUrltask(String urltask)
    {
        this.urltask = urltask;
    }
}
