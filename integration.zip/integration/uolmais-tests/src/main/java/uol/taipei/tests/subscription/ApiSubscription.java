/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         21/07/2014 Criacao inicial
 */

package uol.taipei.tests.subscription;

import java.io.IOException;
import java.util.Random;
import java.util.TreeSet;

import org.apache.http.HttpStatus;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uol.taipei.request.FacileRequest;
import uol.taipei.request.FacileResponse;
import uol.taipei.request.JsonRequest;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.LoginCookie;
import uol.taipei.tests.util.JsonUtil;
import uol.taipei.tests.util.TestUtil;
import uol.taipei.util.hash.HashCode;

public class ApiSubscription extends AbstractTest
{
    static final Logger logger = LoggerFactory.getLogger(ApiSubscription.class);

    public static void main(String[] args)
    {
        if (!verifyParams(args))
        {
            return;
        }

        setUp(args[0]);

        if (envConfig().getUser() == null || envConfig().getUser().equals("") || envConfig().getPass() == null
                || envConfig().getPass().equals(""))
        {
            System.err.println("Invalid user " + envConfig().getUser());
            return;
        }

        logger.debug("-------------------------------------------------");
        logger.debug("tests api subscription");

        try
        {
            ApiSubscription apiSubscription = new ApiSubscription();
            LoginCookie login = new LoginCookie(envConfig().getUser(), envConfig().getPass());
            FacileRequest request = new FacileRequest();
            Integer idtFollowable = apiSubscription.notFollowable(login);

            apiSubscription.subscribeById(login, idtFollowable);
            apiSubscription.verify(login, idtFollowable);
            apiSubscription.list();
            apiSubscription.listWithCurrentPageErr(request);
            apiSubscription.listWithItemsPerPageErr(request);
            apiSubscription.listByUser(login);
            apiSubscription.subscribers(login);
            apiSubscription.notViewedCount(login, idtFollowable);
            apiSubscription.lastViewedDate(login, idtFollowable);
            apiSubscription.lastViewedDateUpdate(login, idtFollowable);
            apiSubscription.unsubscribe(login, idtFollowable);
            apiSubscription.subscribeByProfile(login);

            apiSubscription.subscribeError(login);
            apiSubscription.subscribeByProfileError(login);
            apiSubscription.subscribeByIdError(login);
            apiSubscription.verifyError(login);
            apiSubscription.unsubscribeError(login);
            apiSubscription.verifyNotFound(login);
            apiSubscription.subscribersNotFound(login);
        }
        catch (Exception e)
        {
            logger.error(e.getMessage());
        }
    }

    public JSONObject subscribeByProfile(LoginCookie login) throws Exception
    {
        String codProfile = userNotFollowable(login);

        if (codProfile == null)
        {
            codProfile = userNotFollowableFromDB(login, 10, 10);
        }

        if (codProfile == null)
        {
            logger.info("codProfile not found");
            return null;
        }

        String url = "http://mais.uol.com.br/apiuol/v2/subscription/subscribe.json?codProfile=" + codProfile;
        JSONObject jsonResponse = login.getjson(url);

        if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") != 200)
        {
            logger.error("ERROR - invalid code response - " + jsonResponse.getJSONObject("_response").getInt("code")
                    + " - " + url);
            return null;
        }

        if (!validateMessageJson(jsonResponse, 'S'))
        {
            logger.error("ERROR - return not valid - " + codProfile + " - " + jsonResponse);
            return null;
        }

        // remove um seguivel por codProfile
        Integer idtFollowable = userFollowable(login);
        login.getjson("http://mais.uol.com.br/apiuol/v2/subscription/unsubscribe.json?idtFollowable=" + idtFollowable);

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject subscribeById(LoginCookie login, Integer idtFollowable) throws Exception
    {
        if (idtFollowable == null)
        {
            logger.info("idtFollowable not found");
            return null;
        }

        String url = "http://mais.uol.com.br/apiuol/v2/subscription/subscribe.json?idtFollowable=" + idtFollowable;
        JSONObject jsonResponse = login.getjson(url);

        if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") != 200)
        {
            logger.error("ERROR - invalid code response - " + jsonResponse.getJSONObject("_response").getInt("code")
                    + " - " + url);
            return null;
        }

        if (!validateMessageJson(jsonResponse, 'S'))
        {
            logger.error("ERROR - return not valid - " + idtFollowable + " - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject verify(LoginCookie login, Integer idtFollowable) throws Exception
    {
        if (idtFollowable == null)
        {
            logger.info("idtFollowable not found");
            return null;
        }

        String url = "http://mais.uol.com.br/apiuol/v2/subscription/verify.json?idtFollowable=" + idtFollowable;
        JSONObject jsonResponse = login.getjson(url);

        if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") != 200)
        {
            logger.error("ERROR - invalid code response - " + jsonResponse.getJSONObject("_response").getInt("code")
                    + " - " + url);
            return null;
        }

        if (!validateVerifyJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + idtFollowable + " - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject list() throws IOException, JSONException
    {
        JSONObject jsonResponse = JsonRequest.get("http://mais.uol.com.br/apiuol/v2/subscription/followable/list.json");

        if (jsonResponse.getJSONObject("_response").getInt("code") != 200)
        {
            logger.error("ERROR - invalid code response - " + jsonResponse.getJSONObject("_response").getInt("code"));
            return null;
        }

        if (!validateFollowListJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public boolean listWithCurrentPageErr(FacileRequest request) throws Exception
    {
        String url = "http://mais.uol.com.br/apiuol/v2/subscription/followable/list.json?index.currentPage=x";
        FacileResponse response = request.get(url);

        if (response.getCode() != HttpStatus.SC_BAD_REQUEST)
        {
            logger.error("ERROR - return status not valid - " + response.getCode() + " - " + url);
            return false;
        }

        logger.debug("SUCCESS");
        return true;
    }

    public boolean listWithItemsPerPageErr(FacileRequest request) throws Exception
    {
        String url = "http://mais.uol.com.br/apiuol/v2/subscription/followable/list.json?index.itemsPerPage=x";
        FacileResponse response = request.get(url);

        if (response.getCode() != HttpStatus.SC_BAD_REQUEST)
        {
            logger.error("ERROR - return status not valid - " + response.getCode() + " - " + url);
            return false;
        }

        logger.debug("SUCCESS");
        return true;
    }

    public JSONObject listByUser(LoginCookie login) throws Exception
    {
        JSONObject jsonResponse = login
                .getjson("http://mais.uol.com.br/apiuol/v2/subscription/followable/listByUser.json");

        if (jsonResponse == null || (jsonResponse.getJSONObject("_response").getInt("code") != 200 
                &&  jsonResponse.getJSONObject("_response").getInt("code") != 204))
        {
            logger.error("ERROR - invalid code response - " + jsonResponse);
            return null;
        }

        if (jsonResponse.getJSONObject("_response").getInt("code") == 200 && !validateUserFollowListJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject listByUserSort(LoginCookie login) throws Exception
    {
        JSONObject jsonResponse = login
                .getjson("http://mais.uol.com.br/apiuol/v2/subscription/followable/listByUser.json?sort=update");

        if (jsonResponse == null || (jsonResponse.getJSONObject("_response").getInt("code") != 200
                && jsonResponse.getJSONObject("_response").getInt("code") != 204))
        {
            logger.error("ERROR - invalid code response - " + jsonResponse.getJSONObject("_response").getInt("code"));
            return null;
        }

        if (jsonResponse.getJSONObject("_response").getInt("code") == 200 && !validateUserFollowListJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject unsubscribe(LoginCookie login, Integer idtFollowable) throws Exception
    {
        if (idtFollowable == null)
        {
            logger.info("idtFollowable not found");
            return null;
        }

        String url = "http://mais.uol.com.br/apiuol/v2/subscription/unsubscribe.json?idtFollowable=" + idtFollowable;
        JSONObject jsonResponse = login.getjson(url);

        if (jsonResponse.getJSONObject("_response").getInt("code") != 200)
        {
            logger.error("ERROR - invalid code response - " + jsonResponse.getJSONObject("_response").getInt("code")
                    + " - " + url);
            return null;
        }

        if (!validateMessageJson(jsonResponse, 'S'))
        {
            logger.error("ERROR - return not valid - " + idtFollowable + " - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject subscribers(LoginCookie login) throws Exception
    {
        JSONObject jsonResponse = login.getjson("http://mais.uol.com.br/apiuol/v2/subscription/subscribers/list.json");

        if (jsonResponse.getJSONObject("_response").getInt("code") != 200
                && jsonResponse.getJSONObject("_response").getInt("code") != 204)
        {
            logger.error("ERROR - invalid code response - " + jsonResponse.getJSONObject("_response").getInt("code"));
            return null;
        }

        if (jsonResponse.getJSONObject("_response").getInt("code") != 204 && !validateSubscListJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject notViewedCount(LoginCookie login, Integer idtFollowable) throws Exception
    {
        String url = "http://mais.uol.com.br/apiuol/v2/subscription/followable/" + idtFollowable
                + "/notViewed/count.json";
        JSONObject jsonResponse = login.getjson(url);

        if (jsonResponse.getJSONObject("_response").getInt("code") != 200)
        {
            logger.error("ERROR - invalid code response - " + jsonResponse.getJSONObject("_response").getInt("code")
                    + " - " + url);
            return null;
        }

        try
        {
            jsonResponse.getJSONObject("followableData");
            jsonResponse.getJSONObject("followableData").getString("codProfile");
            jsonResponse.getJSONObject("followableData").getInt("notViewedQtty");
            jsonResponse.getJSONObject("followableData").getInt("idtFollowable");
        }
        catch (Exception e)
        {
            logger.error("ERROR - return not valid - " + e.getMessage() + " - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject lastViewedDate(LoginCookie login, Integer idtFollowable) throws Exception
    {
        String url = "http://mais.uol.com.br/apiuol/v2/subscription/followable/" + idtFollowable
                + "/lastViewedDate.json";
        JSONObject jsonResponse = login.getjson(url);

        if (jsonResponse.getJSONObject("_response").getInt("code") != 200)
        {
            logger.error("ERROR - invalid code response - " + jsonResponse.getJSONObject("_response").getInt("code")
                    + " - " + url);
            return null;
        }

        try
        {
            jsonResponse.getJSONObject("followableData");
            jsonResponse.getJSONObject("followableData").getString("codProfile");
            jsonResponse.getJSONObject("followableData").getString("lastViewedDate");
            jsonResponse.getJSONObject("followableData").getInt("idtFollowable");
        }
        catch (Exception e)
        {
            logger.error("ERROR - return not valid - " + e.getMessage() + " - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject lastViewedDateUpdate(LoginCookie login, Integer idtFollowable) throws Exception
    {
        String url = "http://mais.uol.com.br/apiuol/v2/subscription/followable/" + idtFollowable
                + "/lastViewedDate.json";
        JSONObject jsonResponse = login.postDataJson(url, null);

        if (jsonResponse.getJSONObject("_response").getInt("code") != 200)
        {
            logger.error("ERROR - invalid code response - " + jsonResponse.getJSONObject("_response").getInt("code")
                    + " - " + url);
            return null;
        }

        try
        {
            jsonResponse.getJSONObject("followableData");
            jsonResponse.getJSONObject("followableData").getString("codProfile");
            jsonResponse.getJSONObject("followableData").getInt("idtFollowable");
        }
        catch (Exception e)
        {
            logger.error("ERROR - return not valid - " + e.getMessage() + " - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject subscribeError(LoginCookie login) throws Exception
    {
        JSONObject jsonResponse = login.getjson("http://mais.uol.com.br/apiuol/v2/subscription/subscribe.json");

        if (jsonResponse.getJSONObject("_response").getInt("code") != 400)
        {
            logger.error("ERROR - invalid code response - " + jsonResponse.getJSONObject("_response").getInt("code"));
            return null;
        }

        if (!validateMessageJson(jsonResponse, 'E'))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject subscribeByProfileError(LoginCookie login) throws Exception
    {
        String codProfile = TestUtil.randomString(12);
        JSONObject profile = JsonUtil.fullProfile(codProfile);

        while (profile != null && profile.has("maker") && profile.getJSONObject("maker").has("profile"))
        {
            codProfile = TestUtil.randomString(12);
            profile = JsonUtil.fullProfile(codProfile);
        }

        JSONObject jsonResponse = login
                .getjson("http://mais.uol.com.br/apiuol/v2/subscription/subscribe.json?codProfile=" + codProfile);

        if (jsonResponse.getJSONObject("_response").getInt("code") != 404)
        {
            logger.error("ERROR - invalid code response - " + jsonResponse.getJSONObject("_response").getInt("code"));
            return null;
        }

        if (!validateMessageJson(jsonResponse, 'W'))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject subscribeByIdError(LoginCookie login) throws Exception
    {
        Random r = new Random();
        Integer idtFollowable = r.nextInt();
        JSONObject result = JsonRequest.execQuery("SELECT idt_followable FROM followable WHERE idt_followable = "
                + idtFollowable);

        while (result != null && result.getJSONArray("data").length() > 0)
        {
            idtFollowable = r.nextInt();
            result = JsonRequest.execQuery("SELECT idt_followable FROM followable WHERE idt_followable = " 
                    + idtFollowable);
        }

        JSONObject jsonResponse = login.getjson("http://mais.uol.com.br/apiuol/v2/subscription/subscribe.json?idtFollowable=" 
                + idtFollowable);

        if (jsonResponse.getJSONObject("_response").getInt("code") != 404
                && jsonResponse.getJSONObject("_response").getInt("code") != 400)
        {
            logger.error("ERROR - invalid code response - " + jsonResponse.getJSONObject("_response").getInt("code"));
            return null;
        }

        char messageType = (jsonResponse.getJSONObject("_response").getInt("code") == 400 ? 'E' : 'W');

        if (!validateMessageJson(jsonResponse, messageType))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject verifyError(LoginCookie login) throws Exception
    {
        JSONObject jsonResponse = login
                .getjson("http://mais.uol.com.br/apiuol/v2/subscription/verify.json?idtFollowable=x");

        if (jsonResponse.getJSONObject("_response").getInt("code") != 400)
        {
            logger.error("ERROR - invalid code response - " + jsonResponse.getJSONObject("_response").getInt("code"));
            return null;
        }

        if (!validateMessageJson(jsonResponse, 'E'))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject unsubscribeError(LoginCookie login) throws Exception
    {
        JSONObject jsonResponse = login
                .getjson("http://mais.uol.com.br/apiuol/v2/subscription/unsubscribe.json?idtFollowable=x");

        if (jsonResponse.getJSONObject("_response").getInt("code") != 400)
        {
            logger.error("ERROR - invalid code response - " + jsonResponse.getJSONObject("_response").getInt("code"));
            return null;
        }

        if (!validateMessageJson(jsonResponse, 'E'))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject unsubscribeNotFound(LoginCookie login) throws Exception
    {
        JSONObject jsonResponse = login
                .getjson("http://mais.uol.com.br/apiuol/v2/subscription/unsubscribe.json?idtFollowable=0");

        if (jsonResponse.getJSONObject("_response").getInt("code") != 404)
        {
            logger.error("ERROR - invalid code response - " + jsonResponse.getJSONObject("_response").getInt("code"));
            return null;
        }

        if (!validateMessageJson(jsonResponse, 'W'))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject verifyNotFound(LoginCookie login) throws Exception
    {
        JSONObject jsonResponse = login
                .getjson("http://mais.uol.com.br/apiuol/v2/subscription/verify.json?idtFollowable=0");

        if (jsonResponse.getJSONObject("_response").getInt("code") != 404)
        {
            logger.error("ERROR - invalid code response - " + jsonResponse.getJSONObject("_response").getInt("code"));
            return null;
        }

        if (!validateMessageJson(jsonResponse, 'W'))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject subscribersNotFound(LoginCookie login) throws Exception
    {
        JSONObject jsonResponse = login
                .getjson("http://mais.uol.com.br/apiuol/v2/subscription/subscribers/list.json?index.currentPage=9999");

        if (jsonResponse.getJSONObject("_response").getInt("code") != 204)
        {
            logger.error("ERROR - invalid code response - " + jsonResponse.getJSONObject("_response").getInt("code"));
            return null;
        }

        if (jsonResponse.getJSONObject("_response").getInt("code") != 204 && !validateMessageJson(jsonResponse, 'W'))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    private boolean isThereAny(LoginCookie login) throws Exception
    {
        JSONObject jsonResponse = login
                .getjson("http://mais.uol.com.br/apiuol/v2/subscription/followable/listByUser.json");

        return jsonResponse.has("followableCollection")
                && jsonResponse.getJSONObject("followableCollection").getJSONArray("followables").length() > 0;
    }

    public Integer notFollowable(LoginCookie login) throws Exception
    {
        boolean any = isThereAny(login);
        Integer idtFollowable = null;
        String url = "http://mais.uol.com.br/apiuol/v2/subscription/followable/list.json?index.currentPage=";
        int page = 1;
        JSONObject followableList = JsonRequest.get(url + page);

        while (followableList.has("followableCollection")
                && followableList.getJSONObject("followableCollection").getJSONArray("followables").length() > 0)
        {
            if (!any)
            {
                return followableList.getJSONObject("followableCollection").getJSONArray("followables")
                        .getJSONObject(0).getInt("idtFollowable");
            }

            for (int i = 0; i < followableList.getJSONObject("followableCollection").getJSONArray("followables")
                    .length(); i++)
            {
                idtFollowable = followableList.getJSONObject("followableCollection").getJSONArray("followables")
                        .getJSONObject(i).getInt("idtFollowable");

                if (!isFollowable(login, idtFollowable))
                {
                    return idtFollowable;
                }
            }

            page++;
            followableList = JsonRequest.get(url + page);
        }

        return null;
    }

    private boolean isFollowable(LoginCookie login, Integer idtFollowable) throws Exception
    {
        String url = "http://mais.uol.com.br/apiuol/v2/subscription/followable/listByUser.json?index.currentPage=";
        int page = 1;
        JSONObject jsonResponse = login.getjson(url + page);

        while (jsonResponse.has("followableCollection")
                && jsonResponse.getJSONObject("followableCollection").getJSONArray("followables").length() > 0)
        {
            if (containsFollowable(jsonResponse.getJSONObject("followableCollection").getJSONArray("followables"),
                idtFollowable))
            {
                return true;
            }

            page++;
            jsonResponse = login.getjson(url + page);
        }

        return false;
    }

    private boolean containsFollowable(JSONArray arrayFollowable, Integer idtFollowable) throws Exception
    {
        for (int i = 0; i < arrayFollowable.length(); i++)
        {
            if (arrayFollowable.getJSONObject(i).getInt("idtFollowable") == idtFollowable)
            {
                return true;
            }
        }

        return false;
    }

    private String userNotFollowable(LoginCookie login) throws Exception
    {
        boolean any = isThereAny(login);
        String codProfile;
        String url = "http://mais.uol.com.br/apiuol/v2/media/list?index.itemsPerPage=100&index.currentPage=";
        int page = 1;
        JSONObject mediaList = JsonRequest.get(url + page + "&nocache=" + Math.random());
        TreeSet<String> profiles = new TreeSet<String>();

        while (mediaList.getJSONArray("list").length() > 0)
        {
            for (int i = 0; i < mediaList.getJSONArray("list").length(); i++)
            {
                codProfile = mediaList.getJSONArray("list").getJSONObject(i).getString("codProfile");

                if (!any && !login.getJsonProfile().getJSONObject("item").getString("codProfile").equals(codProfile))
                {
                    return codProfile;
                }

                // Se o profile já foi checado somente continua.
                if (profiles.contains(codProfile))
                {
                    continue;
                }

                if (!isFollowable(login, codProfile) && 
                        !login.getJsonProfile().getJSONObject("item").getString("codProfile").equals(codProfile))
                {
                    return codProfile;
                }

                profiles.add(codProfile);
            }

            page++;
            mediaList = JsonRequest.get(url + page + "&nocache=" + Math.random());
        }

        return null;
    }

    private String userNotFollowableFromDB(LoginCookie login, int totalPage, int itemsPerPage) throws Exception
    {
        boolean any = isThereAny(login);
        String codProfile;
        String query = "SELECT DISTINCT cod_profile_hash FROM media WHERE cod_status = 10 AND ind_hot = 'N' AND flg_draft = 0 "
                + "AND ind_visibility = 'T' AND (ind_media_type = 'V' OR ind_media_type = 'P' OR ind_media_type = 'S' "
                + "OR ind_media_type = 'T') LIMIT ";
        int page = 1;
        TreeSet<String> profiles = new TreeSet<String>();

        JSONObject result = JsonRequest.execQuery(query + page + "," + itemsPerPage);

        while (page <= totalPage && result != null && result.getJSONArray("data").length() > 0)
        {
            for (int i = 0; i < result.getJSONArray("data").length(); i++)
            {
                codProfile = HashCode.decode(Long.parseLong(JsonUtil.getParam(result, "cod_profile_hash").toString()));

                if (!any && !login.getJsonProfile().getJSONObject("item").getString("codProfile").equals(codProfile))
                {
                    return codProfile;
                }

                // Se o profile já foi checado somente continua.
                if (profiles.contains(codProfile))
                {
                    continue;
                }

                if (!isFollowable(login, codProfile) && 
                        !login.getJsonProfile().getJSONObject("item").getString("codProfile").equals(codProfile))
                {
                    return codProfile;
                }

                profiles.add(codProfile);
            }

            page++;
            result = JsonRequest.execQuery(query + page + "," + itemsPerPage);
        }

        return null;
    }

    private boolean isFollowable(LoginCookie login, String codProfile) throws Exception
    {
        String url = "http://mais.uol.com.br/apiuol/v2/subscription/followable/listByUser.json?index.currentPage=";
        int page = 1;
        JSONObject jsonResponse = login.getjson(url + page);

        while (jsonResponse.has("followableCollection")
                && jsonResponse.getJSONObject("followableCollection").getJSONArray("followables").length() > 0)
        {
            if (containsFollowable(jsonResponse.getJSONObject("followableCollection").getJSONArray("followables"),
                codProfile))
            {
                return true;
            }

            page++;
            jsonResponse = login.getjson(url + page);
        }

        return false;
    }

    private Integer userFollowable(LoginCookie login) throws Exception
    {
        String url = "http://mais.uol.com.br/apiuol/v2/subscription/followable/listByUser.json?index.currentPage=";
        int page = 1;
        JSONObject jsonResponse = login.getjson(url + page);

        while (jsonResponse.has("followableCollection")
                && jsonResponse.getJSONObject("followableCollection").getJSONArray("followables").length() > 0)
        {
            for (int i = 0; i < jsonResponse.getJSONObject("followableCollection").getJSONArray("followables").length(); i++)
            {
                if (jsonResponse.getJSONObject("followableCollection").getJSONArray("followables").getJSONObject(i)
                        .has("codProfile"))
                {
                    return jsonResponse.getJSONObject("followableCollection").getJSONArray("followables")
                            .getJSONObject(i).getInt("idtFollowable");
                }
            }

            page++;
            jsonResponse = login.getjson(url + page);
        }

        return null;
    }

    private boolean containsFollowable(JSONArray arrayFollowable, String codProfile) throws Exception
    {
        for (int i = 0; i < arrayFollowable.length(); i++)
        {
            if (arrayFollowable.getJSONObject(i).has("codProfile")
                    && arrayFollowable.getJSONObject(i).getString("codProfile").equals(codProfile))
            {
                return true;
            }
        }

        return false;
    }

    private boolean validateVerifyJson(JSONObject jsonResponse) throws JSONException
    {
        try
        {
            jsonResponse.getJSONObject("subscription").getInt("idtSubscription");
            jsonResponse.getJSONObject("subscription").getString("codProfile");
            jsonResponse.getJSONObject("subscription").getLong("dateSubscription");
            jsonResponse.getJSONObject("subscription").getJSONObject("followable");
            jsonResponse.getJSONObject("subscription").getJSONObject("followable").getInt("idtFollowable");
            jsonResponse.getJSONObject("subscription").getJSONObject("followable").getBoolean("editorTag");

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - jsonVerifyList is not valid - " + e.getMessage() + " - " + jsonResponse);
            return false;
        }
    }

    private boolean validateFollowListJson(JSONObject jsonResponse) throws JSONException
    {
        try
        {
            jsonResponse.getJSONObject("followableCollection");
            jsonResponse.getJSONObject("followableCollection").getInt("numPages");
            jsonResponse.getJSONObject("followableCollection").getInt("total");
            jsonResponse.getJSONObject("followableCollection").getString("orderName");
            jsonResponse.getJSONObject("followableCollection").getJSONArray("followables");

            for (int i = 0; i < jsonResponse.getJSONObject("followableCollection").getJSONArray("followables").length(); i++)
            {
                jsonResponse.getJSONObject("followableCollection").getJSONArray("followables").getJSONObject(i).getInt(
                    "idtFollowable");
                jsonResponse.getJSONObject("followableCollection").getJSONArray("followables").getJSONObject(i).getInt(
                    "numSubscriptionQuantity");
                jsonResponse.getJSONObject("followableCollection").getJSONArray("followables").getJSONObject(i)
                        .getBoolean("flgManualRegisted");
                jsonResponse.getJSONObject("followableCollection").getJSONArray("followables").getJSONObject(i)
                        .getBoolean("flagAnd");
                jsonResponse.getJSONObject("followableCollection").getJSONArray("followables").getJSONObject(i)
                        .getBoolean("editorTag");

                if (jsonResponse.getJSONObject("followableCollection").getJSONArray("followables").getJSONObject(i)
                        .has("desFollowable"))
                {
                    jsonResponse.getJSONObject("followableCollection").getJSONArray("followables").getJSONObject(i)
                            .getString("desFollowable");
                }

                if (jsonResponse.getJSONObject("followableCollection").getJSONArray("followables").getJSONObject(i)
                        .has("idtEditorType"))
                {
                    jsonResponse.getJSONObject("followableCollection").getJSONArray("followables").getJSONObject(i)
                            .getInt("idtEditorType");
                }

                if (jsonResponse.getJSONObject("followableCollection").getJSONArray("followables").getJSONObject(i)
                        .has("codProfile"))
                {
                    jsonResponse.getJSONObject("followableCollection").getJSONArray("followables").getJSONObject(i)
                            .getString("codProfile");
                }
            }

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - jsonFollowList is not valid - " + e.getMessage() + " - " + jsonResponse);
            return false;
        }
    }

    private boolean validateUserFollowListJson(JSONObject jsonResponse) throws JSONException
    {
        try
        {
            jsonResponse.getJSONObject("followableCollection");
            jsonResponse.getJSONObject("followableCollection").getInt("numPages");
            jsonResponse.getJSONObject("followableCollection").getInt("total");
            jsonResponse.getJSONObject("followableCollection").getString("orderName");
            jsonResponse.getJSONObject("followableCollection").getJSONArray("followables");

            for (int i = 0; i < jsonResponse.getJSONObject("followableCollection").getJSONArray("followables").length(); i++)
            {
                jsonResponse.getJSONObject("followableCollection").getJSONArray("followables").getJSONObject(i).getInt(
                    "idtFollowable");
                jsonResponse.getJSONObject("followableCollection").getJSONArray("followables").getJSONObject(i).getInt(
                    "numSubscriptionQuantity");
                jsonResponse.getJSONObject("followableCollection").getJSONArray("followables").getJSONObject(i)
                        .getBoolean("flgManualRegisted");
                jsonResponse.getJSONObject("followableCollection").getJSONArray("followables").getJSONObject(i)
                        .getBoolean("flagAnd");
                jsonResponse.getJSONObject("followableCollection").getJSONArray("followables").getJSONObject(i)
                        .getBoolean("editorTag");

                if (jsonResponse.getJSONObject("followableCollection").getJSONArray("followables").getJSONObject(i)
                        .has("idtEditorType"))
                {
                    jsonResponse.getJSONObject("followableCollection").getJSONArray("followables").getJSONObject(i)
                            .getInt("idtEditorType");
                }

                if (jsonResponse.getJSONObject("followableCollection").getJSONArray("followables").getJSONObject(i)
                        .has("codProfile"))
                {
                    jsonResponse.getJSONObject("followableCollection").getJSONArray("followables").getJSONObject(i)
                            .getString("codProfile");
                }
            }

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - jsonFollowList is not valid - " + e.getMessage() + " - " + jsonResponse);
            return false;
        }
    }

    private boolean validateSubscListJson(JSONObject jsonResponse) throws JSONException
    {
        try
        {
            jsonResponse.getJSONObject("subscriptionCollection");
            jsonResponse.getJSONObject("subscriptionCollection").getInt("numPages");
            jsonResponse.getJSONObject("subscriptionCollection").getInt("total");
            jsonResponse.getJSONObject("subscriptionCollection").getString("orderName");
            jsonResponse.getJSONObject("subscriptionCollection").getJSONArray("subscriptions");

            for (int i = 0; i < jsonResponse.getJSONObject("subscriptionCollection").getJSONArray("subscriptions")
                    .length(); i++)
            {
                jsonResponse.getJSONObject("subscriptionCollection").getJSONArray("subscriptions").getJSONObject(i)
                        .getInt("idtSubscription");
                jsonResponse.getJSONObject("subscriptionCollection").getJSONArray("subscriptions").getJSONObject(i)
                        .getString("codProfile");
                jsonResponse.getJSONObject("subscriptionCollection").getJSONArray("subscriptions").getJSONObject(i)
                        .getInt("dateSubscription");
                jsonResponse.getJSONObject("subscriptionCollection").getJSONArray("subscriptions").getJSONObject(i)
                        .getJSONObject("followable");
                jsonResponse.getJSONObject("subscriptionCollection").getJSONArray("subscriptions").getJSONObject(i)
                        .getJSONObject("followable").getInt("idtFollowable");
                jsonResponse.getJSONObject("subscriptionCollection").getJSONArray("subscriptions").getJSONObject(i)
                        .getJSONObject("followable").getBoolean("editorTag");
            }

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - jsonSubsList is not valid - " + e.getMessage() + " - " + jsonResponse);
            return false;
        }
    }

    private boolean validateMessageJson(JSONObject json, char type)
    {
        try
        {
            json.getJSONObject("messages");

            if (type == 'S')
            {
                json.getJSONObject("messages").getJSONArray("success");

                if (json.getJSONObject("messages").getJSONArray("success").length() < 1)
                {
                    throw new Exception("no has success message");
                }

                for (int i = 0; i < json.getJSONObject("messages").getJSONArray("success").length(); i++)
                {
                    json.getJSONObject("messages").getJSONArray("success").getJSONObject(i).getString("id");
                    json.getJSONObject("messages").getJSONArray("success").getJSONObject(i).getString("description");

                    JsonUtil.validateValueJson(json.getJSONObject("messages").getJSONArray("success").getJSONObject(i),
                        new String[] { "" });
                }
            }
            else if (type == 'E')
            {
                json.getJSONObject("messages").getJSONArray("errors");

                if (json.getJSONObject("messages").getJSONArray("errors").length() < 1)
                {
                    throw new Exception("no has error message");
                }

                for (int i = 0; i < json.getJSONObject("messages").getJSONArray("errors").length(); i++)
                {
                    json.getJSONObject("messages").getJSONArray("errors").getJSONObject(i).getString("id");
                    json.getJSONObject("messages").getJSONArray("errors").getJSONObject(i).getString("description");

                    JsonUtil.validateValueJson(json.getJSONObject("messages").getJSONArray("errors").getJSONObject(i),
                        new String[] { "" });
                }
            }
            else if (type == 'W')
            {
                json.getJSONObject("messages").getJSONArray("warns");

                if (json.getJSONObject("messages").getJSONArray("warns").length() < 1)
                {
                    throw new Exception("no has warn message");
                }

                for (int i = 0; i < json.getJSONObject("messages").getJSONArray("warns").length(); i++)
                {
                    json.getJSONObject("messages").getJSONArray("warns").getJSONObject(i).getString("id");
                    json.getJSONObject("messages").getJSONArray("warns").getJSONObject(i).getString("description");

                    JsonUtil.validateValueJson(json.getJSONObject("messages").getJSONArray("warns").getJSONObject(i),
                        new String[] { "" });
                }
            }
            else
            {
                json.getJSONObject("messages").getJSONArray("infos");

                if (json.getJSONObject("messages").getJSONArray("infos").length() < 1)
                {
                    throw new Exception("no has info message");
                }

                for (int i = 0; i < json.getJSONObject("messages").getJSONArray("infos").length(); i++)
                {
                    json.getJSONObject("messages").getJSONArray("infos").getJSONObject(i).getString("id");
                    json.getJSONObject("messages").getJSONArray("infos").getJSONObject(i).getString("description");

                    JsonUtil.validateValueJson(json.getJSONObject("messages").getJSONArray("infos").getJSONObject(i),
                        new String[] { "" });
                }
            }

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - message invalid - " + e.getMessage() + " - " + json);
            return false;
        }
    }
}
