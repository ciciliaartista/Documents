/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         20/08/2014 Criacao inicial
 */

package uol.taipei.tests.task;

import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uol.taipei.request.FacileRequest;
import uol.taipei.request.FacileResponse;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.util.JsonUtil;
import uol.taipei.tests.util.RequestUtil;

public class Catraca extends AbstractTest
{
    static final Logger logger = LoggerFactory.getLogger(Catraca.class);

    private static Pattern path = Pattern.compile("(PATH=/[0-9A-Z]+/[0-9A-Z]+/[0-9A-Z]+/[0-9]+)");
    private static Pattern server = Pattern.compile("(SERVER=[0-9]+)");
    private static Pattern errorpath = Pattern.compile("(PATH=/thumb_erro_[a-z]+.jpg)");
    private static Pattern isError = Pattern.compile("(ERROR=[0-9]+)");
    private static Pattern auth = Pattern.compile("(PATH=.*)[\n\\s]*(SERVER=[0-9]+)[\n\\s]*(SERVERHOSTS=.*)[\n\\s]*(PUBLIC=[\\d]+)");

    public static void main(String[] args)
    {
        if (!verifyParams(args))
        {
            return;
        }

        setUp(args[0]);

        logger.debug("-------------------------------------------------");
        logger.debug("tests catraca");

        try
        {
            Catraca catraca = new Catraca();
            FacileRequest request = new FacileRequest();

            catraca.probe(request);

            catraca.publicVideo(request);
            catraca.publicPoscast(request);

            catraca.publicThumbVideo(request);

            catraca.restrictNobodyViewVideo(request);
            catraca.restrictRemovedStatusVideo(request);
            catraca.restrictDraftVideo(request);
            catraca.restrictSubscriberVideo(request);

            catraca.restrictNobodyViewThumbVideo(request);
            catraca.restrictRemovedStatusThumbVideo(request);
            catraca.restrictDraftThumbVideo(request);
            catraca.restrictSubscriberThumbVideo(request);

            catraca.errorMediaNotFound(request);
            catraca.errorNotFound(request);
        }
        catch (Exception e)
        {
            logger.error(e.getMessage());
        }
    }

    public boolean probe(FacileRequest request) throws Exception
    {
        FacileResponse response = request.get("http://catraca.mais.sys.srv.intranet:2180/object/service.html");

        if (response.getCode() != 200)
        {
            logger.error("ERROR - return not valid - " + response.getCode());
            return false;
        }

        if (!response.getBody().startsWith("OK"))
        {
            logger.error("ERROR - return not valid - " + response);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean publicVideo(FacileRequest request) throws Exception
    {
        String mediaId = RequestUtil.mediaIdPublic("V");
        FacileResponse response = request.get("http://catraca.mais.sys.srv.intranet:2180/object/service.html?url=" + mediaId
                + ".mp4");

        if (response.getCode() != 200)
        {
            logger.error("ERROR - return not valid - " + response.getCode());
            return false;
        }

        if (!path.matcher(response.getBody()).find() || !server.matcher(response.getBody()).find())
        {
            logger.error("ERROR - return not valid - " + mediaId + " - " + response.getBody().replace("\n", " "));
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean publicPoscast(FacileRequest request) throws Exception
    {
        String mediaId = RequestUtil.mediaIdPublic("P");
        FacileResponse response = request.get("http://catraca.mais.sys.srv.intranet:2180/object/service.html?url=" + mediaId
                + ".mp3");

        if (response.getCode() != 200)
        {
            logger.error("ERROR - return not valid - " + response.getCode());
            return false;
        }

        if (!path.matcher(response.getBody()).find() || !server.matcher(response.getBody()).find())
        {
            logger.error("ERROR - return not valid - " + mediaId + " - " + response.getBody().replace("\n", " "));
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean restrictNobodyViewVideo(FacileRequest request) throws Exception
    {
        Pattern path = Pattern.compile("(PATH=/vd_autor.mp4)");
        String mediaId = RequestUtil.mediaIdRestrict(10, "V", "N", false, false, false, false, false);
        String url = mediaId + ".mp4";
        FacileResponse response = request.get("http://catraca.mais.sys.srv.intranet:2180/object/service.html?url=" + url);

        if (response.getCode() != 200)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        if (!path.matcher(response.getBody()).find() || !server.matcher(response.getBody()).find()
                || !isError.matcher(response.getBody()).find())
        {
            logger.error("ERROR - return not valid - " + url + " - " + response.getBody().replace("\n", " "));
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean restrictRemovedStatusVideo(FacileRequest request) throws Exception
    {
        Pattern path = Pattern.compile("(PATH=/vd_remov-mais.mp4)");
        String mediaId = RequestUtil.mediaIdRestrictFile(20, "V", "T", false, false, false);
        String url = mediaId + ".mp4";
        FacileResponse response = request.get("http://catraca.mais.sys.srv.intranet:2180/object/service.html?url=" + url);

        if (response.getCode() != 200)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        if (!path.matcher(response.getBody()).find() || !server.matcher(response.getBody()).find()
                || !isError.matcher(response.getBody()).find())
        {
            logger.error("ERROR - return not valid - " + url + " - " + response.getBody().replace("\n", " "));
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean restrictDraftVideo(FacileRequest request) throws Exception
    {
        //Pattern path = Pattern.compile("(PATH=/vd_autor.mp4)");
        String mediaId = RequestUtil.mediaIdRestrict(10, "V", "T", true, false, false, false, false);
        String url = mediaId + ".mp4";
        FacileResponse response = request.get("http://catraca.mais.sys.srv.intranet:2180/object/service.html?url=" + url);

        if (response.getCode() != 200)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

//        if (!path.matcher(response.getBody()).find() || !fileServername.matcher(response.getBody()).find()
//                || !isError.matcher(response.getBody()).find())
//        {
//            logger.error("ERROR - return not valid - " + url + " - " + response.getBody().replace("\n", " "));
//            return false;
//        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean restrictSubscriberVideo(FacileRequest request) throws Exception
    {
        Pattern path = Pattern.compile("(PATH=/vd_exc-ass.mp4)");
        String mediaId = RequestUtil.mediaIdRestrict(10, "V", "T", false, true, false, false, false);
        String url = mediaId + ".mp4";
        FacileResponse response = request.get("http://catraca.mais.sys.srv.intranet:2180/object/service.html?url=" + url);

        if (response.getCode() != 200)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        if (!path.matcher(response.getBody()).find() || !server.matcher(response.getBody()).find()
                || !isError.matcher(response.getBody()).find())
        {
            logger.error("ERROR - return not valid - " + url + " - " + response.getBody().replace("\n", " "));
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean restrictProductVideo(FacileRequest request) throws Exception
    {
        //Pattern path = Pattern.compile("(PATH=/vd_product_perm.mp4)");
        Pattern path = Pattern.compile("(PATH=/vd_exc-ass.mp4)");
        String mediaId = RequestUtil.mediaIdRestrictProduct("V");
        String url = mediaId + ".mp4";
        FacileResponse response = request.get("http://catraca.mais.sys.srv.intranet:2180/object/service.html?url=" + url);

        if (response.getCode() != 200)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        if (!path.matcher(response.getBody()).find() || !server.matcher(response.getBody()).find()
                || !isError.matcher(response.getBody()).find())
        {
            logger.error("ERROR - return not valid - " + url + " - " + response.getBody().replace("\n", " "));
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean publicThumbVideo(FacileRequest request) throws Exception
    {
        JSONObject media = JsonUtil.mediaNoRestrict("V");
        FacileResponse response = null;
        String[] thumbs = new String[] {
                                        media.getString("thumbnail").substring(media.getString("thumbnail").lastIndexOf("/") + 1) + ".jpg",
                                        media.getString("thumbSmall").substring(media.getString("thumbSmall").lastIndexOf("/") + 1),
                                        media.getString("thumbMedium").substring(media.getString("thumbMedium").lastIndexOf("/") + 1),
                                        media.getString("thumbLarge").substring(media.getString("thumbLarge").lastIndexOf("/") + 1),
                                        media.getString("thumbWmedium").substring(media.getString("thumbWmedium").lastIndexOf("/") + 1),
                                        media.getString("thumbWlarge").substring(media.getString("thumbWlarge").lastIndexOf("/") + 1) };

        for (String url : thumbs)
        {
            response = request.get("http://catraca.mais.sys.srv.intranet:2180/object/service.html?url=" + url);

            if (response.getCode() != 200)
            {
                logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
                return false;
            }

            if (!path.matcher(response.getBody()).find() || !server.matcher(response.getBody()).find())
            {
                logger.error("ERROR - return not valid - " + url + " - " + response.getBody().replace("\n", " "));
                return false;
            }
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean restrictNobodyViewThumbVideo(FacileRequest request) throws Exception
    {
        String mediaId = RequestUtil.mediaIdRestrict(10, "V", "N", false, false, false, false, false);
        FacileResponse response = null;
        String[] thumbs = new String[] { mediaId + ".jpg", mediaId + "-small.jpg", mediaId + "-medium.jpg", mediaId + "-large.jpg",
                                        mediaId + "-wmedium.jpg", mediaId + "-wlarge.jpg" };

        for (String url : thumbs)
        {
            response = request.get("http://catraca.mais.sys.srv.intranet:2180/object/service.html?url=" + url);

            if (response.getCode() != 200)
            {
                logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
                return false;
            }

            if (!errorpath.matcher(response.getBody()).find() || !server.matcher(response.getBody()).find()
                    || !isError.matcher(response.getBody()).find())
            {
                logger.error("ERROR - return not valid - " + url + " - " + response.getBody().replace("\n", " "));
                return false;
            }
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean restrictRemovedStatusThumbVideo(FacileRequest request) throws Exception
    {
        String mediaId = RequestUtil.mediaIdRestrictFile(20, "V", "T", false, false, false);
        FacileResponse response = null;
        String[] thumbs = new String[] { mediaId + ".jpg", mediaId + "-small.jpg", mediaId + "-medium.jpg", mediaId + "-large.jpg",
                                        mediaId + "-wmedium.jpg", mediaId + "-wlarge.jpg" };

        for (String url : thumbs)
        {
            response = request.get("http://catraca.mais.sys.srv.intranet:2180/object/service.html?url=" + url);

            if (response.getCode() != 200)
            {
                logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
                return false;
            }

            if (!errorpath.matcher(response.getBody()).find() || !server.matcher(response.getBody()).find()
                    || !isError.matcher(response.getBody()).find())
            {
                logger.error("ERROR - return not valid - " + url + " - " + response.getBody().replace("\n", " "));
                return false;
            }
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean restrictDraftThumbVideo(FacileRequest request) throws Exception
    {
        String mediaId = RequestUtil.mediaIdRestrict(10, "V", "T", true, false, false, false, false);
        FacileResponse response = null;
        String[] thumbs = new String[] { mediaId + ".jpg", mediaId + "-small.jpg", mediaId + "-medium.jpg", mediaId + "-large.jpg",
                                        mediaId + "-wmedium.jpg", mediaId + "-wlarge.jpg" };

        for (String url : thumbs)
        {
            response = request.get("http://catraca.mais.sys.srv.intranet:2180/object/service.html?url=" + url);

            if (response.getCode() != 200)
            {
                logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
                return false;
            }

//            if (!errorpath.matcher(response.getBody()).find() || !thumbServername.matcher(response.getBody()).find()
//                    || !isError.matcher(response.getBody()).find())
//            {
//                logger.error("ERROR - return not valid - " + url + " - " + response.getBody().replace("\n", " "));
//                return false;
//            }
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean restrictSubscriberThumbVideo(FacileRequest request) throws Exception
    {
        String mediaId = RequestUtil.mediaIdRestrict(10, "V", "T", false, true, false, false, false);
        FacileResponse response = null;
        String[] thumbs = new String[] { mediaId + ".jpg", mediaId + "-small.jpg", mediaId + "-medium.jpg", mediaId + "-large.jpg",
                                        mediaId + "-wmedium.jpg", mediaId + "-wlarge.jpg" };

        for (String url : thumbs)
        {
            response = request.get("http://catraca.mais.sys.srv.intranet:2180/object/service.html?url=" + url);

            if (response.getCode() != 200)
            {
                logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
                return false;
            }

            if (!path.matcher(response.getBody()).find() || !server.matcher(response.getBody()).find())
            {
                logger.error("ERROR - return not valid - " + url + " - " + response.getBody().replace("\n", " "));
                return false;
            }
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean errorMediaNotFound(FacileRequest request) throws Exception
    {
        FacileResponse response = request.getNoBody("http://catraca.mais.sys.srv.intranet:2180/object/service?url=0.");

        if (response.getCode() != 404)
        {
            logger.error("ERROR - return not valid - " + response.getCode());
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean errorNotFound(FacileRequest request) throws Exception
    {
        FacileResponse response = request.getNoBody("http://catraca.mais.sys.srv.intranet:2180/object/service?url=x.");

        if (response.getCode() != 404)
        {
            logger.error("ERROR - return not valid - " + response.getCode());
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    /**
     * sem acesso as maquinas de storage aX-nomar/namorY.host.intranet
     * 
     * @param request
     * @return boolean
     * @throws Exception
     */
    public boolean authVideo(FacileRequest request) throws Exception
    {
        String mediaId = RequestUtil.mediaIdPublic("V");
        FacileResponse response = request.get("http://catraca.mais.sys.srv.intranet:2180/object/service.html?url=" + mediaId
                + ".mp4");

        if (response.getCode() != 200)
        {
            logger.error("ERROR - return not valid - " + response.getCode());
            return false;
        }

        if (!path.matcher(response.getBody()).find() || !server.matcher(response.getBody()).find())
        {
            logger.error("ERROR - return not valid - " + mediaId + " - " + response.getBody().replace("\n", " "));
            return false;
        }

        HashMap<String, String> map = authMatch(response.getBody());

        if (map == null)
        {
            logger.error("ERROR - response is not valid");
            return false;
        }

        String[] hosts = map.get("hosts").split(",");

        if (hosts == null || hosts.length != 2)
        {
            logger.error("ERROR - response is not valid - invalid hosts");
            return false;
        }

        String u = null;

        for (String h : hosts)
        {
            u = "http://" + h + map.get("path");
            response = request.get(u);

            if (response.getCode() != 200)
            {
                logger.error("ERROR - return not valid - " + response.getCode() + " - " + u);
                return false;
            }
        }

        logger.debug("SUCCESS");

        return true;
    }

    private HashMap<String, String> authMatch(String response)
    {
        Matcher m = auth.matcher(response);

        if (m.matches()) 
        {
            HashMap<String, String> map = new HashMap<String, String>();

            map.put("path", m.group(1));
            map.put("server", m.group(2));
            map.put("hosts", m.group(3));
            map.put("public", m.group(4));

            return map;
        }

        return null;
    }
}
