/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         04/09/2014 Criacao inicial
 */

package uol.taipei.tests;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONObject;

import uol.taipei.request.JsonRequest;
import uol.taipei.tests.util.JsonUtil;
import uol.taipei.tests.util.TestUtil;
import uol.taipei.webServiceClient.WSReturn;

public class MultiUploadApi
{
    private static final Map<String, String> TYPES = new HashMap<String, String>();

    static
    {
        TYPES.put("P", "audio");
        TYPES.put("V", "video");
    }

    private static final Map<String, String> EXT = new HashMap<String, String>();

    static
    {
        EXT.put("V", ".mp4");
        EXT.put("P", ".mp3");
    }

    public static void main(String[] args)
    {
        if (args == null || args.length < 1)
        {
            System.out.println("no codProfileHash");
            return;
        }

        List<java.io.File> fileList = null;
        HashMap<String, String> params = new HashMap<String, String>();
        java.io.File file = null;
        String mediaId = null;
        String fileName = null;
        String codProfileHash = null;
        JSONObject mediajson = null;
        int i = 0;

        for (String type : TYPES.keySet())
        {
            fileList = TestUtil.files(System.getenv("PATH_FILE_TEST") + java.io.File.separator, type);

            for (java.io.File jsonFile : fileList)
            {
                params.clear();

                try
                {
                    if (i >= args.length)
                    {
                        i = 0;
                    }

                    codProfileHash = args[i];
                    mediaId = jsonFile.getName().substring(0, jsonFile.getName().indexOf("."));
                    mediajson = JsonUtil.jsonFromFile(mediaId, type);
                    fileName = System.getenv("PATH_FILE_TEST") + File.separator + mediaId + EXT.get(type);
                    file = new java.io.File(fileName);
                    String tag = tags(mediajson);

                    params.put("media.namSubject", adjustmentToRequest(mediajson.getString("title")));
                    params.put("media.desMedia", mediaId + " " + adjustmentToRequest(mediajson.getString("description")));
                    params.put("media.tags", (tag != null ? tag : "tag,teste"));

                    if (mediajson.has("idtTagService") && !mediajson.getString("idtTagService").equals(""))
                    {
                        params.put("media.idtTagService", mediajson.getString("idtTagService"));
                    }

                    if (mediajson.has("subscriberMedia") && mediajson.getBoolean("subscriberMedia"))
                    {
                        params.put("media.flgSubscriberMedia", "1");
                    }

                    String url = "http://beta.mais.uol.com.br/apiuol/publish/" + TYPES.get(type) + "?variant=json&codProfileHash="
                            + codProfileHash;

                    WSReturn ret = JsonUtil.wsReturn(JsonRequest.execGibraltar(url, "POST", null, null, 10000, file, params));

                    System.out.println(ret);
                }
                catch (Exception e)
                {
                    e.printStackTrace();
                }
                finally
                {
                    i++;
                }
            }
        }
    }

    private static String tags(JSONObject mediajson) throws Exception
    {
        StringBuffer tag = new StringBuffer();

        if (mediajson.has("tags") && mediajson.getJSONArray("tags").length() > 0)
        {
            for (int i = 0; i < mediajson.getJSONArray("tags").length(); i++)
            {
                tag.append((tag.length() < 1 ? "" : ",") + mediajson.getJSONArray("tags").getJSONObject(i).getString("description"));
            }

            return tag.toString();
        }

        return null;
    }

    private static String adjustmentToRequest(String field)
    {
        for (String key : TestUtil.CHARCODE_UNICODE.keySet())
        {
            field = field.replace(key, new String(new int[] { TestUtil.CHARCODE_UNICODE.get(key) }, 0, 1));
        }

        return field;
    }
}
