/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         22/09/2017 Criacao inicial
 */

package uol.taipei.tests.basicauth;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import javax.xml.bind.DatatypeConverter;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.FileUtils;
import org.apache.http.HttpStatus;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uol.taipei.request.FacileRequest;
import uol.taipei.request.FacileResponse;
import uol.taipei.request.JsonRequest;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.util.JsonUtil;
import uol.taipei.tests.util.RequestUtil;
import uol.taipei.tests.util.TestUtil;
import uol.taipei.util.hash.HashCode;

public class ApiPublishBasicAuth extends AbstractTest
{
    static final Logger logger = LoggerFactory.getLogger(ApiPublishBasicAuth.class);

    public static void main(String[] args)
    {
        if (!verifyParams(args))
        {
            return;
        }

        setUp(args[0]);

        if (envConfig().getUser() == null || envConfig().getUser().equals("") || envConfig().getPass() == null || envConfig().getPass().equals(""))
        {
            System.err.println("Invalid user " + envConfig().getUser());
            return;
        }

        logger.debug("-------------------------------------------------");
        logger.debug("tests api publish basic auth");

        try
        {
            ApiPublishBasicAuth apiPublishGibraltar = new ApiPublishBasicAuth();
            JSONObject profile = JsonUtil.fullProfileLogin(envConfig().getUser());

            apiPublishGibraltar.uploadVideo(profile.getString("codProfile"), profile.getJSONObject("mediaConfig").getString("passphrase"));
            apiPublishGibraltar.uploadPodcast(profile.getString("codProfile"), profile.getJSONObject("mediaConfig").getString("passphrase"));
            apiPublishGibraltar.statusAudio(profile.getString("codProfile"), profile.getJSONObject("mediaConfig").getString("passphrase"));

            String mediaId = RequestUtil.mediaId("V", Long.valueOf(profile.getJSONObject("profile").getString("codProfileHash")));

            apiPublishGibraltar.publishThumb(profile.getString("codProfile"), profile.getJSONObject("mediaConfig").getString("passphrase"), Long.valueOf(mediaId));
            apiPublishGibraltar.statusVideo(profile.getString("codProfile"), profile.getJSONObject("mediaConfig").getString("passphrase"), Long.valueOf(mediaId));
            apiPublishGibraltar.statusErrInvalidOwner(profile.getString("codProfile"), profile.getJSONObject("mediaConfig").getString("passphrase"), Long.valueOf(mediaId));
            apiPublishGibraltar.updateMediaErrInvalidOwner(profile.getString("codProfile"), profile.getJSONObject("mediaConfig").getString("passphrase"), Long.valueOf(mediaId));
            apiPublishGibraltar.updateMedia(profile.getString("codProfile"), profile.getJSONObject("mediaConfig").getString("passphrase"), Long.valueOf(mediaId));

            apiPublishGibraltar.updateContentStatus(Long.valueOf(mediaId), 10, 2);

            apiPublishGibraltar.uploadErrNoProfile(profile.getJSONObject("mediaConfig").getString("passphrase"));
            apiPublishGibraltar.uploadErrIvalidProfile(profile.getJSONObject("mediaConfig").getString("passphrase"));

            FacileRequest request = new FacileRequest();

            apiPublishGibraltar.notPublishVideoNoAuth(request, profile.getString("codProfile"));
            apiPublishGibraltar.notPublishAudioNoAuth(request, profile.getString("codProfile"));
        }
        catch (Exception e)
        {
            logger.error(e.getMessage());
        }
    }

    public JSONObject uploadVideo(String codProfile, String passphrase) throws Exception
    {
        String url = "http://beta.mais.uol.com.br/apiuol/publish/video?variant=json";
        String fileName = System.getenv("PATH_FILE_TEST") + File.separator + "video.mp4";
        java.io.File file = new java.io.File(fileName);
        String basicAuth = codProfile+":"+passphrase;
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put("Authorization", "Basic " + DatatypeConverter.printBase64Binary(basicAuth.getBytes("UTF-8")));
        String postData = "media.desMedia=Basic Auth video publish";
        JSONObject jsonResponse = JsonRequest.upload(url, postData, headers, file);

        if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") != 200)
        {
            logger.error("ERROR - response not valid - " + jsonResponse.getJSONObject("_response"));
            return null;
        }

        if (!validatePublishMediaJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject uploadPodcast(String codProfile, String passphrase) throws Exception
    {
        String url = "http://beta.mais.uol.com.br/apiuol/publish/audio?variant=json";
        String fileName = System.getenv("PATH_FILE_TEST") + File.separator + "audio.mp3";
        java.io.File file = new java.io.File(fileName);
        String basicAuth = codProfile+":"+passphrase;
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put("Authorization", "Basic " + DatatypeConverter.printBase64Binary(basicAuth.getBytes("UTF-8")));
        String postData = "media.desMedia=Basic Auth audio publish";
        JSONObject jsonResponse = JsonRequest.upload(url, postData, headers, file);

        if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") != 200)
        {
            logger.error("ERROR - response not valid - " + jsonResponse.getJSONObject("_response"));
            return null;
        }

        if (!validatePublishMediaJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject statusVideo(String codProfile, String passphrase, Long mediaId) throws Exception
    {
        String url = "http://beta.mais.uol.com.br/apiuol/media/status?variant=json&mediaId=" + mediaId;
        String basicAuth = codProfile+":"+passphrase;
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put("Authorization", "Basic " + DatatypeConverter.printBase64Binary(basicAuth.getBytes("UTF-8")));
        JSONObject jsonResponse = JsonRequest.get(url, headers);

        if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") != 200)
        {
            logger.error("ERROR - response not valid - " + jsonResponse.getJSONObject("_response"));
            return null;
        }

        if (!validateStatusJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        if (!"V".equals(jsonResponse.getJSONObject("media").getString("mediaType")))
        {
            logger.error("ERROR - mediaType not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject statusAudio(String codProfile, String passphrase) throws Exception
    {
        Long codProfileHash = HashCode.encode(codProfile);
        String mediaId = RequestUtil.mediaId("P", codProfileHash);
        String url = "http://beta.mais.uol.com.br/apiuol/media/status?variant=json&mediaId=" + mediaId;
        String basicAuth = codProfile+":"+passphrase;
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put("Authorization", "Basic " + DatatypeConverter.printBase64Binary(basicAuth.getBytes("UTF-8")));
        JSONObject jsonResponse = JsonRequest.get(url, headers);

        if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") != 200)
        {
            logger.error("ERROR - response not valid - " + jsonResponse.getJSONObject("_response"));
            return null;
        }

        if (!validateStatusJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        if (!"P".equals(jsonResponse.getJSONObject("media").getString("mediaType")))
        {
            logger.error("ERROR - mediaType not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject publishThumb(String codProfile, String passphrase, Long mediaId)
    {
        FacileRequest request = new FacileRequest();
        HashMap<String, String> params = new HashMap<String, String>();
        final String[] extFoto = new String[] { "jpg", "JPG", "jpeg", "JPEG", "bmp", "BMP", "gif", "GIF", "png", "PNG" };

        try
        {
            String pathfileTest = System.getenv("PATH_FILE_TEST") + java.io.File.separator;
            java.io.File file;

            List<java.io.File> fileList = TestUtil.files(pathfileTest, "B");

            if (!fileList.isEmpty() && fileList.size() > 0)
            {
                java.io.File jsonFile = fileList.get((new Random()).nextInt(fileList.size()));
                String photoId = jsonFile.getName().substring(0, jsonFile.getName().indexOf("."));

                int i = 0;
                do
                {
                    file = new java.io.File(pathfileTest + photoId + "." + extFoto[i]);
                    i++;
                }
                while ((file == null || !file.exists()) && i < extFoto.length);
            }
            else
            {
                file = new java.io.File(pathfileTest + "foto.jpg");
            }

            if (file == null || !file.exists())
            {
                logger.error("ERROR - file not found - " + (file != null ? file.getAbsolutePath() : null));
                return null;
            }

            String base64ImgString = (new Base64()).encodeToString(FileUtils.readFileToByteArray(file));
            params.put("media.thumbnail", base64ImgString);
            params.put("media.idtMedia", mediaId.toString());

            String url = "http://beta.mais.uol.com.br/apiuol/selectThumb?variant=json";
            String basicAuth = codProfile+":"+passphrase;
            HashMap<String, String> headers = new HashMap<String, String>();
            headers.put("Authorization", "Basic " + DatatypeConverter.printBase64Binary(basicAuth.getBytes("UTF-8")));
            FacileResponse response = request.post(url, headers, params);

            if (response.getCode() != 200)
            {
                logger.error("ERROR - response not valid - " + response.getCode());
                return null;
            }

            if (!validateMessageJson(response.getJson(), 'S'))
            {
                logger.error("ERROR - return not valid - " + response.getJson());
                return null;
            }

            logger.debug("SUCCESS");

            return response.getJson();
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return null;
        }
    }

    public boolean statusErrInvalidOwner(String codProfile, String passphrase, Long mediaId) throws Exception
    {
        Long codProfileHash = HashCode.encode(codProfile);
        JSONObject anotherOwner = getDifferentProfile(codProfileHash);
        String url = "http://beta.mais.uol.com.br/apiuol/media/status?variant=json&mediaId=" + mediaId;
        String basicAuth = anotherOwner.getString("codProfile")+":"+passphrase;
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put("Authorization", "Basic " + DatatypeConverter.printBase64Binary(basicAuth.getBytes("UTF-8")));
        String postData = "media.namSubject=" + TestUtil.randomString(5); 
        JSONObject jsonResponse = JsonRequest.post(url, postData, headers);

        if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") == 200)
        {
            logger.error("ERROR - response not valid - " + jsonResponse.getJSONObject("_response"));
            return false;
        }

        if (jsonResponse != null && (jsonResponse.has("mediaStatus") || jsonResponse.has("media")))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean updateMediaErrInvalidOwner(String codProfile, String passphrase, Long mediaId) throws Exception
    {
        Long codProfileHash = HashCode.encode(codProfile);
        JSONObject anotherOwner = getDifferentProfile(codProfileHash);
        String url = "http://beta.mais.uol.com.br/apiuol/media/update?variant=json&mediaId=" + mediaId;
        String basicAuth = anotherOwner.getString("codProfile")+":"+passphrase;
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put("Authorization", "Basic " + DatatypeConverter.printBase64Binary(basicAuth.getBytes("UTF-8")));
        String postData = "media.namSubject=" + TestUtil.randomString(5); 
        JSONObject jsonResponse = JsonRequest.post(url, postData, headers);

        if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") == 200)
        {
            logger.error("ERROR - response not valid - " + jsonResponse.getJSONObject("_response"));
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public JSONObject updateMedia(String codProfile, String passphrase, Long mediaId)
    {
        try
        {
            int retry = 0;
            FacileRequest request = new FacileRequest();
            String basicAuth = codProfile+":"+passphrase;
            HashMap<String, String> headers = new HashMap<String, String>();
            headers.put("Authorization", "Basic " + DatatypeConverter.printBase64Binary(basicAuth.getBytes("UTF-8")));
            FacileResponse media = request.get("http://beta.mais.uol.com.br/apiuol/media/status?variant=json&" 
                    + "&mediaId=" + mediaId, headers);

            // a alteracao valida o dono da midia, entao precisa passar o codProfileHash
            Long codProfileHash = HashCode.encode(media.getJson().getJSONObject("media").getString("codProfile"));
            String url = "http://beta.mais.uol.com.br/apiuol/media/update?variant=json&mediaId=" + mediaId;
            Integer tagService = new Random().nextInt(10000);
            String data = TestUtil.randomString(5);
            //String taglist = tags(media.getJSONObject("media"));

            HashMap<String, String> params = new HashMap<String, String>();
            params.put("media.namSubject", data + " " + (media.getJson().getJSONObject("media").has("title") ? 
                    media.getJson().getJSONObject("media").getString("title") : ""));
            params.put("media.desMedia", data + " Basic Auth - " + (media.getJson().getJSONObject("media").has("description") ? 
                    media.getJson().getJSONObject("media").getString("description") : ""));
            //params.put("media.tags", data + (taglist != null ? "," + taglist : ""));

            if ("V".equals(media.getJson().getJSONObject("media").getString("mediaType")))
            {
                // editorial
                params.put("media.idtTagService", tagService.toString());
            }

            FacileResponse response = request.post(url, headers, params);

            if (response.getCode() != 200)
            {
                logger.error("ERROR - response not valid - " + response);
                return null;
            }

            if (!validateUpdateMediaJson(response.getJson()))
            {
                logger.error("ERROR - return not valid - mediaId " + mediaId + " - " + response.getJson());
                return null;
            }

            FacileResponse mediaUpdate = request.get("http://beta.mais.uol.com.br/apiuol/media/status?variant=json&" 
                    + "&mediaId=" + mediaId, headers);

            while (mediaUpdate != null && mediaUpdate.getCode() != 200 && retry < 3)
            {
                logger.warn("retry after 1s - " + mediaId);

                TestUtil.delay(1000);
                mediaUpdate = request.get("http://beta.mais.uol.com.br/apiuol/media/status?variant=json&" 
                        + "&mediaId=" + mediaId, headers);
                retry++;
            }
            
            if (!response.getJson().getJSONObject("media").getString("title").startsWith(data)
                    || !mediaUpdate.getJson().getJSONObject("media").getString("title").startsWith(data))
            {
                logger.error("ERROR - return not valid - data title was not updated - " + media + " - " + mediaUpdate.getJson());
                return null;
            }

            if (!response.getJson().getJSONObject("media").getString("description").startsWith(data)
                    || !mediaUpdate.getJson().getJSONObject("media").getString("description").startsWith(data))
            {
                logger.error("ERROR - return not valid - data description was not updated - " + media + " - " + mediaUpdate);
                return null;
            }

            if ("V".equals(media.getJson().getJSONObject("media").getString("mediaType")))
            {
                // editorial
                if (!response.getJson().getJSONObject("media").getString("idtTagService")
                        .equals(mediaUpdate.getJson().getJSONObject("media").getString("idtTagService"))
                        || !params.get("media.idtTagService").equals(mediaUpdate.getJson().getJSONObject("media").getString("idtTagService")))
                {
                    logger.error("ERROR - return not valid - data idtTagService was not updated - " + media + " - " + mediaUpdate);
                    return null;
                }
            }

            logger.debug("SUCCESS");

            // volta dados originais
            backData("http://beta.mais.uol.com.br/apiuol/media/update?variant=json&mediaId=" + mediaId + "&codProfileHash=" + codProfileHash, 
                params, media.getJson());

            return response.getJson();
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return null;
        }
    }

    public boolean uploadErrNoProfile(String passphrase) throws Exception
    {
        String fileName = System.getenv("PATH_FILE_TEST") + File.separator + "video.mp4";
        java.io.File file = new java.io.File(fileName);
        String basicAuth = ":"+passphrase;
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put("Authorization", "Basic " + DatatypeConverter.printBase64Binary(basicAuth.getBytes("UTF-8")));
        String postData = "media.desMedia=Basic Auth upload error";
        JSONObject jsonResponse = JsonRequest.upload("http://beta.mais.uol.com.br/apiuol/publish/video?variant=json", postData, headers, file);

        if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") == 200)
        {
            logger.error("ERROR - response not valid - " + jsonResponse.getJSONObject("_response"));
            return false;
        }

        if (jsonResponse != null && jsonResponse.has("media"))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return false;
        }

        basicAuth = "xxx:"+passphrase;
        headers.put("Authorization", "Basic " + DatatypeConverter.printBase64Binary(basicAuth.getBytes("UTF-8")));
        
        jsonResponse = JsonRequest.upload("http://beta.mais.uol.com.br/apiuol/publish/video?variant=json", postData, headers, file);

        if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") == 200)
        {
            logger.error("ERROR - response not valid - " + jsonResponse.getJSONObject("_response"));
            return false;
        }

        if (jsonResponse != null && jsonResponse.has("media"))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean uploadErrIvalidProfile(String passphrase) throws Exception
    {
        String url = "http://beta.mais.uol.com.br/apiuol/publish/video?variant=json";
        String fileName = System.getenv("PATH_FILE_TEST") + File.separator + "video.mp4";
        java.io.File file = new java.io.File(fileName);
        String basicAuth = "xx1y2yz3z456:"+passphrase;
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put("Authorization", "Basic " + DatatypeConverter.printBase64Binary(basicAuth.getBytes("UTF-8")));
        String postData = "media.desMedia=Basic Auth upload error";
        JSONObject jsonResponse = JsonRequest.upload(url, postData, headers, file);

        if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") == 200)
        {
            logger.error("ERROR - response not valid - " + jsonResponse.getJSONObject("_response"));
            return false;
        }

        if (jsonResponse != null && jsonResponse.has("media"))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    /**
     * nao publicar video sem autenticacao gibraltar
     * 
     * @param request
     * @param codProfileHash
     * @return boolean
     */
    public boolean notPublishVideoNoAuth(FacileRequest request, String codProfile)
    {
        try
        {
            java.io.File file = new java.io.File(System.getenv("PATH_FILE_TEST") + File.separator + "video.mp4");
            String basicAuth = codProfile+":";
            HashMap<String, String> headers = new HashMap<String, String>();
            headers.put("Authorization", "Basic " + DatatypeConverter.printBase64Binary(basicAuth.getBytes("UTF-8")));
            FacileResponse response = request.post("http://beta.mais.uol.com.br/apiuol/publish/video?variant=json" 
                    , headers, null, file, false);

            if (response.getCode() == 200)
            {
                logger.error("ERROR - return not valid - " + response.getBody());
                return false;
            }
    
            logger.debug("SUCCESS");
    
            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return false;
        }
    }

    /**
     * nao publicar audio sem autenticacao gibraltar
     * 
     * @param request
     * @param codProfileHash
     * @return boolean
     */
    public boolean notPublishAudioNoAuth(FacileRequest request, String codProfile)
    {
        try
        {
            java.io.File file = new java.io.File(System.getenv("PATH_FILE_TEST") + File.separator + "audio.mp3");
            String basicAuth = codProfile+":";
            HashMap<String, String> headers = new HashMap<String, String>();
            headers.put("Authorization", "Basic " + DatatypeConverter.printBase64Binary(basicAuth.getBytes("UTF-8")));
            FacileResponse response = request.post("http://beta.mais.uol.com.br/apiuol/publish/video?variant=json" 
                    , headers, null, file, false);
    
            if (response.getCode() == 200)
            {
                logger.error("ERROR - return not valid - " + response.getBody());
                return false;
            }
    
            logger.debug("SUCCESS");
    
            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return false;
        }
    }

    /**
     * um profile com codProfileHash diferente
     * 
     * @param codProfileHash
     * @return JSONObject
     * @throws Exception
     */
    private JSONObject getDifferentProfile(Long codProfileHash) throws Exception
    {
        int limit = 10;
        int start = 0;
        Long codChildProfileHash = null;
        JSONArray jsonarray = JsonUtil.codProfileHashPaging(start, limit);

        while (jsonarray != null && jsonarray.length() > 0)
        {
            for (int i = 0; i < jsonarray.length(); i++)
            {
                codChildProfileHash = Long.valueOf(jsonarray.getJSONObject(i).getString("cod_profile_hash"));

                if (!codChildProfileHash.equals(codProfileHash))
                {
                    return JsonUtil.fullProfile(codChildProfileHash);
                }
            }

            start+=limit;
            jsonarray = JsonUtil.codProfileHashPaging(start, limit);
        }

        return null;
    }

    private String tags(JSONObject mediajson) throws Exception
    {
        StringBuffer tag = new StringBuffer();

        if (mediajson.has("tags"))
        {
            // array de tags tags=[{"id": , "description": ""}...]
            if (mediajson.optJSONArray("tags") != null && mediajson.getJSONArray("tags").length() > 0)
            {
                for (int i = 0; i < mediajson.getJSONArray("tags").length(); i++)
                {
                    tag.append((tag.length() < 1 ? "" : ",") + mediajson.getJSONArray("tags").getJSONObject(i).getString("description"));
                }

                return tag.toString();
            }
            // lista de string de tags tags=a,b
            else if (!mediajson.getString("tags").trim().equals(""))
            {
                return mediajson.getString("tags");
            }
        }

        return null;
    }

    private void backData(String url, HashMap<String, String> params, JSONObject mediajson) throws Exception
    {
        String t = tags(mediajson.getJSONObject("media"));

        if ("V".equals(mediajson.getJSONObject("media").getString("mediaType")))
        {
            params.put("media.idtTagService", mediajson.getJSONObject("media").getString("idtTagService"));
        }

        params.put("media.namSubject", mediajson.getJSONObject("media").getString("title"));
        params.put("media.desMedia", mediajson.getJSONObject("media").getString("description"));
        params.put("media.tags", (t != null ? t : ""));

        JsonRequest.execGibraltar(url, "POST", null, null, 10000, null, params);
    }

    private boolean validateStatusJson(JSONObject json)
    {
        try
        {
            json.getJSONObject("media");
            json.getJSONObject("media").getString("title");
            json.getJSONObject("media").getString("mediaId");
            json.getJSONObject("media").getString("url");
            json.getJSONObject("media").getString("thumbnail");
            json.getJSONObject("media").getString("thumbSmall");
            json.getJSONObject("media").getString("thumbMedium");
            json.getJSONObject("media").getString("thumbLarge");
            json.getJSONObject("media").getString("mediaType");
            json.getJSONObject("media").getBoolean("moderateNote");
            json.getJSONObject("media").getBoolean("allowAnonymousComment");
            json.getJSONObject("media").getString("allowNotes");
            json.getJSONObject("media").getString("edFilter");
            json.getJSONObject("media").getString("description");
            json.getJSONObject("media").getBoolean("adultContent");
            json.getJSONObject("media").getString("author");
            json.getJSONObject("media").getString("authorPage");
            json.getJSONObject("media").getString("codProfile");
            json.getJSONObject("media").getString("publishedAt");
            json.getJSONObject("media").getBoolean("blockEmbed");
            json.getJSONObject("media").getBoolean("subscriberMedia");
            json.getJSONObject("media").getString("idtTagService");
            json.getJSONObject("media").getString("tags");

            JsonUtil.validateValueJson(json.getJSONObject("media"), new String[] { "title", "description" });

            json.getJSONObject("mediaStatus");
            json.getJSONObject("mediaStatus").getString("codStatus");

            if ("V".equals(json.getJSONObject("media").getString("mediaType")))
            {
                json.getJSONObject("mediaStatus").getString("datStartEncoding");
                json.getJSONObject("mediaStatus").getString("numPercEncoding");
            }

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - statusjson is not valid - " + e.getMessage() + " - " + json);
            return false;
        }
    }

    private boolean validateUpdateMediaJson(JSONObject json)
    {
        try
        {

            json.getJSONObject("response");
            json.getJSONObject("response").getString("status");
            json.getJSONObject("response").getString("description");

            json.getJSONObject("media");
            json.getJSONObject("media").getString("title");
            json.getJSONObject("media").getString("mediaId");
            json.getJSONObject("media").getString("url");
            json.getJSONObject("media").getString("thumbnail");
            json.getJSONObject("media").getString("thumbSmall");
            json.getJSONObject("media").getString("thumbMedium");
            json.getJSONObject("media").getString("thumbLarge");
            json.getJSONObject("media").getString("mediaType");
            json.getJSONObject("media").getBoolean("moderateNote");
            json.getJSONObject("media").getBoolean("allowAnonymousComment");
            json.getJSONObject("media").getString("allowNotes");
            json.getJSONObject("media").getString("edFilter");
            json.getJSONObject("media").getString("description");
            json.getJSONObject("media").getBoolean("adultContent");
            json.getJSONObject("media").getString("author");
            json.getJSONObject("media").getString("authorPage");
            json.getJSONObject("media").getString("codProfile");
            json.getJSONObject("media").getString("publishedAt");
            json.getJSONObject("media").getBoolean("blockEmbed");
            json.getJSONObject("media").getBoolean("subscriberMedia");
            json.getJSONObject("media").getString("idtTagService");
            json.getJSONObject("media").getString("tags");

            JsonUtil.validateValueJson(json.getJSONObject("media"), new String[] { "title", "description" });

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - updatemediajson is not valid - " + e.getMessage() + " - " + json);
            return false;
        }
    }

    private boolean validatePublishMediaJson(JSONObject json)
    {
        try
        {

            json.getJSONObject("response");
            json.getJSONObject("response").getString("code");
            json.getJSONObject("response").getString("status");
            json.getJSONObject("response").getString("description");

            json.getJSONObject("media");
            json.getJSONObject("media").getString("title");
            json.getJSONObject("media").getString("mediaId");
            json.getJSONObject("media").getString("url");
            json.getJSONObject("media").getString("thumbnail");
            json.getJSONObject("media").getString("thumbSmall");
            json.getJSONObject("media").getString("thumbMedium");
            json.getJSONObject("media").getString("thumbLarge");
            json.getJSONObject("media").getString("mediaType");
            json.getJSONObject("media").getBoolean("moderateNote");
            json.getJSONObject("media").getBoolean("allowAnonymousComment");
            json.getJSONObject("media").getString("allowNotes");
            json.getJSONObject("media").getString("edFilter");
            json.getJSONObject("media").getString("description");
            json.getJSONObject("media").getBoolean("adultContent");
            json.getJSONObject("media").getString("author");
            json.getJSONObject("media").getString("authorPage");
            json.getJSONObject("media").getString("codProfile");
            json.getJSONObject("media").getString("publishedAt");
            json.getJSONObject("media").getBoolean("blockEmbed");
            json.getJSONObject("media").getBoolean("subscriberMedia");
            json.getJSONObject("media").getString("idtTagService");
            json.getJSONObject("media").getString("tags");

            JsonUtil.validateValueJson(json.getJSONObject("media"), new String[] { "title", "description" });

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - publishmediajson is not valid - " + e.getMessage() + " - " + json);
            return false;
        }
    }

    private boolean validateMessageJson(JSONObject json, char type)
    {
        try
        {
            json.getJSONObject("response");

            if (type == 'S')
            {
                // json.getJSONObject("response").getString("code");
                json.getJSONObject("response").getString("status");
                json.getJSONObject("response").getString("description");

                if (!json.getJSONObject("response").getString("status").equals("success"))
                {
                    throw new Exception("no has success message");
                }
            }
            else if (type == 'E')
            {
                if (json == null || json.getJSONObject("_response").getInt("code") == HttpStatus.SC_OK)
                {
                    return false;
                }

                json.getJSONObject("response").getString("code");
                json.getJSONObject("response").getString("status");
                json.getJSONObject("response").getString("description");

                if (!json.getJSONObject("response").getString("status").equals("error"))
                {
                    throw new Exception("no has error message");
                }
                else
                {
                    json.getJSONObject("error").getString("code");
                    json.getJSONObject("error").getString("message");
                }
            }
            else if (type == 'W')
            {
                json.getJSONObject("response").getString("code");
                json.getJSONObject("response").getString("status");
                json.getJSONObject("response").getString("description");

                if (!json.getJSONObject("response").getString("status").equals("warn"))
                {
                    throw new Exception("no has warn message");
                }
            }
            else
            {
                json.getJSONObject("response").getString("code");
                json.getJSONObject("response").getString("status");
                json.getJSONObject("response").getString("description");

                if (!json.getJSONObject("response").getString("status").equals("info"))
                {
                    throw new Exception("no has info message");
                }
            }

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - message invalid - " + e.getMessage() + " - " + json);
            return false;
        }
    }
}
