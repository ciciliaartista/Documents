/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         20/06/2014 Criacao inicial
 */

package uol.taipei.tests.auth;

import java.io.IOException;

import org.apache.http.HttpStatus;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uol.taipei.request.JsonRequest;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.LoginCookie;

public class ApiAuth extends AbstractTest
{
    static final Logger logger = LoggerFactory.getLogger(ApiAuth.class);

    public static void main(String[] args)
    {
        if (!verifyParams(args))
        {
            return;
        }

        setUp(args[0]);

        if (envConfig().getUser() == null || envConfig().getUser().equals("") || envConfig().getPass() == null  || envConfig().getPass().equals(""))
        {
            System.err.println("Invalid user " + envConfig().getUser());
            return;
        }

        logger.debug("-------------------------------------------------");
        logger.debug("tests api auth");

        try
        {
            ApiAuth apiAuth = new ApiAuth();
            LoginCookie login = new LoginCookie(envConfig().getUser(), envConfig().getPass());

            apiAuth.noLogged();
            apiAuth.logged(login);
        }
        catch (Exception e) 
        {
            logger.error(e.getMessage());            
        }
    }

    public JSONObject noLogged() throws IOException, JSONException
    {
        JSONObject jsonResponse = JsonRequest.get("http://mais.uol.com.br/apiuol/v2/auth");

        if (!validateJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        if (jsonResponse.getBoolean("authenticated"))
        {
            logger.error("ERROR - is not logged - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject logged(LoginCookie login) throws Exception
    {
        JSONObject jsonResponse = login.getjson("http://mais.uol.com.br/apiuol/v2/auth");

        if (!validateJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        if (!jsonResponse.getBoolean("authenticated"))
        {
            logger.error("ERROR - is logged - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    private boolean validateJson(JSONObject jsonResponse)
    {
        try
        {
            if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") != HttpStatus.SC_OK)
            {
                return false;
            }

            jsonResponse.getJSONObject("response");
            jsonResponse.getJSONObject("response").getInt("code");
            jsonResponse.getJSONObject("response").getString("description");

            jsonResponse.getBoolean("authenticated");
            jsonResponse.getBoolean("subscriber");
            jsonResponse.getBoolean("hasPhotoQuota");
            jsonResponse.getJSONArray("authorizedProducts");

            for (int j = 0; j < jsonResponse.getJSONArray("authorizedProducts").length(); j++)
            {
                jsonResponse.getJSONArray("authorizedProducts").getInt(j);
            }

            return true;
        }
        catch (Exception e) 
        {
            logger.error("ERROR - json is not valid - " + e.getMessage() + " - " + jsonResponse);
            return false;
        }
    }
}
