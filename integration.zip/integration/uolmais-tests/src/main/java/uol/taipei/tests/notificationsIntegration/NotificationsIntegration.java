package uol.taipei.tests.notificationsIntegration;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.LoginCookie;
import uol.taipei.tests.util.RequestUtil;

/**
 * @author jmoraes
 *
 */
public class NotificationsIntegration extends AbstractTest
{
    static final Logger logger = LoggerFactory.getLogger(NotificationsIntegration.class);

    public static void main(String[] args)
    {
        if (!verifyParams(args))
        {
            return;
        }

        setUp(args[0]);

        if (envConfig().getUser() == null || envConfig().getUser().equals("") || envConfig().getPass() == null
                || envConfig().getPass().equals(""))
        {
            System.err.println("Invalid user " + envConfig().getUser());
            return;
        }

        logger.debug("-------------------------------------------------");
        logger.debug("tests notifications integration");

        try
        {
            NotificationsIntegration notificationsIntegration = new NotificationsIntegration();
            LoginCookie login = new LoginCookie(envConfig().getUser(), envConfig().getPass());

            notificationsIntegration.resetFollowableViewedCounter(login);

        }
        catch (Exception e)
        {
            logger.error(e.getMessage());
        }
    }

    /**
     * Tests the reset of the viewed followable counter
     * 
     * @param login
     * @return true if os ok, false if is not
     * @throws Exception
     */
    public boolean resetFollowableViewedCounter(LoginCookie login) throws Exception
    {
        Long codProfileHash = login.getJsonProfile().getJSONObject("item").getLong("codProfileHash");
        String followableIdStr = RequestUtil.getOneFollowableIdByCodProfileHash(codProfileHash);
        if (StringUtils.isBlank(followableIdStr))
        {
            logger.error("ERROR - cant get a followableId for test user");
            return false;

        }
/*
        Notification notification = new Notification();
        notification.setClientId("4");
        notification.setContextId(followableIdStr);
        notification.setIdtPerson(String.valueOf(login.getJsonProfile().getJSONObject("item").getLong("idtPerson")));

        JSONObject response = NotificationIntegrationManager.getInstance().clearContext(notification, 10000);

        if (response != null && response.has("_response") && response.getJSONObject("_response").getInt("code") == 200)
        {
            logger.debug("SUCCESS");
            return true;
        }
        logger.error("ERROR - return not valid - response: " + response.toString());
*/
        return false;

    }

}
