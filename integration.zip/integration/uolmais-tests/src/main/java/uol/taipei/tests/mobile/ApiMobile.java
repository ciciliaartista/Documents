/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         24/04/2014 Criacao inicial
 */

package uol.taipei.tests.mobile;

import java.io.IOException;

import org.apache.http.HttpStatus;
import org.apache.http.client.ClientProtocolException;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uol.taipei.request.JsonRequest;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.LoginCookie;
import uol.taipei.tests.util.JsonUtil;
import uol.taipei.tests.util.RequestUtil;

public class ApiMobile extends AbstractTest
{
    static final Logger logger = LoggerFactory.getLogger(ApiMobile.class);

    public static void main(String[] args)
    {
        if (!verifyParams(args))
        {
            return;
        }

        setUp(args[0]);

        if (envConfig().getUser() == null || envConfig().getUser().equals("") || envConfig().getPass() == null
                || envConfig().getPass().equals(""))
        {
            System.err.println("Invalid user " + envConfig().getUser());
            return;
        }

        logger.debug("-------------------------------------------------");
        logger.debug("tests api mobile");

        try
        {
            ApiMobile apiMobile = new ApiMobile();
            LoginCookie login = new LoginCookie(envConfig().getUser(), envConfig().getPass());
            JSONObject profile = apiMobile.profile(login);
            String mediaId = RequestUtil.mediaIdPublic("V");

            apiMobile.profile(profile.getJSONObject("item").getString("codProfile"));
            apiMobile.medias(login);
            apiMobile.medias(profile);
            apiMobile.medias(login, profile);
            apiMobile.media(mediaId);
        }
        catch (Exception e)
        {
            logger.error(e.getMessage());
        }
    }

    public JSONObject profile(LoginCookie login) throws Exception, IOException, JSONException
    {
        login.isAuthenticated();
        JSONObject jsonResponse = login.getjson("http://mais.uol.com.br/apiuol/mobile/profile");

        if (!validateProfileJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            throw new JSONException("invalid json - ApiMobile profile");
        }
        else
        {
            logger.debug("SUCCESS");
        }

        return jsonResponse;
    }

    public JSONObject profile(String codProfile)
            throws ClientProtocolException, IllegalStateException, IOException, JSONException
    {
        JSONObject jsonResponse = JsonRequest
                .get("http://mais.uol.com.br/apiuol/mobile/profile/" + codProfile);

        if (!validateProfileJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            throw new JSONException("invalid json - ApiMobile profile " + codProfile);
        }
        else
        {
            logger.debug("SUCCESS");
        }

        return jsonResponse;
    }

    public JSONObject profileQS(String codProfile)
            throws ClientProtocolException, IllegalStateException, IOException, JSONException
    {
        JSONObject jsonResponse = JsonRequest
                .get("http://mais.uol.com.br/apiuol/mobile/profile?codProfile=" + codProfile);

        if (!validateProfileJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            throw new JSONException("invalid json - ApiMobile profile " + codProfile);
        }
        else
        {
            logger.debug("SUCCESS");
        }

        return jsonResponse;
    }

    public JSONObject medias(LoginCookie login) throws Exception
    {
        login.isAuthenticated();
        JSONObject jsonResponse = login.getjson("http://mais.uol.com.br/apiuol/mobile/medias/A/3/1/6");

        if (!validateMediaPageJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            throw new JSONException("invalid json - ApiMobile medias");
        }
        else
        {
            logger.debug("SUCCESS");
        }

        return jsonResponse;
    }

    public JSONObject medias(JSONObject profile)
            throws ClientProtocolException, IllegalStateException, IOException, JSONException
    {
        JSONObject jsonResponse = JsonRequest.get("http://mais.uol.com.br/apiuol/mobile/medias/A/3/1/6/"
                + profile.getJSONObject("item").getString("codProfile"));

        if (!validateMediaPageJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            throw new JSONException("invalid json - ApiMobile medias " + profile);
        }
        else
        {
            logger.debug("SUCCESS");
        }

        return jsonResponse;
    }

    public JSONObject medias(LoginCookie login, JSONObject profile) throws Exception
    {
        login.isAuthenticated();
        JSONObject jsonResponse = login.getjson("http://mais.uol.com.br/apiuol/mobile/medias/A/3/1/6/"
                + profile.getJSONObject("item").getString("codProfile"));

        if (!validateMediaPageJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            throw new JSONException("invalid json - ApiMobile medias " + login + " " + profile);
        }
        else
        {
            logger.debug("SUCCESS");
        }

        return jsonResponse;
    }

    public JSONObject media(String mediaId) throws Exception
    {
        JSONObject jsonResponse = JsonRequest.get("http://mais.uol.com.br/apiuol/mobile/media/" + mediaId);

        if (!validateMediaJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            throw new JSONException("invalid json - ApiMobile media " + mediaId);
        }
        else
        {
            logger.debug("SUCCESS");
        }

        return jsonResponse;
    }

    public JSONObject mediaQS(String mediaId) throws Exception
    {
        JSONObject jsonResponse = JsonRequest.get("http://mais.uol.com.br/apiuol/mobile/media?mediaId=" + mediaId);

        if (!validateMediaJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            throw new JSONException("invalid json - ApiMobile media " + mediaId);
        }
        else
        {
            logger.debug("SUCCESS");
        }

        return jsonResponse;
    }
    
    public boolean validateProfileJson(JSONObject json)
    {
        try
        {
            if (json == null || json.getJSONObject("_response").getInt("code") != HttpStatus.SC_OK)
            {
                return false;
            }
            json.getJSONObject("response");
            json.getJSONObject("response").getLong("code");
            json.getJSONObject("response").getString("description");
            json.getJSONObject("item");
            json.getJSONObject("item").getLong("codProfileHash");
            json.getJSONObject("item").getString("codProfile");
            json.getJSONObject("item").getLong("idtPerson");
            json.getJSONObject("item").getString("namNick");
            json.getJSONObject("item").getString("desUrlProfile");
            json.getJSONObject("item").getInt("numNetworkFriends");
            json.getJSONObject("item").getString("avatar");

            JsonUtil.validateValueJson(json, new String[] { "" });

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - profilejson is not valid - " + e.getMessage() + " - " + json);
            return false;
        }
    }

    private boolean validateMediaPageJson(JSONObject json)
    {
        try
        {
            if (json == null || json.getJSONObject("_response").getInt("code") != HttpStatus.SC_OK)
            {
                return false;
            }
            json.getJSONObject("response");
            json.getJSONObject("response").getLong("code");
            json.getJSONObject("response").getString("description");

            json.getJSONObject("paging");
            json.getJSONObject("paging").getInt("currentPage");
            Boolean.parseBoolean(json.getJSONObject("paging").getString("nextPage"));
            json.getJSONObject("paging").getInt("pageSize");
            Boolean.parseBoolean(json.getJSONObject("paging").getString("previousPage"));
            json.getJSONObject("paging").getString("sort");
            json.getJSONObject("paging").getInt("totalItems");
            json.getJSONObject("paging").getInt("totalPages");

            json.getJSONArray("list");

            for (int i = 0; i < json.getJSONArray("list").length(); i++)
            {
                if (json.getJSONArray("list").getJSONObject(i).has("title"))
                {
                    json.getJSONArray("list").getJSONObject(i).getString("title");
                }

                if (json.getJSONArray("list").getJSONObject(i).has("description"))
                {
                    json.getJSONArray("list").getJSONObject(i).getString("description");
                }

                if (json.getJSONArray("list").getJSONObject(i).has("tags"))
                {
                    json.getJSONArray("list").getJSONObject(i).getString("tags");
                }

                json.getJSONArray("list").getJSONObject(i).getLong("mediaId");
                json.getJSONArray("list").getJSONObject(i).getString("mediaType");
                json.getJSONArray("list").getJSONObject(i).getBoolean("adultContent");
                json.getJSONArray("list").getJSONObject(i).getString("codProfile");
                json.getJSONArray("list").getJSONObject(i).getString("thumbnail");
                json.getJSONArray("list").getJSONObject(i).getString("thumbSmall");
                json.getJSONArray("list").getJSONObject(i).getString("thumbMedium");
                json.getJSONArray("list").getJSONObject(i).getString("thumbLarge");
                json.getJSONArray("list").getJSONObject(i).getString("allowNotes");
                json.getJSONArray("list").getJSONObject(i).getString("shareUrl");
                json.getJSONArray("list").getJSONObject(i).getInt("codStatus");
                json.getJSONArray("list").getJSONObject(i).getString("visibility");

                if ("B".equals(json.getJSONArray("list").getJSONObject(i).getString("mediaType"))
                        || "P".equals(json.getJSONArray("list").getJSONObject(i).getString("mediaType"))
                        || "T".equals(json.getJSONArray("list").getJSONObject(i).getString("mediaType")))
                {
                    json.getJSONArray("list").getJSONObject(i).getString("mediaFile");
                }

                if ("V".equals(json.getJSONArray("list").getJSONObject(i).getString("mediaType"))
                        || "P".equals(json.getJSONArray("list").getJSONObject(i).getString("mediaType")))
                {
                    json.getJSONArray("list").getJSONObject(i).getInt("numRevision");
                }

                if ("V".equals(json.getJSONArray("list").getJSONObject(i).getString("mediaType"))
                        || "P".equals(json.getJSONArray("list").getJSONObject(i).getString("mediaType")))
                {
                    json.getJSONArray("list").getJSONObject(i).getInt("numDuration");
                }

                if ("B".equals(json.getJSONArray("list").getJSONObject(i).getString("mediaType")))
                {
                    json.getJSONArray("list").getJSONObject(i).getString("albumUrl");
                    json.getJSONArray("list").getJSONObject(i).getLong("coverPhotoId");
                    json.getJSONArray("list").getJSONObject(i).getInt("coverPhotoNumRevision");
                    json.getJSONArray("list").getJSONObject(i).getBoolean("coverPhotoAdultContent");
                    json.getJSONArray("list").getJSONObject(i).getInt("coverPhotoCodStatus");
                    json.getJSONArray("list").getJSONObject(i).getBoolean("hasAdultPhotos");
                }

                if ("V".equals(json.getJSONArray("list").getJSONObject(i).getString("mediaType"))
                        && json.getJSONArray("list").getJSONObject(i).has("formats"))
                {
                    json.getJSONArray("list").getJSONObject(i).getJSONArray("formats");

                    for (int j = 0; j < json.getJSONArray("list").getJSONObject(i).getJSONArray("formats")
                            .length(); j++)
                    {
                        json.getJSONArray("list").getJSONObject(i).getJSONArray("formats").getJSONObject(j)
                                .getString("id");
                        json.getJSONArray("list").getJSONObject(i).getJSONArray("formats").getJSONObject(j)
                                .getString("url");
                    }
                }

                JsonUtil.validateValueJson(json.getJSONArray("list").getJSONObject(i),
                    new String[] { "title", "description" });
            }

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - pagejson is not valid - " + e.getMessage() + " - " + json);
            return false;
        }
    }

    private boolean validateMediaJson(JSONObject json)
    {
        try
        {
            if (json == null || json.getJSONObject("_response").getInt("code") != HttpStatus.SC_OK)
            {
                return false;
            }
            json.getJSONObject("response");
            json.getJSONObject("response").getLong("code");
            json.getJSONObject("response").getString("description");

            json.getJSONObject("item");
            json.getJSONObject("item").getLong("mediaId");
            json.getJSONObject("item").getString("mediaType");
            json.getJSONObject("item").getString("mediaFile");
            json.getJSONObject("item").getBoolean("adultContent");
            json.getJSONObject("item").getString("codProfile");
            json.getJSONObject("item").getString("thumbnail");
            json.getJSONObject("item").getString("thumbSmall");
            json.getJSONObject("item").getString("thumbMedium");
            json.getJSONObject("item").getString("thumbLarge");
            json.getJSONObject("item").getString("allowNotes");
            json.getJSONObject("item").getString("shareUrl");
            json.getJSONObject("item").getInt("codStatus");
            json.getJSONObject("item").getString("visibility");

            if (json.getJSONObject("item").has("coverPhotoId"))
            {
                json.getJSONObject("item").getLong("coverPhotoId");
            }

            if (json.getJSONObject("item").has("coverPhotoNumRevision"))
            {
                json.getJSONObject("item").getInt("coverPhotoNumRevision");
            }

            if (json.getJSONObject("item").has("coverPhotoAdultContent"))
            {
                json.getJSONObject("item").getBoolean("coverPhotoAdultContent");
            }

            if (json.getJSONObject("item").has("coverPhotoCodStatus"))
            {
                json.getJSONObject("item").getLong("coverPhotoCodStatus");
            }

            if (json.getJSONObject("item").has("hasAdultPhotos"))
            {
                json.getJSONObject("item").getBoolean("hasAdultPhotos");
            }

            if (json.getJSONObject("item").has("title"))
            {
                json.getJSONObject("item").getString("title");
            }

            if (json.getJSONObject("item").has("description"))
            {
                json.getJSONObject("item").getString("description");
            }

            if (json.getJSONObject("item").has("tags"))
            {
                json.getJSONObject("item").getString("tags");
            }

            JsonUtil.validateValueJson(json.getJSONObject("item"), new String[] { "title", "description" });

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - pagejson is not valid - " + e.getMessage() + " - " + json);
            return false;
        }
    }
}
