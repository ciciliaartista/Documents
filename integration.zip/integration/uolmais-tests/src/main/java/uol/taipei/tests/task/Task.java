/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * msposito                         11/05/2017 Criacao inicial
 */

package uol.taipei.tests.task;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLConnection;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

//import uol.guaruja.client.netty.http.GuarujaHttpConnectionManager;
//import uol.guaruja.client.network.ConnectionManagerIF;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.ExecTask;
import uol.taipei.tests.util.JsonUtil;
import uol.taipei.util.DateUtil;
import uol.taipei.util.hash.HashCode;

public class Task extends AbstractTest
{

    private static final Logger logger = LoggerFactory.getLogger(Task.class);
    private static final Integer TIMEOUT = 30000;
    private static final Integer MAX_CONNECTIONS = 300;
    private static final Integer MAX_EXECUTIONS_PER_CONNECTION = 2000;
    //private ConnectionManagerIF taipeiReplicaConnectionManager;

    // private static NettyLoadbalancerConnectionManager replicaConnectionManager;

    public static void main(String[] args)
    {

        if (!verifyParams(args))
        {
            return;
        }

        setUp(args[0]);

        logger.debug("-------------------------------------------------");
        logger.debug("tests uolmais task");

        try
        {
            Task taskTest = new Task();

            // taskTest.getContent("207861");
            // taskTest.getJobEnconding();
            // taskTest.addContent();
            // taskTest.getMediaList();
            // taskTest.getMediasByDescription();
            // taskTest.getPublicMedias();
            // taskTest.getMediasResumed();
            // taskTest.getDocumentList(HashCode.encode(JsonUtil.codProfile()));
            // taskTest.getMediasModeration();
            // taskTest.getMediasFeatured();
            // taskTest.getMediasFavoriteByProfile(HashCode.encode(JsonUtil.codProfile()));
            // taskTest.getMediasRelatedByMedia(RequestUtil.mediaIdPublic("V"));
            // taskTest.getMediasResumed();
            // taskTest.getPublicMediasResumed(HashCode.encode(JsonUtil.codProfile()));
            // taskTest.updateContent("207861");

            // System.out.println("hash " + Hashing.farmHashFingerprint64().hashInt(0).asInt());
            //JSONObject media = JsonUtil.mediaIdtSubject(false);
            //Long idtSubject = Long.parseLong(JsonUtil.getParam(media, "idt_subject").toString());
            //taskTest.getContentBySubject(idtSubject);

            // taskTest.deleteMedia("207861");
        }
        catch (Exception e)
        {
            logger.error(e.getMessage());
            System.out.println(e.getMessage());
        }
    }

    public Task()
    {
        this.host = "http://" + envConfig().getGlobal().getUrltask() + "/exec";
        init();
    }

    public Task(String url)
    {
        this.host = url;
        init();
    }

    private void init()
    {
/*        try
        {
            taipeiReplicaConnectionManager = new GuarujaHttpConnectionManager(host, TIMEOUT, MAX_CONNECTIONS,
                    MAX_EXECUTIONS_PER_CONNECTION);
        }
        catch (URISyntaxException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }*/
    }
/*
    public Content getContent(String mediaId) throws Exception
    {
        ExecTask task = null;
        Content content = null;

        KeyIdtMedia keyMedia = new KeyIdtMedia(Long.parseLong(mediaId));

        try
        {
            task = new ExecTask(this.taipeiReplicaConnectionManager);
            content = task.getTask(TaskTypes.GET_CONTENT, keyMedia, Content.class);
            System.out.println("Content: " + content.toString());
        }
        catch (Exception e)
        {
            // log.error("Error: ", e);
            System.out.println("Error: " + e);
            return null;
        }
        return content;
    }

    public Content updateContent(String mediaId) throws Exception
    {
        ExecTask task = null;
        Content content = null;

        KeyIdtMedia keyMedia = new KeyIdtMedia(Long.parseLong(mediaId));

        try
        {
            task = new ExecTask(this.taipeiReplicaConnectionManager);
            content = task.getTask(TaskTypes.GET_CONTENT, keyMedia, Content.class);
            content = task.getTask(TaskTypes.UPDATE_CONTENT, keyMedia, Content.class);
            System.out.println("Content: " + content.toString());
        }
        catch (Exception e)
        {
            // log.error("Error: ", e);
            System.out.println("Error: " + e);
            return null;
        }
        return content;
    }

    public Content getContentBySubject(Long idtSubject) throws Exception
    {
        ExecTask task = null;
        Content content = null;

        KeyIdtSubject keySubject = new KeyIdtSubject(idtSubject);

        try
        {
            task = new ExecTask(this.taipeiReplicaConnectionManager);
            content = task.getTask(TaskTypes.GET_CONTENT_BY_SUBJECT, keySubject, Content.class);
            System.out.println("Content by subject: " + content.toString());
        }
        catch (Exception e)
        {
            // log.error("Error: ", e);
            System.out.println("Error: " + e);
            return null;
        }
        return content;
    }

    public Content getContentNoCache(String mediaId) throws Exception
    {
        ExecTask task = null;
        KeyIdtMedia keyMedia = new KeyIdtMedia(Long.parseLong(mediaId));
        Content content = null;

        try
        {
            task = new ExecTask(this.taipeiReplicaConnectionManager);
            content = task.getTask(TaskTypes.GET_CONTENT_NOCACHE, keyMedia, Content.class);
            System.out.println("Content by subject: " + content.toString());
        }
        catch (Exception e)
        {
            // log.error("Error: ", e);
            System.out.println("Error: " + e);
            return null;
        }
        return content;
    }

    public void getJobEnconding() throws Exception
    {
        ExecTask task = null;
        KeyStatusMedia key = new KeyStatusMedia();

        try
        {
            task = new ExecTask(this.taipeiReplicaConnectionManager);
            JobEncoding jobEncoding = task.getTask(TaskTypes.GET_JOB_ENCODING, key, JobEncoding.class);
            System.out.println("job enconding: " + jobEncoding.toString());
        }
        catch (Exception e)
        {
            // log.error("Error: ", e);
            System.out.println("Error: " + e);
        }
        // System.out.println("Content: " + content.toString());
    }

    public BasicContentCollection getMediaList() throws Exception
    {
        ExecTask task = null;
        BasicContentCollection basicContentCollection = null;
        KeyVideoPage keyVideoPage = new KeyVideoPage();
        keyVideoPage.setPage(1);
        keyVideoPage.setNumElements(6);

        try
        {
            task = new ExecTask(this.taipeiReplicaConnectionManager);
            basicContentCollection = task.getTask(TaskTypes.GET_MEDIA_LIST, keyVideoPage, BasicContentCollection.class);

            for (int i = 0; i < basicContentCollection.getContents().length; i++)
            {
                System.out.println("media list: " + basicContentCollection.getContents()[i]);
            }
        }
        catch (Exception e)
        {
            // log.error("Error: ", e);
            System.out.println("Error: " + e);
            return null;
        }
        return basicContentCollection;
    }

    public BasicContentCollection getMediasByDescription() throws Exception
    {
        ExecTask task = null;
        KeyVideoPage keyVideoPage = new KeyVideoPage();
        BasicContentCollection basicContentCollection = null;
        keyVideoPage.setPage(1);
        keyVideoPage.setNumElements(6);
        keyVideoPage.setMediaType(new String[] { "V" });

        try
        {
            task = new ExecTask(this.taipeiReplicaConnectionManager);
            basicContentCollection = task.getTask(TaskTypes.GET_MEDIAS_BY_DESCRIPTION, keyVideoPage,
                BasicContentCollection.class);

            for (int i = 0; i < basicContentCollection.getContents().length; i++)
            {
                System.out.println("media list: " + basicContentCollection.getContents()[i]);
            }
        }
        catch (Exception e)
        {
            // log.error("Error: ", e);
            System.out.println("Error: " + e);
            return null;
        }
        return basicContentCollection;
    }

    public BasicContentCollection getPublicMedias() throws Exception
    {
        ExecTask task = null;
        BasicContentCollection basicContentCollection = null;
        KeyVideoPage keyVideoPage = new KeyVideoPage();
        keyVideoPage.setPage(1);
        keyVideoPage.setNumElements(6);
        keyVideoPage.setMediaType(new String[] { "V" });

        try
        {
            task = new ExecTask(this.taipeiReplicaConnectionManager);
            basicContentCollection = task.getTask(TaskTypes.GET_PUBLIC_MEDIAS, keyVideoPage, BasicContentCollection.class);

            for (int i = 0; i < basicContentCollection.getContents().length; i++)
            {
                System.out.println("media list: " + basicContentCollection.getContents()[i]);
            }
        }
        catch (Exception e)
        {
            // log.error("Error: ", e);
            System.out.println("Error: " + e);
            return null;
        }
        return basicContentCollection;
    }

    public ResumedMediaCollection getMediasResumed() throws Exception
    {
        ExecTask task = null;
        ResumedMediaCollection resumedMediaCollection = null;
        KeyVideoPage keyVideoPage = new KeyVideoPage();
        keyVideoPage.setPage(1);
        keyVideoPage.setNumElements(6);
        // keyVideoPage.setMediaType(new String[] { "V" });

        try
        {
            task = new ExecTask(this.taipeiReplicaConnectionManager);
            resumedMediaCollection = task.getTask(TaskTypes.GET_MEDIAS_RESUMED, keyVideoPage, ResumedMediaCollection.class);
            // resumedMediaCollection = task.getTask(taskName, keyVideoPage, ResumedMediaCollection.class);

            for (int i = 0; i < resumedMediaCollection.getContents().length; i++)
            {
                System.out.println("media list: " + resumedMediaCollection.getContents()[i]);
            }
        }
        catch (Exception e)
        {
            // log.error("Error: ", e);
            System.out.println("Error: " + e);
            return null;
        }

        return resumedMediaCollection;
    }

    public ResumedMediaCollection getPublicMediasResumed(Long codProfileHash) throws Exception
    {
        ExecTask task = null;
        ResumedMediaCollection resumedMediaCollection = null;
        KeyVideoPage keyVideoPage = new KeyVideoPage();
        keyVideoPage.setPage(1);
        keyVideoPage.setNumElements(6);
        keyVideoPage.setEditorialFilter(KeyVideoPage.EDITORIAL_FILTER_ALL);
        keyVideoPage.setCodProfileHash(codProfileHash);
        keyVideoPage.setMediaType(new String[] { "V" });

        try
        {
            task = new ExecTask(this.taipeiReplicaConnectionManager);
            resumedMediaCollection = task.getTask(TaskTypes.GET_PUBLIC_MEDIAS_RESUMED, keyVideoPage,
                ResumedMediaCollection.class);
        }
        catch (Exception e)
        {
            // log.error("Error: ", e);
            System.out.println("Error: " + e);
            return null;
        }

        return resumedMediaCollection;
    }

    public DocumentCollection getDocumentList(Long codProfileHash) throws Exception
    {
        ExecTask task = null;
        KeyVideoPage keyVideoPage = new KeyVideoPage();
        
        DocumentCollection documentCollection = null;
        keyVideoPage.setCodProfileHash(codProfileHash);
        keyVideoPage.setPage(1);
        keyVideoPage.setNumElements(6);
        keyVideoPage.setMediaType(new String[] { "V" });
        keyVideoPage.setEditorialFilter(KeyVideoPage.EDITORIAL_FILTER_ALL);

        try
        {
            task = new ExecTask(this.taipeiReplicaConnectionManager);
            documentCollection = task.getTask(TaskTypes.GET_DOCUMENT_LIST, keyVideoPage, DocumentCollection.class);

            //System.out.println("media list: " + documentCollection.getTotal());
        }
        catch (Exception e)
        {
            logger.error("Error: ", e);
            //System.out.println("Error: " + e);
            return null;
        }
        return documentCollection;
    }

    public BasicContentCollection getMediasModeration() throws Exception
    {
        ExecTask task = null;
        KeyVideoPage keyVideoPage = new KeyVideoPage();
        BasicContentCollection basicContentCollection = null;
        keyVideoPage.setPage(1);
        keyVideoPage.setNumElements(6);

        try
        {
            task = new ExecTask(this.taipeiReplicaConnectionManager);
            basicContentCollection = task.getTask(TaskTypes.GET_MEDIAS_MODERATION, keyVideoPage, BasicContentCollection.class);

            for (int i = 0; i < basicContentCollection.getContents().length; i++)
            {
                System.out.println("media list: " + basicContentCollection.getContents()[i]);
            }
        }
        catch (Exception e)
        {
            // log.error("Error: ", e);
            System.out.println("Error: " + e);
            return null;
        }
        return basicContentCollection;
    }

// esta com erro
//    public BasicContentCollection getMediasEditorialStatus() throws Exception
//    {
//        ExecTask task = null;
//        KeyVideoPage keyVideoPage = new KeyVideoPage();
//        BasicContentCollection basicContentCollection = null;
//        keyVideoPage.setPage(1);
//        keyVideoPage.setNumElements(6);
//        // keyVideoPage.setMediaType(new String[] { "V" });
//
//        try
//        {
//            task = new ExecTask(this.taipeiReplicaConnectionManager);
//            basicContentCollection = task.getTask(TaskTypes.GET_MEDIAS_EDITORIAL_STATUS, keyVideoPage,
//                BasicContentCollection.class);
//
//            for (int i = 0; i < basicContentCollection.getContents().length; i++)
//            {
//                System.out.println("media list: " + basicContentCollection.getContents()[i]);
//            }
//        }
//        catch (Exception e)
//        {
//            // log.error("Error: ", e);
//            System.out.println("Error: " + e);
//            return null;
//        }
//
//        return basicContentCollection;
//    }

    public BasicContentCollection getMediasFeatured() throws Exception
    {
        ExecTask task = null;
        KeyVideoPage keyVideoPage = new KeyVideoPage();
        BasicContentCollection basicContentCollection = null;
        keyVideoPage.setAdm(true);

        try
        {
            task = new ExecTask(this.taipeiReplicaConnectionManager);
            basicContentCollection = task.getTask(TaskTypes.GET_MEDIAS_FEATURED, keyVideoPage, BasicContentCollection.class);

            for (int i = 0; i < basicContentCollection.getContents().length; i++)
            {
                System.out.println("media list: " + basicContentCollection.getContents()[i]);
            }
        }
        catch (Exception e)
        {
            // log.error("Error: ", e);
            System.out.println("Error: " + e);
            return null;
        }
        return basicContentCollection;
    }

//    // está com erro
//    public BasicContentCollection getMediasModeratorStatus() throws Exception
//    {
//        ExecTask task = null;
//        KeyVideoPage keyVideoPage = new KeyVideoPage();
//        BasicContentCollection basicContentCollection = null;
//        keyVideoPage.setAdm(true);
//        keyVideoPage.setPage(1);
//        keyVideoPage.setNumElements(6);
//        keyVideoPage.setLoadWay(3);
//        keyVideoPage.setMediaType(Media.ALL_TYPES);
//        keyVideoPage.setCodEditorialStatus(1);
//        keyVideoPage.setDate(DateUtil.getDate("01/07/2017").getTime());
//        keyVideoPage.setDateEnd(DateUtil.getDate("14/07/2017").getTime());
//        keyVideoPage.setIndAuthorizedLists(Media.AUTHORIZED_LIST_ALL);
//
//        try
//        {
//            task = new ExecTask(this.taipeiReplicaConnectionManager);
//            basicContentCollection = task.getTask(TaskTypes.GET_MEDIAS_MODERATOR_STATUS, keyVideoPage,
//                BasicContentCollection.class);
//
//            for (int i = 0; i < basicContentCollection.getContents().length; i++)
//            {
//                System.out.println("media list: " + basicContentCollection.getContents()[i]);
//            }
//        }
//        catch (Exception e)
//        {
//            // log.error("Error: ", e);
//            System.out.println("Error: " + e);
//            return null;
//        }
//        return basicContentCollection;
//    }

    public BasicFavouriteContentCollection getMediasFavoriteByProfile(Long codProfileHash) throws Exception
    {
        ExecTask task = null;
        KeyVideoPage keyVideoPage = new KeyVideoPage();
        BasicFavouriteContentCollection basicFavContentCollection = null;
        keyVideoPage.setCodProfileHash(codProfileHash);

        try
        {
            task = new ExecTask(this.taipeiReplicaConnectionManager);
            basicFavContentCollection = task.getTask(TaskTypes.GET_MEDIAS_FAVORITE_BY_PROFILE, keyVideoPage,
                BasicFavouriteContentCollection.class);
        }
        catch (Exception e)
        {
            // log.error("Error: ", e);
            System.out.println("Error: " + e);
            return null;
        }
        return basicFavContentCollection;
    }

    public BasicContentCollection getMediasRelatedByMedia(String mediaId) throws Exception
    {
        ExecTask task = null;
        KeyIdtMedia keyMedia = new KeyIdtMedia(Long.parseLong(mediaId));
        BasicContentCollection basicContentCollection = null;

        try
        {
            task = new ExecTask(this.taipeiReplicaConnectionManager);
            basicContentCollection = task.getTask(TaskTypes.GET_MEDIAS_RELATED_BY_MEDIA, keyMedia, Content.class);
            for (int i = 0; i < basicContentCollection.getContents().length; i++)
            {
                System.out.println("media list related: " + basicContentCollection.getContents()[i]);
            }
        }
        catch (Exception e)
        {
            // log.error("Error: ", e);
            System.out.println("Error: " + e);
            return null;
        }
        return basicContentCollection;
    }

    public static void execTask(String taskName)
    {
        try
        {
            URL url = new URL("http://lb.taipei.sys.intranet:2280/exec");
            URLConnection conn;
            conn = url.openConnection();
            conn.setDoOutput(true);

            OutputStream outputStream = conn.getOutputStream();
            String request = "request-id: OlmKLzvMJcfXmtZGanoDFi\nprotocol-version: 1\nrequest-type: " + taskName
                    + "\n\nidtMedia: 207861\nidtOutputFormat: 2\n\n";
            // byte[] encoded = Files.readAllBytes(Paths.get("/tmp/request.txt"));
            byte[] encoded = request.getBytes();
            outputStream.write(encoded);
            outputStream.flush();

            // Get the response
            BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String line;
            while ((line = rd.readLine()) != null)
            {
                System.out.println(line);
            }
            outputStream.close();
            rd.close();
        }
        catch (IOException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
/*
    /*
     * public static void main(String[] args) { try { try { run(); return; } catch (HttpResponseException e) {
     * System.err.println(e.getMessage()); } } catch (Throwable t) { t.printStackTrace(); } System.exit(1); }
     */
}
