/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         04/03/2015 Criacao inicial
 */

package uol.taipei.tests.maxima;

import java.util.HashMap;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uol.taipei.request.UsefulRequest;
import uol.taipei.tests.AbstractTest;

public class HealthCheckMaxima extends AbstractTest
{
    static final Logger logger = LoggerFactory.getLogger(HealthCheckMaxima.class);

    public static void main(String[] args)
    {
        if (!verifyParams(args))
        {
            return;
        }

        setUp(args[0]);

        logger.debug("-------------------------------------------------");
        logger.debug("tests health check dona maxima");

        try
        {
            HealthCheckMaxima healthCheckMaxima = new HealthCheckMaxima();
            UsefulRequest request = new UsefulRequest();

            healthCheckMaxima.probe(request);
        }
        catch (Exception e)
        {
            logger.error(e.getMessage());
        }
    }

    public HealthCheckMaxima()
    {
        this.host = "http://" + envConfig().getGlobal().getUrlmax();
    }

    public HealthCheckMaxima(String url)
    {
        this.host = url;
    }

    public boolean probe(UsefulRequest request) throws Exception
    {
        JSONObject responseJson = null;

        try
        {
            HashMap<String, String> headers = new HashMap<String, String>();
            headers.put("Host", "maxima.mais.sys.intranet");

            responseJson = request.getJson(host + "/probe", headers);

            if (responseJson == null || responseJson.getJSONObject("_response").getInt("code") != 200)
            {
                logger.error("ERROR - return not valid - " + responseJson);
                return false;
            }

            responseJson.getString("upTime");
            responseJson.getString("status");
            responseJson.getString("serverVersion");
        }
        catch (Exception e)
        {
            logger.error("ERROR - return not valid - " + e.getMessage() + " - " + responseJson);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

}
