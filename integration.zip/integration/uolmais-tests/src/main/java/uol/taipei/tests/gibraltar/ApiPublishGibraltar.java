/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         26/08/2014 Criacao inicial
 */

package uol.taipei.tests.gibraltar;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.FileUtils;
import org.apache.http.HttpStatus;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uol.taipei.request.FacileRequest;
import uol.taipei.request.FacileResponse;
import uol.taipei.request.JsonRequest;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.util.JsonUtil;
import uol.taipei.tests.util.RequestUtil;
import uol.taipei.tests.util.TestUtil;
import uol.taipei.util.hash.HashCode;
import uol.taipei.webServiceClient.WSReturn;

public class ApiPublishGibraltar extends AbstractTest
{
    static final Logger logger = LoggerFactory.getLogger(ApiPublishGibraltar.class);

    public static void main(String[] args)
    {
        if (!verifyParams(args))
        {
            return;
        }

        setUp(args[0]);

        if (envConfig().getUser() == null || envConfig().getUser().equals("") || envConfig().getPass() == null || envConfig().getPass().equals(""))
        {
            System.err.println("Invalid user " + envConfig().getUser());
            return;
        }

        logger.debug("-------------------------------------------------");
        logger.debug("tests api publish gibraltar");

        try
        {
            ApiPublishGibraltar apiPublishGibraltar = new ApiPublishGibraltar();
            WSReturn wsprofile = JsonUtil.profile(envConfig().getUser());
            /* pegar como string, como Long vem valor errado
             * getString("codProfileHash") 953124325347642202
             * getLong("codProfileHash") 953124325347642240
             */
            Long codProfileHash = Long.valueOf(wsprofile.getObjResponse().getString("codProfileHash"));

            apiPublishGibraltar.uploadVideo(codProfileHash);
            apiPublishGibraltar.uploadPodcast(codProfileHash);
            apiPublishGibraltar.statusAudio(codProfileHash);

            String mediaId = RequestUtil.mediaId("V", codProfileHash);

//          precisa ser usuario editorial, alguns campos sao restritos a esse tipo de usuario
//            if (mediaId == null)
//            {
//                mediaId = RequestUtil.getMediaIdPublic("V");
//                codProfileHash = Long.valueOf(JsonRequest.getMedia(String.valueOf(mediaId)).getString("cod_profile_hash"));
//            }

            apiPublishGibraltar.publishThumb();
            apiPublishGibraltar.statusVideo(codProfileHash, Long.valueOf(mediaId));
            apiPublishGibraltar.statusErrInvalidOwner(codProfileHash, Long.valueOf(mediaId));
            apiPublishGibraltar.updateMediaErrInvalidOwner(codProfileHash, Long.valueOf(mediaId));
            apiPublishGibraltar.updateMedia(Long.valueOf(mediaId));

            apiPublishGibraltar.updateContentStatus(Long.valueOf(mediaId), 10, 2);

            apiPublishGibraltar.uploadErrNoProfile();
            apiPublishGibraltar.uploadErrIvalidProfile();

            FacileRequest request = new FacileRequest();

            apiPublishGibraltar.notPublishVideoNoAuth(request, codProfileHash);
            apiPublishGibraltar.notPublishAudioNoAuth(request, codProfileHash);
        }
        catch (Exception e)
        {
            logger.error(e.getMessage());
        }
    }

    public JSONObject uploadVideo(Long codProfileHash) throws Exception
    {
        String url = "http://beta.mais.uol.com.br/apiuol/publish/video?variant=json&codProfileHash=" + codProfileHash;
        String fileName = System.getenv("PATH_FILE_TEST") + File.separator + "video.mp4";
        java.io.File file = new java.io.File(fileName);
        HashMap<String, String> params = new HashMap<String, String>();
        params.put("media.desMedia", "Gibraltar video publish");

        WSReturn ret = JsonUtil.wsReturn(JsonRequest.execGibraltar(url, "POST", null, null, 10000, file, params));

        if (ret.getResponseCode() != 200)
        {
            logger.error("ERROR - response not valid - " + ret.getResponseCode());
            return null;
        }

        if (!validatePublishMediaJson(ret.getObjResponse()))
        {
            logger.error("ERROR - return not valid - " + ret.getObjResponse());
            return null;
        }

        logger.debug("SUCCESS");

        return ret.getObjResponse();
    }

    public JSONObject uploadPodcast(Long codProfileHash) throws Exception
    {
        String url = "http://beta.mais.uol.com.br/apiuol/publish/audio?variant=json&codProfileHash=" + codProfileHash;
        String fileName = System.getenv("PATH_FILE_TEST") + File.separator + "audio.mp3";
        java.io.File file = new java.io.File(fileName);
        HashMap<String, String> params = new HashMap<String, String>();
        params.put("media.desMedia", "Gibraltar audio publish");

        WSReturn ret = JsonUtil.wsReturn(JsonRequest.execGibraltar(url, "POST", null, null, 10000, file, params));

        if (ret.getResponseCode() != 200)
        {
            logger.error("ERROR - response not valid - " + ret.getResponseCode());
            return null;
        }

        if (!validatePublishMediaJson(ret.getObjResponse()))
        {
            logger.error("ERROR - return not valid - " + ret.getObjResponse());
            return null;
        }

        logger.debug("SUCCESS");

        return ret.getObjResponse();
    }

    public JSONObject statusVideo(Long codProfileHash, Long mediaId) throws Exception
    {
        String url = "http://beta.mais.uol.com.br/apiuol/media/status?variant=json&codProfileHash=" + codProfileHash + "&mediaId="
                + mediaId;
        WSReturn ret = JsonUtil.wsReturn(JsonRequest.execGibraltar(url, "GET", null, null, 10000, null, null));

        if (ret.getResponseCode() != 200)
        {
            logger.error("ERROR - response not valid - " + ret.getResponseCode());
            return null;
        }

        if (!validateStatusJson(ret.getObjResponse()))
        {
            logger.error("ERROR - return not valid - " + ret.getObjResponse());
            return null;
        }

        if (!"V".equals(ret.getObjResponse().getJSONObject("media").getString("mediaType")))
        {
            logger.error("ERROR - mediaType not valid - " + ret.getObjResponse());
            return null;
        }

        logger.debug("SUCCESS");

        return ret.getObjResponse();
    }

    public JSONObject statusAudio(Long codProfileHash) throws Exception
    {
        String mediaId = RequestUtil.mediaId("P", codProfileHash);
        String url = "http://beta.mais.uol.com.br/apiuol/media/status?variant=json&codProfileHash=" + codProfileHash + "&mediaId="
                + mediaId;
        WSReturn ret = JsonUtil.wsReturn(JsonRequest.execGibraltar(url, "GET", null, null, 10000, null, null));

        if (ret.getResponseCode() != 200)
        {
            logger.error("ERROR - response not valid - " + ret.getResponseCode());
            return null;
        }

        if (!validateStatusJson(ret.getObjResponse()))
        {
            logger.error("ERROR - return not valid - " + ret.getObjResponse());
            return null;
        }

        if (!"P".equals(ret.getObjResponse().getJSONObject("media").getString("mediaType")))
        {
            logger.error("ERROR - mediaType not valid - " + ret.getObjResponse());
            return null;
        }

        logger.debug("SUCCESS");

        return ret.getObjResponse();
    }

    public JSONObject publishThumb()
    {
        HashMap<String, String> params = new HashMap<String, String>();
        final String[] extFoto = new String[] { "jpg", "JPG", "jpeg", "JPEG", "bmp", "BMP", "gif", "GIF", "png", "PNG" };

        try
        {
            String pathfileTest = System.getenv("PATH_FILE_TEST") + java.io.File.separator;
            java.io.File file;

            List<java.io.File> fileList = TestUtil.files(pathfileTest, "B");

            if (!fileList.isEmpty() && fileList.size() > 0)
            {
                java.io.File jsonFile = fileList.get((new Random()).nextInt(fileList.size()));
                String mediaId = jsonFile.getName().substring(0, jsonFile.getName().indexOf("."));

                int i = 0;
                do
                {
                    file = new java.io.File(pathfileTest + mediaId + "." + extFoto[i]);
                    i++;
                }
                while ((file == null || !file.exists()) && i < extFoto.length);
            }
            else
            {
                file = new java.io.File(pathfileTest + "foto.jpg");
            }

            if (file == null || !file.exists())
            {
                logger.error("ERROR - file not found - " + (file != null ? file.getAbsolutePath() : null));
                return null;
            }

            String base64ImgString = (new Base64()).encodeToString(FileUtils.readFileToByteArray(file));
            params.put("media.thumbnail", base64ImgString);

            JSONObject media = JsonUtil.mediaNoRestrictByParam("types=V&edFilter=editorial");

            params.put("media.idtMedia", String.valueOf(media.getLong("mediaId")));

            String url = "http://beta.mais.uol.com.br/apiuol/selectThumb?variant=json&codProfileHash=" + HashCode.encode(media.getString("codProfile"));
            WSReturn ret = JsonUtil.wsReturn(JsonRequest.execGibraltar(url, "POST", null, null, 10000, null, params));

            if (!validateMessageJson(ret.getObjResponse(), 'S'))
            {
                logger.error("ERROR - return not valid - " + ret);
                return null;
            }

            logger.debug("SUCCESS");

            return ret.getObjResponse();
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return null;
        }
    }

    public boolean statusErrInvalidOwner(Long codProfileHash, Long mediaId) throws Exception
    {
        JSONObject anotherOwner = getDifferentProfile(codProfileHash);
        String url = "http://beta.mais.uol.com.br/apiuol/media/status?variant=json&mediaId=" + mediaId + "&codProfileHash=" 
                + anotherOwner.getJSONObject("profile").getLong("codProfileHash");
        WSReturn ret = JsonUtil.wsReturn(JsonRequest.execGibraltar(url, "GET", null, null, 10000, null, null));

        if (ret.getResponseCode() == 200)
        {
            logger.error("ERROR - response not valid - " + ret.getResponseCode());
            return false;
        }

        if (ret.getObjResponse() != null && (ret.getObjResponse().has("mediaStatus") || ret.getObjResponse().has("media")))
        {
            logger.error("ERROR - return not valid - " + ret.getObjResponse());
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean updateMediaErrInvalidOwner(Long codProfileHash, Long mediaId) throws Exception
    {
        JSONObject anotherOwner = getDifferentProfile(codProfileHash);
        String url = "http://beta.mais.uol.com.br/apiuol/media/update?variant=json&mediaId=" + mediaId + "&codProfileHash=" 
                + anotherOwner.getJSONObject("profile").getLong("codProfileHash");
        String data = TestUtil.randomString(5);
        HashMap<String, String> params = new HashMap<String, String>();
        params.put("media.namSubject", data);

        WSReturn ret = JsonUtil.wsReturn(JsonRequest.execGibraltar(url, "POST", null, null, 10000, null, params));

        if (ret.getResponseCode() == 200)
        {
            logger.error("ERROR - response not valid - " + ret);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public JSONObject updateMedia(Long mediaId)
    {
        try
        {
            int retry = 0;
            JSONObject media = JsonRequest.get("http://mais.uol.com.br/apiuol/v2/media/detail?mediaId=" + mediaId + "&nocache=" + Math.random());

            // a alteracao valida o dono da midia, entao precisa passar o codProfileHash
            Long codProfileHash = HashCode.encode(media.getJSONObject("media").getString("codProfile"));
            String url = "http://beta.mais.uol.com.br/apiuol/media/update?variant=json&mediaId=" + mediaId + "&codProfileHash=" + codProfileHash;
            Integer tagService = new Random().nextInt(10000);
            String data = TestUtil.randomString(5);
            //String taglist = tags(media.getJSONObject("media"));

            HashMap<String, String> params = new HashMap<String, String>();
            params.put("media.namSubject", data + " " + (media.getJSONObject("media").has("title") ? 
                    media.getJSONObject("media").getString("title") : ""));
            params.put("media.desMedia", data + " gibraltar - " + (media.getJSONObject("media").has("description") ? 
                    media.getJSONObject("media").getString("description") : ""));
            //params.put("media.tags", data + (taglist != null ? "," + taglist : ""));

            if ("V".equals(media.getJSONObject("media").getString("mediaType")))
            {
                // editorial
                params.put("media.idtTagService", tagService.toString());
            }

            WSReturn ret = JsonUtil.wsReturn(JsonRequest.execGibraltar(url, "POST", null, null, 10000, null, params));

            if (ret.getResponseCode() != 200)
            {
                logger.error("ERROR - response not valid - " + ret.getResponseCode());
                return null;
            }

            if (!validateUpdateMediaJson(ret.getObjResponse()))
            {
                logger.error("ERROR - return not valid - mediaId " + mediaId + " - " + ret.getObjResponse());
                return null;
            }

            WSReturn mediaUpdate = JsonUtil.wsReturn(JsonRequest.execGibraltar("http://beta.mais.uol.com.br/apiuol/media/status?variant=json&codProfileHash=" 
                    + codProfileHash + "&mediaId=" + mediaId, "GET", null, null, 10000));

            while (mediaUpdate != null && mediaUpdate.getResponseCode() != 200 && retry < 3)
            {
                logger.warn("retry after 1s - " + mediaId);

                TestUtil.delay(1000);
                mediaUpdate = JsonUtil.wsReturn(JsonRequest.execGibraltar("http://beta.mais.uol.com.br/apiuol/media/status?variant=json&codProfileHash=" + codProfileHash 
                    + "&mediaId=" + mediaId, "GET", null));
                retry++;
            }
            
            if (!ret.getObjResponse().getJSONObject("media").getString("title").startsWith(data)
                    || !mediaUpdate.getObjResponse().getJSONObject("media").getString("title").startsWith(data))
            {
                logger.error("ERROR - return not valid - data title was not updated - " + media + " - " + mediaUpdate);
                return null;
            }

            if (!ret.getObjResponse().getJSONObject("media").getString("description").startsWith(data)
                    || !mediaUpdate.getObjResponse().getJSONObject("media").getString("description").startsWith(data))
            {
                logger.error("ERROR - return not valid - data description was not updated - " + media + " - " + mediaUpdate);
                return null;
            }

            if ("V".equals(media.getJSONObject("media").getString("mediaType")))
            {
                // editorial
                if (!ret.getObjResponse().getJSONObject("media").getString("idtTagService")
                        .equals(mediaUpdate.getObjResponse().getJSONObject("media").getString("idtTagService"))
                        || !params.get("media.idtTagService").equals(mediaUpdate.getObjResponse().getJSONObject("media").getString("idtTagService")))
                {
                    logger.error("ERROR - return not valid - data idtTagService was not updated - " + media + " - " + mediaUpdate);
                    return null;
                }
            }

            logger.debug("SUCCESS");

            // volta dados originais
            backData("http://beta.mais.uol.com.br/apiuol/media/update?variant=json&mediaId=" + mediaId + "&codProfileHash=" + codProfileHash, 
                params, media);

            return ret.getObjResponse();
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return null;
        }
    }

    public boolean uploadErrNoProfile() throws Exception
    {
        String fileName = System.getenv("PATH_FILE_TEST") + File.separator + "video.mp4";
        java.io.File file = new java.io.File(fileName);
        HashMap<String, String> params = new HashMap<String, String>();
        params.put("media.desMedia", "Gibraltar upload error");

        WSReturn ret = JsonUtil.wsReturn(JsonRequest.execGibraltar("http://beta.mais.uol.com.br/apiuol/publish/video?variant=json", "POST", null, null, 10000, file, params));

        if (ret.getResponseCode() == 200)
        {
            logger.error("ERROR - response not valid - " + ret.getResponseCode());
            return false;
        }

        if (ret.getObjResponse() != null && ret.getObjResponse().has("media"))
        {
            logger.error("ERROR - return not valid - " + ret.getObjResponse());
            return false;
        }

        ret = JsonUtil.wsReturn(JsonRequest.execGibraltar("http://beta.mais.uol.com.br/apiuol/publish/video?variant=json&codProfileHash=", "POST", null, null, 10000, file, 
            params));

        if (ret.getResponseCode() == 200)
        {
            logger.error("ERROR - response not valid - " + ret.getResponseCode());
            return false;
        }

        if (ret.getObjResponse() != null && ret.getObjResponse().has("media"))
        {
            logger.error("ERROR - return not valid - " + ret.getObjResponse());
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean uploadErrIvalidProfile() throws Exception
    {
        String url = "http://beta.mais.uol.com.br/apiuol/publish/video?variant=json&codProfileHash=0";
        String fileName = System.getenv("PATH_FILE_TEST") + File.separator + "video.mp4";
        java.io.File file = new java.io.File(fileName);
        HashMap<String, String> params = new HashMap<String, String>();
        params.put("media.desMedia", "Gibraltar upload error");

        WSReturn ret = JsonUtil.wsReturn(JsonRequest.execGibraltar(url, "POST", null, null, 10000, file, params));

        if (ret.getResponseCode() == 200)
        {
            logger.error("ERROR - response not valid - " + ret.getResponseCode());
            return false;
        }

        if (ret.getObjResponse() != null && ret.getObjResponse().has("media"))
        {
            logger.error("ERROR - return not valid - " + ret.getObjResponse());
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    /**
     * nao publicar video sem autenticacao gibraltar
     * 
     * @param request
     * @param codProfileHash
     * @return boolean
     */
    public boolean notPublishVideoNoAuth(FacileRequest request, Long codProfileHash)
    {
        try
        {
            java.io.File file = new java.io.File(System.getenv("PATH_FILE_TEST") + File.separator + "video.mp4");
            FacileResponse response = request.post("http://beta.mais.uol.com.br/apiuol/publish/video?variant=json&codProfileHash=" 
                    + codProfileHash, null, null, file, false);

            if (response.getCode() == 200)
            {
                logger.error("ERROR - return not valid - " + response.getBody());
                return false;
            }
    
            logger.debug("SUCCESS");
    
            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return false;
        }
    }

    /**
     * nao publicar audio sem autenticacao gibraltar
     * 
     * @param request
     * @param codProfileHash
     * @return boolean
     */
    public boolean notPublishAudioNoAuth(FacileRequest request, Long codProfileHash)
    {
        try
        {
            java.io.File file = new java.io.File(System.getenv("PATH_FILE_TEST") + File.separator + "audio.mp3");
            FacileResponse response = request.post("http://beta.mais.uol.com.br/apiuol/publish/audio?variant=json&codProfileHash=" 
                    + codProfileHash, null, null, file, false);
    
            if (response.getCode() == 200)
            {
                logger.error("ERROR - return not valid - " + response.getBody());
                return false;
            }
    
            logger.debug("SUCCESS");
    
            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return false;
        }
    }

    /**
     * um profile com codProfileHash diferente
     * 
     * @param codProfileHash
     * @return JSONObject
     * @throws Exception
     */
    private JSONObject getDifferentProfile(Long codProfileHash) throws Exception
    {
        int limit = 10;
        int start = 0;
        Long codChildProfileHash = null;
        JSONArray jsonarray = JsonUtil.codProfileHashPaging(start, limit);

        while (jsonarray != null && jsonarray.length() > 0)
        {
            for (int i = 0; i < jsonarray.length(); i++)
            {
                codChildProfileHash = Long.valueOf(jsonarray.getJSONObject(i).getString("cod_profile_hash"));

                if (!codChildProfileHash.equals(codProfileHash))
                {
                    return JsonUtil.fullProfile(codChildProfileHash);
                }
            }

            start+=limit;
            jsonarray = JsonUtil.codProfileHashPaging(start, limit);
        }

        return null;
    }

    private String tags(JSONObject mediajson) throws Exception
    {
        StringBuffer tag = new StringBuffer();

        if (mediajson.has("tags"))
        {
            // array de tags tags=[{"id": , "description": ""}...]
            if (mediajson.optJSONArray("tags") != null && mediajson.getJSONArray("tags").length() > 0)
            {
                for (int i = 0; i < mediajson.getJSONArray("tags").length(); i++)
                {
                    tag.append((tag.length() < 1 ? "" : ",") + mediajson.getJSONArray("tags").getJSONObject(i).getString("description"));
                }

                return tag.toString();
            }
            // lista de string de tags tags=a,b
            else if (!mediajson.getString("tags").trim().equals(""))
            {
                return mediajson.getString("tags");
            }
        }

        return null;
    }

    private void backData(String url, HashMap<String, String> params, JSONObject mediajson) throws Exception
    {
        String t = tags(mediajson.getJSONObject("media"));

        if ("V".equals(mediajson.getJSONObject("media").getString("mediaType")))
        {
            params.put("media.idtTagService", mediajson.getJSONObject("media").getString("idtTagService"));
        }

        params.put("media.namSubject", mediajson.getJSONObject("media").getString("title"));
        params.put("media.desMedia", mediajson.getJSONObject("media").getString("description"));
        params.put("media.tags", (t != null ? t : ""));

        JsonRequest.execGibraltar(url, "POST", null, null, 10000, null, params);
    }

    private boolean validateStatusJson(JSONObject json)
    {
        try
        {
            json.getJSONObject("media");
            json.getJSONObject("media").getString("title");
            json.getJSONObject("media").getString("mediaId");
            json.getJSONObject("media").getString("url");
            json.getJSONObject("media").getString("thumbnail");
            json.getJSONObject("media").getString("thumbSmall");
            json.getJSONObject("media").getString("thumbMedium");
            json.getJSONObject("media").getString("thumbLarge");
            json.getJSONObject("media").getString("mediaType");
            json.getJSONObject("media").getBoolean("moderateNote");
            json.getJSONObject("media").getBoolean("allowAnonymousComment");
            json.getJSONObject("media").getString("allowNotes");
            json.getJSONObject("media").getString("edFilter");
            json.getJSONObject("media").getString("description");
            json.getJSONObject("media").getBoolean("adultContent");
            json.getJSONObject("media").getString("author");
            json.getJSONObject("media").getString("authorPage");
            json.getJSONObject("media").getString("codProfile");
            json.getJSONObject("media").getString("publishedAt");
            json.getJSONObject("media").getBoolean("blockEmbed");
            json.getJSONObject("media").getBoolean("subscriberMedia");
            json.getJSONObject("media").getString("idtTagService");
            json.getJSONObject("media").getString("tags");

            JsonUtil.validateValueJson(json.getJSONObject("media"), new String[] { "title", "description" });

            json.getJSONObject("mediaStatus");
            json.getJSONObject("mediaStatus").getString("codStatus");

            if ("V".equals(json.getJSONObject("media").getString("mediaType")))
            {
                json.getJSONObject("mediaStatus").getString("datStartEncoding");
                json.getJSONObject("mediaStatus").getString("numPercEncoding");
            }

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - statusjson is not valid - " + e.getMessage() + " - " + json);
            return false;
        }
    }

    private boolean validateUpdateMediaJson(JSONObject json)
    {
        try
        {

            json.getJSONObject("response");
            json.getJSONObject("response").getString("status");
            json.getJSONObject("response").getString("description");

            json.getJSONObject("media");
            json.getJSONObject("media").getString("title");
            json.getJSONObject("media").getString("mediaId");
            json.getJSONObject("media").getString("url");
            json.getJSONObject("media").getString("thumbnail");
            json.getJSONObject("media").getString("thumbSmall");
            json.getJSONObject("media").getString("thumbMedium");
            json.getJSONObject("media").getString("thumbLarge");
            json.getJSONObject("media").getString("mediaType");
            json.getJSONObject("media").getBoolean("moderateNote");
            json.getJSONObject("media").getBoolean("allowAnonymousComment");
            json.getJSONObject("media").getString("allowNotes");
            json.getJSONObject("media").getString("edFilter");
            json.getJSONObject("media").getString("description");
            json.getJSONObject("media").getBoolean("adultContent");
            json.getJSONObject("media").getString("author");
            json.getJSONObject("media").getString("authorPage");
            json.getJSONObject("media").getString("codProfile");
            json.getJSONObject("media").getString("publishedAt");
            json.getJSONObject("media").getBoolean("blockEmbed");
            json.getJSONObject("media").getBoolean("subscriberMedia");
            json.getJSONObject("media").getString("idtTagService");
            json.getJSONObject("media").getString("tags");

            JsonUtil.validateValueJson(json.getJSONObject("media"), new String[] { "title", "description" });

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - updatemediajson is not valid - " + e.getMessage() + " - " + json);
            return false;
        }
    }

    private boolean validatePublishMediaJson(JSONObject json)
    {
        try
        {

            json.getJSONObject("response");
            json.getJSONObject("response").getString("code");
            json.getJSONObject("response").getString("status");
            json.getJSONObject("response").getString("description");

            json.getJSONObject("media");
            json.getJSONObject("media").getString("title");
            json.getJSONObject("media").getString("mediaId");
            json.getJSONObject("media").getString("url");
            json.getJSONObject("media").getString("thumbnail");
            json.getJSONObject("media").getString("thumbSmall");
            json.getJSONObject("media").getString("thumbMedium");
            json.getJSONObject("media").getString("thumbLarge");
            json.getJSONObject("media").getString("mediaType");
            json.getJSONObject("media").getBoolean("moderateNote");
            json.getJSONObject("media").getBoolean("allowAnonymousComment");
            json.getJSONObject("media").getString("allowNotes");
            json.getJSONObject("media").getString("edFilter");
            json.getJSONObject("media").getString("description");
            json.getJSONObject("media").getBoolean("adultContent");
            json.getJSONObject("media").getString("author");
            json.getJSONObject("media").getString("authorPage");
            json.getJSONObject("media").getString("codProfile");
            json.getJSONObject("media").getString("publishedAt");
            json.getJSONObject("media").getBoolean("blockEmbed");
            json.getJSONObject("media").getBoolean("subscriberMedia");
            json.getJSONObject("media").getString("idtTagService");
            json.getJSONObject("media").getString("tags");

            JsonUtil.validateValueJson(json.getJSONObject("media"), new String[] { "title", "description" });

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - publishmediajson is not valid - " + e.getMessage() + " - " + json);
            return false;
        }
    }

    private boolean validateMessageJson(JSONObject json, char type)
    {
        try
        {
            json.getJSONObject("response");

            if (type == 'S')
            {
                if (json == null || json.getJSONObject("_response").getInt("code") != HttpStatus.SC_OK)
                {
                    return false;
                }

                // json.getJSONObject("response").getString("code");
                json.getJSONObject("response").getString("status");
                json.getJSONObject("response").getString("description");

                if (!json.getJSONObject("response").getString("status").equals("success"))
                {
                    throw new Exception("no has success message");
                }
            }
            else if (type == 'E')
            {
                if (json == null || json.getJSONObject("_response").getInt("code") == HttpStatus.SC_OK)
                {
                    return false;
                }

                json.getJSONObject("response").getString("code");
                json.getJSONObject("response").getString("status");
                json.getJSONObject("response").getString("description");

                if (!json.getJSONObject("response").getString("status").equals("error"))
                {
                    throw new Exception("no has error message");
                }
                else
                {
                    json.getJSONObject("error").getString("code");
                    json.getJSONObject("error").getString("message");
                }
            }
            else if (type == 'W')
            {
                json.getJSONObject("response").getString("code");
                json.getJSONObject("response").getString("status");
                json.getJSONObject("response").getString("description");

                if (!json.getJSONObject("response").getString("status").equals("warn"))
                {
                    throw new Exception("no has warn message");
                }
            }
            else
            {
                json.getJSONObject("response").getString("code");
                json.getJSONObject("response").getString("status");
                json.getJSONObject("response").getString("description");

                if (!json.getJSONObject("response").getString("status").equals("info"))
                {
                    throw new Exception("no has info message");
                }
            }

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - message invalid - " + e.getMessage() + " - " + json);
            return false;
        }
    }
}
