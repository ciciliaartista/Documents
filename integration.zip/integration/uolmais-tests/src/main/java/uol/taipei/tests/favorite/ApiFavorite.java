/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         05/06/2014 Criacao inicial
 */

package uol.taipei.tests.favorite;

import java.io.IOException;
import java.util.HashMap;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpParams;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uol.taipei.request.JsonRequest;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.LoginCookie;
import uol.taipei.tests.util.JsonUtil;
import uol.taipei.tests.util.TestUtil;

public class ApiFavorite extends AbstractTest
{
    static final Logger logger = LoggerFactory.getLogger(ApiFavorite.class);

    static private final String apiUrl = "http://mais.uol.com.br/apiuol/v2/";

    public static void main(String[] args)
    {
        if (!verifyParams(args))
        {
            return;
        }

        setUp(args[0]);

        if (envConfig().getUser() == null || envConfig().getUser().equals("") || envConfig().getPass() == null || envConfig().getPass().equals(""))
        {
            System.err.println("Invalid user " + envConfig().getUser());
            return;
        }

        logger.debug("-------------------------------------------------");
        logger.debug("tests api favorite");

        try
        {
            ApiFavorite apiFavorite = new ApiFavorite();
            LoginCookie login = new LoginCookie(envConfig().getUser(), envConfig().getPass());
            JSONObject profile = login.getJsonProfile();

            apiFavorite.addErr(login);

            JSONObject media = apiFavorite.mediaAdmNotFavorited(login);
            apiFavorite.add(login, media);

            media = apiFavorite.mediaNotFavorited(login);
            apiFavorite.addPublicMedia(login, media);

            apiFavorite.loggedList(login);
            apiFavorite.list(profile.getJSONObject("item").getString("codProfile"));
            apiFavorite.listWithCodProfileErr();
            apiFavorite.listWithItemsPerPageErr(profile.getJSONObject("item").getString("codProfile"));
            apiFavorite.listWithCurrentPageErr(profile.getJSONObject("item").getString("codProfile"));
            apiFavorite.listWithSortErr(profile.getJSONObject("item").getString("codProfile"));
            apiFavorite.listWithTypesErr(profile.getJSONObject("item").getString("codProfile"));
            apiFavorite.updateErr(login, media);
            apiFavorite.update(login, media);
            apiFavorite.removeErr(login);
            apiFavorite.remove(login, media);
        }
        catch (Exception e)
        {
            logger.error(e.getMessage());
        }
    }

    public JSONObject addErr(LoginCookie login) throws Exception
    {
        String url = apiUrl + "favorite/add.json?idtMedia=&indVisibility=T&isPhoto=false";
        JSONObject jsonResponse = login.postdatajson(url, new HashMap<String, String>());

        if (!validateMessageJson(jsonResponse, 'W', HttpStatus.SC_BAD_REQUEST))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject add(LoginCookie login, JSONObject media) throws Exception
    {
        if (media == null)
        {
            logger.info("no media found");
            return null;
        }

        String url = apiUrl + "favorite/add.json?idtMedia=" + media.getLong("mediaId")
                + "&indVisibility=T&isPhoto=false";
        JSONObject jsonResponse = login.postdatajson(url, new HashMap<String, String>());

        if (!validateMessageJson(jsonResponse, 'S'))
        {
            logger.error("ERROR - return not valid - " + media.getLong("mediaId") + " - " + jsonResponse);
            return null;
        }

        TestUtil.delay(TestUtil.ONE_SECOND);

        if (!isFavorited(login, media.getLong("mediaId")))
        {
            logger.error("ERROR - media favorited not listed - " + media.getLong("mediaId"));
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject addPublicMedia(LoginCookie login, JSONObject media) throws Exception
    {
        if (media == null)
        {
            logger.info("no media found");
            return null;
        }

        String url = apiUrl + "favorite/add.json?idtMedia=" + media.getLong("mediaId")
                + "&indVisibility=T&isPhoto=false";
        JSONObject jsonResponse = login.postdatajson(url, new HashMap<String, String>());

        if (!validateMessageJson(jsonResponse, 'S'))
        {
            logger.error("ERROR - return not valid - " + media.getLong("mediaId") + " - " + jsonResponse);
            return null;
        }

        TestUtil.delay(TestUtil.ONE_SECOND);

        if (!isFavorited(login, media.getLong("mediaId")))
        {
            logger.error("ERROR - media favorited not listed - " + media.getLong("mediaId"));
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject loggedList(LoginCookie login) throws Exception
    {
        String url = apiUrl + "favorite/list";
        JSONObject jsonResponse = login.getjson(url);

        if (!validatePageJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject list(String codProfile) throws IOException, JSONException
    {
        String url = apiUrl + "favorite/list?codProfile=" + codProfile;
        JSONObject jsonResponse = JsonRequest.get(url);

        if (!validatePageJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public boolean listWithCodProfileErr() throws IOException, JSONException
    {
        String url = apiUrl + "favorite/list?codProfile=!@#";
        int responseCode = executeHttpGet(url).getStatusLine().getStatusCode();
        if (responseCode != HttpStatus.SC_BAD_REQUEST)
        {
            logger.error("ERROR - return status not valid - " + responseCode + " - " + url);
            return false;
        }
        logger.debug("SUCCESS");
        return true;
    }

    public boolean listWithItemsPerPageErr(String codProfile) throws IOException, JSONException
    {
        String url = apiUrl + "favorite/list?codProfile=" + codProfile + "&index.itemsPerPage=x";
        int responseCode = executeHttpGet(url).getStatusLine().getStatusCode();
        if (responseCode != HttpStatus.SC_BAD_REQUEST)
        {
            logger.error("ERROR - return status not valid - " + responseCode + " - " + url);
            return false;
        }
        logger.debug("SUCCESS");
        return true;
    }

    public boolean listWithCurrentPageErr(String codProfile) throws IOException, JSONException
    {
        String url = apiUrl + "favorite/list?codProfile=" + codProfile + "&index.currentPage=x";
        int responseCode = executeHttpGet(url).getStatusLine().getStatusCode();
        if (responseCode != HttpStatus.SC_BAD_REQUEST)
        {
            logger.error("ERROR - return status not valid - " + responseCode + " - " + url);
            return false;
        }
        logger.debug("SUCCESS");
        return true;
    }

    public boolean listWithSortErr(String codProfile) throws IOException, JSONException
    {
        String url = apiUrl + "favorite/list?codProfile=" + codProfile + "&sort=x";
        int responseCode = executeHttpGet(url).getStatusLine().getStatusCode();
        if (responseCode != HttpStatus.SC_BAD_REQUEST)
        {
            logger.error("ERROR - return status not valid - " + responseCode + " - " + url);
            return false;
        }
        logger.debug("SUCCESS");
        return true;
    }

    public boolean listWithTypesErr(String codProfile) throws IOException, JSONException
    {
        String url = apiUrl + "favorite/list?codProfile=" + codProfile + "&types=x";
        int responseCode = executeHttpGet(url).getStatusLine().getStatusCode();
        if (responseCode != HttpStatus.SC_BAD_REQUEST)
        {
            logger.error("ERROR - return status not valid - " + responseCode + " - " + url);
            return false;
        }
        logger.debug("SUCCESS");
        return true;
    }

    public JSONObject updateErr(LoginCookie login, JSONObject media) throws Exception
    {
        String url = apiUrl + "favorite/update.json?idtMedia=" + media.getLong("mediaId") + "&indVisibility=x";
        JSONObject jsonResponse = login.postdatajson(url, new HashMap<String, String>());

        if (!validateMessageJson(jsonResponse, 'E', HttpStatus.SC_BAD_REQUEST))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject update(LoginCookie login, JSONObject media) throws Exception
    {
        if (media == null)
        {
            logger.info("no media found");
            return null;
        }

        String url = apiUrl + "favorite/update.json?idtMedia=" + media.getLong("mediaId") + "&indVisibility=";
        HashMap<String, String> params = new HashMap<String, String>();
        JSONObject jsonResponse = null;

        for (String visibility : new String[] { "T", "N" })
        {
            jsonResponse = login.postdatajson(url + visibility, params);

            if (!validateMessageJson(jsonResponse, 'S'))
            {
                logger.error("ERROR - return not valid - " + jsonResponse);
                return null;
            }
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject removeErr(LoginCookie login) throws Exception
    {
        String url = apiUrl + "favorite/remove.json?idtMedia=";
        JSONObject jsonResponse = login.postdatajson(url, new HashMap<String, String>());

        if (!validateMessageJson(jsonResponse, 'W', HttpStatus.SC_BAD_REQUEST))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject remove(LoginCookie login, JSONObject media) throws Exception
    {
        String url = apiUrl + "favorite/remove.json?idtMedia=" + media.getLong("mediaId");
        JSONObject jsonResponse = login.postdatajson(url, new HashMap<String, String>());

        if (!validateMessageJson(jsonResponse, 'S'))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        if (isFavorited(login, media.getLong("mediaId")))
        {
            logger.error("ERROR - media favorited not was removed - " + media.getLong("mediaId"));
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject mediaNotFavorited(LoginCookie login) throws Exception
    {
        String url = apiUrl + "media/list?index.currentPage=";
        int page = 1;
        JSONObject mediaList = JsonRequest.get(url + page + "&nocache=" + Math.random());

        if (mediaList == null || mediaList.getJSONObject("_response").getInt("code") != HttpStatus.SC_OK)
        {
            return null;
        }

        while (mediaList.getJSONArray("list").length() > 0)
        {
            for (int i = 0; i < mediaList.getJSONArray("list").length(); i++)
            {
                if (!isFavorited(login, mediaList.getJSONArray("list").getJSONObject(i).getLong("mediaId"))
                        && JsonUtil.isAllowed(mediaList.getJSONArray("list").getJSONObject(i).getLong("mediaId")))
                {
                    return mediaList.getJSONArray("list").getJSONObject(i);
                }
            }

            page++;
            mediaList = JsonRequest.get(url + page + "&nocache=" + Math.random());

            if (mediaList == null || mediaList.getJSONObject("_response").getInt("code") != HttpStatus.SC_OK)
            {
                return null;
            }
        }

        return null;
    }

    public JSONObject mediaAdmNotFavorited(LoginCookie login) throws Exception
    {
        String url = "http://beta.mais.uol.com.br/sys/adminPage/status?variant=json&types=A&index.currentPage=";
        int page = 1;
        JSONObject mediaList = login.getjson(url + page);

        while (mediaList.getJSONArray("list").length() > 0)
        {
            for (int i = 0; i < mediaList.getJSONArray("list").length(); i++)
            {
                if (!isFavorited(login,
                    Long.parseLong(mediaList.getJSONArray("list").getJSONObject(i).getString("mediaId")))
                        && JsonUtil.isAllowed(Long.parseLong(mediaList.getJSONArray("list").getJSONObject(i)
                                .getString("mediaId"))))
                {
                    return mediaList.getJSONArray("list").getJSONObject(i);
                }
            }

            page++;
            mediaList = login.getjson(url + page);
        }

        return null;
    }

    public boolean isFavorited(LoginCookie login, long mediaId) throws Exception
    {
        String query = "SELECT * FROM profile_favourite_media WHERE idt_media = " + mediaId
                + " AND cod_profile_hash = " + login.getJsonProfile().getJSONObject("item").getLong("codProfileHash");

        JSONObject result = JsonRequest.execQuery(query);

        if (result != null && result.getJSONArray("data").length() > 0)
        {
            return true;
        }

        return false;
    }

    private HttpResponse executeHttpGet(String url) throws IOException, JSONException
    {
        HttpClient client = new DefaultHttpClient();
        HttpParams params = new BasicHttpParams();
        params.setParameter("http.protocol.handle-redirects", false);

        HttpGet httpget = new HttpGet(url);
        httpget.setParams(params);
        HttpResponse response = client.execute(httpget);
        return response;
    }

    private boolean validatePageJson(JSONObject jsonResponse) throws JSONException
    {
        try
        {
            if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") != HttpStatus.SC_OK)
            {
                return false;
            }
            jsonResponse.getJSONObject("response");
            jsonResponse.getJSONObject("response").getInt("code");
            jsonResponse.getJSONObject("response").getString("description");
            jsonResponse.getJSONObject("response").getString("originalRequest");

            if (jsonResponse.has("paging"))
            {
                jsonResponse.getJSONObject("paging");
                jsonResponse.getJSONObject("paging").getInt("currentPage");
                Boolean.parseBoolean(jsonResponse.getJSONObject("paging").getString("nextPage"));
                jsonResponse.getJSONObject("paging").getInt("pageSize");
                Boolean.parseBoolean(jsonResponse.getJSONObject("paging").getString("previousPage"));
                jsonResponse.getJSONObject("paging").getString("sort");
                jsonResponse.getJSONObject("paging").getInt("totalItems");
                jsonResponse.getJSONObject("paging").getInt("totalPages");
            }

            jsonResponse.getJSONArray("list");

            int length = jsonResponse.getJSONArray("list").length();

            for (int i = 0; i < length; i++)
            {
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("title");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("id");
                jsonResponse.getJSONArray("list").getJSONObject(i).getLong("mediaId");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("url");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("mediaType");
                Boolean.parseBoolean(jsonResponse.getJSONArray("list").getJSONObject(i).getString("moderateNote"));
                Boolean.parseBoolean(jsonResponse.getJSONArray("list").getJSONObject(i)
                        .getString("allowAnonymousComment"));
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("allowNotes");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("edFilter");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("thumbnail");

                if (!jsonResponse.getJSONArray("list").getJSONObject(i).getString("mediaType").equals("B")
                        && !jsonResponse.getJSONArray("list").getJSONObject(i).getString("mediaType")
                                .equals("S")
                        && !jsonResponse.getJSONArray("list").getJSONObject(i).getString("mediaType")
                                .equals("L"))
                {
                    jsonResponse.getJSONArray("list").getJSONObject(i).getString("thumbSmall");
                    jsonResponse.getJSONArray("list").getJSONObject(i).getString("thumbMedium");
                    jsonResponse.getJSONArray("list").getJSONObject(i).getString("thumbLarge");
                }

                jsonResponse.getJSONArray("list").getJSONObject(i).getLong("idtSubject");

                if (jsonResponse.getJSONArray("list").getJSONObject(i).getString("mediaType").equals("V"))
                {
                    jsonResponse.getJSONArray("list").getJSONObject(i).getString("player");
                    jsonResponse.getJSONArray("list").getJSONObject(i).getString("duration");

                    if (jsonResponse.getJSONArray("list").getJSONObject(i).has("idtProductList"))
                    {
                        jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("idtProductList");

                        for (int j = 0; j < jsonResponse.getJSONArray("list").getJSONObject(i)
                                .getJSONArray("idtProductList").length(); j++)
                        {
                            jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("idtProductList").getInt(j);
                        }
                    }
                }

                if (jsonResponse.getJSONArray("list").getJSONObject(i).getString("mediaType")
                        .equals("P"))
                {
                    jsonResponse.getJSONArray("list").getJSONObject(i).getString("player");
                    jsonResponse.getJSONArray("list").getJSONObject(i).getString("duration");
                }

                if (!jsonResponse.getJSONArray("list").getJSONObject(i).getString("mediaType").equals("P")
                        && !jsonResponse.getJSONArray("list").getJSONObject(i).getString("mediaType")
                                .equals("P")
                        && !jsonResponse.getJSONArray("list").getJSONObject(i).getString("mediaType")
                                .equals("S")
                        && !jsonResponse.getJSONArray("list").getJSONObject(i).getString("mediaType")
                                .equals("L")
                        && !jsonResponse.getJSONArray("list").getJSONObject(i).getString("mediaType")
                                .equals("B"))
                {
                    jsonResponse.getJSONArray("list").getJSONObject(i).getInt("thumbVersion");
                }

                jsonResponse.getJSONArray("list").getJSONObject(i).getString("description");
                Boolean.parseBoolean(jsonResponse.getJSONArray("list").getJSONObject(i).getString("adultContent"));
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("author");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("authorPage");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("codProfile");
                jsonResponse.getJSONArray("list").getJSONObject(i).getInt("views");
                jsonResponse.getJSONArray("list").getJSONObject(i).getInt("comments");
                jsonResponse.getJSONArray("list").getJSONObject(i).getInt("favorites");
                jsonResponse.getJSONArray("list").getJSONObject(i).getDouble("rating");
                jsonResponse.getJSONArray("list").getJSONObject(i).getInt("votes");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("publishedAt");
                Boolean.parseBoolean(jsonResponse.getJSONArray("list").getJSONObject(i).getString("blockEmbed"));
                Boolean.parseBoolean(jsonResponse.getJSONArray("list").getJSONObject(i).getString("subscriberMedia"));

                int tagLength = jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("tags").length();

                for (int j = 0; j < tagLength; j++)
                {
                    jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("tags").getJSONObject(j)
                            .getLong("id");
                    jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("tags").getJSONObject(j)
                            .getString("description");
                }

                // jsonResponse.getJSONArray("list").getJSONObject(i).getString("idtTagService");

                JsonUtil.validateValueJson(jsonResponse.getJSONArray("list").getJSONObject(i),
                    new String[] { "title", "description" });
            }

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - pagejson is not valid - " + e.getMessage() + " - " + jsonResponse);
            return false;
        }
    }

    private boolean validateMessageJson(JSONObject json, char type)
    {
        return validateMessageJson(json, type, HttpStatus.SC_OK);
    }

    private boolean validateMessageJson(JSONObject json, char type, Integer httpStatus)
    {
        try
        {
            if (json == null || json.getJSONObject("_response").getInt("code") != httpStatus)
            {
                return false;
            }

            json.getJSONObject("messages");

            if (type == 'S')
            {

                json.getJSONObject("messages").getJSONArray("success");

                if (json.getJSONObject("messages").getJSONArray("success").length() < 1)
                {
                    throw new Exception("no has success message");
                }

                for (int i = 0; i < json.getJSONObject("messages").getJSONArray("success").length(); i++)
                {
                    json.getJSONObject("messages").getJSONArray("success").getJSONObject(i).getString("id");
                    json.getJSONObject("messages").getJSONArray("success").getJSONObject(i).getString("description");

                    JsonUtil.validateValueJson(json.getJSONObject("messages").getJSONArray("success").getJSONObject(i),
                        new String[] { "" });
                }
            }
            else if (type == 'E')
            {
                json.getJSONObject("messages").getJSONArray("errors");

                if (json.getJSONObject("messages").getJSONArray("errors").length() < 1)
                {
                    throw new Exception("no has error message");
                }

                for (int i = 0; i < json.getJSONObject("messages").getJSONArray("errors").length(); i++)
                {
                    json.getJSONObject("messages").getJSONArray("errors").getJSONObject(i).getString("id");
                    json.getJSONObject("messages").getJSONArray("errors").getJSONObject(i).getString("description");

                    JsonUtil.validateValueJson(json.getJSONObject("messages").getJSONArray("errors").getJSONObject(i),
                        new String[] { "" });
                }
            }
            else if (type == 'W')
            {
                json.getJSONObject("messages").getJSONArray("warns");

                if (json.getJSONObject("messages").getJSONArray("warns").length() < 1)
                {
                    throw new Exception("no has warn message");
                }

                for (int i = 0; i < json.getJSONObject("messages").getJSONArray("warns").length(); i++)
                {
                    json.getJSONObject("messages").getJSONArray("warns").getJSONObject(i).getString("id");
                    json.getJSONObject("messages").getJSONArray("warns").getJSONObject(i).getString("description");

                    JsonUtil.validateValueJson(json.getJSONObject("messages").getJSONArray("warns").getJSONObject(i),
                        new String[] { "" });
                }
            }
            else
            {
                json.getJSONObject("messages").getJSONArray("infos");

                if (json.getJSONObject("messages").getJSONArray("infos").length() < 1)
                {
                    throw new Exception("no has info message");
                }

                for (int i = 0; i < json.getJSONObject("messages").getJSONArray("infos").length(); i++)
                {
                    json.getJSONObject("messages").getJSONArray("infos").getJSONObject(i).getString("id");
                    json.getJSONObject("messages").getJSONArray("infos").getJSONObject(i).getString("description");

                    JsonUtil.validateValueJson(json.getJSONObject("messages").getJSONArray("infos").getJSONObject(i),
                        new String[] { "" });
                }
            }

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - message invalid - " + e.getMessage() + " - " + json);
            return false;
        }
    }
}
