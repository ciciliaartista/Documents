/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         22/05/2014 Criacao inicial
 */

package uol.taipei.tests.content;

import java.io.IOException;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.http.HttpStatus;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uol.taipei.request.JsonRequest;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.LoginCookie;
import uol.taipei.tests.util.JsonUtil;

public class ListResumed extends AbstractTest
{
    static final Logger logger = LoggerFactory.getLogger(ListResumed.class);

    public static void main(String[] args)
    {
        if (!verifyParams(args))
        {
            return;
        }

        setUp(args[0]);

        if (envConfig().getUser() == null || envConfig().getUser().equals("") || envConfig().getPass() == null || envConfig().getPass().equals(""))
        {
            System.err.println("Invalid user " + envConfig().getUser());
            return;
        }

        logger.debug("-------------------------------------------------");
        logger.debug("tests listResumed");

        try
        {
            ListResumed listResumed = new ListResumed();
            LoginCookie login = new LoginCookie(envConfig().getUser(), envConfig().getPass());
            JSONObject profile = login.getJsonProfile();

            listResumed.list(profile.getJSONObject("item").getString("codProfile"));
            listResumed.types(profile.getJSONObject("item").getString("codProfile"));
        }
        catch (Exception e)
        {
            logger.error(e.getMessage());
        }
    }

    public JSONObject list(String codProfile) throws IOException, JSONException
    {
        JSONObject jsonResponse = JsonRequest.get("http://mais.uol.com.br/sys/content/listResumed.json?types=V,P&codProfile=" + codProfile + "&index.currentPage=1&index.itemsPerPage=80");

        if (!validatePageJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject types(String codProfile) throws IOException, JSONException
    {
        String url = "http://mais.uol.com.br/sys/content/listResumed.json?codProfile=" + codProfile + "&index.currentPage=1&index.itemsPerPage=80&types=";
        String[] arrayTypes = new String[] { "A", "V", "P" };
        JSONObject jsonResponse = null;

        for (String type : arrayTypes)
        {
            jsonResponse = JsonRequest.get(url + type);

            if (!validatePageJson(jsonResponse))
            {
                logger.error("ERROR - return not valid - " + url + type + " - " + jsonResponse);
                return null;
            }

            if (!jsonResponse.get("contentsFromAuthorPage").toString().equals("null"))
            {
                for (int i = 0; i < jsonResponse.getJSONArray("contentsFromAuthorPage").length(); i++)
                {
                    if ("A".equals(type))
                    {
                        if (!ArrayUtils.contains(arrayTypes, jsonResponse.getJSONArray("contentsFromAuthorPage").getJSONObject(i)
                                .getString("indMediaType")))
                        {
                            logger.error("ERROR - mediaType not match - mediaType " + type + " - " + jsonResponse);
                            return null;
                        }
                    }
                    else
                    {
                        if (!jsonResponse.getJSONArray("contentsFromAuthorPage").getJSONObject(i).getString("indMediaType").equals(type))
                        {
                            logger.error("ERROR - mediaType not match - mediaType " + type + " - " + jsonResponse);
                            return null;
                        }
                    }
                }
            }
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    private boolean validatePageJson(JSONObject jsonResponse) throws JSONException
    {
        try
        {
            if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") != HttpStatus.SC_OK)
            {
                return false;
            }
            
            if (jsonResponse.has("contentsFromAuthorPage"))
            {
                jsonResponse.get("contentsFromAuthorPage");
    
                if (!jsonResponse.get("contentsFromAuthorPage").toString().equals("null"))
                {
                    jsonResponse.getJSONArray("contentsFromAuthorPage");
        
                    int length = jsonResponse.getJSONArray("contentsFromAuthorPage").length();
        
                    for (int i = 0; i < length; i++)
                    {
                        jsonResponse.getJSONArray("contentsFromAuthorPage").getJSONObject(i).getLong("idtMedia");
                        jsonResponse.getJSONArray("contentsFromAuthorPage").getJSONObject(i).getString("namSubject");
                        jsonResponse.getJSONArray("contentsFromAuthorPage").getJSONObject(i).getString("indHot");
                        jsonResponse.getJSONArray("contentsFromAuthorPage").getJSONObject(i).getLong("codProfileHash");
                        jsonResponse.getJSONArray("contentsFromAuthorPage").getJSONObject(i).getLong("videoVersion");
                        jsonResponse.getJSONArray("contentsFromAuthorPage").getJSONObject(i).getString("mediaURL");
                        jsonResponse.getJSONArray("contentsFromAuthorPage").getJSONObject(i).getString("thumbURL");
                        jsonResponse.getJSONArray("contentsFromAuthorPage").getJSONObject(i).getString("indMediaType");
                        jsonResponse.getJSONArray("contentsFromAuthorPage").getJSONObject(i).getString("codProfile");
        
                        JsonUtil.validateValueJson(jsonResponse.getJSONArray("contentsFromAuthorPage").getJSONObject(i), new String[] {"namSubject"});
                    }
                }
            }

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - pagejson is not valid - " + e.getMessage() + " - " + jsonResponse);
            return false;
        }
    }
}
