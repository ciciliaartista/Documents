/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         04/08/2014 Criacao inicial
 */

package uol.taipei.tests.ssl;

import java.util.HashMap;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uol.taipei.request.FacileRequest;
import uol.taipei.request.FacileResponse;
import uol.taipei.request.JsonRequest;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.util.RequestUtil;

public class StorageSsl extends AbstractTest
{
    static final Logger logger = LoggerFactory.getLogger(StorageSsl.class);

    public static void main(String[] args)
    {
        if (!verifyParams(args))
        {
            return;
        }

        setUp(args[0]);

        logger.debug("-------------------------------------------------");
        logger.debug("tests ssl storage");

        try
        {
            StorageSsl storageSsl = new StorageSsl();
            FacileRequest request = new FacileRequest();
            request.configureSSL();

            storageSsl.probe();

            String mediaId = RequestUtil.mediaIdPublic("V");

            storageSsl.storagePlayer(request, mediaId, 0);
            storageSsl.storagePlayerV5(request, mediaId, 0);
            storageSsl.storagePlayerThumb(request, mediaId, 0);
            storageSsl.storagePlayerBand(request, mediaId);
            storageSsl.storagePlayerAudio(request);
            storageSsl.storageEmbed(request, mediaId);
            storageSsl.storageEmbedV2(request, mediaId);
            storageSsl.storageEmbedReduzido(request, mediaId);
            storageSsl.storageEmbedReduzidoV2(request, mediaId);
            storageSsl.storageEmbedV2ssl(request, mediaId);
            storageSsl.storageVideo(request, mediaId);
            storageSsl.videoNoReferer(request);
            storageSsl.videoWithWildcard(request);
            storageSsl.videoWithWildcardNoUseragent(request);
            storageSsl.storageThumbVideo(request, mediaId);

            mediaId = RequestUtil.mediaIdPublic("P");

            storageSsl.storageEmbedAudio2(request, mediaId);
            storageSsl.storageEmbedAudio280(request, mediaId);
            storageSsl.storagePodcast(request, mediaId);
        }
        catch (Exception e)
        {
            logger.error(e.getMessage());
        }
    }

    public JSONObject probe() throws Exception
    {
        JSONObject jsonResponse = JsonRequest.get("https://storage.mais.uol.com.br/probe");

        if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") != 200)
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        try
        {
            jsonResponse.getString("upTime");
            jsonResponse.getString("serverVersion");
        }
        catch (Exception e)
        {
            logger.error("ERROR - return not valid - " + e.getMessage() + " - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public boolean storagePlayer(FacileRequest request, String mediaId, int thumbVersion) throws Exception
    {
        String url = "https://storage.mais.uol.com.br/player_video_v2.swf?mediaId=" + mediaId + "&p=mais&tv=" + thumbVersion;
        request.setFollowRedirects(false);
        FacileResponse response = request.get(url);

        if (response.getCode() != 302 && response.getCode() != 301)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        if (!request.getConn().getHeaderField("Location").matches("(.*)?player\\.mais\\.uol\\.com\\.br\\/player_video_v2\\.swf\\?mediaId=" 
                + mediaId + "&p=mais&tv=" + thumbVersion))
        {
            logger.error("ERROR - return not valid - " + request.getConn().getHeaderField("Location"));
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean storagePlayerV5(FacileRequest request, String mediaId, int thumbVersion) throws Exception
    {
        String url = "https://storage.mais.uol.com.br/player_video_v5.swf?mediaId=" + mediaId + "&p=mais&tv=" + thumbVersion;
        request.setFollowRedirects(false);
        FacileResponse response = request.get(url);

        if (response.getCode() != 302 && response.getCode() != 301)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        if (!request.getConn().getHeaderField("Location").matches("(.*)?player\\.mais\\.uol\\.com\\.br\\/player_video_v5\\.swf\\?mediaId=" 
                + mediaId + "&p=mais&tv=" + thumbVersion))
        {
            logger.error("ERROR - return not valid - " + request.getConn().getHeaderField("Location"));
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean storagePlayerThumb(FacileRequest request, String mediaId, int thumbVersion) throws Exception
    {
        String url = "https://storage.mais.uol.com.br/player_video_thumb.swf?mediaId=" + mediaId + "&p=editoruol&tv=" + thumbVersion;
        request.setFollowRedirects(false);
        FacileResponse response = request.get(url);

        if (response.getCode() != 302 && response.getCode() != 301)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        if (!request.getConn().getHeaderField("Location").matches("(.*)?player\\.mais\\.uol\\.com\\.br\\/player_video_thumb\\.swf\\?mediaId=" 
                + mediaId + "&p=editoruol&tv=" + thumbVersion))
        {
            logger.error("ERROR - return not valid - " + request.getConn().getHeaderField("Location"));
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean storagePlayerBand(FacileRequest request, String mediaId) throws Exception
    {
        String url = "https://storage.mais.uol.com.br/player_video_v2_band.swf?mediaId=" + mediaId;
        request.setFollowRedirects(false);
        FacileResponse response = request.get(url);

        if (response.getCode() != 302 && response.getCode() != 301)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        if (!request.getConn().getHeaderField("Location").matches("(.*)?player\\.mais\\.uol\\.com\\.br\\/player_video_v2_band\\.swf\\?mediaId=" 
                + mediaId))
        {
            logger.error("ERROR - return not valid - " + request.getConn().getHeaderField("Location"));
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean storageEmbedV2(FacileRequest request, String mediaId) throws Exception
    {
        String url = "https://storage.mais.uol.com.br/embed_v2.swf?mediaId=" + mediaId;
        request.setFollowRedirects(false);
        FacileResponse response = request.get(url);

        if (response.getCode() != 302 && response.getCode() != 301)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        if (!request.getConn().getHeaderField("Location").matches("(.*)?player\\.mais\\.uol\\.com\\.br\\/embed_v2\\.swf\\?mediaId=" 
                + mediaId))
        {
            logger.error("ERROR - return not valid - " + request.getConn().getHeaderField("Location"));
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean storageEmbed(FacileRequest request, String mediaId) throws Exception
    {
        String url = "https://storage.mais.uol.com.br/embed.swf?mediaId=" + mediaId;
        request.setFollowRedirects(false);
        FacileResponse response = request.get(url);

        if (response.getCode() != 302 && response.getCode() != 301)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        if (!request.getConn().getHeaderField("Location").matches("(.*)?player\\.mais\\.uol\\.com\\.br\\/embed\\.swf\\?mediaId=" 
                + mediaId))
        {
            logger.error("ERROR - return not valid - " + request.getConn().getHeaderField("Location"));
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean storageEmbedReduzido(FacileRequest request, String mediaId) throws Exception
    {
        String url = "https://storage.mais.uol.com.br/embed_reduzido.swf?mediaId=" + mediaId;
        request.setFollowRedirects(false);
        FacileResponse response = request.get(url);

        if (response.getCode() != 302 && response.getCode() != 301)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        if (!request.getConn().getHeaderField("Location").matches("(.*)?player\\.mais\\.uol\\.com\\.br\\/embed_reduzido\\.swf\\?mediaId=" 
                + mediaId))
        {
            logger.error("ERROR - return not valid - " + request.getConn().getHeaderField("Location"));
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean storageEmbedReduzidoV2(FacileRequest request, String mediaId) throws Exception
    {
        String url = "https://storage.mais.uol.com.br/embed_reduzido_v2.swf?mediaId=" + mediaId;
        request.setFollowRedirects(false);
        FacileResponse response = request.get(url);

        if (response.getCode() != 302 && response.getCode() != 301)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        if (!request.getConn().getHeaderField("Location").matches("(.*)?player\\.mais\\.uol\\.com\\.br\\/embed_reduzido_v2\\.swf\\?mediaId=" 
                + mediaId))
        {
            logger.error("ERROR - return not valid - " + request.getConn().getHeaderField("Location"));
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean storageEmbedV2ssl(FacileRequest request, String mediaId) throws Exception
    {
        String url = "https://storage.mais.uol.com.br/embed_v2_ssl.swf?mediaId=" + mediaId;
        request.setFollowRedirects(false);
        FacileResponse response = request.get(url);

        if (response.getCode() != 302 && response.getCode() != 301)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        if (!request.getConn().getHeaderField("Location").matches("(.*)?player\\.mais\\.uol\\.com\\.br\\/embed_v2_ssl\\.swf\\?mediaId=" 
                + mediaId))
        {
            logger.error("ERROR - return not valid - " + request.getConn().getHeaderField("Location"));
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean storagePlayerAudio(FacileRequest request) throws Exception
    {
        String url = "https://storage.mais.uol.com.br/player_audio.swf";
        request.setFollowRedirects(false);
        FacileResponse response = request.get(url);

        if (response.getCode() != 302 && response.getCode() != 301)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        if (!request.getConn().getHeaderField("Location").matches("(.*)?player\\.mais\\.uol\\.com\\.br\\/player_audio\\.swf"))
        {
            logger.error("ERROR - return not valid - " + request.getConn().getHeaderField("Location"));
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean storageEmbedAudio2(FacileRequest request, String mediaId) throws Exception
    {
        String url = "https://storage.mais.uol.com.br/embed_audio2.swf?mediaId=" + mediaId;
        request.setFollowRedirects(false);
        FacileResponse response = request.get(url);

        if (response.getCode() != 302 && response.getCode() != 301)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        if (!request.getConn().getHeaderField("Location").matches("(.*)?player\\.mais\\.uol\\.com\\.br\\/embed_audio2\\.swf\\?mediaId=" 
                + mediaId))
        {
            logger.error("ERROR - return not valid - " + request.getConn().getHeaderField("Location"));
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean storageEmbedAudio280(FacileRequest request, String mediaId) throws Exception
    {
        String url = "https://storage.mais.uol.com.br/embed_audio_280.swf?mediaId=" + mediaId;
        request.setFollowRedirects(false);
        FacileResponse response = request.get(url);

        if (response.getCode() != 302 && response.getCode() != 301)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        if (!request.getConn().getHeaderField("Location").matches("(.*)?player\\.mais\\.uol\\.com\\.br\\/embed_audio_280\\.swf\\?mediaId=" 
                + mediaId))
        {
            logger.error("ERROR - return not valid - " + request.getConn().getHeaderField("Location"));
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean storageVideo(FacileRequest request, String mediaId) throws Exception
    {
        String url = "https://storage.mais.uol.com.br/" + mediaId + ".mp4";
        request.setFollowRedirects(false);
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put("Referer", "http://mais.uol.com.br");

        FacileResponse response = request.get(url, headers);

        if (response.getCode() != 302 && response.getCode() != 301)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        if (!request.getConn().getHeaderField("Location").matches("(.*)?video(hd)?[0-9]+\\.mais\\.uol\\.com\\.br\\/" + mediaId + ".mp4"))
        {
            logger.error("ERROR - return not valid - " + request.getConn().getHeaderField("Location"));
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean storagePodcast(FacileRequest request, String mediaId) throws Exception
    {
        String url = "https://storage.mais.uol.com.br/" + mediaId + ".mp3";
        request.setFollowRedirects(false);
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put("Referer", "http://mais.uol.com.br");

        FacileResponse response = request.get(url, headers);

        if (response.getCode() != 302 && response.getCode() != 301)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        if (!request.getConn().getHeaderField("Location").matches("(.*)?video(hd)?[0-9]+\\.mais\\.uol\\.com\\.br\\/" + mediaId + ".mp3"))
        {
            logger.error("ERROR - return not valid - " + request.getConn().getHeaderField("Location"));
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean videoNoReferer(FacileRequest request) throws Exception
    {
        String mediaId = RequestUtil.mediaIdPublic("V");
        String url = mediaId + ".mp4";
        FacileResponse response = request.get("https://storage.mais.uol.com.br/" + url);
    
        if (response.getCode() != 403)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }
    
        if (!response.getBody().contains("Failure"))
        {
            logger.error("ERROR - " + response.getBody() + " - " + mediaId);
            return false;
        }
    
        logger.debug("SUCCESS");
    
        return true;
    }

    /**
     * request para video do balaio com parametro r
     * 
     * @param request
     * @return boolean
     * @throws Exception
     */
    public boolean videoWithWildcard(FacileRequest request) throws Exception
    {
        String mediaId = RequestUtil.mediaIdPublic("V");
        String url = "https://storage.mais.uol.com.br/" + mediaId + ".mp4?r=http://mais.uol.com.br";
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.93 Safari/537.36");
        FacileResponse response = request.get(url, headers);

        if (response.getCode() != 302)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        if (!request.getConn().getHeaderField("Location").matches("(.*)?video(hd)?[0-9]+\\.mais\\.uol\\.com\\.br\\/" + mediaId + ".mp4\\?r=http(s)?(://|%3A%2F%2F)mais\\.uol\\.com\\.br"))
        {
            logger.error("ERROR - return not valid - " + request.getConn().getHeaderField("Location"));
            return false;
        }

        logger.debug("SUCCESS");
    
        return true;
    }

    public boolean videoWithWildcardNoUseragent(FacileRequest request) throws Exception
    {
        String mediaId = RequestUtil.mediaIdPublic("V");
        String url = "https://storage.mais.uol.com.br/" + mediaId + ".mp4?r=http://mais.uol.com.br";
        FacileResponse response = request.get(url);

        if (response.getCode() != 403)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }
    
        if (!response.getBody().contains("Failure"))
        {
            logger.error("ERROR - " + response.getBody() + " - " + mediaId);
            return false;
        }
    
        logger.debug("SUCCESS");
    
        return true;
    }

    public boolean storageThumbVideo(FacileRequest request, String mediaId) throws Exception
    {
        request.setFollowRedirects(false);
        FacileResponse response = null;
        String url = null;
        String[] thumbs = new String[] { mediaId + ".jpg", 
                                         mediaId + "-small.jpg",
                                         mediaId + "-medium.jpg", 
                                         mediaId + "-large.jpg", 
                                         mediaId + "-xlarge.jpg",
                                         mediaId + "-wlarge.jpg",
                                         mediaId + "-wmedium.jpg" };
    
        for (String t : thumbs)
        {
            url = "https://storage.mais.uol.com.br/" + t;
            response = request.get(url);
    
            if (response.getCode() != 200)
            {
                logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
                return false;
            }
        }
    
        logger.debug("SUCCESS");
    
        return true;
    }
}
