/* Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 *
 * Autor                                Data            Motivo
 * ---------------------------------    ----------      -----------------------
 * cafpereira                           27/07/2010      Criacao da classe
 */

package uol.taipei.tests.util;

import java.io.FilenameFilter;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import uol.taipei.util.StringUtil;

public class TestUtil
{
    public static final long ONE_SECOND = 1000L;
    static final String chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    public static final int[] CODES_CHAR_TO_UNICODE = new int[] { 193, 192, 194, 195, 199, 201, 202, 205, 211, 212, 213, 218 };
    public static final Map<String, Integer> CHARCODE_UNICODE = new HashMap<String, Integer>();

    static
    {
        CHARCODE_UNICODE.put("\\u00c0", 0x00C0); // A grave
        CHARCODE_UNICODE.put("\\u00c1", 0x00C1); // A acute
        CHARCODE_UNICODE.put("\\u00c2", 0x00C2); // A circunflex
        CHARCODE_UNICODE.put("\\u00c3", 0x00C3); // A tilde
        CHARCODE_UNICODE.put("\\u00c7", 0x00C7); // C cedilla
        CHARCODE_UNICODE.put("\\u00c9", 0x00C9); // E acute
        CHARCODE_UNICODE.put("\\u00ca", 0x00CA); // E circunflex
        CHARCODE_UNICODE.put("\\u00cd", 0x00CD); // I acute
        CHARCODE_UNICODE.put("\\u00d3", 0x00D3); // O acute
        CHARCODE_UNICODE.put("\\u00d4", 0x00D4); // O circunflex
        CHARCODE_UNICODE.put("\\u00d5", 0x00D5); // O tilde
        CHARCODE_UNICODE.put("\\u00da", 0x00DA); // U acute
    };

    public static void delay(long duration)
    {
        try
        {
            Thread.sleep(duration);
        }
        catch (InterruptedException e)
        {
            e.printStackTrace();
        }
    }

    public static String generateUniqueString()
    {
        final Date now = new Date();
        final SimpleDateFormat fullDateFormat = new SimpleDateFormat("yyMMddHHmmssSS");
        return fullDateFormat.format(now);
    }

    public static String randomString(int len)
    {
        Random rnd = new Random();
        StringBuilder sb = new StringBuilder(len);

        for (int i = 0; i < len; i++)
        {
            sb.append(chars.charAt(rnd.nextInt(chars.length())));
        }

        return sb.toString();
    }

    public static String randomLengthString()
    {
        StringBuilder sb = new StringBuilder();
        Random rnd = new Random();

        for (int i = 0; i < rnd.nextInt(10); i++)
        {
            sb.append(randomString(Math.abs(rnd.nextInt(10))) + " ");
        }

        return sb.toString();
    }

    public static int randomInt(int min, int max)
    {
        Random rnd = new Random();
        int result = Math.abs(rnd.nextInt(max));

        return (result < min ? min : result);
    }

    public static String cleanBreakLine(String input)
    {
        if (input == null)
        {
            return "";
        }

        return input.replaceAll(" ", "").replaceAll("(\r\n)", "").replaceAll("[\r\n]", "").replaceAll("    ","").replaceAll("\t","");
    }

    /**
     * verifica se str contem algum formato(caixa alta, caixa baixa, normalizado) do term
     * 
     * @param str
     * @param term
     * @return boolean
     */
    public static boolean strContains(String str, String term)
    {
        if (str.contains(term) || str.contains(StringUtil.normalize(term)) || str.contains(StringUtil.normalize(term).toLowerCase()) 
                || str.contains(StringUtil.normalize(term).toUpperCase()) || str.contains(term.toLowerCase()) || str.contains(term.toUpperCase()))
        {
            return true;
        }

        return false;
    }

    /**
     * remove o genero da string
     * 
     * @param str
     * @return String
     */
    public static String noGenre(String str) 
    {
        if (str.length() > 0 && (str.charAt(str.length()-1) == 'o' || str.charAt(str.length()-1) == 'O' || str.charAt(str.length()-1) == 'a' 
                || str.charAt(str.length()-1) == 'A') || str.charAt(str.length()-1) == 'e' || str.charAt(str.length()-1) == 'E') 
        {
            str = str.substring(0, str.length()-1);
        }

        return str;
    }

    public static List<java.io.File> files(String directory, String mediaType)
    {
        java.io.File dir = new java.io.File(directory);

        if ("V".equals(mediaType))
        {
            return Arrays.asList(dir.listFiles(new FilenameFilter()
            {
                @Override
                public boolean accept(java.io.File dir, String name)
                {
                    return name.endsWith(".jsonV");
                }
            }));
        }
        else if ("P".equals(mediaType))
        {
            return Arrays.asList(dir.listFiles(new FilenameFilter()
            {
                @Override
                public boolean accept(java.io.File dir, String name)
                {
                    return name.endsWith(".jsonP");
                }
            }));
        }

        return Arrays.asList(new java.io.File[0]);
    }
}