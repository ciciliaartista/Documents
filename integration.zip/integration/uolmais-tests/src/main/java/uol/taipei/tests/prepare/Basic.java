/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         09/03/2015 Criacao inicial
 */

package uol.taipei.tests.prepare;

import java.io.File;
import java.util.HashMap;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uol.taipei.request.JsonRequest;
import uol.taipei.tests.LoginCookie;
import uol.taipei.tests.publish.ApiPublish;
import uol.taipei.tests.util.JsonUtil;

public class Basic extends ApiPublish
{
    static final Logger logger = LoggerFactory.getLogger(Basic.class);

    public static void main(String[] args)
    {
        if (!verifyParams(args))
        {
            return;
        }

        setUp(args[0]);

        logger.debug("-------------------------------------------------");
        logger.debug("tests prepare");

        try
        {
            LoginCookie login = new LoginCookie(envConfig().getUser(), envConfig().getPass());
            Basic basic = new Basic();

            basic.publishVideoAutor(login);
            basic.publishVideoDraft(login);
            basic.publishVideoHot(login);
            basic.publishVideoSubscriber(login);
            basic.publishAudioAutor(login);
            basic.publishAudioDraft(login);
            basic.publishAudioHot(login);

            basic.removeVideo(login);
            basic.removeAudio(login);
        }
        catch (Exception e)
        {
            logger.error(e.getMessage());
        }
    }

    public JSONObject publishVideoAutor(LoginCookie login)
    {
        try
        {
            String query = "SELECT m.idt_media FROM media m LEFT JOIN file f ON m.idt_file = f.idt_file WHERE m.cod_status = 10 "
                    + "AND m.ind_media_type = 'V' AND  m.ind_visibility = 'N' AND f.cod_status = 10 "
                    + "AND f.idt_file IS NOT NULL AND f.dat_limbo IS NULL ORDER BY m.idt_media DESC LIMIT 1";

            JSONObject result = JsonRequest.execQuery(query);

            if (result != null && result.has("data") && result.getJSONArray("data").length() > 0
                    && !JsonUtil.getParam(result, "idt_media").toString().isEmpty())
            {
                logger.info("INFO - nothing to do");

                return JsonUtil.jsonArrayToObject(result.getJSONArray("columns"), result.getJSONArray("data").getJSONArray(0));
            }

            String fileName = System.getenv("PATH_FILE_TEST") + File.separator + "video.mp4";
            java.io.File file = new java.io.File(fileName);

            if (file == null || !file.exists())
            {
                logger.error("ERROR - file not found - " + (file != null ? file.getAbsolutePath() : null));
                return null;
            }

            HashMap<String, String> params = new HashMap<String, String>();
            params.put("media.namSubject", "somente o dono pode ver");
            params.put("media.tags", "tag");
            params.put("media.indVisibility", "N");

            login.isAuthenticated();

            JSONObject jsonResponse = login.postJson("http://beta.mais.uol.com.br/apiuol/publish/video?variant=json", params, file);

            if (!validateJson(jsonResponse, false, true))
            {
                logger.error("ERROR - return not valid - " + jsonResponse);
                return null;
            }

            logger.debug("SUCCESS");

            return jsonResponse;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return null;
        }
    }

    public JSONObject publishVideoDraft(LoginCookie login)
    {
        try
        {
            String query = "SELECT m.idt_media FROM media m LEFT JOIN file f ON m.idt_file = f.idt_file WHERE m.cod_status = 10 "
                    + "AND m.ind_media_type = 'V' AND  m.flg_draft = 1 AND f.cod_status = 10 "
                    + "AND f.idt_file IS NOT NULL AND f.dat_limbo IS NULL ORDER BY m.idt_media DESC LIMIT 1";

            JSONObject result = JsonRequest.execQuery(query);

            if (result != null && result.has("data") && result.getJSONArray("data").length() > 0
                    && !JsonUtil.getParam(result, "idt_media").toString().isEmpty())
            {
                logger.info("INFO - nothing to do");

                return JsonUtil.jsonArrayToObject(result.getJSONArray("columns"), result.getJSONArray("data").getJSONArray(0));
            }

            String fileName = System.getenv("PATH_FILE_TEST") + File.separator + "video.mp4";
            java.io.File file = new java.io.File(fileName);

            if (file == null || !file.exists())
            {
                logger.error("ERROR - file not found - " + (file != null ? file.getAbsolutePath() : null));
                return null;
            }

            HashMap<String, String> params = new HashMap<String, String>();
            params.put("media.indVisibility", "");

            login.isAuthenticated();

            JSONObject jsonResponse = login.postJson("http://beta.mais.uol.com.br/apiuol/publish/video?variant=json", params, file);

            if (!validateJson(jsonResponse, false, true))
            {
                logger.error("ERROR - return not valid - " + jsonResponse);
                return null;
            }

            logger.debug("SUCCESS");

            return jsonResponse;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return null;
        }
    }

    public JSONObject publishVideoHot(LoginCookie login)
    {
        try
        {
            String query = "SELECT m.idt_media FROM media m LEFT JOIN file f ON m.idt_file = f.idt_file WHERE m.cod_status = 10 "
                    + "AND m.ind_media_type = 'V' AND  ind_hot IN ('U','P') AND f.cod_status = 10 "
                    + "AND f.idt_file IS NOT NULL AND f.dat_limbo IS NULL ORDER BY m.idt_media DESC LIMIT 1";

            JSONObject result = JsonRequest.execQuery(query);

            if (result != null && result.has("data") && result.getJSONArray("data").length() > 0
                    && !JsonUtil.getParam(result, "idt_media").toString().isEmpty())
            {
                logger.info("INFO - nothing to do");

                return JsonUtil.jsonArrayToObject(result.getJSONArray("columns"), result.getJSONArray("data").getJSONArray(0));
            }

            String fileName = System.getenv("PATH_FILE_TEST") + File.separator + "video.mp4";
            java.io.File file = new java.io.File(fileName);

            if (file == null || !file.exists())
            {
                logger.error("ERROR - file not found - " + (file != null ? file.getAbsolutePath() : null));
                return null;
            }

            HashMap<String, String> params = new HashMap<String, String>();
            params.put("media.namSubject", "video hot");
            params.put("media.tags", "tag");
            params.put("media.indVisibility", "T");
            params.put("media.indHot", "U");

            login.isAuthenticated();

            JSONObject jsonResponse = login.postJson("http://beta.mais.uol.com.br/apiuol/publish/video?variant=json", params, file);

            if (!validateJson(jsonResponse, false, true))
            {
                logger.error("ERROR - return not valid - " + jsonResponse);
                return null;
            }

            logger.debug("SUCCESS");

            return jsonResponse;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return null;
        }
    }

    public JSONObject publishVideoSubscriber(LoginCookie login)
    {
        try
        {
            String query = "SELECT m.idt_media FROM media m LEFT JOIN file f ON m.idt_file = f.idt_file WHERE m.cod_status = 10 "
                    + "AND m.ind_media_type = 'V' AND m.flg_subscriber_media = 1 AND f.cod_status = 10 "
                    + "AND f.idt_file IS NOT NULL AND f.dat_limbo IS NULL ORDER BY m.idt_media DESC LIMIT 1";

            JSONObject result = JsonRequest.execQuery(query);

            if (result != null && result.has("data") && result.getJSONArray("data").length() > 0
                    && !JsonUtil.getParam(result, "idt_media").toString().isEmpty())
            {
                logger.info("INFO - nothing to do");

                return JsonUtil.jsonArrayToObject(result.getJSONArray("columns"), result.getJSONArray("data").getJSONArray(0));
            }

            HashMap<String, String> params = prepareParams("V");
            java.io.File file = new java.io.File(params.get("_fileName"));

            if (file == null || !file.exists())
            {
                logger.error("ERROR - file not found - " + (file != null ? file.getAbsolutePath() : null));
                return null;
            }

            params.put("media.flgSubscriberMedia", "1");

            login.isAuthenticated();

            JSONObject jsonResponse = login.postJson("http://beta.mais.uol.com.br/apiuol/publish/video?variant=json", params, file);

            if (!validateJson(jsonResponse, false, true))
            {
                logger.error("ERROR - return not valid - " + jsonResponse);
                return null;
            }

            logger.debug("SUCCESS");

            return jsonResponse;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return null;
        }
    }

    public JSONObject publishAudioAutor(LoginCookie login)
    {
        try
        {
            String query = "SELECT m.idt_media FROM media m LEFT JOIN file f ON m.idt_file = f.idt_file WHERE m.cod_status = 10 "
                    + "AND m.ind_media_type = 'P' AND  m.ind_visibility = 'N' AND f.cod_status = 10 "
                    + "AND f.idt_file IS NOT NULL AND f.dat_limbo IS NULL ORDER BY m.idt_media DESC LIMIT 1";

            JSONObject result = JsonRequest.execQuery(query);

            if (result != null && result.has("data") && result.getJSONArray("data").length() > 0
                    && !JsonUtil.getParam(result, "idt_media").toString().isEmpty())
            {
                logger.info("INFO - nothing to do");

                return JsonUtil.jsonArrayToObject(result.getJSONArray("columns"), result.getJSONArray("data").getJSONArray(0));
            }

            String fileName = System.getenv("PATH_FILE_TEST") + File.separator + "audio.mp3";
            java.io.File file = new java.io.File(fileName);

            if (file == null || !file.exists())
            {
                logger.error("ERROR - file not found - " + (file != null ? file.getAbsolutePath() : null));
                return null;
            }

            HashMap<String, String> params = new HashMap<String, String>();
            params.put("media.namSubject", "somente o dono pode ver");
            params.put("media.tags", "tag");
            params.put("media.indVisibility", "N");

            login.isAuthenticated();

            JSONObject jsonResponse = login.postJson("http://beta.mais.uol.com.br/apiuol/publish/audio?variant=json", params, file);

            if (!validateJson(jsonResponse, false, true))
            {
                logger.error("ERROR - return not valid - " + jsonResponse);
                return null;
            }

            logger.debug("SUCCESS");

            return jsonResponse;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return null;
        }
    }

    public JSONObject publishAudioDraft(LoginCookie login)
    {
        try
        {
            String query = "SELECT m.idt_media FROM media m LEFT JOIN file f ON m.idt_file = f.idt_file WHERE m.cod_status = 10 "
                    + "AND m.ind_media_type = 'P' AND  m.flg_draft = 1 AND f.cod_status = 10 "
                    + "AND f.idt_file IS NOT NULL AND f.dat_limbo IS NULL ORDER BY m.idt_media DESC LIMIT 1";

            JSONObject result = JsonRequest.execQuery(query);

            if (result != null && result.has("data") && result.getJSONArray("data").length() > 0
                    && !JsonUtil.getParam(result, "idt_media").toString().isEmpty())
            {
                logger.info("INFO - nothing to do");

                return JsonUtil.jsonArrayToObject(result.getJSONArray("columns"), result.getJSONArray("data").getJSONArray(0));
            }

            String fileName = System.getenv("PATH_FILE_TEST") + File.separator + "audio.mp3";
            java.io.File file = new java.io.File(fileName);

            if (file == null || !file.exists())
            {
                logger.error("ERROR - file not found - " + (file != null ? file.getAbsolutePath() : null));
                return null;
            }

            HashMap<String, String> params = new HashMap<String, String>();
            params.put("media.indVisibility", "");

            login.isAuthenticated();

            JSONObject jsonResponse = login.postJson("http://beta.mais.uol.com.br/apiuol/publish/audio?variant=json", params, file);

            if (!validateJson(jsonResponse, false, true))
            {
                logger.error("ERROR - return not valid - " + jsonResponse);
                return null;
            }

            logger.debug("SUCCESS");

            return jsonResponse;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return null;
        }
    }

    public JSONObject publishAudioHot(LoginCookie login)
    {
        try
        {
            String query = "SELECT m.idt_media FROM media m LEFT JOIN file f ON m.idt_file = f.idt_file WHERE m.cod_status = 10 "
                    + "AND m.ind_media_type = 'P' AND  ind_hot IN ('U','P') AND f.cod_status = 10 "
                    + "AND f.idt_file IS NOT NULL AND f.dat_limbo IS NULL ORDER BY m.idt_media DESC LIMIT 1";

            JSONObject result = JsonRequest.execQuery(query);

            if (result != null && result.has("data") && result.getJSONArray("data").length() > 0
                    && !JsonUtil.getParam(result, "idt_media").toString().isEmpty())
            {
                logger.info("INFO - nothing to do");

                return JsonUtil.jsonArrayToObject(result.getJSONArray("columns"), result.getJSONArray("data").getJSONArray(0));
            }

            String fileName = System.getenv("PATH_FILE_TEST") + File.separator + "audio.mp3";
            java.io.File file = new java.io.File(fileName);

            if (file == null || !file.exists())
            {
                logger.error("ERROR - file not found - " + (file != null ? file.getAbsolutePath() : null));
                return null;
            }

            HashMap<String, String> params = new HashMap<String, String>();
            params.put("media.namSubject", "audio hot");
            params.put("media.tags", "tag");
            params.put("media.indVisibility", "T");
            params.put("media.indHot", "U");

            login.isAuthenticated();

            JSONObject jsonResponse = login.postJson("http://beta.mais.uol.com.br/apiuol/publish/audio?variant=json", params, file);

            if (!validateJson(jsonResponse, false, true))
            {
                logger.error("ERROR - return not valid - " + jsonResponse);
                return null;
            }

            logger.debug("SUCCESS");

            return jsonResponse;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return null;
        }
    }

    public JSONObject removeVideo(LoginCookie login)
    {
        try
        {
            String query = "SELECT m.idt_media FROM media m LEFT JOIN file f ON m.idt_file = f.idt_file WHERE m.cod_status = 20 "
                    + "AND m.ind_media_type = 'V' AND f.cod_status = 10 AND f.idt_file IS NOT NULL AND f.dat_limbo IS NULL ORDER BY m.idt_media DESC LIMIT 1";

            JSONObject result = JsonRequest.execQuery(query);

            if (result != null && result.has("data") && result.getJSONArray("data").length() > 0
                    && !JsonUtil.getParam(result, "idt_media").toString().isEmpty())
            {
                logger.info("INFO - nothing to do");

                return JsonUtil.jsonArrayToObject(result.getJSONArray("columns"), result.getJSONArray("data").getJSONArray(0));
            }

            String fileName = System.getenv("PATH_FILE_TEST") + File.separator + "video.mp4";
            java.io.File file = new java.io.File(fileName);

            if (file == null || !file.exists())
            {
                logger.error("ERROR - file not found - " + (file != null ? file.getAbsolutePath() : null));
                return null;
            }

            HashMap<String, String> params = new HashMap<String, String>();
            params.put("media.namSubject", "video removido");
            params.put("media.tags", "tag");
            params.put("media.indVisibility", "T");

            login.isAuthenticated();

            JSONObject jsonResponse = login.postJson("http://beta.mais.uol.com.br/apiuol/publish/video?variant=json", params, file);

            if (!validateJson(jsonResponse, false, true))
            {
                logger.error("ERROR - return not valid - " + jsonResponse);
                return null;
            }

            // aguarda encoding
            verifyProcessing(login, jsonResponse, false);

            JSONObject jsonRemove = remove(login, jsonResponse.getJSONObject("media").getString("mediaId"));

            if (jsonRemove == null)
            {
                logger.error("ERROR - " + jsonRemove + " - " + jsonResponse);
                return null;
            }

            logger.debug("SUCCESS");

            return jsonResponse;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return null;
        }
    }

    public JSONObject removeAudio(LoginCookie login)
    {
        try
        {
            String query = "SELECT m.idt_media FROM media m LEFT JOIN file f ON m.idt_file = f.idt_file WHERE m.cod_status = 20 "
                    + "AND m.ind_media_type = 'P' AND f.cod_status = 10 AND f.idt_file IS NOT NULL AND f.dat_limbo IS NULL ORDER BY m.idt_media DESC LIMIT 1";

            JSONObject result = JsonRequest.execQuery(query);

            if (result != null && result.has("data") && result.getJSONArray("data").length() > 0
                    && !JsonUtil.getParam(result, "idt_media").toString().isEmpty())
            {
                logger.info("INFO - nothing to do");

                return JsonUtil.jsonArrayToObject(result.getJSONArray("columns"), result.getJSONArray("data").getJSONArray(0));
            }

            String fileName = System.getenv("PATH_FILE_TEST") + File.separator + "audio.mp3";
            java.io.File file = new java.io.File(fileName);

            if (file == null || !file.exists())
            {
                logger.error("ERROR - file not found - " + (file != null ? file.getAbsolutePath() : null));
                return null;
            }

            HashMap<String, String> params = new HashMap<String, String>();
            params.put("media.namSubject", "audio removido");
            params.put("media.tags", "tag");
            params.put("media.indVisibility", "T");

            login.isAuthenticated();

            JSONObject jsonResponse = login.postJson("http://beta.mais.uol.com.br/apiuol/publish/audio?variant=json", params, file);

            if (!validateJson(jsonResponse, false, true))
            {
                logger.error("ERROR - return not valid - " + jsonResponse);
                return null;
            }

            // aguarda encoding
            verifyProcessing(login, jsonResponse, false);

            JSONObject jsonRemove = remove(login, jsonResponse.getJSONObject("media").getString("mediaId"));

            if (jsonRemove == null)
            {
                logger.error("ERROR - " + jsonRemove + " - " + jsonResponse);
                return null;
            }

            logger.debug("SUCCESS");

            return jsonResponse;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return null;
        }
    }
}
