/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         04/08/2014 Criacao inicial
 */

package uol.taipei.tests.storage;

import java.util.HashMap;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uol.taipei.request.FacileRequest;
import uol.taipei.request.FacileResponse;
import uol.taipei.request.JsonRequest;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.util.RequestUtil;

public class Storage extends AbstractTest
{
    static final Logger logger = LoggerFactory.getLogger(Storage.class);

    public static void main(String[] args)
    {
        if (!verifyParams(args))
        {
            return;
        }

        setUp(args[0]);

        logger.debug("-------------------------------------------------");
        logger.debug("tests storage");

        try
        {
            Storage storage = new Storage();
            FacileRequest request = new FacileRequest();

            storage.probe();

            String mediaId = RequestUtil.mediaIdPublic("V");

            storage.storagePlayer(request, mediaId, 0);
            storage.storagePlayerV5(request, mediaId, 0);
            storage.storagePlayerThumb(request, mediaId, 0);
            storage.storagePlayerBand(request, mediaId);
            storage.storagePlayerAudio(request);
            storage.storageEmbed(request, mediaId);
            storage.storageEmbedV2(request, mediaId);
            storage.storageEmbedReduzido(request, mediaId);
            storage.storageEmbedReduzidoV2(request, mediaId);
            storage.storageEmbedV2ssl(request, mediaId);
            storage.storageVideo(request, mediaId);
            storage.videoNoReferer(request);
            storage.videoWithWildcard(request);
            storage.videoWithWildcardNoUseragent(request);
            storage.storageThumbVideo(request, mediaId);

            mediaId = RequestUtil.mediaIdPublic("P");

            storage.storageEmbedAudio2(request, mediaId);
            storage.storageEmbedAudio280(request, mediaId);            
            storage.storagePodcast(request, mediaId);
        }
        catch (Exception e)
        {
            logger.error(e.getMessage());
        }
    }

    public JSONObject probe() throws Exception
    {
        JSONObject jsonResponse = JsonRequest.get("http://storage.mais.uol.com.br/probe");

        if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") != 200)
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        try
        {
            jsonResponse.getString("upTime");
            jsonResponse.getString("serverVersion");
        }
        catch (Exception e)
        {
            logger.error("ERROR - return not valid - " + e.getMessage() + " - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public boolean storagePlayer(FacileRequest request, String mediaId, int thumbVersion) throws Exception
    {
        String url = "http://storage.mais.uol.com.br/player_video_v2.swf?mediaId=" + mediaId + "&p=mais&tv=" + thumbVersion;
        request.setFollowRedirects(false);
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put("Referer", "http://mais.uol.com.br");

        FacileResponse response = request.get(url, headers);

        if (response.getCode() != 302 && response.getCode() != 301)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        if (!request.getConn().getHeaderField("Location").matches("(http:\\/\\/)?player\\.mais\\.uol\\.com\\.br\\/player_video_v2\\.swf\\?mediaId=" 
                + mediaId + "&p=mais&tv="+ thumbVersion))
        {
            logger.error("ERROR - return not valid - " + request.getConn().getHeaderField("Location"));
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean storagePlayerV5(FacileRequest request, String mediaId, int thumbVersion) throws Exception
    {
        String url = "http://storage.mais.uol.com.br/player_video_v5.swf?mediaId=" + mediaId + "&p=mais&tv=" + thumbVersion;
        request.setFollowRedirects(false);
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put("Referer", "http://mais.uol.com.br");

        FacileResponse response = request.get(url, headers);

        if (response.getCode() != 302 && response.getCode() != 301)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        if (!request.getConn().getHeaderField("Location").matches("(http:\\/\\/)?player\\.mais\\.uol\\.com\\.br\\/player_video_v5\\.swf\\?mediaId=" 
                + mediaId + "&p=mais&tv="+ thumbVersion))
        {
            logger.error("ERROR - return not valid - " + request.getConn().getHeaderField("Location"));
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean storagePlayerThumb(FacileRequest request, String mediaId, int thumbVersion) throws Exception
    {
        String url = "http://storage.mais.uol.com.br/player_video_thumb.swf?mediaId=" + mediaId + "&p=editoruol&tv=" + thumbVersion;
        request.setFollowRedirects(false);
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put("Referer", "http://mais.uol.com.br");

        FacileResponse response = request.get(url, headers);

        if (response.getCode() != 302 && response.getCode() != 301)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        if (!request.getConn().getHeaderField("Location").matches("(http:\\/\\/)?player\\.mais\\.uol\\.com\\.br\\/player_video_thumb\\.swf\\?mediaId=" 
                + mediaId + "&p=editoruol&tv="+ thumbVersion))
        {
            logger.error("ERROR - return not valid - " + request.getConn().getHeaderField("Location"));
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean storagePlayerBand(FacileRequest request, String mediaId) throws Exception
    {
        String url = "http://storage.mais.uol.com.br/player_video_v2_band.swf?mediaId=" + mediaId;
        request.setFollowRedirects(false);
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put("Referer", "http://mais.uol.com.br");

        FacileResponse response = request.get(url, headers);

        if (response.getCode() != 302 && response.getCode() != 301)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        if (!request.getConn().getHeaderField("Location").matches("(http:\\/\\/)?player\\.mais\\.uol\\.com\\.br\\/player_video_v2_band\\.swf\\?mediaId=" 
                + mediaId))
        {
            logger.error("ERROR - return not valid - " + request.getConn().getHeaderField("Location"));
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean storageEmbedV2(FacileRequest request, String mediaId) throws Exception
    {
        String url = "http://storage.mais.uol.com.br/embed_v2.swf?mediaId=" + mediaId;
        request.setFollowRedirects(false);
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put("Referer", "http://mais.uol.com.br");

        FacileResponse response = request.get(url, headers);

        if (response.getCode() != 302 && response.getCode() != 301)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        if (!request.getConn().getHeaderField("Location").matches("(http:\\/\\/)?player\\.mais\\.uol\\.com\\.br\\/embed_v2\\.swf\\?mediaId=" 
                + mediaId))
        {
            logger.error("ERROR - return not valid - " + request.getConn().getHeaderField("Location"));
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean storageEmbed(FacileRequest request, String mediaId) throws Exception
    {
        String url = "http://storage.mais.uol.com.br/embed.swf?mediaId=" + mediaId;
        request.setFollowRedirects(false);
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put("Referer", "http://mais.uol.com.br");

        FacileResponse response = request.get(url, headers);

        if (response.getCode() != 302 && response.getCode() != 301)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        if (!request.getConn().getHeaderField("Location").matches("(http:\\/\\/)?player\\.mais\\.uol\\.com\\.br\\/embed\\.swf\\?mediaId=" 
                + mediaId))
        {
            logger.error("ERROR - redir not valid - " + request.getConn().getHeaderField("Location"));
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean storageEmbedReduzido(FacileRequest request, String mediaId) throws Exception
    {
        String url = "http://storage.mais.uol.com.br/embed_reduzido.swf?mediaId=" + mediaId;
        request.setFollowRedirects(false);
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put("Referer", "http://mais.uol.com.br");

        FacileResponse response = request.get(url, headers);

        if (response.getCode() != 302 && response.getCode() != 301)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        if (!request.getConn().getHeaderField("Location").matches("(http:\\/\\/)?player\\.mais\\.uol\\.com\\.br\\/embed_reduzido\\.swf\\?mediaId=" 
                + mediaId))
        {
            logger.error("ERROR - redir not valid - " + request.getConn().getHeaderField("Location"));
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean storageEmbedReduzidoV2(FacileRequest request, String mediaId) throws Exception
    {
        String url = "http://storage.mais.uol.com.br/embed_reduzido_v2.swf?mediaId=" + mediaId;
        request.setFollowRedirects(false);
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put("Referer", "http://mais.uol.com.br");

        FacileResponse response = request.get(url, headers);

        if (response.getCode() != 302 && response.getCode() != 301)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        if (!request.getConn().getHeaderField("Location").matches("(http:\\/\\/)?player\\.mais\\.uol\\.com\\.br\\/embed_reduzido_v2\\.swf\\?mediaId=" 
                + mediaId))
        {
            logger.error("ERROR - redir not valid - " + request.getConn().getHeaderField("Location"));
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    /**
     * embed v2 ssl. Apesar do nome e usado em http tambem
     * 
     * @param request
     * @param mediaId
     * @return Boolean
     * @throws Exception
     */
    public boolean storageEmbedV2ssl(FacileRequest request, String mediaId) throws Exception
    {
        String url = "http://storage.mais.uol.com.br/embed_v2_ssl.swf?mediaId=" + mediaId;
        request.setFollowRedirects(false);
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put("Referer", "http://mais.uol.com.br");

        FacileResponse response = request.get(url, headers);

        if (response.getCode() != 302 && response.getCode() != 301)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        if (!request.getConn().getHeaderField("Location").matches("(http:\\/\\/)?player\\.mais\\.uol\\.com\\.br\\/embed_v2_ssl\\.swf\\?mediaId=" 
                + mediaId))
        {
            logger.error("ERROR - redir not valid - " + request.getConn().getHeaderField("Location"));
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean storagePlayerAudio(FacileRequest request) throws Exception
    {
        String url = "http://storage.mais.uol.com.br/player_audio.swf";
        request.setFollowRedirects(false);
        FacileResponse response = request.get(url);

        if (response.getCode() != 302 && response.getCode() != 301)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        if (!request.getConn().getHeaderField("Location").matches("(http:\\/\\/)?player\\.mais\\.uol\\.com\\.br\\/player_audio\\.swf"))
        {
            logger.error("ERROR - redir not valid - " + request.getConn().getHeaderField("Location"));
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean storageEmbedAudio2(FacileRequest request, String mediaId) throws Exception
    {
        String url = "http://storage.mais.uol.com.br/embed_audio2.swf?mediaId=" + mediaId;
        request.setFollowRedirects(false);
        FacileResponse response = request.get(url);

        if (response.getCode() != 302 && response.getCode() != 301)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        if (!request.getConn().getHeaderField("Location").matches("(http:\\/\\/)?player\\.mais\\.uol\\.com\\.br\\/embed_audio2\\.swf\\?mediaId=" 
                + mediaId))
        {
            logger.error("ERROR - redir not valid - " + request.getConn().getHeaderField("Location"));
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean storageEmbedAudio280(FacileRequest request, String mediaId) throws Exception
    {
        String url = "http://storage.mais.uol.com.br/embed_audio_280.swf?mediaId=" + mediaId;
        request.setFollowRedirects(false);
        FacileResponse response = request.get(url);

        if (response.getCode() != 302 && response.getCode() != 301)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        if (!request.getConn().getHeaderField("Location").matches("(http:\\/\\/)?player\\.mais\\.uol\\.com\\.br\\/embed_audio_280\\.swf\\?mediaId=" 
                + mediaId))
        {
            logger.error("ERROR - redir not valid - " + request.getConn().getHeaderField("Location"));
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean storageVideo(FacileRequest request, String mediaId) throws Exception
    {
        String url = "http://storage.mais.uol.com.br/" + mediaId + ".mp4";
        request.setFollowRedirects(false);
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put("Referer", "http://mais.uol.com.br");

        FacileResponse response = request.get(url, headers);

        if (response.getCode() != 302)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        if (!request.getConn().getHeaderField("Location").matches("(http:\\/\\/)?video(hd)?[0-9]+\\.mais\\.uol\\.com\\.br\\/" + mediaId + ".mp4"))
        {
            logger.error("ERROR - redir not valid - " + request.getConn().getHeaderField("Location"));
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean storagePodcast(FacileRequest request, String mediaId) throws Exception
    {
        String url = "http://storage.mais.uol.com.br/" + mediaId + ".mp3";
        request.setFollowRedirects(false);
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put("Referer", "http://mais.uol.com.br");

        FacileResponse response = request.get(url, headers);

        if (response.getCode() != 302)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        if (!request.getConn().getHeaderField("Location").matches("(http:)?(\\/\\/)?video(hd)?[0-9]+\\.mais\\.uol\\.com\\.br\\/" + mediaId + ".mp3"))
        {
            logger.error("ERROR - redir not valid - " + request.getConn().getHeaderField("Location"));
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean storageThumbVideo(FacileRequest request, String mediaId) throws Exception
    {
        request.setFollowRedirects(false);
        FacileResponse response = null;
        String url = null;
        String[] thumbs = new String[] { mediaId + ".jpg", 
                                         mediaId + "-small.jpg",
                                         mediaId + "-medium.jpg", 
                                         mediaId + "-large.jpg", 
                                         mediaId + "-xlarge.jpg",
                                         mediaId + "-wlarge.jpg",
                                         mediaId + "-wmedium.jpg" };

        for (String t : thumbs)
        {
            url = "http://storage.mais.uol.com.br/" + t;
            response = request.get(url);

            if (response.getCode() != 200)
            {
                logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
                return false;
            }
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean videoNoReferer(FacileRequest request) throws Exception
    {
        String mediaId = RequestUtil.mediaIdPublic("V");
        String url = "http://storage.mais.uol.com.br/" + mediaId + ".mp4";
        request.setFollowRedirects(false);
        FacileResponse response = request.get(url);

        if (response.getCode() != 403)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        if (!response.getBody().contains("Failure"))
        {
            logger.error("ERROR - " + response.getBody() + " - " + mediaId);
            return false;
        }

        logger.debug("SUCCESS");
    
        return true;
    }

    /**
     * request para video do balaio com parametro r
     * 
     * @param request
     * @return boolean
     * @throws Exception
     */
    public boolean videoWithWildcard(FacileRequest request) throws Exception
    {
        String mediaId = RequestUtil.mediaIdPublic("V");
        String url = "http://storage.mais.uol.com.br/" + mediaId + ".mp4?r=http://mais.uol.com.br";
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.93 Safari/537.36");
        request.setFollowRedirects(false);
        FacileResponse response = request.get(url, headers);

        if (response.getCode() != 302)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        if (!request.getConn().getHeaderField("Location").matches("(http:\\/\\/)?video(hd)?[0-9]+\\.mais\\.uol\\.com\\.br\\/" + mediaId + ".mp4\\?r=http(://|%3A%2F%2F)mais\\.uol\\.com\\.br"))
        {
            logger.error("ERROR - redir not valid - " + request.getConn().getHeaderField("Location"));
            return false;
        }
    
        logger.debug("SUCCESS");
    
        return true;
    }

    public boolean videoWithWildcardNoUseragent(FacileRequest request) throws Exception
    {
        String mediaId = RequestUtil.mediaIdPublic("V");
        String url = "http://storage.mais.uol.com.br/" + mediaId + ".mp4?r=http://mais.uol.com.br";
        request.setFollowRedirects(false);
        FacileResponse response = request.get(url);

        if (response.getCode() != 403)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        if (!response.getBody().contains("Failure"))
        {
            logger.error("ERROR - " + response.getBody() + " - " + mediaId);
            return false;
        }
    
        logger.debug("SUCCESS");
    
        return true;
    }
}
