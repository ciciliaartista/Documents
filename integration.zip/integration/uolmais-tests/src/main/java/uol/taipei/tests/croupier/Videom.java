/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         20/08/2015 Criacao inicial
 */

package uol.taipei.tests.croupier;

import java.util.HashMap;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uol.taipei.request.FacileRequest;
import uol.taipei.request.FacileResponse;
import uol.taipei.request.JsonRequest;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.util.RequestUtil;

public class Videom extends AbstractTest
{
    static final Logger logger = LoggerFactory.getLogger(Videom.class);

    public static void main(String[] args)
    {
        if (!verifyParams(args))
        {
            return;
        }

        setUp(args[0]);

        logger.debug("-------------------------------------------------");
        logger.debug("tests videom");

        try
        {
            Videom videom = new Videom();
            FacileRequest request = new FacileRequest();

            videom.probe();

            String mediaId = RequestUtil.mediaIdPublic("V");

            videom.videoMobile(request, mediaId);
            videom.videoMobileNoFormat9(request);
            videom.videoNoReferer(request);
            videom.videoWithWildcard(request);
            videom.videoWithWildcardNoUseragent(request);

            mediaId = RequestUtil.mediaIdPublic("P");

            videom.podcastMobile(request, mediaId);
        }
        catch (Exception e)
        {
            logger.error(e.getMessage());
        }
    }

    public JSONObject probe() throws Exception
    {
        JSONObject jsonResponse = JsonRequest.get("http://video.m.mais.uol.com.br/probe");

        if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") != 200)
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        try
        {
            jsonResponse.getString("upTime");
            jsonResponse.getString("status");
            jsonResponse.getString("serverVersion");
        }
        catch (Exception e)
        {
            logger.error("ERROR - return not valid - " + e.getMessage() + " - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public boolean videoMobile(FacileRequest request, String mediaId) throws Exception
    {
        String fileName = mediaId + ".mp4";
        String url = "http://video.m.mais.uol.com.br/" + fileName;
        request.setFollowRedirects(false);
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put("Referer", "http://mais.uol.com.br");

        FacileResponse response = request.get(url, headers);

        if (response.getCode() != 302)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        if (!request.getConn().getHeaderField("Location").matches("(http:\\/\\/)?video(hd)?[0-9]+\\.mais\\.uol\\.com\\.br\\/" + fileName))
        {
            logger.error("ERROR - return not valid - " + request.getConn().getHeaderField("Location"));
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean videoMobileNoFormat9(FacileRequest request) throws Exception
    {
        String mediaId = RequestUtil.mediaIdNoVideoFormatFile(9);
        String url = "http://video.m.mais.uol.com.br/" + mediaId + "-9.mp4";
        request.setFollowRedirects(false);
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put("Referer", "http://mais.uol.com.br");

        FacileResponse response = request.get(url, headers);

        if (response.getCode() != 302)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        if (!request.getConn().getHeaderField("Location").matches("(http:\\/\\/)?video(hd)?[0-9]+\\.mais\\.uol\\.com\\.br\\/" + mediaId + ".mp4"))
        {
            logger.error("ERROR - return not valid - " + request.getConn().getHeaderField("Location"));
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean videoNoReferer(FacileRequest request) throws Exception
    {
        String mediaId = RequestUtil.mediaIdPublic("V");
        String url = "http://video.m.mais.uol.com.br/" + mediaId + ".mp4";
        FacileResponse response = request.get(url);

        if (response.getCode() != 302)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        if (!request.getConn().getHeaderField("Location").matches("(http:\\/\\/)?video(hd)?[0-9]+\\.mais\\.uol\\.com\\.br\\/" + mediaId + ".mp4"))
        {
            logger.error("ERROR - return not valid - " + request.getConn().getHeaderField("Location"));
            return false;
        }

        logger.debug("SUCCESS");
    
        return true;
    }

    /**
     * request para video do balaio com parametro r
     * 
     * @param request
     * @return boolean
     * @throws Exception
     */
    public boolean videoWithWildcard(FacileRequest request) throws Exception
    {
        String mediaId = RequestUtil.mediaIdPublic("V");
        String url = "http://video.m.mais.uol.com.br/" + mediaId + ".mp4?r=http://mais.uol.com.br";
        boolean followRedirects = request.getHttpConn().getInstanceFollowRedirects();
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.93 Safari/537.36");
        request.setFollowRedirects(false);

        FacileResponse response = request.get(url, headers);
        request.getHttpConn().setInstanceFollowRedirects(followRedirects);

        if (response.getCode() != 302)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        if (!request.getConn().getHeaderField("Location").matches("(http:\\/\\/)?video(hd)?[0-9]+\\.mais\\.uol\\.com\\.br\\/" + mediaId + ".mp4\\?r=http://mais\\.uol\\.com\\.br"))
        {
            logger.error("ERROR - return not valid - " + request.getConn().getHeaderField("Location"));
            return false;
        }

        logger.debug("SUCCESS");
    
        return true;
    }

    public boolean videoWithWildcardNoUseragent(FacileRequest request) throws Exception
    {
        String mediaId = RequestUtil.mediaIdPublic("V");
        String url = "http://video.m.mais.uol.com.br/" + mediaId + ".mp4?r=http://mais.uol.com.br";
        FacileResponse response = request.get(url);

        if (response.getCode() != 302)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        if (!request.getConn().getHeaderField("Location").matches("(http:\\/\\/)?video(hd)?[0-9]+\\.mais\\.uol\\.com\\.br\\/" + mediaId + ".mp4\\?r=http://mais\\.uol\\.com\\.br"))
        {
            logger.error("ERROR - return not valid - " + request.getConn().getHeaderField("Location"));
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean podcastMobile(FacileRequest request, String mediaId) throws Exception
    {
        String url = "http://video.m.mais.uol.com.br/" + mediaId + ".mp3";
        request.setFollowRedirects(false);
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put("Referer", "http://mais.uol.com.br");

        FacileResponse response = request.get(url, headers);

        if (response.getCode() != 302)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        if (!request.getConn().getHeaderField("Location").matches("(http:\\/\\/)?video(hd)?[0-9]+\\.mais\\.uol\\.com\\.br\\/" + mediaId + ".mp3"))
        {
            logger.error("ERROR - return not valid - " + request.getConn().getHeaderField("Location"));
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }
}
