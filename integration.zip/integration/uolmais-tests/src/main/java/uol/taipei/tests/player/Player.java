/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         08/06/2015 Criacao inicial
 */

package uol.taipei.tests.player;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uol.taipei.request.FacileRequest;
import uol.taipei.request.FacileResponse;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.util.JsonUtil;
import uol.taipei.tests.util.RequestUtil;

public class Player extends AbstractTest
{
    static final Logger logger = LoggerFactory.getLogger(Player.class);

    public static void main(String[] args)
    {
        if (!verifyParams(args))
        {
            return;
        }

        setUp(args[0]);

        if (envConfig().getUser() == null || envConfig().getUser().equals("") || envConfig().getPass() == null || envConfig().getPass().equals(""))
        {
            System.err.println("Invalid user " + envConfig().getUser());
            return;
        }

        logger.debug("-------------------------------------------------");
        logger.debug("tests api player");

        try
        {
            Player player = new Player();
            JSONObject media = JsonUtil.mediaNoRestrict("V");

            player.playerhtml5(media.getLong("mediaId"));
            player.player(media.getLong("mediaId"), media.getInt("thumbVersion"));
            player.playerV5(media.getLong("mediaId"), media.getInt("thumbVersion"));
            player.playerThumb(media.getLong("mediaId"), media.getInt("thumbVersion"));
            player.playerBand(media.getLong("mediaId"));
            player.embed(media.getLong("mediaId"));
            player.embedV2(media.getLong("mediaId"));
            player.embedReduzido(media.getLong("mediaId"));
            player.embedReduzidoV2(media.getLong("mediaId"));
            player.embedV2ssl(media.getLong("mediaId"));

            String mediaId = RequestUtil.mediaIdPublic("P");

            player.playerhtml5Audio(mediaId);
            player.playerAudio();
            player.embedAudio2(mediaId);
            player.embedAudio280(mediaId);
        }
        catch (Exception e)
        {
            logger.error(e.getMessage());
        }
    }

    public boolean playerhtml5(Long mediaId) throws Exception
    {
        FacileRequest request = new FacileRequest();
        String url = "http://player.mais.uol.com.br/index.html?mediaId=" + mediaId;
        FacileResponse response = request.get(url);

        if (response.getCode() != 200 && response.getCode() != 304 && response.getCode() != 301)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean player(Long mediaId, int thumbVersion) throws Exception
    {
        FacileRequest request = new FacileRequest();
        String url = "http://player.mais.uol.com.br/player_video_v2.swf?mediaId=" + mediaId + "&p=mais&tv=" + thumbVersion;
        FacileResponse response = request.get(url);

        if (response.getCode() != 200 && response.getCode() != 304)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean playerV5(Long mediaId, int thumbVersion) throws Exception
    {
        FacileRequest request = new FacileRequest();
        String url = "http://player.mais.uol.com.br/player_video_v5.swf?mediaId=" + mediaId + "&p=mais&tv=" + thumbVersion;
        FacileResponse response = request.get(url, 1);

        if (response.getCode() != 200 && response.getCode() != 304)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean playerThumb(Long mediaId, int thumbVersion) throws Exception
    {
        FacileRequest request = new FacileRequest();
        String url = "http://player.mais.uol.com.br/player_video_thumb.swf?mediaId=" + mediaId + "&p=editoruol&tv=" + thumbVersion;
        FacileResponse response = request.get(url);

        if (response.getCode() != 200 && response.getCode() != 304)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean playerBand(Long mediaId) throws Exception
    {
        FacileRequest request = new FacileRequest();
        String url = "http://player.mais.uol.com.br/player_video_v2_band.swf?mediaId=" + mediaId;
        FacileResponse response = request.get(url);

        if (response.getCode() != 200 && response.getCode() != 304)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean embedV2(Long mediaId) throws Exception
    {
        FacileRequest request = new FacileRequest();
        String url = "http://player.mais.uol.com.br/embed_v2.swf?mediaId=" + mediaId;
        FacileResponse response = request.get(url);

        if (response.getCode() != 200 && response.getCode() != 304)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean embed(Long mediaId) throws Exception
    {
        FacileRequest request = new FacileRequest();
        String url = "http://player.mais.uol.com.br/embed.swf?mediaId=" + mediaId;
        FacileResponse response = request.get(url);

        if (response.getCode() != 200 && response.getCode() != 304)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean embedReduzido(Long mediaId) throws Exception
    {
        FacileRequest request = new FacileRequest();
        String url = "http://player.mais.uol.com.br/embed_reduzido.swf?mediaId=" + mediaId;
        FacileResponse response = request.get(url);

        if (response.getCode() != 200 && response.getCode() != 304)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean embedReduzidoV2(Long mediaId) throws Exception
    {
        FacileRequest request = new FacileRequest();
        String url = "http://player.mais.uol.com.br/embed_reduzido_v2.swf?mediaId=" + mediaId;
        FacileResponse response = request.get(url);

        if (response.getCode() != 200 && response.getCode() != 304)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean embedV2ssl(Long mediaId) throws Exception
    {
        FacileRequest request = new FacileRequest();
        String url = "http://player.mais.uol.com.br/embed_v2_ssl.swf?mediaId=" + mediaId;
        FacileResponse response = request.get(url);

        if (response.getCode() != 200 && response.getCode() != 304)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean playerhtml5Audio(String mediaId) throws Exception
    {
        FacileRequest request = new FacileRequest();
        String url = "http://player.mais.uol.com.br/index.html?mediaId=" + mediaId;
        FacileResponse response = request.get(url);

        if (response.getCode() != 200 && response.getCode() != 304 && response.getCode() != 301)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean playerAudio() throws Exception
    {
        FacileRequest request = new FacileRequest();
        String url = "http://player.mais.uol.com.br/player_audio.swf";
        FacileResponse response = request.get(url, 2);

        if (response.getCode() != 200 && response.getCode() != 304)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean embedAudio2(String mediaId) throws Exception
    {
        FacileRequest request = new FacileRequest();
        String url = "http://player.mais.uol.com.br/embed_audio2.swf?mediaId=" + mediaId;
        FacileResponse response = request.get(url, 1);

        if (response.getCode() != 200 && response.getCode() != 304)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean embedAudio280(String mediaId) throws Exception
    {
        FacileRequest request = new FacileRequest();
        String url = "http://player.mais.uol.com.br/embed_audio_280.swf?mediaId=" + mediaId;
        FacileResponse response = request.get(url, 1);

        if (response.getCode() != 200 && response.getCode() != 304)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }
}
