/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         05/08/2014 Criacao inicial
 */

package uol.taipei.tests;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.CharUtils;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;

import uol.taipei.request.UsefulRequest;
import uol.taipei.tests.util.TestUtil;
import uol.taipei.util.FileUtil;

public class MediasFromProd
{
    private static String filePath = System.getenv("PATH_FILE_TEST") + File.separator;

    public static void main(String[] args)
    {
        try
        {
            if (StringUtils.isBlank(filePath))
            {
                System.out.println("dir to download not exists");
                return;
            }

            if (args != null && args.length > 0)
            {
                clean("V");
                clean("P");

                for (String param : args)
                {
                    download("types=" + "V" + (param.startsWith("&") ? "" : "&") + param);
                    download("types=" + "P" + (param.startsWith("&") ? "" : "&") + param);
                }
            }
            else
            {
                clean("V");
                download("sort=todayViewed&types=" + "V");

                clean("P");
                download("sort=todayViewed&types=" + "P");
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    private static void download(String param) throws Exception
    {
        UsefulRequest request = new UsefulRequest();

        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put("Host", "mais.uol.com.br");

        // ip de vip de prod
        String url = "http://10.129.160.23/apiuol/v2/media/list?" + (param != null ? param : "sort=todayViewed");

        System.out.println(url);

        //JSONObject mediaList = JsonRequest.get(url + "&nocache=" + Math.random());
        JSONObject mediaList = request.getJson(url + "&nocache=" + Math.random(), headers);
        JSONObject jsonPlayer = null;
        String urlMedia = null;
        String urlDownload = null;
        java.io.File file = null;
        boolean requestok = false;

        if (mediaList.getJSONArray("list").length() > 0)
        {
            for (int i = 0; i < mediaList.getJSONArray("list").length(); i++)
            {
                if ("V".equals(mediaList.getJSONArray("list").getJSONObject(i).getString("mediaType")))
                {
                    //jsonPlayer = JsonRequest.get("http://10.129.160.23/apiuol/player/media?action=showPlayer&p=mais&types=V&mediaId="
                    //        + mediaList.getJSONArray("list").getJSONObject(i).getLong("mediaId") + "&nocache=" + Math.random());
                    jsonPlayer = request.getJson("http://10.129.160.23/apiuol/player/media?action=showPlayer&p=mais&types=V&mediaId="
                            + mediaList.getJSONArray("list").getJSONObject(i).getLong("mediaId") + "&nocache=" + Math.random(), headers);
                    urlMedia = getUrlByFormat(jsonPlayer, 2, false);
                    file = new java.io.File(filePath + mediaList.getJSONArray("list").getJSONObject(i).getLong("mediaId") + ".mp4");

                    // muda o dominio para um outro que deve apontar para os ips de prod
                    urlDownload = urlMedia.replace("video", "videox") + "?ver="
                            + mediaList.getJSONArray("list").getJSONObject(i).getInt("thumbVersion") + "&r=http%3A%2F%2Fmais.uol.com.br";
                }
                else if ("P".equals(mediaList.getJSONArray("list").getJSONObject(i).getString("mediaType")))
                {
                    urlMedia = "http://videox" + (new Random().nextInt(19) + 17) + ".mais.uol.com.br/";
                    file = new java.io.File(filePath + mediaList.getJSONArray("list").getJSONObject(i).getLong("mediaId") + ".mp3");
                    urlDownload = urlMedia + mediaList.getJSONArray("list").getJSONObject(i).getLong("mediaId") + ".mp3";
                }

                if (file != null && file.exists())
                {
                    continue;
                }

                try
                {
                    URL urlRequest = new URL(urlDownload);
                    URLConnection conn = urlRequest.openConnection();
                    conn.setRequestProperty("Referer", "http://mais.uol.com.br");
                    InputStream input = null;
                    HttpURLConnection httpConnection = null;
                    requestok = executeUrlConnection(urlRequest, conn, httpConnection);
                    input = conn.getInputStream();

                    if (requestok)
                    {
                        // grava o arquivo
                        writeFile(input, file);
                        // gera um arquivo com o json da midia
                        writeFileJson(mediaList.getJSONArray("list").getJSONObject(i), null);
                    }
                }
                catch (Exception e)
                {
                    e.printStackTrace();
                }
            }

            System.out.println("midias copiadas para " + filePath);
        }
    }

    private static boolean executeUrlConnection(URL urlRequest, URLConnection conn, HttpURLConnection httpConnection)
    {
        try
        {
            conn = urlRequest.openConnection();
            conn.setRequestProperty("Referer", "http://mais.uol.com.br");
            httpConnection = (HttpURLConnection) conn;

            return true;
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());
            return false;
        }
    }

    private static void writeFile(InputStream inputin, java.io.File fileout) throws Exception
    {
        FileOutputStream output = new FileOutputStream(fileout);
        FileUtil.copyStream(inputin, output);
        output.close();
    }

    private static void writeFileJson(JSONObject jsonMediaListItem, Integer index) throws Exception
    {
        JSONObject jsonItem = jsonMediaListItem;
        jsonItem.put("title", (jsonMediaListItem.has("title") ? adjustmentToFile(jsonMediaListItem.getString("title")) : ""));
        jsonItem.put("description", (jsonMediaListItem.has("description") ? adjustmentToFile(jsonMediaListItem.getString("description")) : ""));
        String extension = (index != null ? "-" + index : "") + ".json" + jsonMediaListItem.getString("mediaType");
        FileWriter fileJson = new FileWriter(filePath + jsonMediaListItem.getLong("mediaId") + extension);
        fileJson.write(jsonItem.toString());
        fileJson.flush();
        fileJson.close();
    }

    private static String adjustmentToFile(String field)
    {
        StringBuilder adj = new StringBuilder();

        for (int i = 0; i < field.length(); i++)
        {
            if (ArrayUtils.contains(TestUtil.CODES_CHAR_TO_UNICODE, field.codePointAt(i)))
            {
                adj.append(CharUtils.unicodeEscaped(field.charAt(i)));
            }
            else
            {
                adj.append(field.charAt(i));
            }
        }

        return adj.toString();
    }

    private static String getUrlByFormat(JSONObject jsonResponse, int format, boolean isSecure) throws Exception
    {
        for (int j = 0; j < jsonResponse.getJSONObject("media").getJSONArray("formats").length(); j++)
        {
            if (jsonResponse.getJSONObject("media").getJSONArray("formats").getJSONObject(j).getInt("id") == format)
            {
                if (isSecure)
                {
                    return jsonResponse.getJSONObject("media").getJSONArray("formats").getJSONObject(j).getString("secureUrl");
                }
                else
                {
                    return jsonResponse.getJSONObject("media").getJSONArray("formats").getJSONObject(j).getString("url");
                }
            }
        }

        return null;
    }

    private static void clean(String type)
    {
        String mediaId = null;
        java.io.File fileMedia = null;

        List<java.io.File> fileList = TestUtil.files(System.getenv("PATH_FILE_TEST") + java.io.File.separator, type);

        if (!fileList.isEmpty() && fileList.size() > 0)
        {
            for (java.io.File file : fileList)
            {
                mediaId = file.getName().substring(0, file.getName().indexOf("."));

                if ("V".equals(type))
                {
                    fileMedia = new java.io.File(System.getenv("PATH_FILE_TEST") + File.separator + mediaId + ".mp4");
                }
                else if ("P".equals(type))
                {
                    fileMedia = new java.io.File(System.getenv("PATH_FILE_TEST") + File.separator + mediaId + ".mp3");
                }

                System.out.println("removendo json " + file);
                System.out.println("removendo midia " + fileMedia);

                FileUtil.deleteFile(file);

                if (fileMedia != null && fileMedia.exists())
                {
                    FileUtil.deleteFile(fileMedia);
                }
            }
        }
    }
}
