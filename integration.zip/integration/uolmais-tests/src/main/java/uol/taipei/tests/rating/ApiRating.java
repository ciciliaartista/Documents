/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         20/06/2014 Criacao inicial
 */

package uol.taipei.tests.rating;

import org.apache.http.HttpStatus;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uol.taipei.request.JsonRequest;
import uol.taipei.request.UsefulRequest;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.LoginCookie;
import uol.taipei.tests.util.JsonUtil;
import uol.taipei.tests.util.TestUtil;

public class ApiRating extends AbstractTest
{
    static final Logger logger = LoggerFactory.getLogger(ApiRating.class);

    public static void main(String[] args)
    {
        if (!verifyParams(args))
        {
            return;
        }

        setUp(args[0]);

        if (envConfig().getUser() == null || envConfig().getUser().equals("") || envConfig().getPass() == null || envConfig().getPass().equals(""))
        {
            System.err.println("Invalid user " + envConfig().getUser());
            return;
        }

        logger.debug("-------------------------------------------------");
        logger.debug("tests api rating");

        try
        {
            ApiRating apiRating = new ApiRating();
            UsefulRequest login = new LoginCookie(envConfig().getUser(), envConfig().getPass());
            JSONObject media = JsonUtil.mediaNoRestrict("V");

            apiRating.noLoggedAdd(media);
            apiRating.loggedAdd(login, media);
        }
        catch (Exception e)
        {
            logger.error(e.getMessage());
        }
    }

    public JSONObject noLoggedAdd(JSONObject media) throws Exception
    {
        int retry = 0;
        int rating = TestUtil.randomInt(1, 5);
        JSONObject jsonmedia = JsonRequest.get("http://mais.uol.com.br/apiuol/v2/media/detail?mediaId=" + media.getLong("mediaId") + "&nocache=" + Math.random());
        int vote = jsonmedia.getJSONObject("media").getInt("votes");
        JSONObject jsonResponse = JsonRequest.get("http://mais.uol.com.br/apiuol/v2/rating/add/" + media.getLong("mediaId") + "/" + rating + ".json");

        if (!validateMessageJson(jsonResponse, 'S'))
        {
            logger.error("ERROR - return not valid - " + media.getLong("mediaId") + " " + jsonResponse);
            return null;
        }

        jsonmedia = JsonUtil.fullMedia(String.valueOf(media.getLong("mediaId")));

        while ((media.getInt("votes") == Integer.parseInt(jsonmedia.getString("num_total_vote")) || Integer.parseInt(jsonmedia.getString("num_total_vote")) <= vote) && retry < 3)
        {
            logger.warn("retry after 1s - " + media.getLong("mediaId"));

            TestUtil.delay(1000);
            jsonmedia = JsonUtil.fullMedia(String.valueOf(media.getLong("mediaId")));
            retry++;
        }

        if (media.getInt("votes") == Integer.parseInt(jsonmedia.getString("num_total_vote")))
        {
            logger.error("ERROR - same total votes - " + media.getLong("mediaId"));
            return null;
        }

        if (Integer.parseInt(jsonmedia.getString("num_total_vote")) <= vote)
        {
            logger.error("ERROR - vote was not updated - " + media.getLong("mediaId"));
            return null;
        }

        if (Integer.parseInt(jsonmedia.getString("num_average_vote")) == 0.0)
        {
            logger.error("ERROR - rating was not updated - " + media.getLong("mediaId"));
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject loggedAdd(UsefulRequest login, JSONObject media) throws Exception
    {
        int rating = TestUtil.randomInt(1, 5);
        JSONObject jsonmedia = JsonRequest.get("http://mais.uol.com.br/apiuol/v2/media/detail?mediaId=" + media.getLong("mediaId") + "&nocache=" + Math.random());
        int vote = jsonmedia.getJSONObject("media").getInt("votes");
        JSONObject jsonResponse = login.getJson("http://mais.uol.com.br/apiuol/v2/rating/add/" + media.getLong("mediaId") + "/" + rating + ".json");

        if (!validateMessageJson(jsonResponse, 'S'))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        // espera antes de responder, para verificar se esta havendo demora na replicacao de banco
        TestUtil.delay(1000);

        jsonmedia = JsonUtil.fullMedia(String.valueOf(media.getLong("mediaId")));

        if (media.getInt("votes") == Integer.parseInt(jsonmedia.getString("num_total_vote")))
        {
            logger.error("ERROR - same total votes - " + media.getLong("mediaId"));
            return null;
        }

        if (Integer.parseInt(jsonmedia.getString("num_total_vote")) <= vote)
        {
            logger.error("ERROR - vote was not updated - " + media.getLong("mediaId"));
            return null;
        }

        if (Integer.parseInt(jsonmedia.getString("num_average_vote")) == 0.0)
        {
            logger.error("ERROR - rating was not updated - " + media.getLong("mediaId"));
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    private boolean validateMessageJson(JSONObject json, char type)
    {
        try
        {
            if (json == null || json.getJSONObject("_response").getInt("code") != HttpStatus.SC_OK)
            {
                return false;
            }
            json.getJSONObject("messages");

            if (type == 'S')
            {
                json.getJSONObject("messages").getJSONArray("success");

                if (json.getJSONObject("messages").getJSONArray("success").length() < 1)
                {
                    throw new Exception("no has success message");
                }

                for (int i = 0; i < json.getJSONObject("messages").getJSONArray("success").length(); i++)
                {
                    json.getJSONObject("messages").getJSONArray("success").getJSONObject(i).getString("id");
                    json.getJSONObject("messages").getJSONArray("success").getJSONObject(i).getString("description");

                    JsonUtil.validateValueJson(json.getJSONObject("messages").getJSONArray("success").getJSONObject(i),
                        new String[] { "" });
                }
            }
            else if (type == 'E')
            {
                json.getJSONObject("messages").getJSONArray("errors");

                if (json.getJSONObject("messages").getJSONArray("errors").length() < 1)
                {
                    throw new Exception("no has error message");
                }

                for (int i = 0; i < json.getJSONObject("messages").getJSONArray("errors").length(); i++)
                {
                    json.getJSONObject("messages").getJSONArray("errors").getJSONObject(i).getString("id");
                    json.getJSONObject("messages").getJSONArray("errors").getJSONObject(i).getString("description");

                    JsonUtil.validateValueJson(json.getJSONObject("messages").getJSONArray("errors").getJSONObject(i),
                        new String[] { "" });
                }
            }
            else if (type == 'W')
            {
                json.getJSONObject("messages").getJSONArray("warns");

                if (json.getJSONObject("messages").getJSONArray("warns").length() < 1)
                {
                    throw new Exception("no has warn message");
                }

                for (int i = 0; i < json.getJSONObject("messages").getJSONArray("warns").length(); i++)
                {
                    json.getJSONObject("messages").getJSONArray("warns").getJSONObject(i).getString("id");
                    json.getJSONObject("messages").getJSONArray("warns").getJSONObject(i).getString("description");

                    JsonUtil.validateValueJson(json.getJSONObject("messages").getJSONArray("warns").getJSONObject(i),
                        new String[] { "" });
                }
            }
            else
            {
                json.getJSONObject("messages").getJSONArray("infos");

                if (json.getJSONObject("messages").getJSONArray("infos").length() < 1)
                {
                    throw new Exception("no has info message");
                }

                for (int i = 0; i < json.getJSONObject("messages").getJSONArray("infos").length(); i++)
                {
                    json.getJSONObject("messages").getJSONArray("infos").getJSONObject(i).getString("id");
                    json.getJSONObject("messages").getJSONArray("infos").getJSONObject(i).getString("description");

                    JsonUtil.validateValueJson(json.getJSONObject("messages").getJSONArray("infos").getJSONObject(i),
                        new String[] { "" });
                }
            }

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - message invalid - " + e.getMessage() + " - " + json);
            return false;
        }
    }
}
