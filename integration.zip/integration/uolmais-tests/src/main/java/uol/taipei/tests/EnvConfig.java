/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         04/04/2014 Criacao inicial
 */

package uol.taipei.tests;

public class EnvConfig
{
    private String env;
    private String user;
    private String pass;
    private String userRadius;
    private String passRadius;
    private String urlSolrMaster;
    private String urlSolrSlave;
    private String hostsEncoders;
    private String urlQueue;
    private GlobalConfig global;

    public String getEnv()
    {
        return env;
    }

    public void setEnv(String env)
    {
        this.env = env;
    }

    public String getUser()
    {
        return user;
    }

    public void setUser(String user)
    {
        this.user = user;
    }

    public String getPass()
    {
        return pass;
    }

    public void setPass(String pass)
    {
        this.pass = pass;
    }

    public String getUserRadius()
    {
        return userRadius;
    }

    public void setUserRadius(String userRadius)
    {
        this.userRadius = userRadius;
    }

    public String getPassRadius()
    {
        return passRadius;
    }

    public void setPassRadius(String passRadius)
    {
        this.passRadius = passRadius;
    }

    public String getUrlSolrMaster()
    {
        return urlSolrMaster;
    }

    public void setUrlSolrMaster(String urlSolrMaster)
    {
        this.urlSolrMaster = urlSolrMaster;
    }

    public String getUrlSolrSlave()
    {
        return urlSolrSlave;
    }

    public void setUrlSolrSlave(String urlSolrSlave)
    {
        this.urlSolrSlave = urlSolrSlave;
    }

    public String getHostsEncoders()
    {
        return hostsEncoders;
    }

    public void setHostsEncoders(String hostsEncoders)
    {
        this.hostsEncoders = hostsEncoders;
    }

    public String getUrlQueue()
    {
        return urlQueue;
    }

    public void setUrlQueue(String urlQueue)
    {
        this.urlQueue = urlQueue;
    }

    public GlobalConfig getGlobal()
    {
        return global;
    }

    public void setGlobal(GlobalConfig global)
    {
        this.global = global;
    }

    @Override
    public String toString()
    {
        return env + "-" + user + "-" + userRadius;
    }
}
