/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         10/01/2015 Criacao inicial
 */

package uol.taipei.tests;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

//import uol.guaruja.KeyIF;
//import uol.guaruja.TaskError;
//import uol.guaruja.client.RemoteException;
//import uol.guaruja.client.ResponseReader;
//import uol.guaruja.client.netty.http.GuarujaHttpConnectionManager;
//import uol.guaruja.client.network.ConnectionManagerIF;
//import uol.guaruja.client.network.LoadBalancerException;
//import uol.guaruja.client.network.Session;
//import uol.guaruja.protocol.ResponseStatus;

public class ExecTask
{
    private static final Logger logger = LoggerFactory.getLogger(ExecTask.class);

//    protected ConnectionManagerIF replicaConnectionManager;

//    public ExecTask(ConnectionManagerIF replicaConnectionManager)
//    {
//        this.replicaConnectionManager = replicaConnectionManager;
//    }
/*
    @SuppressWarnings("unchecked")
    public  <E> E exec(final String taskName, Object obj) throws Exception
    {
        Object bean = null;
        ResponseReader reader = null;
        Session session = null;

        try
        {
            session = replicaConnectionManager.getSession();

            if (session == null)
            {
                logger.error("no session");
            }
            else
            {
                logger.debug(String.format("[Update]: Task : %s ; key : %s", taskName, obj));

                reader = session.execute(taskName, obj);
                reader.setIgnoreUnknownAttributes(true);
                bean = (E) reader.readObject(obj.getClass());
            }
        }
        finally
        {
            if (session != null)
            {
                replicaConnectionManager.releaseSession(session);
            }
        }

        return (E) bean;
    }
*/
    /**
     * executa task get
     *
     * @param taskName
     * @param key
     * @param c
     * @param <E>
     * @return
     */
    /*@SuppressWarnings("unchecked")
    public  <E> E getTask(String taskName, KeyIF key, Class<?> c)
            throws Exception
    {
        E getTask = (E) getTask(taskName, key, c, null);

        return getTask;
    }*/
    /**
     * executa task get
     *
     * @param <E> tipo do bean
     * @param taskName
     * @param key
     * @param c classe do bean de retorno
     * @return <E> tipo do bean de retorno
     */
    /*@SuppressWarnings("unchecked")
    public <E> E getTask(String taskName, KeyIF key, Class<?> c, String sessionIp)
            throws Exception
    {
        Session session = null;

        if (sessionIp != null && !sessionIp.equals(""))
        {
            session = replicaConnectionManager.getSession(sessionIp);
        }
        else
        {
            session = replicaConnectionManager.getSession();
        }

        ResponseReader reader = null;
        E bean = null;

        try
        {
            logger.info("Task call: " + taskName + " (" + c + ") server: " + session.getServerId() + " key: " + key);

            reader = session.execute(taskName, key);
            reader.setIgnoreUnknownAttributes(true);

            bean = (E) reader.readObject(c);

            if (reader.getStatus() != ResponseStatus.OK)
            {
                throw new Exception("Error ResponseStatus: " + reader.getStatus() + " server: " + session.getServerId()
                        + " taskName: " + taskName);
            }
        }
        catch (RemoteException re)
        {
            if (re.getErrorCode() == TaskError.NOT_FOUND_ERROR)
            {
            }
            else
            {
                throw new Exception(re);
            }
        }
        catch (Exception e)
        {
            throw new Exception(e);
        }
        finally
        {
            replicaConnectionManager.releaseSession(session);
        }

        return (E) bean;
    }*/
    
    /**
     * executa task update
     * 
     * @param taskName
     * @param obj
     */
    /*public void execUpdtTask(String taskName, Object obj)
            throws Exception
    {
        Session session = replicaConnectionManager.getSession();
        ResponseReader reader = null;

        try
        {
            logger.debug("Task call: " + taskName + " (" + obj + ") server: " + session.getServerId());

            reader = session.execute(taskName, obj);
            reader.setIgnoreUnknownAttributes(true);

            if (reader.getStatus() != ResponseStatus.OK)
            {
                throw new Exception("Error ResponseStatus: " + reader.getStatus() + " server: " + session.getServerId()
                        + " taskName: " + taskName);
            }
        }
        catch (RemoteException re)
        {
            if (re.getErrorCode() == TaskError.NOT_FOUND_ERROR)
            {

            }
            else
            {
                throw new Exception(re);
            }
        }
        catch (Exception e)
        {
            throw new Exception(e);
        }
        finally
        {
            replicaConnectionManager.releaseSession(session);
        }
    }*/
    /**
     * Abre uma sessão o taipei-tasks e define no objeto. Deve ser chimport uol.guaruja.client.network.Session;
import uol.guaruja.protocol.ResponseStatus;amado antes de se executar uma task.
     * 
     * @param loadBalancerURL
     * @param bindHost
     * @return
     */
    /*public  void openConnection(final GuarujaHttpConnectionManager connectionManager)
    {
        logger.debug("Initializing ConnectionManager... LB");

        if (replicaConnectionManager != null)
        {
            Session session=null;
            try
            {
                session = replicaConnectionManager.getSession();
            }
            catch (LoadBalancerException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

            if (session != null)
            {
                replicaConnectionManager.releaseSession(session);
            }
            else
            {
                replicaConnectionManager = connectionManager;
            }
        }
        else
        {
            replicaConnectionManager = connectionManager;
        }
    }*/

    /**
     * 
     * @throws Exception
     */
    /*public void closeConnection() throws Exception
    {
        if (replicaConnectionManager != null)
        {
            replicaConnectionManager.close();
        }
    }*/
}
