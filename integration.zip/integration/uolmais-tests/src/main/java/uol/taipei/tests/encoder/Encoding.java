/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         05/09/2014 Criacao inicial
 */

package uol.taipei.tests.encoder;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uol.taipei.tests.LoginCookie;
import uol.taipei.tests.publish.ApiPublish;

public class Encoding extends ApiPublish
{
    static final Logger logger = LoggerFactory.getLogger(Encoding.class);

    public static void main(String[] args)
    {
        if (!verifyParams(args))
        {
            return;
        }

        setUp(args[0]);

        if (envConfig().getUser() == null || envConfig().getUser().equals("") || envConfig().getPass() == null || envConfig().getPass().equals(""))
        {
            System.err.println("Invalid user " + envConfig().getUser());
            return;
        }

        logger.debug("-------------------------------------------------");
        logger.debug("tests encoding");

        try
        {
            Encoding encoding = new Encoding();
            LoginCookie login = new LoginCookie(envConfig().getUser(), envConfig().getPass());

            encoding.encodeVideo(login, true);
            encoding.encodeAudio(login, true);
        }
        catch (Exception e)
        {
            logger.error(e.getMessage());
        }
    }

    public JSONObject encodeVideo(LoginCookie login, boolean verbose)
    {
        try
        {
            JSONObject jsonResponse = publishVideo(login);
            JSONObject result = verifyProcessing(login, jsonResponse, verbose);

            if (result == null)
            {
                logger.error("ERROR");
                return null;
            }

            logger.debug("SUCCESS");

            return result;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return null;
        }
    }

    public JSONObject encodeAudio(LoginCookie login, boolean verbose)
    {
        try
        {
            JSONObject jsonResponse = publishAudio(login);
            JSONObject result = verifyProcessing(login, jsonResponse, verbose);

            if (result == null)
            {
                logger.error("ERROR");
                return null;
            }

            logger.debug("SUCCESS");

            return result;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return null;
        }
    }
}
