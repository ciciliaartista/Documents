/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         25/06/2014 Criacao inicial
 */

package uol.taipei.tests;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.HashMap;

import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import uol.taipei.request.FacileRequest;
import uol.taipei.request.FacileResponse;
import uol.taipei.request.JsonRequest;

public abstract class AbstractTest
{
    static final Logger logger = LoggerFactory.getLogger(AbstractTest.class);

    protected static final String CONFIG_TESTS = "tests.xml";
    protected static final String ENVIRONMENT = "qa";
    private static EnvConfig envConfig = null;

    protected String host;
    protected boolean isSSL = false;

    /**
     * executar antes dos testes
     * @param env stg, qa ou prod
     */
    protected static void setUp(String env)
    {
        BeanFactory factory = new ClassPathXmlApplicationContext(CONFIG_TESTS);
        TestConfig testConfig = (TestConfig) factory.getBean("testConfig");
        envConfig = testConfig.getConfigByEnv().get(env);
    }

    protected static EnvConfig envConfig()
    {
        return envConfig;
    }

    /**
     * verifica a disponibilidade do um servico, url, probe
     * 
     * @param request
     * @param url
     * @throws IOException
     * @throws JSONException
     */
    protected static void availability(FacileRequest request, String url) throws Exception
    {
        int retry = 0;
        FacileResponse response = request.get(url);

        while (retry < 3 && (response == null || response.getCode() != 200))
        {
            response = request.get(url);
            retry++;
        }

        if (response != null && response.getCode() != 200)
        {
            logger.info(url + " - " + response.getCode());
        }

        if (response == null)
        {
            logger.info(url + " - " + response);
        }
    }

    /**
     * verifica o minimo de parametros
     * 
     * @param params
     * @return boolean
     */
    protected static boolean verifyParams(String[] params)
    {
        if (params.length < 1)
        {
            logger.error("Invalid arguments. <env>");
            return false;
        }

        if (!params[0].equals("stg") && !params[0].equals("qa") && !params[0].equals("prod"))
        {
            logger.error("Invalid arguments. env unknown " + params[0]);
            return false;
        }

        return true;
    }

    /**
     * update de codSataus e codEditorialStatus de midia
     * 
     * @param mediaId
     * @param status
     * @param editorialStatus
     * @throws Exception
     */
    protected void updateContentStatus(long mediaId, int status, int editorialStatus) throws Exception
    {
        FacileRequest request = new FacileRequest();
        JSONObject media = JsonRequest.get("http://mais.uol.com.br/apiuol/v2/media/detail.json?mediaId=" + mediaId);
        boolean isDraft = false;

        if (media.getJSONObject("content").getJSONObject("media").getInt("flgDraft") == 1)
        {
            isDraft = true;
        }

        String url = "http://maxima.mais.sys.intranet/task/runTask?keyXML="
                + URLEncoder.encode(
                    "<uol.taipei.store.domain.Media><idtMedia>"
                            + mediaId
                            + "</idtMedia><codStatus>"
                            + status
                            + "</codStatus>"
                            + (media.getJSONObject("content").getJSONObject("media").has("idtFile") ? "<idtFile>"
                                    + media.getJSONObject("content").getJSONObject("media").getLong("idtFile")
                                    + "</idtFile>" : "") + "<codProfileHash>"
                            + media.getJSONObject("content").getJSONObject("media").getLong("codProfileHash")
                            + "</codProfileHash><numTemporaryServer>"
                            + media.getJSONObject("content").getJSONObject("media").getInt("numTemporaryServer")
                            + "</numTemporaryServer><numRetry>0</numRetry><codEditorialStatus>"
                            + (isDraft ? 1 : editorialStatus)
                            + "</codEditorialStatus><flgFeatured>0</flgFeatured><indMediaType>"
                            + media.getJSONObject("content").getJSONObject("media").getString("indMediaType")
                            + "</indMediaType></uol.taipei.store.domain.Media>", "UTF-8")
                + "&task=UpdateMediaEncoderReplicaTask&bean=uol.taipei.store.domain.Content";

        request.get(url);
    }

    protected class UpdateContentThread extends Thread
    {
        private long mediaId;
        private int status;
        private int editorialStatus;

        public UpdateContentThread(long mediaId, int status, int editorialStatus)
        {
            this.mediaId = mediaId;
            this.status = status;
            this.editorialStatus = editorialStatus;
        }

        public void run()
        {
            try
            {
                updateContentStatus(mediaId, status, editorialStatus);
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
        }
    }

    protected class GibraltarPostThread extends Thread
    {
        private String url = null;
        private HashMap<String, String> params = null;

        public GibraltarPostThread(String url, HashMap<String, String> params)
        {
            this.url = url;
            this.params = params;
        }

        public void run()
        {
            try
            {
                JsonRequest.execGibraltar(url, "POST", null, null, 10000, null, params);
            }
            catch (Exception e)
            {
                logger.warn(e.getMessage());
            }
        }
    }
}
