/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         02/08/2016 Criacao inicial
 */

package uol.taipei.tests.drakkar;

import java.util.Arrays;
import java.util.LinkedList;

import org.apache.http.HttpStatus;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uol.taipei.request.FacileRequest;
import uol.taipei.request.FacileResponse;
import uol.taipei.request.JsonRequest;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.util.JsonUtil;
import uol.taipei.tests.util.RequestUtil;

public class ApiV3Player extends AbstractTest
{
    static final Logger logger = LoggerFactory.getLogger(ApiV3Player.class);

    public static void main(String[] args)
    {
        if (!verifyParams(args))
        {
            return;
        }

        setUp(args[0]);

        if (envConfig().getUser() == null || envConfig().getUser().equals("") || envConfig().getPass() == null
                || envConfig().getPass().equals(""))
        {
            System.err.println("Invalid user " + envConfig().getUser());
            return;
        }

        logger.debug("-------------------------------------------------");
        logger.debug("tests api v3 player");

        try
        {
            ApiV3Player apiPlayer = new ApiV3Player(false);
            FacileRequest request = new FacileRequest();

            if (apiPlayer.isSSL)
            {
                request.configureSSL();
            }

            String mediaId = RequestUtil.mediaIdPublic("V");

            apiPlayer.player(mediaId, request);
            apiPlayer.viewNotify(mediaId, request);

            mediaId = RequestUtil.mediaIdPublic("P");

            apiPlayer.player(mediaId, request);
            apiPlayer.viewNotify(mediaId, request);
        }
        catch (Exception e)
        {
            logger.error(e.getMessage());
        }
    }

    /**
     * construtor
     * 
     * @param isSSL define http ou https
     */
    public ApiV3Player(boolean isSSL)
    {
        this.isSSL = isSSL;
        this.host = "http" + (isSSL ? "s" : "") + "://" + envConfig().getGlobal().getUrlapi();
    }

    /**
     * construtor
     * 
     * @param url dominio para executar testes
     */
    public ApiV3Player(String url)
    {
        this.host = url;
    }

    public JSONObject viewNotify(String mediaId, FacileRequest request) throws Exception
    {
        String url = host + "/apiuol/v3/media/view/notify/" + mediaId;
        JSONObject jsonResponse = null;

        if (isSSL)
        {
            FacileResponse response = request.get(url);
            jsonResponse = response.getJson();
        }
        else
        {
            jsonResponse = JsonRequest.get(url);
        }

        if (jsonResponse == null || jsonResponse.getJSONObject("response").getInt("code") != 200)
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        try
        {
            jsonResponse.getJSONObject("response");
            jsonResponse.getJSONObject("response").getInt("code");
            jsonResponse.getJSONObject("response").getString("description");
            jsonResponse.getJSONObject("response").getString("originalRequest");
        }
        catch (Exception e)
        {
            logger.error("ERROR - return not valid - " + e.getMessage() + " - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject player(String mediaId, FacileRequest request) throws Exception
    {
        String url = host + "/apiuol/v3/player/" + mediaId;
        JSONObject jsonResponse = null;

        if (isSSL)
        {
            FacileResponse response = request.get(url);
            jsonResponse = response.getJson();
        }
        else
        {
            jsonResponse = JsonRequest.get(url);
        }
        
        if (!validateJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse + " - " + url);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    private boolean validateJson(JSONObject jsonResponse) throws JSONException
    {
        try
        {
            if (jsonResponse == null || jsonResponse.getJSONObject("response").getInt("code") != HttpStatus.SC_OK)
            {
                return false;
            }

            jsonResponse.getJSONObject("response");
            jsonResponse.getJSONObject("response").getInt("code");
            jsonResponse.getJSONObject("response").getString("description");
            jsonResponse.getJSONObject("response").getString("originalRequest");

            jsonResponse.getJSONObject("item");
            jsonResponse.getJSONObject("item").getString("title");
            jsonResponse.getJSONObject("item").getLong("mediaId");
            jsonResponse.getJSONObject("item").getString("hash");
            jsonResponse.getJSONObject("item").getString("url");
            jsonResponse.getJSONObject("item").getString("type");
            jsonResponse.getJSONObject("item").getInt("revision");
            jsonResponse.getJSONObject("item").getString("author");
            jsonResponse.getJSONObject("item").getString("codProfile");
            jsonResponse.getJSONObject("item").getString("userIp");
            jsonResponse.getJSONObject("item").getString("shareUrl");

            jsonResponse.getJSONObject("item").getJSONObject("duration");
            jsonResponse.getJSONObject("item").getJSONObject("duration").getInt("seconds");
            jsonResponse.getJSONObject("item").getJSONObject("duration").getString("formatted");

            if (jsonResponse.getJSONObject("item").getString("type").equals("P"))
            {
                jsonResponse.getJSONObject("item").getString("audioUrl");
            }

            if (jsonResponse.getJSONObject("item").getString("type").equals("V"))
            {
                jsonResponse.getJSONObject("item").isNull("audioUrl");

                jsonResponse.getJSONObject("item").getString("thumbnail");
                jsonResponse.getJSONObject("item").getInt("generatedThumbs");
                jsonResponse.getJSONObject("item").getString("tags");

                jsonResponse.getJSONObject("item").getJSONObject("playerParameters");
                jsonResponse.getJSONObject("item").getJSONObject("playerParameters").getString("dfp_native_timeout_on");
                jsonResponse.getJSONObject("item").getJSONObject("playerParameters").getString("dfp_custom_timeout_buffer_time");
                jsonResponse.getJSONObject("item").getJSONObject("playerParameters").getString("range_request");
                jsonResponse.getJSONObject("item").getJSONObject("playerParameters").getString("dfp_native_timeout_time");
                jsonResponse.getJSONObject("item").getJSONObject("playerParameters").getString("dfp_custom_timeout_request_time");
                jsonResponse.getJSONObject("item").getJSONObject("playerParameters").getString("dfp_custom_timeout_on");
    
                if (!jsonResponse.getJSONObject("item").getJSONObject("playerParameters").isNull("iu"))
                {
                    jsonResponse.getJSONObject("item").getJSONObject("playerParameters").getString("iu");
                }
    
                jsonResponse.getJSONObject("item").getJSONObject("formats");
    
                for (int j = 0; j < jsonResponse.getJSONObject("item").getJSONObject("formats").names().length(); j++)
                {
                    String formatName = jsonResponse.getJSONObject("item").getJSONObject("formats").names().getString(j);
    
                    if (!FORMATS_NAME.contains(formatName))
                    {
                        logger.error("ERROR - json is not valid - " + formatName + " - " + jsonResponse);
    
                        return false;
                    }
    
                    jsonResponse.getJSONObject("item").getJSONObject("formats").getJSONObject(formatName).getString("url");
                    jsonResponse.getJSONObject("item").getJSONObject("formats").getJSONObject(formatName).getString(
                        "filename");
                }
            }

            JsonUtil.validateValueJson(jsonResponse.getJSONObject("item"), new String[] { "title" });

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - json is not valid - " + e.getMessage() + " - " + jsonResponse);
            return false;
        }
    }

    private static final LinkedList<String> FORMATS_NAME = new LinkedList<>(Arrays.asList(new String[] { "3gp-240p",
                                                                                                        "3gp-144p",
                                                                                                        "1080p",
                                                                                                        "360p",
                                                                                                        "480p",
                                                                                                        "720p",
                                                                                                        "mobile",
                                                                                                        "HLS" }));
}
