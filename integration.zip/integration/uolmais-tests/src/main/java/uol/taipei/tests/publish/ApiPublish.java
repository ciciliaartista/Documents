/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         21/04/2014 Criacao inicial
 */

package uol.taipei.tests.publish;

import java.io.File;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.http.HttpStatus;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uol.taipei.request.FacileRequest;
import uol.taipei.request.FacileResponse;
import uol.taipei.request.JsonRequest;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.LoginCookie;
import uol.taipei.tests.LoginRadius;
import uol.taipei.tests.moderation.MediaAdm;
import uol.taipei.tests.util.JsonUtil;
import uol.taipei.tests.util.RequestUtil;
import uol.taipei.tests.util.TestUtil;
import uol.taipei.util.DateUtil;
import uol.taipei.util.StringUtil;

public class ApiPublish extends AbstractTest
{
    static final Logger logger = LoggerFactory.getLogger(ApiPublish.class);

    private static final Map<String, String> TYPES = new HashMap<String, String>();

    static
    {
        TYPES.put("P", "audio");
        TYPES.put("V", "video");
    }

    private static final Map<String, String> EXT = new HashMap<String, String>();

    static
    {
        EXT.put("V", ".mp4");
        EXT.put("P", ".mp3");
    }

    public static void main(String[] args)
    {
        if (!verifyParams(args))
        {
            return;
        }

        setUp(args[0]);

        if (envConfig().getUser() == null || envConfig().getUser().equals("") || envConfig().getPass() == null || envConfig().getPass().equals(""))
        {
            System.err.println("Invalid user " + envConfig().getUser());
            return;
        }

        logger.debug("-------------------------------------------------");
        logger.debug("tests api publish");

        try
        {
            ApiPublish apiPublish = new ApiPublish();
            LoginCookie login = new LoginCookie(envConfig().getUser(), envConfig().getPass());

            FacileRequest request = new FacileRequest();

            apiPublish.publishErr(login);
            apiPublish.noLoggedUpVidRedir();
            apiPublish.noLoggedUpPodRedir();
            apiPublish.notPublishVideoNoLogged(request);
            apiPublish.notPublishAudioNoLogged(request);
            apiPublish.publishVideo(login);
            apiPublish.publishThumb(login);
            apiPublish.publishAudio(login);
            apiPublish.authorTags(login);
            apiPublish.adminPage(login);
            apiPublish.statusAudio(login);

            String mediaId = RequestUtil.mediaId("V", login.getJsonProfile().getJSONObject("item").getLong("codProfileHash"));

            apiPublish.statusErrInvalidOwner(login);
            apiPublish.updateErrInvalidOwner(login);
            apiPublish.statusVideo(login, mediaId);
            apiPublish.update(login, mediaId);
            apiPublish.updateData(login, mediaId);
            apiPublish.updateCharset(login, mediaId);
            apiPublish.updateSpecialCharacters(login, mediaId);
            apiPublish.updateVisible(login, mediaId);
            apiPublish.updateHot(login, mediaId);
            apiPublish.updateCountry(login, mediaId);
            apiPublish.updateProduct(login, mediaId);
            apiPublish.updateInfos(login, mediaId);
            apiPublish.updateAuthorizeList(login, mediaId);
            apiPublish.updateSubscriber(login, mediaId);
            apiPublish.updateEmbed(login, mediaId);
            apiPublish.defaultConfig(login);
            apiPublish.presetVideo(login);
            apiPublish.remove(login, mediaId);

            apiPublish.updateContentStatus(Long.valueOf(mediaId), 10, 2);
        }
        catch (Exception e)
        {
            logger.error(e.getMessage());
        }
    }

    public JSONObject publishThumb(LoginCookie login)
    {
        HashMap<String, String> params = new HashMap<String, String>();
        final String[] extFoto = new String[] { "jpg", "JPG", "jpeg", "JPEG", "bmp", "BMP", "gif", "GIF", "png", "PNG" };

        try
        {
            String pathfileTest = System.getenv("PATH_FILE_TEST") + java.io.File.separator;
            java.io.File file;

            List<java.io.File> fileList = TestUtil.files(pathfileTest, "B");
            
            if (!fileList.isEmpty() && fileList.size() > 0)
            {
                java.io.File jsonFile = fileList.get((new Random()).nextInt(fileList.size()));
                String mediaId = jsonFile.getName().substring(0, jsonFile.getName().indexOf("."));

                int i = 0;
                do
                {
                    file = new java.io.File(pathfileTest + mediaId + "." + extFoto[i]);
                    i++;
                }
                while ((file == null || !file.exists()) && i < extFoto.length);
            }
            else
            {
                file = new java.io.File(pathfileTest + "foto.jpg");
            }

            if (file == null || !file.exists())
            {
                logger.error("ERROR - file not found - " + (file != null ? file.getAbsolutePath() : null));
                return null;
            }

            String base64ImgString = (new Base64()).encodeToString(FileUtils.readFileToByteArray(file));
            params.put("media.thumbnail", base64ImgString);

            JSONObject media = JsonUtil.mediaNoRestrictByParam("types=V&edFilter=editorial&codProfile="
                    + login.getJsonProfile().getJSONObject("item").getString("codProfile"));

            if (media == null)
            {
                media = JsonUtil.mediaNoRestrictByParam("types=V&edFilter=editorial");
            }

            if (media == null)
            {
                logger.warn("WARN - no video editorial");
                return null;
            }

            String mediaId = String.valueOf(media.getLong("mediaId"));
            params.put("media.idtMedia", mediaId);

            login.isAuthenticated();
            JSONObject jsonResponse = login.postdatajson("http://beta.mais.uol.com.br/apiuol/selectThumb?variant=json", params);

            if (!validateMessageJson(jsonResponse, 'S'))
            {
                logger.error("ERROR - return not valid - mediaId " + mediaId + " - " + jsonResponse);
                return null;
            }

            logger.debug("SUCCESS");

            return jsonResponse;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return null;
        }
    }

    public JSONObject publishErr(LoginCookie login)
    {
        try
        {
            HashMap<String, String> params = new HashMap<String, String>();
            login.isAuthenticated();

            JSONObject jsonResponse = login.postjson("http://beta.mais.uol.com.br/apiuol/publish/video?variant=json", params, null);

            if (!validateMessageJson(jsonResponse, 'E'))
            {
                logger.error("ERROR - return not valid - " + jsonResponse);
                return null;
            }

            logger.debug("SUCCESS");

            return jsonResponse;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return null;
        }
    }

    /**
     * request nao autenticado para tela de upload de video redireciona para login/acesso
     * 
     * @return boolean
     * @throws Exception
     */

    public boolean noLoggedUpVidRedir() throws Exception
    {
        FacileRequest request = new FacileRequest();
        String url = "http://beta.mais.uol.com.br/sys/publish/video";
        FacileResponse response = request.get(url);

        if (response.getCode() != 302)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        if (!request.getConn().getHeaderField("Location").matches("https://acesso\\.uol\\.com\\.br/login\\.html\\?skin=uolmais&dest=REDIR\\|http://beta\\.mais\\.uol\\.com\\.br/sys/publish/video(.*)"))
        {
            logger.error("ERROR - return not valid - " + request.getConn().getHeaderField("Location"));
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    /**
     * request nao autenticado para tela de upload de audio redireciona para login/acesso
     * 
     * @return boolean
     * @throws Exception
     */

    public boolean noLoggedUpPodRedir() throws Exception
    {
        FacileRequest request = new FacileRequest();
        String url = "http://beta.mais.uol.com.br/sys/publish/audio";
        FacileResponse response = request.get(url);

        if (response.getCode() != 302)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        if (!request.getConn().getHeaderField("Location").matches("https://acesso\\.uol\\.com\\.br/login\\.html\\?skin=uolmais&dest=REDIR\\|http://beta\\.mais\\.uol\\.com\\.br/sys/publish/audio(.*)"))
        {
            logger.error("ERROR - return not valid - " + request.getConn().getHeaderField("Location"));
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public JSONObject publishVideo(LoginCookie login)
    {
        try
        {
            HashMap<String, String> params = prepareParams("V");
            java.io.File file = new java.io.File(params.get("_fileName"));

            if (file == null || !file.exists())
            {
                logger.error("ERROR - file not found - " + (file != null ? file.getAbsolutePath() : null));
                return null;
            }

            login.isAuthenticated();

            JSONObject jsonResponse = login.postjson("http://beta.mais.uol.com.br/apiuol/publish/video?variant=json", params, file);

            if (!validateJson(jsonResponse, false, true))
            {
                logger.error("ERROR - return not valid - " + jsonResponse);
                return null;
            }

            logger.debug("SUCCESS");

            return jsonResponse;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return null;
        }
    }

    public JSONObject publishAudio(LoginCookie login)
    {
        try
        {
            HashMap<String, String> params = prepareParams("P");
            java.io.File file = new java.io.File(params.get("_fileName"));

            if (file == null || !file.exists())
            {
                logger.error("ERROR - file not found - " + (file != null ? file.getAbsolutePath() : null));
                return null;
            }

            login.isAuthenticated();

            JSONObject jsonResponse = login.postjson("http://beta.mais.uol.com.br/apiuol/publish/audio?variant=json", params, file);

            if (!validateJson(jsonResponse, false, true))
            {
                logger.error("ERROR - return not valid - " + jsonResponse);
                return null;
            }

            logger.debug("SUCCESS");

            return jsonResponse;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return null;
        }
    }

    public boolean notPublishVideoNoLogged(FacileRequest request)
    {
        try
        {
            HashMap<String, String> params = prepareParams("V");
            java.io.File file = new java.io.File(params.get("_fileName"));

            if (file == null || !file.exists())
            {
                logger.error("ERROR - file not found - " + (file != null ? file.getAbsolutePath() : null));
                return false;
            }

            FacileResponse response = request.post("http://beta.mais.uol.com.br/apiuol/publish/video?variant=json", null, params, file, false);

            if (response.getCode() == 200)
            {
                logger.error("ERROR - return not valid - " + response.getBody());
                return false;
            }

            logger.debug("SUCCESS");

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return false;
        }
    }

    public boolean notPublishAudioNoLogged(FacileRequest request)
    {
        try
        {
            HashMap<String, String> params = prepareParams("P");
            java.io.File file = new java.io.File(params.get("_fileName"));

            if (file == null || !file.exists())
            {
                logger.error("ERROR - file not found - " + (file != null ? file.getAbsolutePath() : null));
                return false;
            }

            FacileResponse response = request.post("http://beta.mais.uol.com.br/apiuol/publish/audio?variant=json", null, params, file, false);

            if (response.getCode() == 200)
            {
                logger.error("ERROR - return not valid - " + response.getBody());
                return false;
            }

            logger.debug("SUCCESS");

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return false;
        }
    }

    public JSONObject adminPage(LoginCookie login)
    {
        try
        {
            login.isAuthenticated();

            JSONObject jsonResponse = login.getjson("http://beta.mais.uol.com.br/sys/adminPage/status?variant=json");

            if (!validatePageJson(jsonResponse))
            {
                logger.error("ERROR - return not valid - " + jsonResponse);
                return null;
            }

            logger.debug("SUCCESS");

            return jsonResponse;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return null;
        }
    }

    public JSONObject authorTags(LoginCookie login) throws Exception
    {
        login.isAuthenticated();
        JSONObject jsonResponse = login.getjson("http://beta.mais.uol.com.br/sys/tags/author.json?index.itemsPerPage=20");

        if (!validateTagsJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public boolean statusErrInvalidOwner(LoginCookie login) throws Exception
    {
        login.isAuthenticated();
        JSONObject media = mediaDifferentOwner(login.getJsonProfile().getJSONObject("item").getLong("codProfileHash"));
        JSONObject jsonResponse = login.getjson("http://beta.mais.uol.com.br/sys/media/status?variant=json&mediaId=" + media.getString("idt_media"));

        if (jsonResponse.getJSONObject("_response").getInt("code") == 200)
        {
            logger.error("ERROR - return not valid - " + media + " - " + jsonResponse);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean updateErrInvalidOwner(LoginCookie login) throws Exception
    {
        login.isAuthenticated();
        JSONObject media = mediaDifferentOwner(login.getJsonProfile().getJSONObject("item").getLong("codProfileHash"));
        HashMap<String, String> params = new HashMap<String, String>();
        params.put("media.namSubject", "media alterada " + DateUtil.getDateString(new Date(), "yyyy-MM-dd_HH-mm-ss"));
        JSONObject jsonResponse = login.postdatajson("http://beta.mais.uol.com.br/apiuol/media/update?variant=json&mediaId="
                + media.getString("idt_media"), params);

        if (jsonResponse.getJSONObject("_response").getInt("code") == 200)
        {
            logger.error("ERROR - return not valid - " + media + " - " + jsonResponse);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public JSONObject statusVideo(LoginCookie login, String mediaId) throws Exception
    {
        login.isAuthenticated();
        JSONObject jsonResponse = login.getjson("http://beta.mais.uol.com.br/sys/media/status?variant=json&mediaId=" + mediaId);

        if (!validateJson(jsonResponse, true, true))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        if (!"V".equals(jsonResponse.getJSONObject("media").getString("mediaType")))
        {
            logger.error("ERROR - mediaType not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject statusAudio(LoginCookie login) throws Exception
    {
        login.isAuthenticated();
        String mediaId = RequestUtil.mediaId("P", login.getJsonProfile().getJSONObject("item").getLong("codProfileHash"));
        JSONObject jsonResponse = login.getjson("http://beta.mais.uol.com.br/sys/media/status?variant=json&mediaId=" + mediaId);

        if (!validateJson(jsonResponse, true, true))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        if (!"P".equals(jsonResponse.getJSONObject("media").getString("mediaType")))
        {
            logger.error("ERROR - mediaType not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject update(LoginCookie login, String mediaId)
    {
        try
        {
            login.isAuthenticated();

            JSONObject mediaStatus = login.getjson("http://beta.mais.uol.com.br/sys/media/status?variant=json&mediaId=" + mediaId);

            HashMap<String, String> params = new HashMap<String, String>();
            params.put("media.namSubject", "media alterada " + DateUtil.getDateString(new Date(), "yyyy-MM-dd_HH-mm-ss"));

            JSONObject jsonResponse = login.postdatajson("http://beta.mais.uol.com.br/apiuol/media/update?variant=json&mediaId="
                    + mediaId, params);

            if (!validateJson(jsonResponse, false, false))
            {
                logger.error("ERROR - return not valid - mediaId " + mediaId + " - " + jsonResponse);
                return null;
            }

            if (mediaStatus.getJSONObject("media").getString("title").equals(jsonResponse.getJSONObject("media").getString("title")))
            {
                logger.error("ERROR - return not valid - data was not updated - " + mediaStatus + " " + jsonResponse);
                return null;
            }

            logger.debug("SUCCESS");

            // volta dados originais
            backData(login, "http://beta.mais.uol.com.br/apiuol/media/update?variant=json&mediaId="+ mediaId, params, mediaStatus);

            return jsonResponse;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return null;
        }
    }

    public JSONObject updateData(LoginCookie login, String mediaId)
    {
        try
        {
            login.isAuthenticated();

            JSONObject mediaStatus = login.getjson("http://beta.mais.uol.com.br/sys/media/status?variant=json&mediaId=" + mediaId);
            int retry = 0;
            HashMap<String, String> params = new HashMap<String, String>();
            params.put("media.namSubject", "media alterada " + DateUtil.getDateString(new Date(), "yyyy-MM-dd_HH-mm-ss"));
            params.put("media.desMedia", "media alterada " + TestUtil.generateUniqueString());
            params.put("media.tags", "tag" + new Random().nextInt(100));

            if ("V".equals(mediaStatus.getJSONObject("media").getString("mediaType")))
            {
                // editorial
                params.put("media.idtTagService", "1010");
            }

            JSONObject jsonResponse = login.postdatajson("http://beta.mais.uol.com.br/apiuol/media/update?variant=json&mediaId="
                    + mediaId, params);

            if (!validateJson(jsonResponse, false, false))
            {
                logger.error("ERROR - return not valid - mediaId " + mediaId + " - " + jsonResponse);
                return null;
            }

            JSONObject mediaUpdate = login.getjson("http://beta.mais.uol.com.br/sys/media/status?variant=json&mediaId=" + mediaId);

            // para dectar demora na replicacao de banco
            while (!jsonResponse.getJSONObject("media").getString("title").equals(mediaUpdate.getJSONObject("media").getString("title"))
                    || !params.get("media.namSubject").equals(mediaUpdate.getJSONObject("media").getString("title")) && retry < envConfig().getGlobal().getRetry())
            {
                logger.warn("retry status after 1s - media " + mediaId);

                TestUtil.delay(2000);
                mediaUpdate = login.getjson("http://beta.mais.uol.com.br/sys/media/status?variant=json&mediaId=" + mediaId);
                retry++;
            }

            if (!jsonResponse.getJSONObject("media").getString("title").equals(mediaUpdate.getJSONObject("media").getString("title"))
                    || !params.get("media.namSubject").equals(mediaUpdate.getJSONObject("media").getString("title")))
            {
                logger.error("ERROR - return not valid - data title was not updated - " + mediaStatus + " " + mediaUpdate);
                return null;
            }

            if (!jsonResponse.getJSONObject("media").getString("description")
                    .equals(mediaUpdate.getJSONObject("media").getString("description"))
                    || !params.get("media.desMedia").equals(mediaUpdate.getJSONObject("media").getString("description")))
            {
                logger.error("ERROR - return not valid - data description was not updated - " + mediaStatus + " " + mediaUpdate);
                return null;
            }

            for (String tag : params.get("media.tags").split(","))
            {
                if (!ArrayUtils.contains(jsonResponse.getJSONObject("media").getString("tags").split(","), tag.trim()))
                {
                    logger.error("ERROR - return not valid - data tags was not updated - " + mediaStatus + " " + mediaUpdate);
                    return null;
                }
            }

            if ("V".equals(mediaStatus.getJSONObject("media").getString("mediaType")))
            {
                // editorial
                if (!jsonResponse.getJSONObject("media").getString("idtTagService")
                        .equals(mediaUpdate.getJSONObject("media").getString("idtTagService"))
                        || !params.get("media.idtTagService").equals(mediaUpdate.getJSONObject("media").getString("idtTagService")))
                {
                    logger.error("ERROR - return not valid - data idtTagService was not updated - " + mediaStatus + " " + mediaUpdate);
                    return null;
                }
            }

            logger.debug("SUCCESS");

            // volta dados originais
            backData(login, "http://beta.mais.uol.com.br/apiuol/media/update?variant=json&mediaId="+ mediaId, params, mediaStatus);

            return jsonResponse;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return null;
        }
    }

    public JSONObject updateCharset(LoginCookie login, String mediaId)
    {
        try
        {
            login.isAuthenticated();

            int retry = 0;
            JSONObject mediaStatus = login.getjson("http://beta.mais.uol.com.br/sys/media/status?variant=json&mediaId=" + mediaId);
            HashMap<String, String> params = new HashMap<String, String>();
            params.put("media.namSubject",
                "\u00E0c\u00E9nt\u00FC\u00E1\u00E7\u00e3\u00F4 " + DateUtil.getDateString(new Date(), "yyyy-MM-dd_HH-mm-ss"));
            params.put("media.desMedia", "media alterada " + "\u00C0\u00E0\u00C8\u00E8\u00CC\u00EC\u00D2\u00F2\u00D9\u00F9" // grave
                    + "\u00E1\u00C9\u00E9\u00ED\u00D3\u00F3\u00DA\u00FA\u00FD" // acute
                    + "\u00C2\u00E2\u00CA\u00EA\u00EE\u00D4\u00F4\u00DB\u00FB" // circumflex
                    + "\u00c3\u00e3\u00d5\u00f5\u00d1\u00f1" // tilde
                    + "\u00C4\u00E4\u00CB\u00EB\u00EF\u00D6\u00F6\u00DC\u00FC\u00FF" // umlaut
                    + "\u00C7\u00E7" // cedilla
            );

            params.put("media.tags", "t\u00E1g");

            if ("V".equals(mediaStatus.getJSONObject("media").getString("mediaType")))
            {
                params.put("media.idtTagService", "1010");
            }

            JSONObject jsonResponse = login.postdatajson("http://beta.mais.uol.com.br/apiuol/media/update?variant=json&mediaId="
                    + mediaId, params);

            if (!validateJson(jsonResponse, false, false))
            {
                logger.error("ERROR - return not valid - mediaId " + mediaId + " - " + jsonResponse);
                return null;
            }

            JSONObject mediaUpdate = login.getjson("http://beta.mais.uol.com.br/sys/media/status?variant=json&mediaId=" + mediaId);

            // para dectar demora na replicacao de banco
            while ((!jsonResponse.getJSONObject("media").getString("title").equals(mediaUpdate.getJSONObject("media").getString("title"))
                    || !(params.get("media.namSubject").equals(StringUtil.toUTF8(mediaUpdate.getJSONObject("media").getString("title"))) 
                    || params.get("media.namSubject").equals(mediaUpdate.getJSONObject("media").getString("title")))) && retry < envConfig().getGlobal().getRetry())
            {
                logger.warn("retry status after 1s - media " + mediaId);

                TestUtil.delay(2000);
                mediaUpdate = login.getjson("http://beta.mais.uol.com.br/sys/media/status?variant=json&mediaId=" + mediaId);
                retry++;
            }

            if (!jsonResponse.getJSONObject("media").getString("title").equals(mediaUpdate.getJSONObject("media").getString("title"))
                    || !(params.get("media.namSubject").equals(StringUtil.toUTF8(mediaUpdate.getJSONObject("media").getString("title"))) 
                    || params.get("media.namSubject").equals(mediaUpdate.getJSONObject("media").getString("title"))))
            {
                logger.error("ERROR - return not valid - data title was not updated - " + params.get("media.namSubject") + " "
                        + mediaUpdate);
                return null;
            }

            if (!jsonResponse.getJSONObject("media").getString("description").equals(mediaUpdate.getJSONObject("media").getString("description"))
                    || !(params.get("media.desMedia").equals(StringUtil.toUTF8(mediaUpdate.getJSONObject("media").getString("description"))) 
                    || params.get("media.desMedia").equals(mediaUpdate.getJSONObject("media").getString("description"))))
            {
                logger.error("ERROR - return not valid - data description was not updated - " + params.get("media.desMedia") + " "
                        + mediaUpdate);
                return null;
            }

            for (int i = 0; i < params.get("media.desMedia").length(); i++)
            {
                if (params.get("media.desMedia").codePointAt(i) != mediaUpdate.getJSONObject("media").getString("description").codePointAt(i))
                {
                    logger.error("ERROR - return not valid - data description was not updated - " + params.get("media.desMedia") + " " + mediaUpdate);
                    return null;
                }
            }

            for (String tag : params.get("media.tags").split(","))
            {
                if (!(ArrayUtils.contains(jsonResponse.getJSONObject("media").getString("tags").split(","), StringUtil.toISO88591(tag).trim()) 
                        || ArrayUtils.contains(jsonResponse.getJSONObject("media").getString("tags").split(","), tag.trim())))
                {
                    logger.error("ERROR - return not valid - data tags was not updated - " + tag + " " + mediaUpdate);
                    return null;
                }
            }

            logger.debug("SUCCESS");

            return jsonResponse;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return null;
        }
    }

    public JSONObject updateSpecialCharacters(LoginCookie login, String mediaId)
    {
        try
        {
            login.isAuthenticated();

            int retry = 0;
            JSONObject mediaStatus = login.getjson("http://beta.mais.uol.com.br/sys/media/status?variant=json&mediaId=" + mediaId);
            // < > sao removidos
            HashMap<String, String> params = new HashMap<String, String>();
            params.put("media.namSubject",
                "$ # @ - _ + = ^ ~ ! ? { [ ] } ( ) , . \" / \\ " + DateUtil.getDateString(new Date(), "yyyy-MM-dd_HH-mm-ss"));
            params.put("media.desMedia", "$ # @ - _ + = ^ ~ ! ? { [ ] } ( ) , . \" / \\ " + TestUtil.generateUniqueString());

            JSONObject jsonResponse = login.postdatajson("http://beta.mais.uol.com.br/apiuol/media/update?variant=json&mediaId="
                    + mediaId, params);

            if (!validateJson(jsonResponse, false, false))
            {
                logger.error("ERROR - return not valid - mediaId " + mediaId + " - " + jsonResponse);
                return null;
            }

            JSONObject mediaUpdate = login.getjson("http://beta.mais.uol.com.br/sys/media/status?variant=json&mediaId=" + mediaId);

            // para dectar demora na replicacao de banco
            while (!jsonResponse.getJSONObject("media").getString("title").equals(mediaUpdate.getJSONObject("media").getString("title")) && retry < envConfig().getGlobal().getRetry())
            {
                logger.warn("retry status after 1s - media " + mediaId);

                TestUtil.delay(2000);
                mediaUpdate = login.getjson("http://beta.mais.uol.com.br/sys/media/status?variant=json&mediaId=" + mediaId);
                retry++;
            }

            if (!jsonResponse.getJSONObject("media").getString("title").equals(mediaUpdate.getJSONObject("media").getString("title")))
            {
                logger.error("ERROR - return not valid - data title was not updated - " + mediaStatus + " " + mediaUpdate);
                return null;
            }

            if (!jsonResponse.getJSONObject("media").getString("description").equals(mediaUpdate.getJSONObject("media").getString("description")))
            {
                logger.error("ERROR - return not valid - data description was not updated - " + mediaStatus + " " + mediaUpdate);
                return null;
            }

            mediaUpdate = login.getjson("http://beta.mais.uol.com.br/sys/media/status.json?variant=json&mediaId=" + mediaId);

            if (!params.get("media.namSubject").equals(mediaUpdate.getJSONObject("content").getJSONObject("media").getString("namSubject")))
            {
                logger.error("ERROR - return not valid - data title was not updated - " + params.get("media.namSubject") + " "
                        + mediaUpdate);
                return null;
            }

            if (!params.get("media.desMedia").equals(mediaUpdate.getJSONObject("content").getJSONObject("media").getString("desMedia")))
            {
                logger.error("ERROR - return not valid - data description was not updated - " + params.get("media.desMedia") + " "
                        + mediaUpdate);
                return null;
            }

            logger.debug("SUCCESS");

            return jsonResponse;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return null;
        }
    }

    public JSONObject updateHot(LoginCookie login, String mediaId) throws Exception
    {
        String indHot = null;

        try
        {
            login.isAuthenticated();

            int retry = 0;
            JSONObject mediaStatus = login.getjson("http://beta.mais.uol.com.br/sys/media/status.json?variant=json&mediaId=" + mediaId);
            indHot = mediaStatus.getJSONObject("content").getJSONObject("media").getString("indHot");
            JSONObject jsonResponse = null;
            HashMap<String, String> params = new HashMap<String, String>();
            boolean adultContent = false;
            String[] hot = new String[] { "N", "U", "P" };

            for (String h : hot)
            {
                params.put("media.indHot", h);
                adultContent = ("N".equals(h) ? false : true);
                jsonResponse = login.postdatajson("http://beta.mais.uol.com.br/apiuol/media/update?variant=json&mediaId=" + mediaId,
                    params);

                if (!validateJson(jsonResponse, false, false))
                {
                    logger.error("ERROR - return not valid - mediaId " + mediaId + " - " + jsonResponse);
                    return null;
                }

                JSONObject mediaUpdate = login.getjson("http://beta.mais.uol.com.br/sys/media/status?variant=json&mediaId=" + mediaId);

                // para dectar demora na replicacao de banco
                while (!"P".equals(mediaStatus.getJSONObject("content").getJSONObject("media").getString("indHot"))
                        && (adultContent != mediaUpdate.getJSONObject("media").getBoolean("adultContent") || adultContent != jsonResponse
                        .getJSONObject("media").getBoolean("adultContent")) && retry < envConfig().getGlobal().getRetry())
                {
                    logger.warn("retry status after 1s - media " + mediaId + " " + h);

                    TestUtil.delay(3000);
                    mediaUpdate = login.getjson("http://beta.mais.uol.com.br/sys/media/status?variant=json&mediaId=" + mediaId);
                    retry++;
                }

                if (!"P".equals(mediaStatus.getJSONObject("content").getJSONObject("media").getString("indHot"))
                        && (adultContent != mediaUpdate.getJSONObject("media").getBoolean("adultContent") || adultContent != jsonResponse
                                .getJSONObject("media").getBoolean("adultContent")))
                {
                    logger.error("ERROR - return not valid - data hot was not updated - " + h + " " + adultContent + " " + jsonResponse
                            + " " + mediaUpdate);
                    return null;
                }

                mediaUpdate = login.getjson("http://beta.mais.uol.com.br/sys/media/status.json?variant=json&mediaId=" + mediaId);

                if ("P".equals(mediaStatus.getJSONObject("content").getJSONObject("media").getString("indHot"))
                        && !"N".equals(mediaUpdate.getJSONObject("content").getJSONObject("media").getString("indHot")))
                {
                    logger.error("ERROR - return not valid - data hot permanent could be not updated - " + h + " " + mediaStatus + " "
                            + mediaUpdate);
                    return null;
                }

                if (!params.get("media.indHot").equals(mediaUpdate.getJSONObject("content").getJSONObject("media").getString("indHot"))
                        && !"P".equals(mediaStatus.getJSONObject("content").getJSONObject("media").getString("indHot")))
                {
                    logger.error("ERROR - return not valid - data hot was not updated - " + h + " " + mediaUpdate);
                    return null;
                }
            }

            logger.debug("SUCCESS");

            // volta valor original
            try
            {
                new MediaAdm().updateAdmHot(new LoginRadius(envConfig().getUserRadius(), envConfig().getPassRadius()), Long.valueOf(mediaId), indHot);
            }
            catch (Exception e)
            {
                logger.warn(e.getMessage() + " - can not possible set original data");
            }

            return jsonResponse;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return null;
        }
    }

    public JSONObject updateVisible(LoginCookie login, String mediaId) throws Exception
    {
        int retry = 0;
        String indVisibility = null;
        HashMap<String, String> params = new HashMap<String, String>();
        String[] visibility = new String[] { "T", "N" };

        try
        {
            login.isAuthenticated();

            JSONObject mediaStatus = login.getjson("http://beta.mais.uol.com.br/sys/media/status.json?variant=json&mediaId=" + mediaId);
            indVisibility = mediaStatus.getJSONObject("content").getJSONObject("media").getString("indVisibility");
            JSONObject jsonResponse = null;

            for (String v : visibility)
            {
                params.put("media.indVisibility", v);

                jsonResponse = login.postdatajson("http://beta.mais.uol.com.br/apiuol/media/update?variant=json&mediaId=" + mediaId, params);

                if (!validateJson(jsonResponse, false, false))
                {
                    logger.error("ERROR - return not valid - mediaId " + mediaId + " - " + jsonResponse);
                    return null;
                }

                mediaStatus = login.getjson("http://beta.mais.uol.com.br/sys/media/status.json?variant=json&mediaId=" + mediaId);

                // para dectar demora na replicacao de banco
                while (!v.equals(mediaStatus.getJSONObject("content").getJSONObject("media").getString("indVisibility")) 
                        && retry < envConfig().getGlobal().getRetry())
                {
                    logger.warn("retry status after 1s - media " + mediaId + " " + v);

                    TestUtil.delay(2000);
                    mediaStatus = login.getjson("http://beta.mais.uol.com.br/sys/media/status.json?variant=json&mediaId=" + mediaId);
                    retry++;
                }

                if (!v.equals(mediaStatus.getJSONObject("content").getJSONObject("media").getString("indVisibility")))
                {
                    logger.error("ERROR - return not valid - data visibility was not updated - " + v + " " + mediaStatus);
                    return null;
                }
            }

            logger.debug("SUCCESS");

            // volta dados
            params.put("media.indVisibility", indVisibility);
            login.postdatajson("http://beta.mais.uol.com.br/apiuol/media/update?variant=json&mediaId=" + mediaId, params);
            
            return jsonResponse;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return null;
        }
    }

    public JSONObject updateCountry(LoginCookie login, String mediaId)
    {
        try
        {
            int retry = 0;
            JSONObject jsonResponse = null;
            login.isAuthenticated();

            JSONObject mediaStatus = login.getjson("http://beta.mais.uol.com.br/sys/media/status?variant=json&mediaId=" + mediaId);
            HashMap<String, String> params = new HashMap<String, String>();

            if ("V".equals(mediaStatus.getJSONObject("media").getString("mediaType")))
            {
                for (String country : new String[] { "BR-0", "US-1" })
                {
                    params.put("media.countryList", country);
    
                    jsonResponse = login.postdatajson("http://beta.mais.uol.com.br/apiuol/media/update?variant=json&mediaId=" + mediaId, params);
    
                    if (!validateJson(jsonResponse, false, false))
                    {
                        logger.error("ERROR - return not valid - mediaId " + mediaId + " - " + jsonResponse);
                        return null;
                    }
    
                    JSONObject mediaUpdate = login.getjson("http://beta.mais.uol.com.br/sys/media/status.json?variant=json&mediaId=" + mediaId);

                    // para dectar demora na replicacao de banco
                    while (!country.equals(mediaUpdate.getJSONObject("content").getJSONObject("media").getString("countryList")) && retry < envConfig().getGlobal().getRetry())
                    {
                        logger.warn("retry status after 1s - " + mediaId + " " + country);

                        TestUtil.delay(2000);
                        mediaUpdate = login.getjson("http://beta.mais.uol.com.br/sys/media/status.json?variant=json&mediaId=" + mediaId);
                        retry++;
                    }
    
                    if (!country.equals(mediaUpdate.getJSONObject("content").getJSONObject("media").getString("countryList")))
                    {
                        logger.error("ERROR - return not valid - data country was not updated - " + country + " " + mediaUpdate);
                        return null;
                    }
                }
            }

            logger.debug("SUCCESS");

            return jsonResponse;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return null;
        }
    }

    public JSONObject updateProduct(LoginCookie login, String mediaId)
    {
        try
        {
            int retry = 0;
            JSONObject jsonResponse = null;
            login.isAuthenticated();

            JSONObject mediaStatus = login.getjson("http://beta.mais.uol.com.br/sys/media/status?variant=json&mediaId=" + mediaId);
            HashMap<String, String> params = new HashMap<String, String>();

            if ("V".equals(mediaStatus.getJSONObject("media").getString("mediaType")))
            {
                for (String product : new String[] { "0", "0,1" })
                {   
                    params.put("media.idtProductList", product);

                    jsonResponse = login.postdatajson("http://beta.mais.uol.com.br/apiuol/media/update?variant=json&mediaId=" + mediaId, params);

                    if (!validateJson(jsonResponse, false, false))
                    {
                        logger.error("ERROR - return not valid - mediaId " + mediaId + " - " + jsonResponse);
                        return null;
                    }

                    JSONObject mediaUpdate = login.getjson("http://beta.mais.uol.com.br/sys/media/status.json?variant=json&mediaId="
                            + mediaId);

                    // para dectar demora na replicacao de banco
                    while (!mediaUpdate.getJSONObject("content").has("productList") && retry < envConfig().getGlobal().getRetry())
                    {
                        logger.warn("retry status after 1s - " + mediaId);

                        TestUtil.delay(2000);
                        mediaUpdate = login.getjson("http://beta.mais.uol.com.br/sys/media/status.json?variant=json&mediaId=" + mediaId);
                        retry++;
                    }

                    for (int i = 0; i < mediaUpdate.getJSONObject("content").getJSONArray("productList").length(); i++)
                    {
                        if (!ArrayUtils.contains(product.split(","),
                            String.valueOf(mediaUpdate.getJSONObject("content").getJSONArray("productList").getInt(i))))
                        {
                            logger.error("ERROR - return not valid - data product was not updated - " + product + " " + mediaUpdate);
                            return null;
                        }
                    }
                }
            }

            logger.debug("SUCCESS");

            return jsonResponse;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return null;
        }
    }

    public JSONObject updateInfos(LoginCookie login, String mediaId)
    {
        try
        {
            JSONObject jsonResponse = null;
            login.isAuthenticated();

            JSONObject mediaStatus = login.getjson("http://beta.mais.uol.com.br/sys/media/status?variant=json&mediaId=" + mediaId);
            int retry = 0;
            HashMap<String, String> params = new HashMap<String, String>();

            if ("V".equals(mediaStatus.getJSONObject("media").getString("mediaType")))
            {
                params.put("media.desExtraInformation", "http://mais.uol.com.br/home?extrainfo=" + TestUtil.generateUniqueString());
            }

            params.put("media.infoExternal", TestUtil.generateUniqueString());

            jsonResponse = login.postdatajson("http://beta.mais.uol.com.br/apiuol/media/update?variant=json&mediaId=" + mediaId, params);

            if (!validateJson(jsonResponse, false, false))
            {
                logger.error("ERROR - return not valid - mediaId " + mediaId + " - " + jsonResponse);
                return null;
            }

            JSONObject mediaUpdate = login.getjson("http://beta.mais.uol.com.br/sys/media/status.json?variant=json&mediaId=" + mediaId);

            // para dectar demora na replicacao de banco
            while (!params.get("media.infoExternal").equals(mediaUpdate.getJSONObject("content").getJSONObject("media").getString("infoExternal")) 
                    && retry < envConfig().getGlobal().getRetry())
            {
                logger.warn("retry status after 1s - " + mediaId);

                TestUtil.delay(2000);
                mediaUpdate = login.getjson("http://beta.mais.uol.com.br/sys/media/status.json?variant=json&mediaId=" + mediaId);
                retry++;
            }

            if ("V".equals(mediaStatus.getJSONObject("media").getString("mediaType")))
            {
                if (!params.get("media.desExtraInformation").equals(mediaUpdate.getJSONObject("content").getJSONObject("media").getString("desExtraInformation")))
                {
                    logger.error("ERROR - return not valid - data desExtraInformation was not updated - "
                            + params.get("media.desExtraInformation") + " " + mediaUpdate);
                    return null;
                }
            }

            if (!params.get("media.infoExternal").equals(mediaUpdate.getJSONObject("content").getJSONObject("media").getString("infoExternal")))
            {
                logger.error("ERROR - return not valid - data infoExternal was not updated - " + params.get("media.infoExternal") + " "
                        + mediaUpdate);
                return null;
            }

            logger.debug("SUCCESS");

            return jsonResponse;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return null;
        }
    }

    public JSONObject updateAuthorizeList(LoginCookie login, String mediaId)
    {
        try
        {
            login.isAuthenticated();

            int retry = 0;
            HashMap<String, String> params = new HashMap<String, String>();
            JSONObject jsonResponse = null;
            String[] auth = new String[] { "N", "M", "A", "T", "P" };

            for (String a : auth)
            {
                params.put("media.indAuthorizedLists", a);

                jsonResponse = login.postdatajson("http://beta.mais.uol.com.br/apiuol/media/update?variant=json&mediaId=" + mediaId,
                    params);

                if (!validateJson(jsonResponse, false, false))
                {
                    logger.error("ERROR - return not valid - mediaId " + mediaId + " - " + jsonResponse);
                    return null;
                }

                JSONObject mediaUpdate = login.getjson("http://beta.mais.uol.com.br/sys/media/status.json?variant=json&mediaId=" + mediaId);

                // para dectar demora na replicacao de banco
                while (!a.equals(mediaUpdate.getJSONObject("content").getJSONObject("media").getString("indAuthorizedLists")) && retry < envConfig().getGlobal().getRetry())
                {
                    logger.warn("retry status after 1s - media " + mediaId + " " + a);

                    TestUtil.delay(2000);
                    mediaUpdate = login.getjson("http://beta.mais.uol.com.br/sys/media/status.json?variant=json&mediaId=" + mediaId);
                    retry++;
                }

                if (!a.equals(mediaUpdate.getJSONObject("content").getJSONObject("media").getString("indAuthorizedLists")))
                {
                    logger.error("ERROR - return not valid - data authorizedLists was not updated - " + a + " " + mediaUpdate);
                    return null;
                }
            }

            logger.debug("SUCCESS");

            return jsonResponse;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return null;
        }
    }

    public JSONObject updateSubscriber(LoginCookie login, String mediaId)
    {
        try
        {
            login.isAuthenticated();

            int retry = 0;
            JSONObject jsonResponse = null;
            HashMap<String, String> params = new HashMap<String, String>();
            boolean flgSubscriberMedia = false;

            for (String subscriber : new String[] { "0", "1" })
            {
                flgSubscriberMedia = (subscriber.equals("1") ? true : false);
                params.put("media.flgSubscriberMedia", subscriber);

                jsonResponse = login.postdatajson("http://beta.mais.uol.com.br/apiuol/media/update?variant=json&mediaId=" + mediaId,
                    params);

                if (!validateJson(jsonResponse, false, false))
                {
                    logger.error("ERROR - return not valid - mediaId " + mediaId + " - " + jsonResponse);
                    return null;
                }

                JSONObject mediaUpdate = login.getjson("http://beta.mais.uol.com.br/sys/media/status?variant=json&mediaId=" + mediaId);

                // para dectar demora na replicacao de banco
                while (flgSubscriberMedia != mediaUpdate.getJSONObject("media").getBoolean("subscriberMedia") && retry < envConfig().getGlobal().getRetry())
                {
                    logger.warn("retry status after 1s - " + mediaId + " " + flgSubscriberMedia);

                    TestUtil.delay(3000);
                    mediaUpdate = login.getjson("http://beta.mais.uol.com.br/sys/media/status?variant=json&mediaId=" + mediaId);
                    retry++;
                }

                if (jsonResponse.getJSONObject("media").getBoolean("subscriberMedia") != mediaUpdate.getJSONObject("media").getBoolean("subscriberMedia")
                        || flgSubscriberMedia != mediaUpdate.getJSONObject("media").getBoolean("subscriberMedia"))
                {
                    logger.error("ERROR - return not valid - data subscriberMedia was not updated - " + flgSubscriberMedia + " " + mediaUpdate);
                    return null;
                }
            }

            logger.debug("SUCCESS");

            return jsonResponse;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return null;
        }
    }

    public JSONObject updateEmbed(LoginCookie login, String mediaId)
    {
        try
        {
            login.isAuthenticated();

            JSONObject jsonResponse = null;
            HashMap<String, String> params = new HashMap<String, String>();
            boolean flgBlockEmbed = false;
            int retry =0 ;

            for (String embed : new String[] { "0", "1" })
            {
                flgBlockEmbed = (embed.equals("1") ? true : false);
                params.put("media.flgBlockEmbed", embed);

                jsonResponse = login.postdatajson("http://beta.mais.uol.com.br/apiuol/media/update?variant=json&mediaId=" + mediaId,
                    params);

                if (!validateJson(jsonResponse, false, false))
                {
                    logger.error("ERROR - return not valid - mediaId " + mediaId + " - " + jsonResponse);
                    return null;
                }

                JSONObject mediaUpdate = login.getjson("http://beta.mais.uol.com.br/sys/media/status?variant=json&mediaId=" + mediaId);

                // para dectar demora na replicacao de banco
                while ((!mediaUpdate.has("media") || jsonResponse.getJSONObject("media").getBoolean("blockEmbed") != mediaUpdate.getJSONObject("media").getBoolean("blockEmbed")
                        || flgBlockEmbed != mediaUpdate.getJSONObject("media").getBoolean("blockEmbed")) && retry < envConfig().getGlobal().getRetry())
                {
                    logger.warn("retry status after 1s - media " + mediaId + " " + embed);

                    TestUtil.delay(2000);
                    mediaUpdate = login.getjson("http://beta.mais.uol.com.br/sys/media/status?variant=json&mediaId=" + mediaId);
                    retry++;
                }

                if (jsonResponse.getJSONObject("media").getBoolean("blockEmbed") != mediaUpdate.getJSONObject("media").getBoolean("blockEmbed")
                        || flgBlockEmbed != mediaUpdate.getJSONObject("media").getBoolean("blockEmbed"))
                {
                    logger.error("ERROR - return not valid - data blockEmbed was not updated - " + embed + " " + mediaUpdate);
                    return null;
                }
            }

            logger.debug("SUCCESS");

            return jsonResponse;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return null;
        }
    }

    public JSONObject defaultConfig(LoginCookie login)
    {
        try
        {
            String fileName = System.getenv("PATH_FILE_TEST") + File.separator + "video.mp4";
            java.io.File file = new java.io.File(fileName);

            if (file == null || !file.exists())
            {
                logger.error("ERROR - file not found - " + (file != null ? file.getAbsolutePath() : null));
                return null;
            }

            HashMap<String, String> params = new HashMap<String, String>();
            params.put("media.desMedia", params.get("media.desMedia") + " - config default");

            login.isAuthenticated();

            JSONObject jsonResponse = login.postjson("http://beta.mais.uol.com.br/apiuol/publish/video?variant=json", params, file);

            if (!validateJson(jsonResponse, false, true))
            {
                logger.error("ERROR - return not valid - " + jsonResponse);
                return null;
            }

            JSONObject jsonContent = login.getjson("http://beta.mais.uol.com.br/sys/media/status.json?variant=json&mediaId="
                    + jsonResponse.getJSONObject("media").getString("mediaId"));

            if (jsonContent == null || !jsonContent.has("content") || !jsonContent.getJSONObject("content").has("media"))
            {
                logger.error("ERROR - content not found " + jsonResponse);
                return null;
            }

            if (jsonContent.getJSONObject("content").getJSONObject("media").getLong("idtMedia") != Long.parseLong(jsonResponse
                    .getJSONObject("media").getString("mediaId")))
            {
                logger.error("ERROR - return not match mediaId " + jsonResponse.getJSONObject("media").getString("mediaId") + " - "
                        + jsonContent);
                return null;
            }

            if (!jsonContent.getJSONObject("maker").getJSONObject("mediaConfig").getString("indVisibility")
                    .equals(jsonContent.getJSONObject("content").getJSONObject("media").getString("indVisibility")))
            {
                logger.error("ERROR - return not match indVisibility - " + jsonContent);
                return null;
            }

            if (!jsonContent.getJSONObject("maker").getJSONObject("mediaConfig").getString("indAllowNotes")
                    .equals(jsonContent.getJSONObject("content").getJSONObject("media").getString("indAllowNotes")))
            {
                logger.error("ERROR - return not match indAllowNotes - " + jsonContent);
                return null;
            }

            if (!jsonContent.getJSONObject("maker").getJSONObject("mediaConfig").getString("indHot")
                    .equals(jsonContent.getJSONObject("content").getJSONObject("media").getString("indHot")))
            {
                logger.error("ERROR - return not match indHot " + jsonContent);
                return null;
            }

            if (jsonContent.getJSONObject("maker").getJSONObject("mediaConfig").getInt("flgNotifyComment") != jsonContent
                    .getJSONObject("content").getJSONObject("media").getInt("flgNotifyComment"))
            {
                logger.error("ERROR - return not match flgNotifyComment - " + jsonContent);
                return null;
            }

            if (jsonContent.getJSONObject("content").getJSONObject("media").has("indBlockCountry")
                    && !jsonContent.getJSONObject("maker").getJSONObject("mediaConfig").getString("indBlockCountry")
                            .equals(jsonContent.getJSONObject("content").getJSONObject("media").getString("indBlockCountry")))
            {
                logger.error("ERROR - return not match indBlockCountry - " + jsonContent);
                return null;
            }

            if (jsonContent.getJSONObject("maker").getJSONObject("mediaConfig").getInt("flgBlockEmbed") != jsonContent
                    .getJSONObject("content").getJSONObject("media").getInt("flgBlockEmbed"))
            {
                logger.error("ERROR - return not match flgBlockEmbed - " + jsonContent);
                return null;
            }

            logger.debug("SUCCESS");

            return jsonResponse;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return null;
        }
    }

    public JSONObject presetVideo(LoginCookie login)
    {
        try
        {
            HashMap<String, String> params = new HashMap<String, String>();
            String fileName = System.getenv("PATH_FILE_TEST") + File.separator + "video.mp4";
            java.io.File file = new java.io.File(fileName);

            if (file == null || !file.exists())
            {
                logger.error("ERROR - file not found - " + (file != null ? file.getAbsolutePath() : null));
                return null;
            }

            JSONObject jsonResponse = null;

            for (Integer preset : new Integer[] { 1, 2, 3 })
            {
                params.put("media.desMedia", params.get("media.desMedia") + " - preset " + preset);
                params.put("media.tags", params.get("media.tags") + ",preset");
                params.put("mediaVideo.numEncodedPreset", preset.toString());

                login.isAuthenticated();

                jsonResponse = login.postjson("http://beta.mais.uol.com.br/apiuol/publish/video?variant=json", params, file);

                if (!validateJson(jsonResponse, false, true))
                {
                    logger.error("ERROR - return not valid - preset " + preset + " - " + jsonResponse);
                    return null;
                }

                JSONObject jsonmedia = login.getjson("http://mais.uol.com.br/apiuol/v2/media/detail.json?mediaId="
                        + jsonResponse.getJSONObject("media").getString("mediaId") + "&nocache=" + Math.random());

                if (jsonmedia.has("content")
                        && jsonmedia.getJSONObject("content").getJSONObject("mediaVideo").getInt("numEncodedPreset") != preset.intValue())
                {
                    logger.error("ERROR - preset not - preset was not update - " + preset + " - " + jsonmedia);
                    return null;
                }
            }

            logger.debug("SUCCESS");

            return jsonResponse;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return null;
        }
    }

    public JSONObject remove(LoginCookie login, String mediaId) throws Exception
    {
        login.isAuthenticated();
        JSONObject jsonResponse = login.getjson("http://beta.mais.uol.com.br/sys/media/remove?variant=json&mediaId=" + mediaId);
        int retry = 0;

        if (!validateMessageJson(jsonResponse, 'S'))
        {
            logger.error("ERROR - return not valid - mediaId " + mediaId + " - " + jsonResponse);
            return null;
        }

        JSONObject mediaUpdate = login.getjson("http://beta.mais.uol.com.br/sys/media/status?variant=json&mediaId=" + mediaId);

        // para dectar demora na replicacao de banco
        while ((!mediaUpdate.has("mediaStatus") || !mediaUpdate.getJSONObject("mediaStatus").getString("codStatus").equals("20")) 
                && retry < envConfig().getGlobal().getRetry())
        {
            logger.warn("retry status after 1s - media " + mediaId);

            TestUtil.delay(2000);
            mediaUpdate = login.getjson("http://beta.mais.uol.com.br/sys/media/status?variant=json&mediaId=" + mediaId);
            retry++;
        }

        if (!mediaUpdate.getJSONObject("mediaStatus").getString("codStatus").equals("20"))
        {
            logger.error("ERROR - return not valid - codStatus was not updated - " + mediaUpdate);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    /**
     * media de outro autor/dono
     * 
     * {"idt_media":"207004","ind_media_type":"S","cod_profile_hash":"3961374576122549130"}
     * 
     * @param codProfileHash
     * @return JSONObject
     * @throws Exception
     */
    private JSONObject mediaDifferentOwner(Long codProfileHash) throws Exception
    {
        int limit = 10;
        int start = 0;
        Long codChildProfileHash = null;
        JSONArray jsonarray = JsonUtil.mediaPaging(start, limit);

        while (jsonarray != null && jsonarray.length() > 0)
        {
            for (int i = 0; i < jsonarray.length(); i++)
            {
                codChildProfileHash = Long.valueOf(jsonarray.getJSONObject(i).getString("cod_profile_hash"));

                if (!codChildProfileHash.equals(codProfileHash))
                {
                    return jsonarray.getJSONObject(i);
                }
            }

            start+=limit;
            jsonarray = JsonUtil.mediaPaging(start, limit);
        }

        return null;
    }

    protected HashMap<String, String> prepareParams(String type) throws Exception, JSONException
    {
        HashMap<String, String> params = new HashMap<String, String>();
        List<java.io.File> fileList = TestUtil.files(System.getenv("PATH_FILE_TEST") + java.io.File.separator, type);
        java.io.File file = null;

        if (!fileList.isEmpty() && fileList.size() > 0)
        {
            int index = new Random().nextInt(fileList.size());
            java.io.File jsonFile = fileList.get(index);
            String mediaId = jsonFile.getName().substring(0, jsonFile.getName().indexOf("."));
            JSONObject mediajson = JsonUtil.jsonFromFile(mediaId, type);
            file = new java.io.File(System.getenv("PATH_FILE_TEST") + File.separator + mediaId + EXT.get(type));

            String tag = tags(mediajson);
            String tagsrv = tagService(mediajson);

            params.put("_fileName", file.getAbsolutePath());
            params.put("_mediaId", mediaId);
            params.put("media.namSubject", adjustmentToRequest(mediajson.getString("title")));
            params.put("media.desMedia", mediaId + " " + adjustmentToRequest(mediajson.getString("description")));
            params.put("media.tags", (tag != null ? tag : ""));
            params.put("media.idtTagService", "1010" + (tagsrv != null ? (tagsrv.startsWith(",") ? "" : ",") + tagsrv : ""));

            if (mediajson.has("subscriberMedia") && mediajson.getBoolean("subscriberMedia"))
            {
                params.put("media.flgSubscriberMedia", "1");
            }
        }
        else
        {
            params.put("_fileName", System.getenv("PATH_FILE_TEST") + File.separator + TYPES.get(type) + EXT.get(type));
            params.put("media.namSubject", "video " + DateUtil.getDateString(new Date(), "yyyy-MM-dd_HH-mm-ss"));
            params.put("media.desMedia", "teste " + TYPES.get(type) + " publicado via api");
            params.put("media.tags", "tag");
            params.put("media.idtTagService", "1010");
        }

        params.put("media.indAllowNotes", "T");
        params.put("media.indHot", "N");

        if (envConfig().getEnv().equals("stg") || envConfig().getEnv().equals("qa"))
        {
            params.put("media.indVisibility", "T");
        }
        else
        {
            params.put("media.indVisibility", "N");
        }

        return params;
    }

    private void backData(LoginCookie login, String url, HashMap<String, String> params, JSONObject mediajson) throws Exception
    {
        params.put("media.namSubject", mediajson.getJSONObject("media").getString("title"));
        params.put("media.desMedia", mediajson.getJSONObject("media").getString("description"));
        params.put("media.tags", mediajson.getJSONObject("media").getString("tags"));

        login.postdatajson(url, params);
    }

    private String findFile(java.io.File file, String name, final String[] extentions)
    {
        int i = 0;

        while ((file == null || !file.exists()) && i < extentions.length)
        {
            file = new java.io.File(System.getenv("PATH_FILE_TEST") + File.separator + name + "." + extentions[i]);
            i++;
        }

        return (file == null ? null : file.getAbsolutePath());
    }

    private String tags(JSONObject mediajson) throws Exception
    {
        StringBuffer tag = new StringBuffer();

        if (mediajson.has("tags") && mediajson.getJSONArray("tags").length() > 0)
        {
            for (int i = 0; i < mediajson.getJSONArray("tags").length(); i++)
            {
                tag.append((tag.length() < 1 ? "" : ",") + mediajson.getJSONArray("tags").getJSONObject(i).getString("description"));
            }

            return tag.toString();
        }

        return null;
    }

    private String tagService(JSONObject mediajson) throws Exception
    {
        if (mediajson.has("idtTagService") && !mediajson.getString("idtTagService").equals(""))
        {
            return mediajson.getString("idtTagService");
        }

        return null;
    }

    private String adjustmentToRequest(String field)
    {
        for (String key : TestUtil.CHARCODE_UNICODE.keySet())
        {
            field = field.replace(key, new String(new int[] { TestUtil.CHARCODE_UNICODE.get(key) }, 0, 1));
        }

        return field;
    }

    private boolean validateMessageJson(JSONObject json, char type)
    {
        try
        {
            json.getJSONObject("response");

            if (type == 'S')
            {
                if (json == null || json.getJSONObject("_response").getInt("code") != HttpStatus.SC_OK)
                {
                    return false;
                }

                // json.getJSONObject("response").getString("code");
                json.getJSONObject("response").getString("status");
                json.getJSONObject("response").getString("description");

                if (!json.getJSONObject("response").getString("status").equals("success"))
                {
                    throw new Exception("no has success message");
                }
            }
            else if (type == 'E')
            {
                if (json == null || json.getJSONObject("_response").getInt("code") == HttpStatus.SC_OK)
                {
                    return false;
                }

                json.getJSONObject("response").getString("code");
                json.getJSONObject("response").getString("status");
                json.getJSONObject("response").getString("description");

                if (!json.getJSONObject("response").getString("status").equals("error"))
                {
                    throw new Exception("no has error message");
                }
                else
                {
                    json.getJSONObject("error").getString("code");
                    json.getJSONObject("error").getString("message");
                }
            }
            else if (type == 'W')
            {
                json.getJSONObject("response").getString("code");
                json.getJSONObject("response").getString("status");
                json.getJSONObject("response").getString("description");

                if (!json.getJSONObject("response").getString("status").equals("warn"))
                {
                    throw new Exception("no has warn message");
                }
            }
            else
            {
                json.getJSONObject("response").getString("code");
                json.getJSONObject("response").getString("status");
                json.getJSONObject("response").getString("description");

                if (!json.getJSONObject("response").getString("status").equals("info"))
                {
                    throw new Exception("no has info message");
                }
            }

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - message invalid - " + e.getMessage() + " - " + json);
            return false;
        }
    }

    protected boolean validateJson(JSONObject json, boolean status, boolean publish)
    {
        try
        {
            if (json == null || json.getJSONObject("_response").getInt("code") != HttpStatus.SC_OK)
            {
                return false;
            }

            if (!status)
            {
                json.getJSONObject("response");

                if (publish)
                {
                    json.getJSONObject("response").getString("code");
                }

                json.getJSONObject("response").getString("status");
                json.getJSONObject("response").getString("description");
            }

            json.getJSONObject("media");
            json.getJSONObject("media").getString("title");
            json.getJSONObject("media").getString("mediaId");
            json.getJSONObject("media").getString("url");
            json.getJSONObject("media").getString("thumbnail");
            json.getJSONObject("media").getString("thumbSmall");
            json.getJSONObject("media").getString("thumbMedium");
            json.getJSONObject("media").getString("thumbLarge");
            json.getJSONObject("media").getString("mediaType");
            json.getJSONObject("media").getBoolean("moderateNote");
            json.getJSONObject("media").getBoolean("allowAnonymousComment");
            json.getJSONObject("media").getString("allowNotes");
            json.getJSONObject("media").getString("edFilter");
            json.getJSONObject("media").getString("description");
            json.getJSONObject("media").getBoolean("adultContent");
            json.getJSONObject("media").getString("author");
            json.getJSONObject("media").getString("authorPage");
            json.getJSONObject("media").getString("codProfile");
            json.getJSONObject("media").getString("publishedAt");
            json.getJSONObject("media").getBoolean("blockEmbed");
            json.getJSONObject("media").getBoolean("subscriberMedia");
            json.getJSONObject("media").getString("idtTagService");
            json.getJSONObject("media").getString("tags");

            JsonUtil.validateValueJson(json.getJSONObject("media"), new String[] { "title", "description" });

            if (status)
            {
                json.getJSONObject("mediaStatus");
                json.getJSONObject("mediaStatus").getString("codStatus");

                if ("V".equals(json.getJSONObject("media").getString("mediaType")))
                {
                    json.getJSONObject("mediaStatus").getString("datStartEncoding");
                    json.getJSONObject("mediaStatus").getString("numPercEncoding");
                }
            }

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - json is not valid - " + e.getMessage() + " - " + json);
            return false;
        }
    }

    private boolean validatePageJson(JSONObject json)
    {
        try
        {
            if (json == null || json.getJSONObject("_response").getInt("code") != HttpStatus.SC_OK)
            {
                return false;
            }

            json.getJSONObject("response");
            json.getJSONObject("response").getInt("code");
            json.getJSONObject("response").getString("description");
            json.getJSONObject("response").getString("originalRequest");

            json.getJSONObject("paging").getString("currentPage");
            json.getJSONObject("paging").getString("itemsPerPage");
            json.getJSONObject("paging").getString("sort");

            json.getJSONArray("list");

            for (int i = 0; i < json.getJSONArray("list").length(); i++)
            {
                json.getJSONArray("list").getJSONObject(i).getString("title");
                json.getJSONArray("list").getJSONObject(i).getString("mediaId");
                json.getJSONArray("list").getJSONObject(i).getString("url");
                json.getJSONArray("list").getJSONObject(i).getString("thumbnail");
                json.getJSONArray("list").getJSONObject(i).getString("thumbSmall");
                json.getJSONArray("list").getJSONObject(i).getString("thumbMedium");
                json.getJSONArray("list").getJSONObject(i).getString("thumbLarge");
                json.getJSONArray("list").getJSONObject(i).getString("mediaType");
                json.getJSONArray("list").getJSONObject(i).getBoolean("moderateNote");
                json.getJSONArray("list").getJSONObject(i).getBoolean("allowAnonymousComment");
                json.getJSONArray("list").getJSONObject(i).getString("allowNotes");
                json.getJSONArray("list").getJSONObject(i).getString("edFilter");
                json.getJSONArray("list").getJSONObject(i).getString("description");
                json.getJSONArray("list").getJSONObject(i).getBoolean("adultContent");
                json.getJSONArray("list").getJSONObject(i).getString("author");
                json.getJSONArray("list").getJSONObject(i).getString("authorPage");
                json.getJSONArray("list").getJSONObject(i).getString("codProfile");
                json.getJSONArray("list").getJSONObject(i).getString("publishedAt");
                json.getJSONArray("list").getJSONObject(i).getBoolean("blockEmbed");
                json.getJSONArray("list").getJSONObject(i).getBoolean("subscriberMedia");
                json.getJSONArray("list").getJSONObject(i).getString("idtTagService");
                json.getJSONArray("list").getJSONObject(i).getString("tags");
                json.getJSONArray("list").getJSONObject(i).getString("indVisibility");
                json.getJSONArray("list").getJSONObject(i).getString("codStatus");

                if (json.getJSONArray("list").getJSONObject(i).getString("mediaType").equals("V"))
                {
                    json.getJSONArray("list").getJSONObject(i).getString("formats");
                }

                JsonUtil.validateValueJson(json.getJSONArray("list").getJSONObject(i), new String[] { "title", "description" });
            }

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - pagejson is not valid - " + e.getMessage() + " - " + json);
            return false;
        }
    }

    private boolean validateTagsJson(JSONObject json)
    {
        try
        {
            if (json == null || json.getJSONObject("_response").getInt("code") != HttpStatus.SC_OK)
            {
                return false;
            }
            json.getJSONObject("tagCloudPage");
            json.getJSONObject("tagCloudPage").getInt("currentPage");
            json.getJSONObject("tagCloudPage").getInt("itemsPerPage");
            json.getJSONObject("tagCloudPage").getInt("totalItems");
            json.getJSONObject("tagCloudPage").getInt("totalPages");
            json.getJSONObject("tagCloudPage").getInt("previousPage");
            json.getJSONObject("tagCloudPage").getJSONArray("previousPageCollection");
            json.getJSONObject("tagCloudPage").getInt("nextPage");
            json.getJSONObject("tagCloudPage").getJSONArray("nextPageCollection");
            json.getJSONObject("tagCloudPage").getString("sortBy");
            json.getJSONObject("tagCloudPage").getString("orderBy");
            json.getJSONObject("tagCloudPage").getJSONArray("items");

            for (int i = 0; i < json.getJSONObject("tagCloudPage").getJSONArray("previousPageCollection").length(); i++)
            {
                json.getJSONObject("tagCloudPage").getJSONArray("previousPageCollection").getInt(i);
            }

            for (int i = 0; i < json.getJSONObject("tagCloudPage").getJSONArray("nextPageCollection").length(); i++)
            {
                json.getJSONObject("tagCloudPage").getJSONArray("nextPageCollection").getInt(i);
            }

            for (int i = 0; i < json.getJSONObject("tagCloudPage").getJSONArray("items").length(); i++)
            {
                json.getJSONObject("tagCloudPage").getJSONArray("items").getJSONObject(i).getLong("idtTag");
                json.getJSONObject("tagCloudPage").getJSONArray("items").getJSONObject(i).getString("desTag");
                json.getJSONObject("tagCloudPage").getJSONArray("items").getJSONObject(i).getInt("numUsed");
            }

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - tagsjson is not valid - " + e.getMessage() + " - " + json);
            return false;
        }
    }

    protected JSONObject verifyProcessing(LoginCookie login, JSONObject jsonResponse, boolean verbose) throws Exception
    {
        JSONObject jsonitems = null;
        Map<Integer, Integer> info = new HashMap<Integer, Integer>();
        String mediaId = null;
        String type = null;
    
        if (jsonResponse.getJSONObject("media").has("mediaType"))
        {
            type = jsonResponse.getJSONObject("media").getString("mediaType");
        }
        else if (jsonResponse.getJSONObject("media").has("indMediaType"))
        {
            type = jsonResponse.getJSONObject("media").getString("indMediaType");
        }
    
        if (type == null)
        {
            logger.error("ERROR - mediaType not found - " + jsonResponse);
            return null;
        }
    
        mediaId = jsonResponse.getJSONObject("media").getString("mediaId");
    
        if (mediaId == null)
        {
            logger.error("ERROR - mediaId not found - " + jsonResponse);
            return null;
        }
    
        JSONObject jsonmedia = null;
        int codStatus = 0;
    
        while (codStatus < 10)
        {
            if (verbose)
            {
                status(codStatus, "media " + mediaId);
            }
    
            Thread.sleep((verbose ? 10000 : 60000));
    
            jsonmedia = login.getjson("http://beta.mais.uol.com.br/sys/media/status?variant=json&mediaId=" + mediaId);
    
            if (jsonmedia != null && !jsonmedia.has("mediaStatus"))
            {
                logger.error("ERROR - invalid media status - " + jsonmedia + " - " + mediaId);
                return null;
            }
    
            codStatus = Integer.valueOf(jsonmedia.getJSONObject("mediaStatus").getString("codStatus"));
    
            if ("V".equals(jsonmedia.getJSONObject("media").getString("mediaType")))
            {
                try
                {
                    jsonitems = JsonRequest.get("http://mais.uol.com.br/apiuol/v2/media/formats/" + mediaId + ".json");
    
                    if (jsonitems != null && jsonitems.has("formats") && jsonitems.getJSONObject("formats").has("mediaOutputFormats"))
                    {
                        for (int i = 0; i < jsonitems.getJSONObject("formats").getJSONArray("mediaOutputFormats").length(); i++)
                        {
                            if (verbose)
                            {
                                status(
                                    jsonitems.getJSONObject("formats").getJSONArray("mediaOutputFormats").getJSONObject(i).getInt("codStatus"),
                                    "format "
                                            + jsonitems.getJSONObject("formats").getJSONArray("mediaOutputFormats").getJSONObject(i)
                                                    .getInt("idtOutputFormat"));
                            }
    
                            if (10 != jsonitems.getJSONObject("formats").getJSONArray("mediaOutputFormats").getJSONObject(i)
                                    .getInt("codStatus"))
                            {
                                codStatus = jsonitems.getJSONObject("formats").getJSONArray("mediaOutputFormats").getJSONObject(i)
                                        .getInt("codStatus");
                                info.put(
                                    jsonitems.getJSONObject("formats").getJSONArray("mediaOutputFormats").getJSONObject(i)
                                            .getInt("idtOutputFormat"), codStatus);
                            }
                        }
                    }
                }
                catch (Exception e)
                {
                    logger.warn(e.getMessage() + " - " + jsonitems);
                    throw new Exception(e);
                }
            }
        }
    
        if (codStatus == 10)
        {
            return jsonmedia;
        }
        else if (codStatus >= 60)
        {
            logger.error("ERROR - encoding error - " + mediaId
                    + (!info.isEmpty() ? infoByStatus(info, codStatus, jsonmedia.getJSONObject("media").getString("mediaType")) : ""));
        }
        else if (codStatus == 11)
        {
            logger.info("ERROR - file blocked - " + mediaId
                    + (!info.isEmpty() ? infoByStatus(info, codStatus, jsonmedia.getJSONObject("media").getString("mediaType")) : ""));
    
            JSONObject mediaFile = JsonUtil.mediaFile(mediaId);
    
            if (mediaFile != null && Integer.parseInt(mediaFile.getString("cod_status")) == 11
                    && Integer.parseInt(mediaFile.getString("file_status")) == 11)
            {
                return jsonmedia;
            }
        }
        else
        {
            logger.error("ERROR - " + mediaId);
        }
    
        return null;
    }

    protected String infoByStatus(Map<Integer, Integer> info, int codStatus, String type) throws JSONException
    {
        StringBuffer ret = new StringBuffer();
    
        for (Integer key : info.keySet())
        {
            if (info.get(key).intValue() == codStatus)
            {
                ret.append((ret.length() > 0 ? "," : "") + info.get(key));
            }
        }
    
        return ("V".equals(type) ? " on format: " : "") + ret.toString();
    }

    protected void status(int codStatus, String msg)
    {
        if (codStatus == 10)
        {
            logger.info(codStatus + " AVAILABLE " + (msg != null ? "- " + msg : ""));
        }
        else if (codStatus == 0)
        {
            logger.info(codStatus + " UPLOADED " + (msg != null ? "- " + msg : ""));
        }
        else if (codStatus == 1)
        {
            logger.info(codStatus + " COPYNG_MEDIA_PROCESSOR " + (msg != null ? "- " + msg : ""));
        }
        else if (codStatus == 2)
        {
            logger.info(codStatus + " PROCESSING " + (msg != null ? "- " + msg : ""));
        }
        else if (codStatus == 3)
        {
            logger.info(codStatus + " COPYNG_STORAGE " + (msg != null ? "- " + msg : ""));
        }
        else if (codStatus == 12)
        {
            logger.info(codStatus + " REVISING " + (msg != null ? "- " + msg : ""));
        }
        else if (codStatus == 13)
        {
            logger.info(codStatus + " CHANGING_THUMB " + (msg != null ? "- " + msg : ""));
        }
        else if (codStatus == 14)
        {
            logger.info(codStatus + " SELECTING_THUMB " + (msg != null ? "- " + msg : ""));
        }
        else if (codStatus == 15)
        {
            logger.info(codStatus + " CHANGING_MEDIA " + (msg != null ? "- " + msg : ""));
        }
        else if (codStatus == 20)
        {
            logger.info(codStatus + " ASKED_REMOVE " + (msg != null ? "- " + msg : ""));
        }
        else if (codStatus == 11)
        {
            logger.info(codStatus + " BLOCKED " + (msg != null ? "- " + msg : ""));
        }
        else if (codStatus == 33)
        {
            logger.info(codStatus + " BLACKLISTED " + (msg != null ? "- " + msg : ""));
        }
        else if (codStatus == 60)
        {
            logger.info(codStatus + " UNSUPPORTED_ENCODING " + (msg != null ? "- " + msg : ""));
        }
        else if (codStatus == 70)
        {
            logger.info(codStatus + " ERROR_LOADING_UPLOADED " + (msg != null ? "- " + msg : ""));
        }
        else if (codStatus == 72)
        {
            logger.info(codStatus + " ERROR_PROCESSING " + (msg != null ? "- " + msg : ""));
        }
        else if (codStatus == 73)
        {
            logger.info(codStatus + " ERROR_SAVING_STORAGE " + (msg != null ? "- " + msg : ""));
        }
        else if (codStatus == 75)
        {
            logger.info(codStatus + " ERROR_OPENING_FILE " + (msg != null ? "- " + msg : ""));
        }
        else
        {
            logger.info(codStatus + " " + (msg != null ? "- " + msg : ""));
        }
    }
}

