/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         20/06/2014 Criacao inicial
 */

package uol.taipei.tests.token;

import org.apache.http.HttpStatus;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.LoginCookie;

public class Token extends AbstractTest
{
    static final Logger logger = LoggerFactory.getLogger(Token.class);

    public static void main(String[] args)
    {
        if (!verifyParams(args))
        {
            return;
        }

        setUp(args[0]);

        if (envConfig().getUser() == null || envConfig().getUser().equals("") || envConfig().getPass() == null || envConfig().getPass().equals(""))
        {
            System.err.println("Invalid user " + envConfig().getUser());
            return;
        }

        logger.debug("-------------------------------------------------");
        logger.debug("tests token");

        try
        {
            Token token = new Token();
            LoginCookie login = new LoginCookie(envConfig().getUser(), envConfig().getPass());

            JSONObject jtoken = token.create(login);
            token.refresh(login, jtoken.getString("token"));
        }
        catch (Exception e) 
        {
            logger.error(e.getMessage());            
        }
    }

    public JSONObject create(LoginCookie login) throws Exception
    {
        JSONObject jsonResponse = login.getjson("http://beta.mais.uol.com.br/sys/token");

        if (!validateJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject refresh(LoginCookie login, String uploadToken) throws Exception
    {
        JSONObject jsonResponse = login.getjson("http://beta.mais.uol.com.br/sys/token?action=refreshToken&uploadToken=" + uploadToken);

        if (!validateJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        if (!jsonResponse.getString("token").equals(uploadToken))
        {
            logger.error("ERROR - invalid token - " + uploadToken + " - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    private boolean validateJson(JSONObject jsonResponse)
    {
        try
        {
            if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") != HttpStatus.SC_OK)
            {
                return false;
            }
            jsonResponse.getString("token");

            return true;
        }
        catch (Exception e) 
        {
            logger.error("ERROR - json is not valid - " + e.getMessage() + " - " + jsonResponse);
            return false;
        }
    }
}
