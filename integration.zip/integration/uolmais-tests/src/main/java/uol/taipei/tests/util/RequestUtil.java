/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         21/10/2014 Criacao inicial
 */

package uol.taipei.tests.util;

import org.json.JSONObject;

import uol.taipei.request.JsonRequest;

public class RequestUtil
{
    public static String tagService(boolean onlyOne, int totalPage, int itemsPerPage) throws Exception
    {
        int page = 1;
        StringBuffer tagService = new StringBuffer();
        String query = "SELECT des_idt_tag_service FROM media WHERE cod_status = 10 AND ind_hot = 'N' AND flg_draft = 0 AND ind_visibility = 'T' "
                + "AND (ind_media_type = 'V' OR ind_media_type = 'P' OR ind_media_type = 'S' OR ind_media_type = 'T') "
                + "AND des_idt_tag_service IS NOT NULL AND des_idt_tag_service <> '' LIMIT ";

        JSONObject result = JsonRequest.execQuery(query + page + "," + itemsPerPage);

        while (page <= totalPage && result != null && result.has("data") && result.getJSONArray("data").length() > 0)
        {
            for (int i = 0; i < result.getJSONArray("data").length(); i++)
            {
                Integer index = JsonUtil.indexOf(result, "des_idt_tag_service");
                if (!result.getJSONArray("data").getJSONArray(i).getString(index).isEmpty())
                {
                    for (String s : result.getJSONArray("data").getJSONArray(i).getString(index).split(","))
                    {
                        if (!s.isEmpty())
                        {
                            tagService.append((tagService.length() < 1 ? "" : ",") + s);
                        }
                    }
                }

                if (onlyOne)
                {
                    if (tagService.toString().split(",").length == 1)
                    {
                        return tagService.toString();
                    }
                }
                else
                {
                    if (tagService.toString().split(",").length > 1)
                    {
                        return tagService.toString();
                    }
                }
            }

            page++;
            result = JsonRequest.execQuery(query + page + "," + itemsPerPage);
        }

        return null;
    }

    public static String mediaId(String type, Long codProfileHash) throws Exception
    {
        String query = "SELECT m.idt_media FROM media m WHERE m.cod_status = 10 " + (type != null ? " AND m.ind_media_type = '" + type + "' " : " ") 
                + (codProfileHash != null ? " AND m.cod_profile_hash = " + codProfileHash + " " : " ") + "ORDER BY m.idt_media DESC LIMIT 1";

        JSONObject result = JsonRequest.execQuery(query);

        if (result != null && result.has("data") && result.getJSONArray("data").length() > 0 
                && JsonUtil.getParam(result, "idt_media") != null)
        {
            return JsonUtil.getParam(result, "idt_media").toString();
        }

        return null;
    }

    public static String mediaIdPublic(String type) throws Exception
    {
        String query = "SELECT m.idt_media FROM media m LEFT JOIN media_product mp ON mp.idt_media = m.idt_media "
                + "LEFT JOIN media_country mc ON mc.idt_media = m.idt_media WHERE m.cod_status = 10 AND m.ind_visibility = 'T' "
                + "AND m.ind_hot = 'N'" + (type != null ? " AND m.ind_media_type = '" + type + "' " : " ") 
                + "AND m.flg_draft = 0 AND m.flg_subscriber_media = 0 "
                + "AND mp.idt_product IS NULL AND mc.cod_iso_country IS NULL AND m.dat_publish_scheduling <= now() ORDER BY m.idt_media DESC LIMIT 1";

        JSONObject result = JsonRequest.execQuery(query);

        Integer index = JsonUtil.indexOf(result, "idt_media");
        if (index != null)
        {
            return result.getJSONArray("data").getJSONArray(0).getString(index);
        }

        return null;
    }

    public static String mediaIdPublic(String type, long codProfileHash) throws Exception
    {
        String query = "SELECT m.idt_media FROM media m LEFT JOIN media_product mp ON mp.idt_media = m.idt_media "
                + "LEFT JOIN media_country mc ON mc.idt_media = m.idt_media WHERE m.cod_status = 10 AND m.ind_visibility = 'T' "
                + "AND m.ind_hot = 'N' AND m.ind_media_type = '" + type + "' AND m.cod_profile_hash = " + codProfileHash
                + " AND m.flg_draft = 0 AND m.flg_subscriber_media = 0 "
                + "AND mp.idt_product IS NULL AND mc.cod_iso_country IS NULL AND m.dat_publish_scheduling <= now() ORDER BY m.idt_media DESC LIMIT 1";

        JSONObject result = JsonRequest.execQuery(query);

        if (result != null && result.has("data") && result.getJSONArray("data").length() > 0 
                && !JsonUtil.getParam(result,"idt_media").toString().isEmpty())
        {
            return JsonUtil.getParam(result,"idt_media").toString();
        }

        return null;
    }

    public static String mediaIdRestrict(int status, String type, String visibility, boolean draft, boolean subscriber, boolean hot, boolean geoip, boolean product) throws Exception
    {
        String query = "SELECT m.idt_media FROM media m LEFT JOIN media_product mp ON mp.idt_media = m.idt_media "
                + "LEFT JOIN media_country mc ON mc.idt_media = m.idt_media "
                + "WHERE m.cod_status = " + status + " AND m.ind_hot IN (" + (hot ? "'U','P'" : "'N'") + ") "
                + "AND m.flg_draft = " + (draft ? "1" : 0) + " AND m.ind_visibility = '" + visibility + "' AND m.ind_media_type = '" + type
                + "' AND m.flg_subscriber_media = " + (subscriber ? "1" : "0") + " AND mc.cod_iso_country IS " + (geoip ? "NOT " : "" ) + "NULL " 
                + "AND mp.idt_product IS " + (product ? "NOT " : "") + "NULL ORDER BY idt_media DESC LIMIT 1";

        JSONObject result = JsonRequest.execQuery(query);

        if (result != null && result.has("data") && result.getJSONArray("data").length() > 0 
                && !JsonUtil.getParam(result,"idt_media").toString().isEmpty())
        {
            return JsonUtil.getParam(result,"idt_media").toString();
        }

        return null;
    }

    public static String mediaIdRestrictProduct(String type) throws Exception
    {
        String query = "SELECT m.idt_media FROM media m LEFT JOIN media_product mp ON mp.idt_media = m.idt_media WHERE m.cod_status = 10 "
                + "AND m.ind_visibility = 'T' AND m.ind_hot = 'N' AND m.ind_media_type = '"+ type +"' AND m.flg_draft = 0 "
                + "AND m.flg_subscriber_media = 0 AND mp.idt_product IS NOT NULL ORDER BY m.idt_media DESC LIMIT 1";

        JSONObject result = JsonRequest.execQuery(query);

        if (result != null && result.has("data") && result.getJSONArray("data").length() > 0 
                && !JsonUtil.getParam(result,"idt_media").toString().isEmpty())
        {
            return JsonUtil.getParam(result,"idt_media").toString();
        }

        return null;
    }

    public static String mediaIdRestrictFile(int status, String type, String visibility, boolean draft, boolean subscriber, boolean hot) throws Exception
    {
        String query = "SELECT m.idt_media FROM media m LEFT JOIN file f ON m.idt_file = f.idt_file WHERE m.cod_status = " + status 
                + " AND m.ind_hot IN (" + (hot ? "'U','P'" : "'N'") + ") " + "AND m.flg_draft = " + (draft ? "1" : 0) 
                + " AND m.ind_visibility = '" + visibility + "' AND m.ind_media_type = '" + type
                + "' AND m.flg_subscriber_media = " + (subscriber ? "1" : "0") + " AND f.cod_status = 10 " 
                + " AND f.idt_file IS NOT NULL AND f.dat_limbo IS NULL ORDER BY m.idt_media DESC LIMIT 1";

        JSONObject result = JsonRequest.execQuery(query);

        if (result != null && result.has("data") && result.getJSONArray("data").length() > 0 
                && !JsonUtil.getParam(result,"idt_media").toString().isEmpty())
        {
            return JsonUtil.getParam(result,"idt_media").toString();
        }

        return null;
    }

    public static String mediaIdVideoFormatFile(int format) throws Exception
    {
        String query = "SELECT m.idt_media,f.idt_file FROM media m LEFT JOIN file f ON m.idt_file = f.idt_file WHERE m.cod_status = 10 "
                + "AND m.ind_media_type = 'V' AND m.ind_visibility = 'T' AND m.ind_hot = 'N' AND m.flg_draft = 0 AND m.flg_subscriber_media = 0 "
                + "AND (SELECT fo.idt_output_format FROM file_outputformat fo WHERE fo.idt_file = m.idt_file AND fo.idt_output_format = " 
                + format + ") IS NOT NULL AND f.cod_status = 10 AND f.idt_file IS NOT NULL ORDER BY m.idt_media DESC LIMIT 1 ";

        JSONObject result = JsonRequest.execQuery(query);

        if (result != null && result.has("data") && result.getJSONArray("data").length() > 0 
                && !JsonUtil.getParam(result,"idt_media").toString().isEmpty())
        {
            return JsonUtil.getParam(result,"idt_media").toString();
        }

        return null;
    }

    public static String mediaIdNoVideoFormatFile(int format) throws Exception
    {
        String query = "SELECT m.idt_media,f.idt_file FROM media m LEFT JOIN file f ON m.idt_file = f.idt_file WHERE m.cod_status = 10 "
                + "AND m.ind_media_type = 'V' AND m.ind_visibility = 'T' AND m.ind_hot = 'N' AND m.flg_draft = 0 AND m.flg_subscriber_media = 0 "
                + "AND (SELECT fo.idt_output_format FROM file_outputformat fo WHERE fo.idt_file = m.idt_file AND fo.idt_output_format = " 
                + format + ") IS NULL AND f.cod_status = 10 AND f.idt_file IS NOT NULL ORDER BY m.idt_media DESC LIMIT 1 ";

        JSONObject result = JsonRequest.execQuery(query);

        if (result != null && result.has("data") && result.getJSONArray("data").length() > 0 
                && !JsonUtil.getParam(result, "idt_media").toString().isEmpty())
        {
            return JsonUtil.getParam(result, "idt_media").toString();
        }

        return null;
    }

    public static String editorType() throws Exception
    {
        String query = "SELECT idt_editor_type FROM editor_type ORDER BY idt_editor_type DESC LIMIT 1";
        JSONObject result = JsonRequest.execQuery(query);

        if (result != null && result.has("data") && result.getJSONArray("data").length() > 0)
        {
            if (!JsonUtil.getParam(result,"idt_editor_type").toString().isEmpty())
            {
                return JsonUtil.getParam(result,"idt_editor_type").toString();
            }
        }

        return null;
    }

    public static String getOneFollowableIdByCodProfileHash(Long codProfileHash) throws Exception
    {
        String query = "select idt_followable from subscription where cod_profile_hash = " + codProfileHash;

        JSONObject result = JsonRequest.execQuery(query);

        if (result != null && result.has("data") && result.getJSONArray("data").length() > 0 
                && !JsonUtil.getParam(result,"idt_followable").toString().isEmpty())
        {
            return JsonUtil.getParam(result,"idt_followable").toString();
        }

        return null;
    }
    
}
