/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         04/07/2014 Criacao inicial
 */

package uol.taipei.tests;

import java.util.Calendar;
import java.util.Date;

import uol.taipei.util.DateUtil;

public class DateParsing
{
    private long time;
    private Calendar calendar;
    private long dateInit;
    private long dateEnd;

    public DateParsing()
    {
        time = System.currentTimeMillis();
        calendar = Calendar.getInstance();
        calendar.setTimeInMillis(time);
    }

    /**
     * time(00:01:25) e format(HH:mm:ss) dever estar no mesmo padrao
     * 
     * @param time
     * @param format
     * @throws Exception
     */
    public DateParsing(String time, String format) throws Exception
    {
        Date date = DateUtil.getDate(time, format);

        this.time = date.getTime();
        calendar = Calendar.getInstance();
        calendar.setTimeInMillis(this.time);
    }

    /**
     * tempo(data+horario) completo em millis
     * 
     * @return long
     */
    public long getTime()
    {
        return time;
    }

    /**
     * ano YYYY
     * 
     * @return int
     */
    public int getYear()
    {
        return calendar.get(Calendar.YEAR);
    }

    /**
     * mes MM
     * 
     * @return int
     */
    public int getMonth()
    {
        return calendar.get(Calendar.MONTH) + 1;
    }

    /**
     * dia dd
     * 
     * @return int
     */
    public int getDay()
    {
        return calendar.get(Calendar.DAY_OF_MONTH);
    }

    /**
     * tempo(horario) em segundos
     * 
     * @return int
     */
    public int timeInSeconds() 
    {
        return (calendar.get(Calendar.HOUR_OF_DAY) * 3600 + calendar.get(Calendar.MINUTE) * 60 + calendar.get(Calendar.SECOND));
    }

    /**
     * data dd/MM/YYYY
     * 
     * @return String
     */
    public String dateString()
    {
        return (getDay() < 10 ? "0" + getDay() : getDay()) + "/" + (getMonth() < 10 ? "0" + getMonth() : getMonth()) + "/" + getYear();
    }

    /**
     * data dd/MM/yyyy HH:mm
     * 
     * @return String
     * @throws Exception
     */
    public String dateTimeString() throws Exception
    {
        return DateUtil.getDateString(DateUtil.getDate(time), "dd/MM/yyyy HH:mm");
    }

    /**
     * data dd/MM/YYYY de um mes antes
     * 
     * @return String
     */
    public String oneMonthBefore()
    {
        int mes = getMonth();
        int ano = getYear();

        if (mes == 0)
        {
            ano--;
            mes = 12;
        }
        else
        {
            mes--;
        }

        String date = (getDay() < 10 ? "0" + getDay() : getDay()) + "/" + (mes < 10 ? "0" + mes : mes) + "/" + ano;

        return date;
    }

    /**
     * tempo(dd/MM/yyyy HH:mm) em millis
     * 
     * @param time
     * @return String
     * @throws Exception
     */
    public static String timeMillisToString(Long time) throws Exception
    {
        return DateUtil.getDateString(DateUtil.getDate(time), "dd/MM/yyyy HH:mm");
    }

    /**
     * tempo em hora HH:mm:ss
     * 
     * @param time
     * @return String
     */
    public static String timeHourString(String time)
    {
        int partsOfTime = time.split(":").length;

        if (partsOfTime < 2)
        {
            time = "00:00:" + time;
        }
        else if (partsOfTime == 2)
        {
            time = "00:" + time;
        }

        return time;
    }

    /**
     * data, considerando horario inicial 00:00
     * 
     * @return long
     * @throws Exception
     */
    public long getDateInit() throws Exception
    {
        if (dateInit <= 0)
        {
            dateInit = DateUtil.getDateHour(oneMonthBefore(), true).getTime();
        }

        return dateInit;
    }

    /**
     * data, considerando hora final 23:59
     * @return
     * @throws Exception
     */
    public long getDateEnd() throws Exception
    {
        if (dateEnd <= 0)
        {
            dateEnd = DateUtil.getDateHour(dateString(), false).getTime();
        }

        return dateEnd;
    }
}
