/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         17/12/2015 Criacao inicial
 */

package uol.taipei.tests.encoder;

import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uol.taipei.request.FacileRequest;
import uol.taipei.request.FacileResponse;
import uol.taipei.request.JsonRequest;
import uol.taipei.tests.AbstractTest;

public class HealthCheckEncoder extends AbstractTest
{
    static final Logger logger = LoggerFactory.getLogger(HealthCheckEncoder.class);

    public static void main(String[] args)
    {
        if (!verifyParams(args))
        {
            return;
        }

        setUp(args[0]);

        logger.debug("-------------------------------------------------");
        logger.debug("tests health check encoder");

        try
        {
            HealthCheckEncoder healthCheckEncoder = null;

            for (String hostName : envConfig().getHostsEncoders().split(","))
            {
                healthCheckEncoder = new HealthCheckEncoder(hostName);
                healthCheckEncoder.probe();
            }
            
        }
        catch (Exception e) 
        {
            logger.error(e.getMessage());            
        }
    }

    public HealthCheckEncoder(String url)
    {
        this.host = url;
    }

    public boolean probe() throws Exception
    {
        FacileRequest request = new FacileRequest();
        JSONObject json = JsonRequest.get("http://maxima.mais.sys.intranet/configParameter/search?searchIdtConfigParameterType=1&"
                + "searchIdtConfigParameter=&searchNamKey=ServerInstance." + host 
                + ".%25.numServerEncoder&searchNamValue=&searchLimit=100");
        String u = null;
        FacileResponse response = null;
        String array = json.getJSONObject("_response").getString("data");
        JSONArray jsonArray = new JSONArray(array);

        if (json == null || jsonArray.length() < 1)
        {
            logger.error("ERROR - no encoder server configured - " + json);
            return false;
        }
        
        JSONObject instanceQtty = JsonRequest.get("http://maxima.mais.sys.intranet/configParameter/search?searchIdtConfigParameterType=1&searchIdtConfigParameter=&searchNamKey=ServerInstance."+host+".qtty&searchNamValue=&searchLimit=100");
        int instances = new JSONArray(instanceQtty.getJSONObject("_response").getString("data")).getJSONObject(0).getInt("namValue");

        for (int i = 0; i < instances; i++)
        {
            u = "http://" + host + ".host.intranet:" + (2000 + jsonArray.getJSONObject(i).getInt("namValue")) + "/probe";
            response = request.get(u);

            if (response.getCode() != 200)
            {
                logger.error("ERROR - return not valid - " + response.getCode() + " - " + u);
                return false;
            }

            try
            {
                response.getJson().getString("upTime");
                response.getJson().getString("status");
                response.getJson().getString("serverVersion");
            }
            catch (Exception e)
            {
                logger.error("ERROR - return not valid - " + e.getMessage() + " - " + response.getBody());
                return false;
            }
        }

        logger.debug("SUCCESS");

        return true;
    }
}
