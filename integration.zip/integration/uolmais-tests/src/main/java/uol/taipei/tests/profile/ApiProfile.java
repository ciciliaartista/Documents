/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         04/06/2014 Criacao inicial
 */

package uol.taipei.tests.profile;

import org.apache.http.HttpStatus;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uol.taipei.request.FacileRequest;
import uol.taipei.request.FacileResponse;
import uol.taipei.request.JsonRequest;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.LoginCookie;
import uol.taipei.tests.util.RequestUtil;

public class ApiProfile extends AbstractTest
{
    static final Logger logger = LoggerFactory.getLogger(ApiProfile.class);

    static private final String apiUrl = "http://mais.uol.com.br/apiuol/v2/";

    public static void main(String[] args)
    {
        if (!verifyParams(args))
        {
            return;
        }

        setUp(args[0]);

        if (envConfig().getUser() == null || envConfig().getUser().equals("") || envConfig().getPass() == null || envConfig().getPass().equals(""))
        {
            System.err.println("Invalid user " + envConfig().getUser());
            return;
        }

        logger.debug("-------------------------------------------------");
        logger.debug("tests api profile");

        try
        {
            ApiProfile apiProfile = new ApiProfile();
            LoginCookie login = new LoginCookie(envConfig().getUser(), envConfig().getPass());
            FacileRequest request = new FacileRequest();

            apiProfile.invalidUrl("x");
            apiProfile.profileUrl(login.getJsonProfile().getJSONObject("item").getString("desUrlProfile"));
            apiProfile.profileUrlErr(request);
            apiProfile.profileEditorTypeErr(request);
            apiProfile.profileEmptyEditorTypeErr(request);

            String editortype = RequestUtil.editorType();
            apiProfile.profileEditorType(editortype);
        }
        catch (Exception e)
        {
            logger.error(e.getMessage());
        }
    }

    public boolean profileEmptyEditorTypeErr(FacileRequest request) throws Exception
    {
        String url = apiUrl + "profile/editorType";
        FacileResponse response = request.getNoBody(url); 

        if (response.getCode() != HttpStatus.SC_NOT_FOUND)
        {
            logger.error("ERROR - return status not valid - " + response.getCode() + " - " + url);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean profileEditorTypeErr(FacileRequest request) throws Exception
    {
        String url = apiUrl + "profile/editortype/x";
        FacileResponse response = request.getNoBody(url); 

        if (response.getCode() != HttpStatus.SC_BAD_REQUEST)
        {
            logger.error("ERROR - return status not valid - " + response.getCode() + " - " + url);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public JSONObject profileEditorType(String editortype) throws Exception
    {
        if (editortype == null || editortype.equals(""))
        {
            logger.error("ERROR - invalid editortype - " + editortype);
            return null;
        }

        String url = apiUrl + "profile/editortype/" + editortype;
        JSONObject jsonResponse = JsonRequest.get(url);

        if (!validateEditorTypeJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public boolean profileUrlErr(FacileRequest request) throws Exception
    {
        String url = apiUrl + "profile/url";
        FacileResponse response = request.getNoBody(url); 

        if (response.getCode() != HttpStatus.SC_NOT_FOUND)
        {
            logger.error("ERROR - return status not valid - " + response.getCode() + " - " + url);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public JSONObject invalidUrl(String urlProfile) throws Exception
    {
        String url = apiUrl + "profile/url/" + urlProfile;
        JSONObject jsonResponse = JsonRequest.get(url);

        if (jsonResponse.getJSONObject("_response").getInt("code") != 400)
        {
            logger.error("ERROR - return status not valid - " + jsonResponse.getJSONObject("_response").getInt("code") + " - " + url);
            return null;
        }

        if (jsonResponse.has("found") && jsonResponse.getBoolean("found"))
        {
            logger.error("ERROR - urlProfile not match - " + urlProfile + " - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject profileUrl(String urlProfile) throws Exception
    {
        JSONObject jsonResponse = JsonRequest.get(apiUrl + "profile/url/" + urlProfile);

        if (!validateProfileUrlJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        if (jsonResponse.getBoolean("found") && !jsonResponse.getJSONObject("profile").getString("desUrlProfile").equals(urlProfile))
        {
            logger.error("ERROR - urlProfile not match - " + urlProfile + " - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    private boolean validateEditorTypeJson(JSONObject jsonResponse)
    {
        try
        {
            if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") != HttpStatus.SC_OK)
            {
                return false;
            }

            jsonResponse.getJSONObject("editorType");
            jsonResponse.getJSONObject("editorType").getInt("idtEditorType");
            jsonResponse.getJSONObject("editorType").getString("desEditorType");

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - editortypejson is not valid - " + e.getMessage() + " - " + jsonResponse);
            return false;
        }
    }

    private boolean validateProfileUrlJson(JSONObject jsonResponse)
    {
        try
        {
            if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") != HttpStatus.SC_OK)
            {
                return false;
            }

            jsonResponse.getBoolean("found");

            if (jsonResponse.getBoolean("found"))
            {
                if (jsonResponse.has("reservedUrl"))
                {
                    jsonResponse.getBoolean("reservedUrl");
                }
                
                jsonResponse.getJSONObject("profile");
                jsonResponse.getJSONObject("profile").getString("codProfile");
                jsonResponse.getJSONObject("profile").getString("codProfileHash");
                jsonResponse.getJSONObject("profile").getString("namNick");
                jsonResponse.getJSONObject("profile").getString("desUrlProfile");
            }

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - profileUrljson is not valid - " + e.getMessage() + " - " + jsonResponse);
            return false;
        }
    }
}
