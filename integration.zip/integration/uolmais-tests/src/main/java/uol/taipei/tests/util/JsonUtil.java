/* Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 *
 * Autor                                Data            Motivo
 * ---------------------------------    ----------      -----------------------
 * cafpereira                           27/07/2010      Criacao da classe
 */

package uol.taipei.tests.util;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import uol.taipei.request.JsonRequest;
import uol.taipei.util.StringUtil;
import uol.taipei.util.hash.HashCode;
import uol.taipei.util.media.MediaUtil;
import uol.taipei.webServiceClient.WSReturn;

public class JsonUtil
{
    static final Logger logger = LoggerFactory.getLogger(JsonUtil.class);

    /**
     * objeto json de um arquivo local
     * 
     * @param mediaId
     * @param mediaType
     * @return JSONObject
     * @throws Exception
     */
    public static JSONObject jsonFromFile(String mediaId, String mediaType) throws Exception
    {
        InputStream input = new FileInputStream(
                System.getenv("PATH_FILE_TEST") + java.io.File.separator + mediaId + ".json" + mediaType);
        String jsonTxt = IOUtils.toString(input);
        return new JSONObject(jsonTxt);
    }

    /**
     * obtem WSReturn de JSONObject de resposta de um request
     *  
     * @param jsonResponse
     * @return WSReturn
     */
    public static WSReturn wsReturn(JSONObject jsonResponse)
    {
        WSReturn ret = null;

        if (jsonResponse != null)
        {
            ret = new WSReturn();

            ret.setObjResponse(jsonResponse);

            if (jsonResponse.has("_response"))
            {
                try
                {
                    ret.setResponseCode(jsonResponse.getJSONObject("_response").getInt("code"));
                    ret.setResponseMessage(jsonResponse.getJSONObject("_response").getString("message"));
                }
                catch (Exception e)
                {
                    logger.warn(e.getMessage());
                }
            }
        }

        return ret;
    }

    /**
     * dados de profile por meio de ticotico
     * 
     * @param idtPerson
     * @return WSReturn
     */
    public static WSReturn profile(Long idtPerson)
    {
        return wsReturn(JsonRequest.execGibraltar("http://ws.uolk.sys.intranet/rest/profile/idtPerson/" + idtPerson, "GET", null,
            null, 5000));
    }

    /**
     * dados de profile por meio do ticotico
     * 
     * @param login
     * @return WSReturn
     */
    public static WSReturn profile(String login)
    {
        /*
         * como essa chamada e feita via get, o spring considera a uri ate o ultimo ponto. Entao, se o login e visitante
         * (*.com) e necessario apendar mais um ponto no fim
         */
        String ponto = (login.contains(".") ? "." : "");
        return wsReturn(JsonRequest.execGibraltar("http://ws.uolk.sys.intranet/rest/profile/namLogin/" + login + ponto, "GET",
            null, null, 5000));
    }

    /**
     * dados de um profile por meio da dona maxima
     * 
     * {"profile":{"codProfileHash":2464350640667993250,"idtPerson":131694561,"indUserProfile":"A","namNick":"user.test","desUrlProfile":"usertest","flgVoteAllowed":1,"numNetworkFriends":3,"numInvitationPending":2,"desDailyQuote":"","datCreation":1312217694000,"indStatus":"A","flgHotContent":0,"datBirth":null,"numAvatarVersion":0,"namNickUnique":"iq0ze7elq10i","indNickVisibility":"1","indDatBirthVisibility":"0","desAboutYou":null,"indAboutYouVisibility":"3","flgEditorialProfile":0,"flgPublicProfile":0,"indNamLoginVisibility":"0","indModerationStatus":"N"},"internetProf":{"codProfileHash":2464350640667993250,"namLogin":"user.test"},"mediaConfig":null,"codProfile":"iq0ze7elq10i"}
     * 
     * @param codProfile
     * @return JSONObject
     */
    public static JSONObject fullProfile(String codProfile)
    {
        return JsonRequest.get("http://maxima.mais.sys.intranet/profile?mode=codProfile&user=" + codProfile);
    }

    /**
     * dados de profile por meio da dona maxima
     * 
     * {"profile":{"codProfileHash":2464350640667993250,"idtPerson":131694561,"indUserProfile":"A","namNick":"user.test","desUrlProfile":"usertest","flgVoteAllowed":1,"numNetworkFriends":3,"numInvitationPending":2,"desDailyQuote":"","datCreation":1312217694000,"indStatus":"A","flgHotContent":0,"datBirth":null,"numAvatarVersion":0,"namNickUnique":"iq0ze7elq10i","indNickVisibility":"1","indDatBirthVisibility":"0","desAboutYou":null,"indAboutYouVisibility":"3","flgEditorialProfile":0,"flgPublicProfile":0,"indNamLoginVisibility":"0","indModerationStatus":"N"},"internetProf":{"codProfileHash":2464350640667993250,"namLogin":"user.test"},"mediaConfig":null,"codProfile":"iq0ze7elq10i"}
     * 
     * @param codProfileHash
     * @return JSONObject
     */
    public static JSONObject fullProfile(Long codProfileHash)
    {
        return JsonRequest.get("http://maxima.mais.sys.intranet/profile?mode=codProfileHash&user=" + codProfileHash);
    }

    /**
     * dados de um profile por meio da dona maxima
     * 
     * {"profile":{"codProfileHash":3046513378745488419,"idtPerson":128666154,"indUserProfile":"A","namNick":"dmais1","desUrlProfile":"dmais1","flgVoteAllowed":1,"numNetworkFriends":3,"numInvitationPending":0,"desDailyQuote":"asdfasfsafda","datCreation":1312217693000,"indStatus":"C","flgHotContent":0,"datBirth":null,"numAvatarVersion":0,"namNickUnique":"buonaparte","indNickVisibility":"1","indDatBirthVisibility":"0","desAboutYou":null,"indAboutYouVisibility":"3","flgEditorialProfile":1,"flgPublicProfile":0,"indNamLoginVisibility":"0","indModerationStatus":"N"},"internetProf":{"codProfileHash":3046513378745488419,"namLogin":"dmais1"},"mediaConfig":{"codProfileHash":3046513378745488419,"desSubject":"Sem","indVisibility":"T","indAllowNotes":"A","codTheme":0,"indHot":"N","flgAllowVideoComment":0,"flgAllowAnonymousComment":0,"flgModerateNote":1,"flgNotifyComment":0,"desHomepage":"Sem","flgBulletinRequester":0,"indEditorType":null,"numServer":0,"numMedias":0,"codPublicity":"cod-Publicity_teste","codPartnerDfp":"/uol/testedfp","indBlockCountry":null,"flgBlockEmbed":0,"passphrase":null},"codProfile":"n596v178lf6r"}
     * 
     * @param codProfile
     * @return JSONObject
     */
    public static JSONObject fullProfileLogin(String namLogin)
    {
        return JsonRequest.get("http://maxima.mais.sys.intranet/profile?mode=namLogin&user=" + namLogin);
    }

    /**
     * dados de profile por meio da dona maxima
     * 
     * {"profile":{"codProfileHash":3046513378745488419,"idtPerson":128666154,"indUserProfile":"A","namNick":"dmais1","desUrlProfile":"dmais1","flgVoteAllowed":1,"numNetworkFriends":3,"numInvitationPending":0,"desDailyQuote":"asdfasfsafda","datCreation":1312217693000,"indStatus":"C","flgHotContent":0,"datBirth":null,"numAvatarVersion":0,"namNickUnique":"buonaparte","indNickVisibility":"1","indDatBirthVisibility":"0","desAboutYou":null,"indAboutYouVisibility":"3","flgEditorialProfile":1,"flgPublicProfile":0,"indNamLoginVisibility":"0","indModerationStatus":"N"},"internetProf":{"codProfileHash":3046513378745488419,"namLogin":"dmais1"},"mediaConfig":{"codProfileHash":3046513378745488419,"desSubject":"Sem","indVisibility":"T","indAllowNotes":"A","codTheme":0,"indHot":"N","flgAllowVideoComment":0,"flgAllowAnonymousComment":0,"flgModerateNote":1,"flgNotifyComment":0,"desHomepage":"Sem","flgBulletinRequester":0,"indEditorType":null,"numServer":0,"numMedias":0,"codPublicity":"cod-Publicity_teste","codPartnerDfp":"/uol/testedfp","indBlockCountry":null,"flgBlockEmbed":0,"passphrase":null},"codProfile":"n596v178lf6r"}
     * 
     * @param codProfileHash
     * @return JSONObject
     */
    public static JSONObject fullProfilePerson(Long idtPerson)
    {
        return JsonRequest.get("http://maxima.mais.sys.intranet/profile?mode=idtPerson&user=" + idtPerson);
    }

    /**
     * dados de um profile
     * 
     * {"namLogin":"um-qa7","codProfile":"lc037ek9ic0w","numAvatarVersion":"0", "indNamLoginVisibility":"3","namNick":
     * "umqasete" ,"desUrlProfile":"qa7","numNetworkFriends"
     * :"10","indUserProfile":"A","indStatus":"A","flgPublicProfile": 1,"namNickUnique"
     * :"um-qa7","flgDefaultImage":1,"flgHotContent":"0","desDailyQuote" :"","indModerationStatus":"A"}
     * 
     * @param codProfile
     * @return JSONObject
     */
    public static JSONObject publicProfile(String codProfile)
    {
        return JsonRequest.get("http://pr.tt.uol.com.br/rest/public/profile/codProfile/" + codProfile);
    }

    /**
     * dados de um profile
     * 
     * {"namLogin":"um-qa7","codProfile":"lc037ek9ic0w","numAvatarVersion":"0", "indNamLoginVisibility":"3","namNick":
     * "umqasete" ,"desUrlProfile":"qa7","numNetworkFriends"
     * :"10","indUserProfile":"A","indStatus":"A","flgPublicProfile": 1,"namNickUnique"
     * :"um-qa7","flgDefaultImage":1,"flgHotContent":"0","desDailyQuote" :"","indModerationStatus":"A"}
     * 
     * @param codProfileHash
     * @return JSONObject
     */
    public static JSONObject publicProfile(Long codProfileHash)
    {
        return JsonRequest.get("http://pr.tt.uol.com.br/rest/public/profile/" + codProfileHash);
    }

    /**
     * dados de um profile
     * 
     * {"namLogin":"um-qa7","codProfile":"lc037ek9ic0w","numAvatarVersion":"0", "indNamLoginVisibility":"3","namNick":
     * "umqasete" ,"desUrlProfile":"qa7","numNetworkFriends"
     * :"10","indUserProfile":"A","indStatus":"A","flgPublicProfile": 1,"namNickUnique"
     * :"um-qa7","flgDefaultImage":1,"flgHotContent":"0","desDailyQuote" :"","indModerationStatus":"A"}
     * 
     * @param namLogin
     * @return JSONObject
     */
    public static JSONObject publicProfileLogin(String namLogin)
    {
        return JsonRequest.get("http://pr.tt.uol.com.br/rest/public/profile/namLogin/" + namLogin);
    }

    /**
     * verifica qual a posicao de uma coluna no json, supondo que existe um array de colunas
     * 
     * @param json
     * @param column
     * @return Integer
     * @throws JSONException
     */
    public static Integer indexOf(JSONObject json, String column) throws JSONException
    {
        if (json != null && json.has("columns"))
        {
            JSONArray jsonArray = json.getJSONArray("columns");

            for (int i = 0; i < jsonArray.length(); i++)
            {
                if (jsonArray.getString(i).equals(column))
                {
                    return i;
                }
            }
        }
        return null;
    }

    /***
     * Retorna o objeto do valor do parametro na resposta json
     * 
     * @param json
     * @param param
     * @return Object
     * @throws JSONException
     */
    public static Object getParam(JSONObject json, String param) throws JSONException
    {
        Integer index = indexOf(json, param);
        if (index != null)
        {
            return json.getJSONArray("data").getJSONArray(0).get(index);
        }
        return null;
    }

    /**
     * verifica se objeto esta no jsonarray
     * 
     * @param jsonArray
     * @param objectToFind
     * @return boolean
     * @throws JSONException
     */
    public static boolean contains(JSONArray jsonArray, Object objectToFind) throws JSONException
    {
        for (int i = 0; i < jsonArray.length(); i++)
        {
            if (jsonArray.get(i).equals(objectToFind))
            {
                return true;
            }
        }

        return false;
    }

    /**
     * verifica se int esta no jsonarray
     * 
     * @param jsonArray
     * @param objectToFind
     * @return boolean
     * @throws JSONException
     */
    public static boolean contains(JSONArray jsonArray, int objectToFind) throws JSONException
    {
        for (int i = 0; i < jsonArray.length(); i++)
        {
            if (jsonArray.getInt(i) == objectToFind)
            {
                return true;
            }
        }

        return false;
    }

    /**
     * verifica se long esta no jsonarray
     * 
     * @param jsonMediaArray
     * @param mediaIdToFind
     * @return boolean
     * @throws JSONException
     */
    public static boolean containsMedia(JSONArray jsonMediaArray, long mediaIdToFind) throws JSONException
    {
        for (int i = 0; i < jsonMediaArray.length(); i++)
        {
            if (jsonMediaArray.getJSONObject(i).getLong("mediaId") == mediaIdToFind)
            {
                return true;
            }
        }

        return false;
    }

    /**
     * verifica se string esta no jsonarray
     * 
     * @param jsonMediaArray
     * @param idToFind
     * @return boolean
     * @throws JSONException
     */
    public static boolean containsMedia(JSONArray jsonMediaArray, String idToFind) throws JSONException
    {
        String mediaHash;
        if (idToFind.lastIndexOf("-") > 0)
        {
            mediaHash = idToFind.substring(idToFind.lastIndexOf("-"));
        }
        else
        {
            mediaHash = idToFind;
        }
        for (int i = 0; i < jsonMediaArray.length(); i++)
        {
            if (jsonMediaArray.getJSONObject(i).getString("id").endsWith(mediaHash))
            {
                return true;
            }
        }

        return false;
    }

    /**
     * verifica se o term esta presente no titulo, descricao ou tag da listagem de midia publica. O jsonArray e o
     * elemento list
     * 
     * @param jsonArray
     * @param term
     * @return boolean
     * @throws JSONException
     */
    public static boolean containsTerms(JSONArray jsonArray, String term) throws JSONException
    {
        int numberQuotes = StringUtils.countOccurrencesOf(term, "\"");

        if (numberQuotes == 2)
        {
            String pattern = "^\"(.*?)\"$";
            Pattern r = Pattern.compile(pattern);
            Matcher m = r.matcher(term);

            if (m.find())
            {
                term = term.replaceAll("\"", "");
            }
        }

        for (int i = 0; i < jsonArray.length(); i++)
        {
            if (TestUtil.strContains(jsonArray.getJSONObject(i).getString("title"), term)
                    || TestUtil.strContains(jsonArray.getJSONObject(i).getString("title"), TestUtil.noGenre(term))
                    || TestUtil.strContains(jsonArray.getJSONObject(i).getString("title"), StringUtil.toUTF8(term)))
            {
                return true;
            }

            if (jsonArray.getJSONObject(i).has("description"))
            {
                if (TestUtil.strContains(jsonArray.getJSONObject(i).getString("description"), term)
                        || TestUtil.strContains(jsonArray.getJSONObject(i).getString("description"),
                            TestUtil.noGenre(term))
                        || TestUtil.strContains(jsonArray.getJSONObject(i).getString("description"),
                            StringUtil.toUTF8(term)))
                {
                    return true;
                }
            }

            for (int j = 0; j < jsonArray.getJSONObject(i).getJSONArray("tags").length(); j++)
            {
                if (TestUtil.strContains(
                    jsonArray.getJSONObject(i).getJSONArray("tags").getJSONObject(j).getString("description"), term)
                        || TestUtil.strContains(
                            jsonArray.getJSONObject(i).getJSONArray("tags").getJSONObject(j).getString("description"),
                            TestUtil.noGenre(term))
                        || TestUtil.strContains(
                            jsonArray.getJSONObject(i).getJSONArray("tags").getJSONObject(j).getString("description"),
                            StringUtil.toUTF8(term)))
                {
                    return true;
                }
            }

            if (TestUtil.strContains(jsonArray.getJSONObject(i).getString("author"), term)
                    || TestUtil.strContains(jsonArray.getJSONObject(i).getString("author"), TestUtil.noGenre(term))
                    || TestUtil.strContains(jsonArray.getJSONObject(i).getString("author"), StringUtil.toUTF8(term)))
            {
                return true;
            }
        }

        return false;
    }

    /**
     * verifica se tagName esta no jsonarray
     * 
     * @param jsonTagArray
     * @param tagName
     * @return boolean
     * @throws JSONException
     */
    public static boolean containsTagName(JSONArray jsonTagArray, String tagName) throws JSONException
    {
        for (int i = 0; i < jsonTagArray.length(); i++)
        {
            if (jsonTagArray.getJSONObject(i).getString("description").equals(tagName))
            {
                return true;
            }
        }

        return false;
    }

    /**
     * verifica se tagId esta no jsonarray
     * 
     * @param jsonTagArray
     * @param tagId
     * @return boolean
     * @throws JSONException
     */
    public static boolean containsTagId(JSONArray jsonTagArray, int tagId) throws JSONException
    {
        for (int i = 0; i < jsonTagArray.length(); i++)
        {
            if (jsonTagArray.getJSONObject(i).getInt("id") == tagId)
            {
                return true;
            }
        }

        return false;
    }

    /**
     * verifica valor sem definicao(variavek nao definida) no json de template
     * 
     * @param jsonResponse
     * @param noValidate
     * @throws JSONException
     */
    public static void validateValueJson(JSONObject jsonResponse, String[] noValidate) throws JSONException
    {
        for (int i = 0; i < jsonResponse.names().length(); i++)
        {
            if (!ArrayUtils.contains(noValidate, jsonResponse.names().getString(i))
                    && !jsonResponse.get(jsonResponse.names().getString(i)).toString().contains("R$")
                    && (jsonResponse.get(jsonResponse.names().getString(i)).toString().startsWith("$")
                            || jsonResponse.get(jsonResponse.names().getString(i)).toString().contains("${")))
            {
                throw new JSONException(
                        "invalid value json. Variable not defined (key " + jsonResponse.names().getString(i) + " value "
                                + jsonResponse.get(jsonResponse.names().getString(i)) + ")");
            }
        }
    }

    /**
     * uma midia vinda da api de listagem
     * 
     * {"title":"titulo","id":"titulo-04029C3362C4890366","mediaId":3011139, "url":
     * "http://mais.uol.com.br/view/78oudicj60ka/titulo-04029C3362C4890366?types=A&amp;"
     * ,"mediaType":"V","indVisibility": "T","moderateNote":false,"allowAnonymousComment"
     * :false,"allowNotes":"T","edFilter" :"editorial","thumbnail":"http://thumb.mais.uol.com.br/3011139"
     * ,"thumbSmall":"http://thumb.mais.uol.com.br/3011139-small.jpg?ver=1"
     * ,"thumbMedium":"http://thumb.mais.uol.com.br/3011139-medium.jpg?ver=1"
     * ,"thumbLarge":"http://thumb.mais.uol.com.br/3011139-large.jpg?ver=1"
     * ,"thumbWmedium":"http://thumb.mais.uol.com.br/3011139-wmedium.jpg?ver=1"
     * ,"thumbWlarge":"http://thumb.mais.uol.com.br/3011139-wlarge.jpg?ver=1"
     * ,"player":"http://player.mais.uol.com.br/player_video_v5.swf"
     * ,"duration":"0:39","numThumbnailIdentifier":3,"thumbVersion"
     * :1,"idtProductList":[],"formats":[2,6,8,9],"description" :"15758293","adultContent":false,"author":"teste
     * mais","authorPage" :
     * "http://mais.uol.com.br/content.html?types=A&amp;action=contentsFromAuthor&amp;codProfile=78oudicj60ka"
     * ,"codProfile" :"78oudicj60ka","views":4,"comments":0,"favorites":1,"rating"
     * :4,"votes":2,"publishedAt":"2016-02-05 09:05:29" ,"blockEmbed":false,"subscriberMedia":false,"embedCode":
     * "<object width=\"457\" height=\"368\" id=\"player_3011139\"
     * classid=\"clsid:D27CDB6E-AE6D-11cf-96B8-444553540000\" ><param name=\"allowFullScreenInteractive\" value=\"true\"
     * /><param value=\"true\" name=\"allowfullscreen\"/><param
     * value=\"http://player.mais.uol.com.br/player_video_v5.swf?mediaId=3011139&ver=1\" name=\"movie\"/><param
     * value=\"always\" name=\"allowscriptaccess\"/><param value=\"window\" name=\"wmode\"/><embed id=\"player_3011139\"
     * allowFullScreenInteractive=\"true\" width=\"457\" height=\"368\" type=\"application/x-shockwave-flash\"
     * allowscriptaccess=\"always\" allowfullscreen=\"true\"
     * src=\"http://player.mais.uol.com.br/player_video_v5.swf?mediaId=3011139&ver=1\" wmode=\"window\"
     * /></embed><noscript><a href=\"http://mais.uol.com.br/view/3011139\">Zidane e Cristiano Ronaldo fazem tabelinha em
     * treino</a></noscript></object>" ,"idtTagService":"1010","idtSubject":0,"tags":[{"id":322,"description":
     * "esporte"},{"id":8644285,"description": "aplicativo noticias"}]}
     * 
     * @param types
     * @return JSONObject
     * @throws JSONException
     */
    public static JSONObject apiMedia(String types) throws JSONException
    {
        String paramTypes = (types != null ? "types=" + types + "&" : "");
        String url = "http://mais.uol.com.br/apiuol/v2/media/list?" + paramTypes;
        JSONObject mediaList = JsonRequest.get(url + "&nocache=" + Math.random());

        if (mediaList.getJSONArray("list").length() > 0)
        {
            return mediaList.getJSONArray("list").getJSONObject(0);
        }

        return null;
    }

    /**
     * midia sem restricao por meio de api
     * 
     * @param types
     * @return JSONObject
     * @throws JSONException
     */
    public static JSONObject mediaNoRestrict(String types) throws JSONException
    {
        String paramTypes = (types != null ? "types=" + types + "&" : "");
        int page = 1;
        String url = "http://mais.uol.com.br/apiuol/v2/media/list?" + paramTypes + "index.currentPage=";
        JSONObject mediaList = JsonRequest.get(url + page + "&nocache=" + Math.random());

        while (mediaList != null && mediaList.has("list") && mediaList.getJSONArray("list").length() > 0)
        {
            for (int i = 0; i < mediaList.getJSONArray("list").length(); i++)
            {
                if (!mediaList.getJSONArray("list").getJSONObject(i).getBoolean("subscriberMedia")
                        && ((mediaList.getJSONArray("list").getJSONObject(i).has("idtProductList") && mediaList
                                .getJSONArray("list").getJSONObject(i).getJSONArray("idtProductList").length() < 1)
                                || !mediaList.getJSONArray("list").getJSONObject(i).has("idtProductList"))
                        && JsonUtil.isAllowed(mediaList.getJSONArray("list").getJSONObject(i).getLong("mediaId")))
                {
                    return mediaList.getJSONArray("list").getJSONObject(i);
                }
            }

            page++;
            mediaList = JsonRequest.get(url + page + "&nocache=" + Math.random());
        }

        return null;
    }

    /**
     * midia sem restricao por meio de api com parametro
     * 
     * @param queryString
     * @return JSONObject
     * @throws JSONException
     */
    public static JSONObject mediaNoRestrictByParam(String queryString) throws JSONException
    {
        int page = 1;
        String url = "http://mais.uol.com.br/apiuol/v2/media/list?" + (queryString != null ? queryString + "&" : "")
                + "index.currentPage=";
        JSONObject mediaList = JsonRequest.get(url + page + "&nocache=" + Math.random());

        while (mediaList != null && mediaList.has("list") && mediaList.getJSONArray("list").length() > 0)
        {
            for (int i = 0; i < mediaList.getJSONArray("list").length(); i++)
            {
                if (!mediaList.getJSONArray("list").getJSONObject(i).getBoolean("subscriberMedia")
                        && ((mediaList.getJSONArray("list").getJSONObject(i).has("idtProductList") && mediaList
                                .getJSONArray("list").getJSONObject(i).getJSONArray("idtProductList").length() < 1)
                                || !mediaList.getJSONArray("list").getJSONObject(i).has("idtProductList"))
                        && JsonUtil.isAllowed(mediaList.getJSONArray("list").getJSONObject(i).getLong("mediaId")))
                {
                    return mediaList.getJSONArray("list").getJSONObject(i);
                }
            }

            page++;
            mediaList = JsonRequest.get(url + page + "&nocache=" + Math.random());
        }

        return null;
    }

    /**
     * verifica se midia esta disponivel por meio de api
     * 
     * @param mediaId
     * @return JSONObject
     * @throws JSONException
     */
    public static boolean isAllowed(Long mediaId) throws JSONException
    {
        JSONObject media = JsonRequest.get(
            "http://mais.uol.com.br/apiuol/v2/media/detail.json?mediaId=" + mediaId + "&nocache=" + Math.random());

        if (media.has("content") && media.getJSONObject("content").has("media")
                && "N".equals(media.getJSONObject("content").getJSONObject("media").getString("indHot"))
                && 10 == media.getJSONObject("content").getJSONObject("media").getInt("codStatus")
                && "T".equals(media.getJSONObject("content").getJSONObject("media").getString("indVisibility"))
                && media.getJSONObject("content").getJSONObject("media").getInt("flgDraft") == 0)
        {
            return true;
        }

        return false;
    }

    /**
     * codProfile por meio de api
     * 
     * @return String
     * @throws JSONException
     */
    public static String codProfile() throws JSONException
    {
        JSONObject mediaList = JsonRequest.get("http://mais.uol.com.br/apiuol/v2/media/list?&nocache=" + Math.random());

        if (mediaList.getJSONArray("list").length() > 0)
        {
            return mediaList.getJSONArray("list").getJSONObject(0).getString("codProfile");
        }

        return null;
    }

    /**
     * tags por meio de api
     * 
     * @param onlyOne
     * @return JSONArray
     * @throws JSONException
     */
    public static JSONArray tags(boolean onlyOne) throws JSONException
    {
        int page = 1;
        String url = "http://mais.uol.com.br/apiuol/v2/media/list?index.currentPage=" + page;
        JSONObject mediaList = JsonRequest.get(url);

        while (mediaList != null && mediaList.getJSONArray("list").length() > 0)
        {
            for (int i = 0; i < mediaList.getJSONArray("list").length(); i++)
            {
                if (onlyOne)
                {
                    if (mediaList.getJSONArray("list").getJSONObject(i).getJSONArray("tags").length() > 0)
                    {
                        return mediaList.getJSONArray("list").getJSONObject(i).getJSONArray("tags");
                    }
                }
                else
                {
                    if (mediaList.getJSONArray("list").getJSONObject(i).getJSONArray("tags").length() > 1)
                    {
                        return mediaList.getJSONArray("list").getJSONObject(i).getJSONArray("tags");
                    }
                }
            }

            page++;
            mediaList = JsonRequest.get(url + page);
        }

        return null;
    }

    /**
     * tagservice por meio de api
     * 
     * @param onlyOne
     * @return String
     * @throws JSONException
     */
    public static String tagService(boolean onlyOne) throws JSONException
    {
        String tagService;
        int page = 1;
        String url = "http://mais.uol.com.br/apiuol/v2/media/list?index.currentPage=";
        JSONObject mediaList = JsonRequest.get(url + page + "&nocache=" + Math.random());

        while (mediaList.getJSONArray("list").length() > 0)
        {
            for (int i = 0; i < mediaList.getJSONArray("list").length(); i++)
            {
                tagService = mediaList.getJSONArray("list").getJSONObject(i).getString("idtTagService");

                if (onlyOne)
                {
                    if (!tagService.contains(",") && !tagService.isEmpty())
                    {
                        return tagService;
                    }
                }
                else
                {
                    if (tagService.contains(",") && tagService.split(",").length > 1)
                    {
                        return tagService;
                    }
                }
            }

            page++;
            mediaList = JsonRequest.get(url + page + "&nocache=" + Math.random());
        }

        return null;
    }

    /**
     * tag por nome
     * 
     * {"dat_last_use":"2008-07-01 10:56:09.0","num_used":"3","des_tag":"x","idt_tag":"378"}
     * 
     * @param desTag
     * @return JSONObject
     * @throws Exception
     */
    public static JSONArray tag(String desTag) throws Exception
    {
        String query = "SELECT * FROM tag WHERE des_tag = '" + desTag + "'";
        JSONObject result = JsonRequest.execQuery(query);

        if (result != null && result.has("data") && result.getJSONArray("data").length() > 0)
        {
            return result.getJSONArray("data").getJSONArray(0);
        }

        return null;
    }

    /**
     * dados de um file
     * 
     * {"num_server":"0","cod_status":"21","idt_file":"1"}
     * 
     * @param fileId
     * @return JSONObject
     * @throws Exception
     */
    public static JSONObject file(String fileId) throws Exception
    {
        String query = "SELECT idt_file, cod_status, num_server FROM file WHERE idt_file = " + fileId;
        JSONObject result = JsonRequest.execQuery(query);

        if (result != null && result.getJSONArray("data").length() > 0)
        {
            return jsonArrayToObject(result.getJSONArray("columns"), result.getJSONArray("data").getJSONArray(0));
        }

        return null;
    }

    /**
     * dados de media e de seu file
     * 
     * {"file_status":"10","idt_media":"2997511","num_server":"7", "ind_media_type":"V","cod_status":"10","idt_file":
     * "42340"}
     * 
     * @param mediaId
     * @return JSONObject
     * @throws Exception
     */
    public static JSONObject mediaFile(String mediaId) throws Exception
    {
        String query = "SELECT m.idt_media, m.cod_status, m.ind_media_type, f.idt_file, f.num_server, f.cod_status file_status "
                + "FROM media m LEFT JOIN file f ON f.idt_file = m.idt_file WHERE m.idt_media = " + mediaId;
        JSONObject result = JsonRequest.execQuery(query);

        if (result != null && result.getJSONArray("data").length() > 0)
        {
            return jsonArrayToObject(result.getJSONArray("columns"), result.getJSONArray("data").getJSONArray(0));
        }

        return null;
    }

    /**
     * media com/sem idtSubject(id de comentario do babel)
     * 
     * {"idt_media":"2989199","idt_subject":"21897638"}
     * 
     * @param withIdtSubject
     * @return JSONObject
     * @throws Exception
     */
    public static JSONObject mediaIdtSubject(boolean withIdtSubject) throws Exception
    {
        String query = "SELECT idt_media,idt_subject FROM media WHERE cod_status = 10 AND idt_subject "
                + (withIdtSubject ? ">" : "<=") + " 0 LIMIT 1";

        JSONObject result = JsonRequest.execQuery(query);

        return result;
    }

    /**
     * media
     * 
     * {"ind_visibility":"T","idt_media":"207366","flg_draft":"0", "ind_media_type":"V","cod_profile_hash":
     * "2464350640667993250","ind_hot":"N" ,"cod_status":"10","cod_editorial_status":"2","idt_file":"23453"}
     * 
     * @param mediaId
     * @return JSONObject
     * @throws Exception
     */
    public static JSONObject media(String mediaId) throws Exception
    {
        String query = "SELECT idt_media,cod_status,ind_hot,cod_editorial_status,flg_draft,ind_media_type,ind_visibility,cod_profile_hash,idt_file "
                + "FROM media WHERE idt_media = " + mediaId;
        JSONObject result = JsonRequest.execQuery(query);

        if (result != null && result.getJSONArray("data").length() > 0)
        {
            return jsonArrayToObject(result.getJSONArray("columns"), result.getJSONArray("data").getJSONArray(0));
        }

        return null;
    }

    /***
     * Transforma o json array em um json object
     * 
     * @param jsonColumns
     * @param jsonData
     * @return JSONObject
     * @throws JSONException
     */
    public static JSONObject jsonArrayToObject(JSONArray jsonColumns, JSONArray jsonData) throws JSONException
    {
        JSONObject jsonObject = new JSONObject();
        for (int i = 0; i < jsonData.length(); i++)
        {
            jsonObject.put(jsonColumns.getString(i), jsonData.get(i));
        }
        return jsonObject;
    }

    /**
     * full media
     * 
     * {"flg_draft":"0","num_sumarize_views_per_day":"1","ind_hot":"N", "des_hostname":"d3-uolmais-stg4.host.intranet",
     * "ind_authorized_lists":"T", "ind_visibility":"T","nam_subject":"Riders Match"
     * ,"flg_block_embed":"0","dat_first_view_per_day" :"2015-09-01 14:57:01.0","cod_ip":"172.22.32.157",
     * "cod_profile_hash":"2464350640667993250","num_sum_vote":"0","idt_media"
     * :"207366","num_favorited":"0","num_total_vote":"0","idt_subject":"0",
     * "flg_send_newsfeed":"1","num_process_retry": "0","cod_status":"10","dat_featured"
     * :null,"flg_default_config":"0","dat_published":"2015-08-18 15:51:12.0", "num_comments"
     * :"0","flg_featured":"0","des_media": "Best Of Hottest Extreme Sports Girls - 2013","ind_media_type":"V"
     * ,"dat_last_view":"2015-09-01 14:57:01.0", "dat_first_view_per_time":"2015-09-01
     * 14:57:01.0","cod_block_reason":null ,"num_average_vote":"0","flg_bypass":"0","des_extra_information":"",
     * "cod_hash_in":"d3f74c9e72ee06cbf7796e67d161319d" ,"dat_last_update":"2015-08-18 15:50:00.0"
     * ,"flg_subscriber_media":"0","num_honors":"0", "ind_allow_notes":"T","des_idt_tag_service"
     * :null,"flg_notify_comment":"1" ,"num_temporary_server":"35","num_albums":"0","ind_media_protection":"A",
     * "idt_file" :"173520","num_views":"14","info_external":null,"flg_send_notification"
     * :"0","ind_indexing_status":"0", "num_sumarize_views_per_time":"1", "dat_publish_scheduling" :"2015-08-18
     * 15:50:00.0","cod_editorial_status":"2"}
     * 
     * @param mediaId
     * @return JSONObject
     * @throws Exception
     */
    public static JSONObject fullMedia(String mediaId) throws Exception
    {
        String query = "SELECT * FROM media WHERE idt_media = " + mediaId;
        JSONObject result = JsonRequest.execQuery(query);

        if (result != null && result.getJSONArray("data").length() > 0)
        {
            return jsonArrayToObject(result.getJSONArray("columns"), result.getJSONArray("data").getJSONArray(0));
        }

        return null;
    }

    /**
     * dados de uma midia publica por tipo
     * 
     * {"idt_media":"3001414","ind_media_type":"V"}
     * 
     * @param types
     * @return JSONObject
     * @throws Exception
     */
    public static JSONObject mediaPublic(String types) throws Exception
    {
        String query = "SELECT m.idt_media,m.ind_media_type FROM media m LEFT JOIN media_product mp ON mp.idt_media = m.idt_media "
                + "LEFT JOIN media_country mc ON mc.idt_media = m.idt_media WHERE m.cod_status = 10 AND m.ind_visibility = 'T' "
                + "AND m.ind_hot = 'N' "
                + (types != null ? "AND m.ind_media_type IN ('" + types.replaceAll(",", "','") + "')" : "")
                + " AND m.flg_draft = 0 AND m.flg_subscriber_media = 0 "
                + "AND mp.idt_product IS NULL AND mc.cod_iso_country IS NULL AND m.dat_publish_scheduling <= now() ORDER BY m.idt_media DESC LIMIT 1";

        JSONObject result = JsonRequest.execQuery(query);

        if (result != null && result.has("data") && result.getJSONArray("data").length() > 0)
        {
            return jsonArrayToObject(result.getJSONArray("columns"), result.getJSONArray("data").getJSONArray(0));
        }

        return null;
    }

    /**
     * dados de uma midia
     * 
     * {"idt_media":"3001413","cod_profile_hash":"953124325347642202"}
     * 
     * @param status
     * @param type
     * @param visibility
     * @param draft
     * @param subscriber
     * @param hot
     * @param geoip
     * @param product
     * @return JSONObject
     * @throws Exception
     */
    public static JSONObject media(int status, String type, String visibility, boolean draft, boolean subscriber,
            boolean hot, boolean geoip, boolean product) throws Exception
    {
        String query = "SELECT m.idt_media,m.cod_profile_hash FROM media m LEFT JOIN media_product mp ON mp.idt_media = m.idt_media "
                + "LEFT JOIN media_country mc ON mc.idt_media = m.idt_media " + "WHERE m.cod_status = " + status
                + " AND m.ind_hot IN (" + (hot ? "'U','P'" : "'N'") + ") " + "AND m.flg_draft = " + (draft ? "1" : 0)
                + " AND m.ind_visibility = '" + visibility + "' AND m.ind_media_type = '" + type
                + "' AND m.flg_subscriber_media = " + (subscriber ? "1" : "0") + " AND mc.cod_iso_country IS "
                + (geoip ? "NOT " : "") + "NULL " + "AND mp.idt_product IS " + (product ? "NOT " : "")
                + "NULL ORDER BY idt_media DESC LIMIT 1";

        JSONObject result = JsonRequest.execQuery(query);

        if (result != null && result.getJSONArray("data").length() > 0)
        {
            return jsonArrayToObject(result.getJSONArray("columns"), result.getJSONArray("data").getJSONArray(0));
        }

        return null;
    }

    /**
     * dados decorados de uma midia
     * 
     * {"id":"-0402993168C4810366","codProfile":"78oudicj60ka","idt_media": "3001413","cod_profile_hash":
     * "953124325347642202"}
     * 
     * @param status
     * @param type
     * @param visibility
     * @param draft
     * @param subscriber
     * @param hot
     * @param geoip
     * @param product
     * @return JSONObject
     * @throws Exception
     */

    public static JSONObject mediaDecored(int status, String type, String visibility, boolean draft, boolean subscriber,
            boolean hot, boolean geoip, boolean product) throws Exception
    {
        JSONObject media = media(status, type, visibility, draft, subscriber, hot, geoip, product);

        if (media != null)
        {
            media.put("id", MediaUtil.mediaToUrlHash(Long.valueOf(media.getString("idt_media")), ""));
            media.put("codProfile", HashCode.decode(Long.valueOf(media.getString("cod_profile_hash"))));
        }

        return media;
    }

    /**
     * jsonarray da pagina com os dados
     * 
     * [{"idt_media":"207004","ind_media_type":"S","cod_profile_hash": "3961374576122549130"},{"idt_media":"207001",
     * "ind_media_type":"T","cod_profile_hash":"3961374576122549130"}]
     * 
     * @param start
     * @param limit
     * @return JSONArray
     * @throws Exception
     */
    public static JSONArray mediaPaging(int start, int limit) throws Exception
    {
        String query = "SELECT idt_media, ind_media_type, cod_profile_hash FROM media WHERE cod_status = 10 ORDER BY idt_media DESC LIMIT "
                + start + "," + limit;

        JSONObject result = JsonRequest.execQuery(query);

        if (result != null && result.getJSONArray("data").length() > 0)
        {
            return dataJsonArray(result.getJSONArray("columns"), result.getJSONArray("data"));
        }

        return null;
    }

    /**
     * jsonarray da pagina com os dados
     * 
     * [{"idt_media":"207004","ind_media_type":"S","cod_profile_hash": "3961374576122549130"},{"idt_media":"207001",
     * "ind_media_type":"T","cod_profile_hash":"3961374576122549130"}]
     * 
     * @param start
     * @param limit
     * @return JSONArray
     * @throws Exception
     */
    public static JSONObject mediaPublicPaging(String types, int start, int limit) throws Exception
    {
        String query = "SELECT m.idt_media, m.ind_media_type, m.cod_profile_hash FROM media m "
                + "LEFT JOIN media_product mp ON mp.idt_media = m.idt_media "
                + "LEFT JOIN media_country mc ON mc.idt_media = m.idt_media WHERE m.cod_status = 10 AND m.ind_visibility = 'T' "
                + "AND m.ind_hot = 'N' "
                + (types != null ? "AND m.ind_media_type IN ('" + types.replaceAll(",", "','") + "')" : "")
                + " AND m.flg_draft = 0 AND m.flg_subscriber_media = 0 AND mp.idt_product IS NULL AND mc.cod_iso_country IS NULL "
                + "AND m.dat_publish_scheduling <= now() ORDER BY m.idt_media DESC LIMIT " + start + "," + limit;

        JSONObject result = JsonRequest.execQuery(query);

        if (result != null && result.getJSONArray("data").length() > 0)
        {
            return result;
        }

        return null;
    }

    /**
     * jsonarray da pagina com codProfileHash
     * 
     * [{"cod_profile_hash":"572023393103477806"},{"cod_profile_hash": "3495691416887435465"},{"cod_profile_hash":
     * "2351627037787421845"}]
     * 
     * @param start
     * @param limit
     * @return JSONArray
     * @throws Exception
     */
    public static JSONArray codProfileHashPaging(int start, int limit) throws Exception
    {
        String query = "SELECT DISTINCT cod_profile_hash FROM media WHERE cod_status < 23 ORDER BY idt_media DESC LIMIT "
                + start + "," + limit;

        JSONObject result = JsonRequest.execQuery(query);

        if (result != null && result.getJSONArray("data").length() > 0)
        {
            return dataJsonArray(result.getJSONArray("columns"), result.getJSONArray("data"));
        }

        return null;
    }

    /***
     * Retorna um jsonArray com jsonObjects com a informações de cada midia
     * 
     * @param columns
     * @param data
     * @return JSONArray
     * @throws Exception
     */
    public static JSONArray dataJsonArray(JSONArray columns, JSONArray data) throws Exception
    {
        JSONArray json = new JSONArray();
        for (int i = 0; i < data.length(); i++)
        {
            json.put(jsonArrayToObject(columns, data.getJSONArray(i)));
        }
        return json;
    }

    /**
     * playlist do usuario
     * 
     * {"dat_creation":"2014-06-13 16:06:21.0","ind_visibility":"N","num_medias"
     * :"0","des_playlist":null,"nam_playlist": "playlist140613160623528","num_friends_medias"
     * :"0","cod_profile_hash":"953124325347642202","idt_playlist":"557"}
     * 
     * @param codProfileHash
     * @param minMedias max 100
     * @return JSONObject
     * @throws Exception
     */
    public static JSONObject playlist(Long codProfileHash, int minMedias) throws Exception
    {
        String query = "SELECT idt_playlist, cod_profile_hash, ind_visibility, num_medias FROM playlist WHERE cod_profile_hash = "
                + codProfileHash + " AND num_medias BETWEEN " + minMedias
                + " AND 99 ORDER BY idt_playlist DESC LIMIT 1";
        JSONObject result = JsonRequest.execQuery(query);

        if (result != null && result.has("data") && result.getJSONArray("data").length() > 0)
        {
            return jsonArrayToObject(result.getJSONArray("columns"), result.getJSONArray("data").getJSONArray(0));
        }

        return null;
    }

    /**
     * jsonarray de playlists com limite
     * 
     * [{"cod_profile_hash":"953124325347642202","idt_playlist":"1505"},...,{ "cod_profile_hash":"953124325347642202",
     * "idt_playlist":"1504"}]
     * 
     * @param limit
     * @return JSONArray
     * @throws Exception
     */
    public static JSONArray playlists(int limit) throws Exception
    {
        String query = "SELECT idt_playlist, cod_profile_hash FROM playlist WHERE ind_visibility = 'T' ORDER BY idt_playlist DESC LIMIT "
                + limit;
        JSONObject result = JsonRequest.execQuery(query);

        if (result != null && result.getJSONArray("data").length() > 0)
        {
            return dataJsonArray(result.getJSONArray("columns"), result.getJSONArray("data"));
        }

        return null;
    }

    /**
     * playlist
     * 
     * {"ind_visibility":"N","num_medias":"0","cod_profile_hash": "953124325347642202","idt_playlist":"557"}
     * 
     * @param playlistId
     * @return JSONObject
     * @throws Exception
     */
    public static JSONObject playlist(String playlistId) throws Exception
    {
        String query = "SELECT idt_playlist, cod_profile_hash, ind_visibility, num_medias FROM playlist WHERE idt_playlist = "
                + playlistId;
        JSONObject result = JsonRequest.execQuery(query);

        if (result != null && result.has("data") && result.getJSONArray("data").length() > 0)
        {
            return jsonArrayToObject(result.getJSONArray("columns"), result.getJSONArray("data").getJSONArray(0));
        }

        return null;
    }

    /**
     * playlistMedia
     * 
     * {"idt_media":"2989269","num_position":"5","idt_playlist":"375"}
     * 
     * @param playlistId
     * @param mediaId
     * @return JSONObject
     * @throws Exception
     */
    public static JSONObject playlistMedia(String playlistId, String mediaId) throws Exception
    {
        String query = "SELECT idt_playlist,idt_media,num_position FROM media_playlist WHERE idt_playlist = "
                + playlistId + " AND idt_media = " + mediaId;
        JSONObject result = JsonRequest.execQuery(query);

        if (result != null && result.has("data") && result.getJSONArray("data").length() > 0)
        {
            return jsonArrayToObject(result.getJSONArray("columns"), result.getJSONArray("data").getJSONArray(0));
        }

        return null;
    }

    /**
     * playlistMedia
     * 
     * {"idt_media":"2989269","num_position":"5","idt_playlist":"375"}
     * 
     * @param playlistId
     * @return JSONObject
     * @throws Exception
     */
    public static JSONObject playlistMedia(String playlistId) throws Exception
    {
        String query = "SELECT idt_playlist,idt_media,num_position FROM media_playlist WHERE idt_playlist = "
                + playlistId + " ORDER BY num_position DESC LIMIT 1";
        JSONObject result = JsonRequest.execQuery(query);

        if (result != null && result.has("data") && result.getJSONArray("data").length() > 0)
        {
            return jsonArrayToObject(result.getJSONArray("columns"), result.getJSONArray("data").getJSONArray(0));
        }

        return null;
    }

    /**
     * followable
     * 
     * {"tags":"1,1010","idt_followable":"2","flg_editorial":"0", "flg_manual_registered":"1","cod_profile_hash":null,
     * "flg_and":"0","num_subscription_quantity" :"1","des_followable":"des Followable","idt_editor_type":"1"}
     * 
     * @return JSONObject
     * @throws Exception
     */
    public static JSONObject followable() throws Exception
    {
        String query = "SELECT f.*, GROUP_CONCAT(DISTINCT ft.idt_tag SEPARATOR ',') as tags, ft.flg_editorial FROM followable f "
                + "LEFT JOIN followable_tag ft ON f.idt_followable = ft.idt_followable GROUP BY f.idt_followable ORDER BY f.idt_followable DESC LIMIT 1";
        JSONObject result = JsonRequest.execQuery(query);

        if (result != null && result.has("data") && result.getJSONArray("data").length() > 0)
        {
            return jsonArrayToObject(result.getJSONArray("columns"), result.getJSONArray("data").getJSONArray(0));
        }

        return null;
    }
}
