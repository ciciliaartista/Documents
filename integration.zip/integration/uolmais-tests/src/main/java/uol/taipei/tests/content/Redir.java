/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         14/01/2016 Criacao inicial
 */

package uol.taipei.tests.content;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uol.taipei.request.FacileRequest;
import uol.taipei.request.FacileResponse;
import uol.taipei.request.JsonRequest;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.util.JsonUtil;
import uol.taipei.tests.util.RequestUtil;
import uol.taipei.webServiceClient.ProfileUrl;
import uol.taipei.webServiceClient.wsManager.WsProfileManager;

public class Redir extends AbstractTest
{
    static final Logger logger = LoggerFactory.getLogger(Redir.class);

    private WsProfileManager wsProfileManager = new WsProfileManager(10, 10);

    public static void main(String[] args)
    {
        if (!verifyParams(args))
        {
            return;
        }

        setUp(args[0]);

        logger.debug("-------------------------------------------------");
        logger.debug("tests servlet redir");

        try
        {
            Redir redir = new Redir();

            redir.mediaId();
            redir.perfilUrl();
        }
        catch (Exception e) 
        {
            logger.error(e.getMessage());            
        }
    }

    /**
     * servlet de redir a partir de mediaId. 
     * O hash e encodado em base62, exemplo de url encurtada http://tv.uol/Cal2 o 302 leva para http://tvuol.uol.com.br/video/-04021B3364C4810366
     * 
     * @param request
     * @return boolean
     * @throws Exception
     */
    public boolean mediaId() throws Exception
    {
        FacileRequest request = new FacileRequest();
        request.setFollowRedirects(false);

        String mediaId = RequestUtil.mediaIdPublic("V");
        JSONObject media = JsonRequest.get("http://mais.uol.com.br/apiuol/v3/player/getMedia/" + mediaId);
        FacileResponse response = request.get(media.getJSONObject("item").getString("shareUrl"));

        if (response.getCode() != 302)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " 
                    + media.getJSONObject("item").getString("shareUrl"));
            return false;
        }

        if (!request.getConn().getHeaderField("Location").matches("(http:\\/\\/)?tvuol\\.uol\\.com\\.br\\/video\\/(.*)" 
                + media.getJSONObject("item").getString("mediaHashUrl").substring(media.getJSONObject("item").getString("mediaHashUrl").lastIndexOf("-")) 
                + "(.*)"))
        {
            logger.error("ERROR - return not valid - " + request.getConn().getHeaderField("Location"));
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    /**
     * redir para pagina de lista de midias do usuario
     * 
     * http://mais.uol.com.br/usr/urlPerfil -> http://mais.uol.com.br/sys/content/author?codProfile=corProfilePerfil
     * 
     * @return boolean
     * @throws Exception
     */
    public boolean perfilUrl() throws Exception
    {
        FacileRequest request = new FacileRequest();
        request.setFollowRedirects(false);

        JSONObject profile = getProfileWithUrl();

        if (profile == null)
        {
            logger.error("ERROR - no profile found");
            return false;
        }

        FacileResponse response = request.get("http://mais.uol.com.br/usr/" + profile.getString("desUrlProfile"));

        if (response.getCode() != 302)
        {
            logger.error("ERROR - return not valid - " + response);
            return false;
        }

        if (!request.getConn().getHeaderField("Location").matches(
            "(http:\\/\\/)?mais\\.uol\\.com\\.br\\/sys\\/content\\/author(.*)?codProfile=" + profile.getString("codProfile") 
            + "(.*)"))
        {
            logger.error("ERROR - return not valid - " + request.getConn().getHeaderField("Location"));
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    private JSONObject getProfileWithUrl() throws Exception
    {
        JSONObject profile = null;
        int limit = 10;
        int start = 0;
        JSONArray jsonarray = JsonUtil.codProfileHashPaging(start, limit);

        while (jsonarray != null && jsonarray.length() > 0)
        {
            for (int i = 0; i < jsonarray.length(); i++)
            {
                profile = JsonUtil.publicProfile(Long.valueOf(jsonarray.getJSONObject(i).getString("cod_profile_hash")));

                if (profile.has("desUrlProfile") && !profile.isNull("desUrlProfile") 
                        && StringUtils.isNotBlank(profile.getString("desUrlProfile"))
                        && checkUrlProfile(profile.getString("desUrlProfile")))
                {
                    return profile;
                }
            }

            start+=limit;
            jsonarray = JsonUtil.codProfileHashPaging(start, limit);
        }

        return null;
    }

    private boolean checkUrlProfile(String urlCheck)
    {
        try
        {
            ProfileUrl profileUrl = wsProfileManager.verifyUrl(urlCheck);

            if (profileUrl != null)
            {
                return true;
            }

            return false;
        }
        catch (Exception e)
        {
            logger.error(e.getMessage(), e);

            return false;
        }
    }
}
