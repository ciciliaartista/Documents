package uol.taipei.tests.playlist;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpParams;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.LoginCookie;
import uol.taipei.tests.util.JsonUtil;
import uol.taipei.tests.util.TestUtil;
import uol.taipei.util.DateUtil;

public class ApiPlaylistErr extends AbstractTest
{
    static final Logger logger = LoggerFactory.getLogger(ApiPlaylistErr.class);

    static private final String apiUrl = "http://mais.uol.com.br/apiuol/v2/playlist";

    public static void main(String[] args)
    {
        if (!verifyParams(args))
        {
            return;
        }

        setUp(args[0]);

        if (envConfig().getUser() == null || envConfig().getUser().equals("") || envConfig().getPass() == null || envConfig().getPass().equals(""))
        {
            System.err.println("Invalid user " + envConfig().getUser());
            return;
        }

        logger.debug("-------------------------------------------------");
        logger.debug("tests api playlist err");

        try
        {
            ApiPlaylistErr apiPlaylistErr = new ApiPlaylistErr();
            LoginCookie login = new LoginCookie(envConfig().getUser(), envConfig().getPass());

            apiPlaylistErr.invalidUrl();
            apiPlaylistErr.detailWithoutParam();
            apiPlaylistErr.detailWithInvalidPlaylistId();
            apiPlaylistErr.listWithoutParam();
            apiPlaylistErr.listWithInvalidMedia(login.getJsonProfile().getJSONObject("item").getString("codProfile"));
            apiPlaylistErr.listWithInvalidIndexParam(login.getJsonProfile().getJSONObject("item").getString("codProfile"));
            apiPlaylistErr.createWithoutParam(login);
            apiPlaylistErr.updateWithInvalidPlaylistId(login);
            apiPlaylistErr.removeWithInvalidPlaylistId(login);
            apiPlaylistErr.listMediaWithInvalidPlaylistId(login);
            apiPlaylistErr.addMediaWithInvalidPlaylistId(login);
            apiPlaylistErr.moveMediaWithInvalidPlaylistId(login);
            apiPlaylistErr.removeMediaWithInvalidPlaylistId(login);
        }
        catch (Exception e)
        {
            logger.error(e.getMessage());
        }
    }

    private HttpResponse executeHttpGet(String url) throws IOException, JSONException
    {
        HttpClient client = new DefaultHttpClient();
        HttpParams params = new BasicHttpParams();
        params.setParameter("http.protocol.handle-redirects", false);

        HttpGet httpget = new HttpGet(url);
        httpget.setParams(params);
        HttpResponse response = client.execute(httpget);
        return response;
    }

    private boolean validateMessageJson(JSONObject json, char type)
    {
        try
        {
            json.getJSONObject("result");

            if (type == 'E')
            {
                json.getJSONObject("result").getJSONArray("errors");

                if (json.getJSONObject("result").getJSONArray("errors").length() < 1)
                {
                    throw new Exception("no has error message");
                }

                for (int i = 0; i < json.getJSONObject("result").getJSONArray("errors").length(); i++)
                {
                    json.getJSONObject("result").getJSONArray("errors").getJSONObject(i).getString("id");
                    json.getJSONObject("result").getJSONArray("errors").getJSONObject(i).getString("description");

                    JsonUtil.validateValueJson(json.getJSONObject("result").getJSONArray("errors").getJSONObject(i),
                        new String[] { "" });
                }
            }
            else if (type == 'W')
            {
                json.getJSONObject("result").getJSONArray("warns");

                if (json.getJSONObject("result").getJSONArray("warns").length() < 1)
                {
                    throw new Exception("no has warn message");
                }

                for (int i = 0; i < json.getJSONObject("result").getJSONArray("warns").length(); i++)
                {
                    json.getJSONObject("result").getJSONArray("warns").getJSONObject(i).getString("id");
                    json.getJSONObject("result").getJSONArray("warns").getJSONObject(i).getString("description");

                    JsonUtil.validateValueJson(json.getJSONObject("result").getJSONArray("warns").getJSONObject(i),
                        new String[] { "" });
                }
            }
            else
            {
                json.getJSONObject("result").getJSONArray("infos");

                if (json.getJSONObject("result").getJSONArray("infos").length() < 1)
                {
                    throw new Exception("no has info message");
                }

                for (int i = 0; i < json.getJSONObject("result").getJSONArray("infos").length(); i++)
                {
                    json.getJSONObject("result").getJSONArray("infos").getJSONObject(i).getString("id");
                    json.getJSONObject("result").getJSONArray("infos").getJSONObject(i).getString("description");

                    JsonUtil.validateValueJson(json.getJSONObject("result").getJSONArray("infos").getJSONObject(i),
                        new String[] { "" });
                }
            }

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - message invalid - " + e.getMessage() + " - " + json);
            return false;
        }
    }

    public boolean invalidUrl() throws IOException, JSONException
    {
        String url = apiUrl + "/";
        int responseCode = executeHttpGet(url).getStatusLine().getStatusCode();
        if (responseCode != HttpStatus.SC_NOT_FOUND)
        {
            logger.error("ERROR - return status not valid - " + responseCode + " - " + url);
            return false;
        }
        logger.debug("SUCCESS");
        return true;
    }

    public boolean detailWithoutParam() throws IOException, JSONException
    {
        String url = apiUrl + "/detail";
        int responseCode = executeHttpGet(url).getStatusLine().getStatusCode();
        if (responseCode != HttpStatus.SC_BAD_REQUEST)
        {
            logger.error("ERROR - return status not valid - " + responseCode + " - " + url);
            return false;
        }
        logger.debug("SUCCESS");
        return true;
    }

    public boolean detailWithInvalidPlaylistId() throws IOException, JSONException
    {
        String url = apiUrl + "/detail/x";
        int responseCode = executeHttpGet(url).getStatusLine().getStatusCode();
        if (responseCode != HttpStatus.SC_BAD_REQUEST)
        {
            logger.error("ERROR - return status not valid - " + responseCode + " - " + url);
            return false;
        }
        logger.debug("SUCCESS");
        return true;
    }

    public boolean listWithoutParam() throws IOException, JSONException
    {
        String url = apiUrl + "/list";
        int responseCode = executeHttpGet(url).getStatusLine().getStatusCode();
        if (responseCode != HttpStatus.SC_BAD_REQUEST)
        {
            logger.error("ERROR - return status not valid - " + responseCode + " - " + url);
            return false;
        }
        logger.debug("SUCCESS");
        return true;
    }

    public boolean listWithInvalidMedia(String codProfile) throws IOException, JSONException
    {
        String url = apiUrl + "/list/" + codProfile + "/x";
        int responseCode = executeHttpGet(url).getStatusLine().getStatusCode();
        if (responseCode != HttpStatus.SC_BAD_REQUEST)
        {
            logger.error("ERROR - return status not valid - " + responseCode + " - " + url);
            return false;
        }
        logger.debug("SUCCESS");
        return true;
    }

    public boolean listWithInvalidIndexParam(String codProfile) throws IOException, JSONException
    {
        String url = apiUrl + "/list?codProfile=" + codProfile + "&index.currentPage=x";
        int responseCode = executeHttpGet(url).getStatusLine().getStatusCode();
        if (responseCode != HttpStatus.SC_BAD_REQUEST)
        {
            logger.error("ERROR - return status not valid - " + responseCode + " - " + url);
            return false;
        }
        logger.debug("SUCCESS");
        return true;
    }

    public JSONObject createWithoutParam(LoginCookie login)
    {
        try
        {
            String url = apiUrl + "/create";
            HashMap<String, String> params = new HashMap<String, String>();
            login.isAuthenticated();

            JSONObject jsonResponse = login.postJson(url, params, null);

            if (jsonResponse.getJSONObject("_response").getInt("code") != HttpStatus.SC_BAD_REQUEST)
            {
                logger.error("ERROR - return status not valid - "
                        + jsonResponse.getJSONObject("_response").getInt("code") + " - " + url);
                return null;

            }
            else if (!validateMessageJson(jsonResponse, 'W'))
            {
                logger.error("ERROR - return not valid - " + jsonResponse);
                return null;
            }

            logger.debug("SUCCESS");

            return jsonResponse;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return null;
        }
    }

    public JSONObject updateWithInvalidPlaylistId(LoginCookie login) throws IOException, JSONException
    {

        try
        {
            login.isAuthenticated();
            String url = apiUrl + "/update?idtPlaylist=x&name=playlist" + TestUtil.generateUniqueString()
                    + "&visibility=N";
            HashMap<String, String> params = new HashMap<String, String>();
            params.put("idtPlaylist", "x");
            params.put("name", "playlist." + DateUtil.getDateString(new Date(), "yyyy-MM-dd_HH-mm-ss"));
            params.put("visibility", "N");

            JSONObject jsonResponse = login.postJson(url, params, null);

            if (jsonResponse.getJSONObject("_response").getInt("code") != HttpStatus.SC_BAD_REQUEST)
            {
                logger.error("ERROR - return status not valid - "
                        + jsonResponse.getJSONObject("_response").getInt("code") + " - " + url);
                return null;

            }
            else if (!validateMessageJson(jsonResponse, 'W'))
            {
                logger.error("ERROR - return not valid " + jsonResponse);
                return null;
            }
            logger.debug("SUCCESS");

            return jsonResponse;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return null;
        }
    }

    public JSONObject removeWithInvalidPlaylistId(LoginCookie login) throws IOException, JSONException
    {
        try
        {
            login.isAuthenticated();
            String url = apiUrl + "/remove?playlistId=x";
            JSONObject jsonResponse = login.getJson(url);

            if (jsonResponse.getJSONObject("_response").getInt("code") != HttpStatus.SC_BAD_REQUEST)
            {
                logger.error("ERROR - return status not valid - "
                        + jsonResponse.getJSONObject("_response").getInt("code") + " - " + url);
                return null;

            }
            else if (!validateMessageJson(jsonResponse, 'W'))
            {
                logger.error("ERROR - return not valid " + jsonResponse);
                return null;
            }

            logger.debug("SUCCESS");

            return jsonResponse;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return null;
        }
    }

    public JSONObject listMediaWithInvalidPlaylistId(LoginCookie login) throws IOException, JSONException
    {
        try
        {
            login.isAuthenticated();
            String url = apiUrl + "/media/list?playlistId=x";
            JSONObject jsonResponse = login.getJson(url);

            if (jsonResponse.getJSONObject("_response").getInt("code") != HttpStatus.SC_BAD_REQUEST)
            {
                logger.error("ERROR - return status not valid - "
                        + jsonResponse.getJSONObject("_response").getInt("code") + " - " + url);
                return null;

            }
            else if (!validateMessageJson(jsonResponse, 'W'))
            {
                logger.error("ERROR - return not valid " + jsonResponse);
                return null;
            }

            logger.debug("SUCCESS");

            return jsonResponse;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return null;
        }
    }

    public JSONObject addMediaWithInvalidPlaylistId(LoginCookie login) throws IOException, JSONException
    {
        try
        {
            login.isAuthenticated();
            String url = apiUrl + "/media/add?playlistId=x&mediaId=x";
            JSONObject jsonResponse = login.getjson(url);
            if (jsonResponse.getJSONObject("_response").getInt("code") != HttpStatus.SC_BAD_REQUEST)
            {
                logger.error("ERROR - return status not valid - "
                        + jsonResponse.getJSONObject("_response").getInt("code") + " - " + url);
                return null;

            }
            else if (!validateMessageJson(jsonResponse, 'W'))
            {
                logger.error("ERROR - return not valid " + jsonResponse);
                return null;
            }

            logger.debug("SUCCESS");

            return jsonResponse;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return null;
        }
    }

    public JSONObject moveMediaWithInvalidPlaylistId(LoginCookie login) throws IOException, JSONException
    {
        try
        {
            login.isAuthenticated();
            String url = apiUrl + "/media/move?playlistId=x&mediaId=x&from=0&to=1";
            JSONObject jsonResponse = login.getjson(url);

            if (jsonResponse.getJSONObject("_response").getInt("code") != HttpStatus.SC_BAD_REQUEST)
            {
                logger.error("ERROR - return status not valid - "
                        + jsonResponse.getJSONObject("_response").getInt("code") + " - " + url);
                return null;

            }
            else if (!validateMessageJson(jsonResponse, 'W'))
            {
                logger.error("ERROR - return not valid " + jsonResponse);
                return null;
            }

            logger.debug("SUCCESS");

            return jsonResponse;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return null;
        }
    }

    public JSONObject removeMediaWithInvalidPlaylistId(LoginCookie login) throws IOException, JSONException
    {
        try
        {
            login.isAuthenticated();
            String url = apiUrl + "/media/remove?playlistId=x&mediaId=x";
            JSONObject jsonResponse = login.getjson(url);

            if (jsonResponse.getJSONObject("_response").getInt("code") != HttpStatus.SC_BAD_REQUEST)
            {
                logger.error("ERROR - return status not valid - "
                        + jsonResponse.getJSONObject("_response").getInt("code") + " - " + url);
                return null;

            }
            else if (!validateMessageJson(jsonResponse, 'W'))
            {
                logger.error("ERROR - return not valid " + jsonResponse);
                return null;
            }

            logger.debug("SUCCESS");

            return jsonResponse;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return null;
        }
    }

}
