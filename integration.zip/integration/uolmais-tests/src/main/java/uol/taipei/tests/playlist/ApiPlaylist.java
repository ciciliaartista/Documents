/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         04/04/2014 Criacao inicial
 */

package uol.taipei.tests.playlist;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;

import org.apache.http.HttpStatus;
import org.apache.http.client.ClientProtocolException;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uol.taipei.request.JsonRequest;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.LoginCookie;
import uol.taipei.tests.util.JsonUtil;
import uol.taipei.tests.util.TestUtil;
import uol.taipei.util.DateUtil;
import uol.taipei.util.StringUtil;

public class ApiPlaylist extends AbstractTest
{
    static final Logger logger = LoggerFactory.getLogger(ApiPlaylist.class);

    public static void main(String[] args)
    {
        if (!verifyParams(args))
        {
            return;
        }

        setUp(args[0]);

        if (envConfig().getUser() == null || envConfig().getUser().equals("") || envConfig().getPass() == null || envConfig().getPass().equals(""))
        {
            System.err.println("Invalid user " + envConfig().getUser());
            return;
        }

        logger.debug("-------------------------------------------------");
        logger.debug("tests api playlist");

        try
        {
            ApiPlaylist apiPlaylist = new ApiPlaylist();
            LoginCookie login = new LoginCookie(envConfig().getUser(), envConfig().getPass());

            apiPlaylist.notCreatePublic();
            apiPlaylist.create(login);
            apiPlaylist.createCharset(login);

            JSONObject playlist = JsonUtil.playlist(login.getJsonProfile().getJSONObject("item").getLong("codProfileHash"), 0);
            String listId = apiPlaylist.listPlaylistId(3);

            apiPlaylist.detailPublic(playlist.getString("idt_playlist"));
            apiPlaylist.detail(login, playlist.getString("idt_playlist"));
            apiPlaylist.detailsPublic(listId);
            apiPlaylist.details(login, listId);
            apiPlaylist.detailPublicQs(playlist.getString("idt_playlist"));
            apiPlaylist.detailQs(login, playlist.getString("idt_playlist"));
            apiPlaylist.detailsPublicQs(listId);
            apiPlaylist.detailsQs(login, listId);
            apiPlaylist.listPublic(login.getJsonProfile().getJSONObject("item").getString("codProfile"));
            apiPlaylist.list(login, login.getJsonProfile().getJSONObject("item").getString("codProfile"));
            apiPlaylist.notUpdatePublic(playlist.getString("idt_playlist"));
            apiPlaylist.update(login, playlist.getString("idt_playlist"));
            apiPlaylist.updateCharset(login, playlist.getString("idt_playlist"));
            apiPlaylist.apacheCache(login, playlist.getString("idt_playlist"));
            apiPlaylist.apacheCacheQs(login, playlist.getString("idt_playlist"));

            JSONObject media = apiPlaylist.mediaNotAdd(playlist.getString("idt_playlist"));

            apiPlaylist.notAddMediaPublic(playlist.getString("idt_playlist"), Long.valueOf(media.getString("idt_media")));
            apiPlaylist.addMedia(login, playlist.getString("idt_playlist"), Long.valueOf(media.getString("idt_media")));
            apiPlaylist.listMediaPublic(playlist.getString("idt_playlist"));
            apiPlaylist.listMedia(login, playlist.getString("idt_playlist"));
            apiPlaylist.notMoveMediaPublic(login, playlist.getString("idt_playlist"));
            apiPlaylist.moveMedia(login, playlist.getString("idt_playlist"));
            apiPlaylist.notRemoveMediaPublic(playlist.getString("idt_playlist"), Long.valueOf(media.getString("idt_media")));
            apiPlaylist.removeMedia(login, playlist.getString("idt_playlist"), Long.valueOf(media.getString("idt_media")));
            apiPlaylist.notRemovePublic(playlist.getString("idt_playlist"));
            apiPlaylist.remove(login, playlist.getString("idt_playlist"));

            apiPlaylist.createFull(login);
        }
        catch (Exception e)
        {
            logger.error(e.getMessage());
        }
    }

    public JSONObject list(LoginCookie login, String codProfile) throws Exception
    {
        login.isAuthenticated();
        JSONObject jsonResponse = login.getjson("http://mais.uol.com.br/apiuol/v2/playlist/list?codProfile=" + codProfile);

        if (!validatePageJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject listPublic(String codProfile) throws Exception
    {
        JSONObject jsonResponse = JsonRequest.get("http://mais.uol.com.br/apiuol/v2/playlist/list?codProfile=" + codProfile);

        if (!validatePageJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject create(LoginCookie login)
    {
        try
        {
            //HashMap<String, String> params = new HashMap<String, String>();
            // params.put("name", "playlist." + DateUtil.getDateString(new
            // Date(), "yyyy-MM-dd_HH-mm-ss"));
            // params.put("visibility", "T");
            login.isAuthenticated();

            JSONObject jsonResponse = login.postjson(
                "http://mais.uol.com.br/apiuol/v2/playlist/create?name=playlist%20"
                        + DateUtil.getDateString(new Date(), "yyyy-MM-dd_HH-mm-ss") + "&visibility=T", null);

            if (!validateMessageJson(jsonResponse, 'S'))
            {
                logger.error("ERROR - return not valid - " + jsonResponse);
                return null;
            }

            logger.debug("SUCCESS");

            TestUtil.delay(TestUtil.ONE_SECOND);

            return jsonResponse;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return null;
        }
    }

    public JSONObject notCreatePublic()
    {
        try
        {
            JSONObject jsonResponse = JsonRequest.post(
                "http://mais.uol.com.br/apiuol/v2/playlist/create?name=playlist%20"
                        + DateUtil.getDateString(new Date(), "yyyy-MM-dd_HH-mm-ss") + "&visibility=T", null);

            if (validateMessageJson(jsonResponse, 'S'))
            {
                logger.error("ERROR - return not valid - " + jsonResponse);
                return null;
            }

            logger.debug("SUCCESS");

            return jsonResponse;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return null;
        }
    }

    public JSONObject createCharset(LoginCookie login)
    {
        try
        {
            String name = "\u00E0c\u00E9nt\u00FC\u00E1\u00E7\u00e3\u00F4 " + DateUtil.getDateString(new Date(), "yyyy-MM-dd_HH-mm-ss");

            HashMap<String, String> params = new HashMap<String, String>();
            params.put("name", name);
            params.put("visibility", "T");
            login.isAuthenticated();

            JSONObject jsonResponse = login.postdatajson("http://mais.uol.com.br/apiuol/v2/playlist/create", params);

            if (!validateMessageJson(jsonResponse, 'S'))
            {
                logger.error("ERROR - return not valid - " + jsonResponse);
                return null;
            }

            logger.debug("SUCCESS");

            TestUtil.delay(TestUtil.ONE_SECOND);

            JSONObject playlistList = login.getjson("http://mais.uol.com.br/apiuol/v2/playlist/list/"
                    + login.getJsonProfile().getJSONObject("item").getString("codProfile"));

            if (name.equals(StringUtil.toUTF8(playlistList.getJSONObject("result").getJSONArray("items").getJSONObject(0)
                    .getString("namPlaylist"))))
            {
                logger.error("ERROR - return not valid - data title was not valid - " + name + " " + playlistList);
                return null;
            }

            return jsonResponse;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return null;
        }
    }

    public JSONObject update(LoginCookie login, String playlistId)
    {
        try
        {
            HashMap<String, String> params = new HashMap<String, String>();
            params.put("idtPlaylist", String.valueOf(playlistId));
            params.put("name", "playlist." + DateUtil.getDateString(new Date(), "yyyy-MM-dd_HH-mm-ss"));
            params.put("visibility", "N");
            login.isAuthenticated();

            JSONObject jsonResponse = login.postjson("http://mais.uol.com.br/apiuol/v2/playlist/update?idtPlaylist=" + playlistId
                    + "&name=playlist" + TestUtil.generateUniqueString() + "&visibility=N", params);

            if (!validateMessageJson(jsonResponse, 'S'))
            {
                logger.error("ERROR - return not valid - playlistId " + playlistId + " - " + jsonResponse);
                return null;
            }

            TestUtil.delay(TestUtil.ONE_SECOND);
            JSONObject playlist = playlistFromApi(login, playlistId);
            JSONObject playlistDet = login.getjson("http://mais.uol.com.br/apiuol/v2/playlist/detail?playlistId=" + playlistId + "&nocache="
                    + Math.random());

            if (!validateUpdateJson(playlist, playlistDet))
            {
                logger.error("ERROR - return not valid - playlistId " + playlistId + " - playlist was not updated - " + playlist + " - "
                        + playlistDet);
                return null;
            }

            logger.debug("SUCCESS");

            return jsonResponse;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return null;
        }
    }

    public JSONObject notUpdatePublic(String playlistId)
    {
        try
        {
            HashMap<String, String> params = new HashMap<String, String>();
            params.put("idtPlaylist", String.valueOf(playlistId));
            params.put("name", "playlist." + DateUtil.getDateString(new Date(), "yyyy-MM-dd_HH-mm-ss"));
            params.put("visibility", "N");

            JSONObject jsonResponse = JsonRequest.post("http://mais.uol.com.br/apiuol/v2/playlist/update?idtPlaylist=" + playlistId
                    + "&name=playlist" + TestUtil.generateUniqueString() + "&visibility=N", null);

            if (validateMessageJson(jsonResponse, 'S'))
            {
                logger.error("ERROR - return not valid - playlistId " + playlistId + " - " + jsonResponse);
                return null;
            }

            logger.debug("SUCCESS");

            return jsonResponse;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return null;
        }
    }

    public JSONObject updateCharset(LoginCookie login, String playlistId)
    {
        try
        {
            String name = "playlist \u00E0c\u00E9nt\u00FC\u00E1\u00E7\u00e3\u00F4 "
                    + DateUtil.getDateString(new Date(), "yyyy-MM-dd_HH-mm-ss");
            HashMap<String, String> params = new HashMap<String, String>();
            params.put("idtPlaylist", String.valueOf(playlistId));
            params.put("name", name);
            params.put("visibility", "N");
            login.isAuthenticated();

            JSONObject jsonResponse = login.postdatajson("http://mais.uol.com.br/apiuol/v2/playlist/update", params);

            if (!validateMessageJson(jsonResponse, 'S'))
            {
                logger.error("ERROR - return not valid - playlistId " + playlistId + " - " + jsonResponse);
                return null;
            }

            TestUtil.delay(TestUtil.ONE_SECOND);
            JSONObject playlist = playlistFromApi(login, playlistId);
            JSONObject playlistDet = login.getjson("http://mais.uol.com.br/apiuol/v2/playlist/detail?playlistId=" + playlistId + "&nocache="
                    + Math.random());

            if (!validateUpdateJson(playlist, playlistDet))
            {
                logger.error("ERROR - return not valid - playlistId " + playlistId + " - playlist was not updated - " + playlist + " - "
                        + playlistDet);
                return null;
            }

            logger.debug("SUCCESS");

            return jsonResponse;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return null;
        }
    }

    /**
     * api de detalhes de uma playlist. url em query string
     * 
     * @param login
     * @param playlistId
     * @return JSONObject
     * @throws ClientProtocolException
     * @throws IllegalStateException
     * @throws IOException
     * @throws JSONException
     */
    public JSONObject detailQs(LoginCookie login, String playlistId) throws Exception
    {
        login.isAuthenticated();
        JSONObject jsonResponse = login.getjson("http://mais.uol.com.br/apiuol/v2/playlist/detail?playlistId=" + playlistId);

        if (!validateJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + playlistId + " - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    /**
     * api de detalhes de uma playlist publica. url em query string
     * 
     * @param playlistId
     * @return JSONObject
     * @throws Exception
     */
    public JSONObject detailPublicQs(String playlistId) throws Exception
    {
        JSONObject jsonResponse = JsonRequest.get("http://mais.uol.com.br/apiuol/v2/playlist/detail?playlistId=" + playlistId);

        if (!validateJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + playlistId + " - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    /**
     * api de detalhes de uma lista de playlist. url em query string
     * 
     * @param login
     * @param listPlaylistId
     * @return JSONObject
     * @throws Exception
     */
    public JSONObject detailsQs(LoginCookie login, String listPlaylistId) throws Exception
    {
        login.isAuthenticated();
        JSONObject jsonResponse = login.getjson("http://mais.uol.com.br/apiuol/v2/playlist/detail?playlistId=" + listPlaylistId);

        if (!validateArrayJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + listPlaylistId + " - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    /**
     * api de detalhes de uma lista de playlist publica. url em query string
     * 
     * @param login
     * @param listPlaylistId
     * @return JSONObject
     * @throws Exception
     */
    public JSONObject detailsPublicQs(String listPlaylistId) throws Exception
    {
        JSONObject jsonResponse = JsonRequest.get("http://mais.uol.com.br/apiuol/v2/playlist/detail?playlistId=" + listPlaylistId);

        if (!validateArrayJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + listPlaylistId + " - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    /**
     * api de detalhes de uma playlist. url em rest
     * 
     * @param login
     * @param playlistId
     * @return JSONObject
     * @throws ClientProtocolException
     * @throws IllegalStateException
     * @throws IOException
     * @throws JSONException
     */
    public JSONObject detail(LoginCookie login, String playlistId) throws Exception
    {
        login.isAuthenticated();
        JSONObject jsonResponse = login.getjson("http://mais.uol.com.br/apiuol/v2/playlist/detail/" + playlistId);

        if (!validateJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + playlistId + " - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    /**
     * api de detalhes de uma playlist publica. url em rest
     * 
     * @param playlistId
     * @return JSONObject
     * @throws Exception
     */
    public JSONObject detailPublic(String playlistId) throws Exception
    {
        JSONObject jsonResponse = JsonRequest.get("http://mais.uol.com.br/apiuol/v2/playlist/detail/" + playlistId);

        if (!validateJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + playlistId + " - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    /**
     * api de detalhes de uma lista de playlist. url em rest
     * 
     * @param login
     * @param listPlaylistId
     * @return JSONObject
     * @throws Exception
     */
    public JSONObject details(LoginCookie login, String listPlaylistId) throws Exception
    {
        login.isAuthenticated();
        JSONObject jsonResponse = login.getjson("http://mais.uol.com.br/apiuol/v2/playlist/detail/" + listPlaylistId);

        if (!validateArrayJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + listPlaylistId + " - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    /**
     * api de detalhes de uma lista de playlist publica. url em rest
     * 
     * @param login
     * @param listPlaylistId
     * @return JSONObject
     * @throws Exception
     */
    public JSONObject detailsPublic(String listPlaylistId) throws Exception
    {
        JSONObject jsonResponse = JsonRequest.get("http://mais.uol.com.br/apiuol/v2/playlist/detail/" + listPlaylistId);

        if (!validateArrayJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + listPlaylistId + " - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    /**
     * cache de api de detalhes de uma playlist. url em query string
     * 
     * @param login
     * @param playlistId
     * @return boolean
     */
    public boolean apacheCacheQs(LoginCookie login, String playlistId)
    {
        try
        {
            login.isAuthenticated();

            JSONObject playlist = JsonRequest.get("http://mais.uol.com.br/apiuol/v2/playlist/detail?playlistId=" + playlistId);
            JSONObject jsonResponse = login.postjson("http://mais.uol.com.br/apiuol/v2/playlist/update?idtPlaylist=" + playlistId 
                + "&name=playlist" + TestUtil.generateUniqueString() + "&visibility=N", new HashMap<String, String>());

            if (!validateMessageJson(jsonResponse, 'S'))
            {
                logger.error("ERROR - return not valid - playlistId " + playlistId + " - " + jsonResponse);
                return false;
            }

            TestUtil.delay(TestUtil.ONE_SECOND);
            JSONObject playlistCache = JsonRequest.get("http://mais.uol.com.br/apiuol/v2/playlist/detail?playlistId=" + playlistId);

            if (!playlist.getJSONObject("result").getString("namPlaylist").equals(playlistCache.getJSONObject("result").getString("namPlaylist")))
            {
                logger.error("ERROR - return not valid - playlist " + playlistId + " is not cacheable");
                return false;
            }

            logger.debug("SUCCESS");

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return false;
        }
    }

    /**
     * cache de api de detalhes de uma playlist. url em rest
     * 
     * @param login
     * @param playlistId
     * @return boolean
     */
    public boolean apacheCache(LoginCookie login, String playlistId)
    {
        try
        {
            login.isAuthenticated();

            JSONObject playlist = JsonRequest.get("http://mais.uol.com.br/apiuol/v2/playlist/detail/" + playlistId);
            JSONObject jsonResponse = login.postjson("http://mais.uol.com.br/apiuol/v2/playlist/update?idtPlaylist=" + playlistId 
                + "&name=playlist" + TestUtil.generateUniqueString() + "&visibility=N", new HashMap<String, String>());

            if (!validateMessageJson(jsonResponse, 'S'))
            {
                logger.error("ERROR - return not valid - playlistId " + playlistId + " - " + jsonResponse);
                return false;
            }

            TestUtil.delay(TestUtil.ONE_SECOND);
            JSONObject playlistCache = JsonRequest.get("http://mais.uol.com.br/apiuol/v2/playlist/detail/" + playlistId);

            if (!playlist.getJSONObject("result").getString("namPlaylist").equals(playlistCache.getJSONObject("result").getString("namPlaylist")))
            {
                logger.error("ERROR - return not valid - playlist is not cacheable - " + playlist + " - " + playlistCache);
                return false;
            }

            logger.debug("SUCCESS");

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return false;
        }
    }

    public JSONObject remove(LoginCookie login, String playlistId) throws Exception
    {
        login.isAuthenticated();
        JSONObject jsonResponse = login.getjson("http://mais.uol.com.br/apiuol/v2/playlist/remove?playlistId=" + playlistId);

        if (!validateMessageJson(jsonResponse, 'S'))
        {
            logger.error("ERROR - return not valid - playlistId " + playlistId + " - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject notRemovePublic(String playlistId) throws Exception
    {
        JSONObject jsonResponse = JsonRequest.get("http://mais.uol.com.br/apiuol/v2/playlist/remove?playlistId=" + playlistId);

        if (validateMessageJson(jsonResponse, 'S'))
        {
            logger.error("ERROR - return not valid - playlistId " + playlistId + " - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject addMedia(LoginCookie login, String playlistId, Long mediaId) throws Exception
    {
        login.isAuthenticated();
        JSONObject playlist = JsonUtil.playlist(playlistId);
        JSONObject jsonResponse = login.getjson("http://mais.uol.com.br/apiuol/v2/playlist/media/add?playlistId="
                + playlist.getString("idt_playlist") + "&mediaId=" + mediaId);

        if (!validateMessageJson(jsonResponse, 'S'))
        {
            logger.error("ERROR - return not valid - playlistId " + playlist.getString("idt_playlist") + " mediaId " + mediaId + " - " + jsonResponse);
            return null;
        }

        TestUtil.delay(TestUtil.ONE_SECOND);
        JSONObject playlistDet = JsonUtil.playlist(playlistId);
        JSONObject playlistMediaList = login.getjson("http://mais.uol.com.br/apiuol/v2/playlist/media/list?playlistId=" + playlistId + "&nocache=" + Math.random());

        int item = Integer.parseInt(playlist.getString("num_medias")) + 1;

        if (item != Integer.parseInt(playlistDet.getString("num_medias"))
                && item != playlistMediaList.getJSONObject("playlist").getInt("numMedias")
                && item != playlistMediaList.getJSONObject("medias").getInt("totalItems"))
        {
            logger.error("ERROR - return not valid - items not match - numMedia expected " + item + " playlist " + playlistDet
                    + " playlistMedia " + playlistMediaList);
            return null;
        }

        if (!apiPlaylistContainsMedia(login, playlistId, mediaId))
        {
            logger.error("ERROR - return not valid - media not found - " + mediaId + " playlist " + playlistId);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject notAddMediaPublic(String playlistId, Long mediaId) throws Exception
    {
        JSONObject playlist = JsonUtil.playlist(playlistId);
        JSONObject jsonResponse = JsonRequest.get("http://mais.uol.com.br/apiuol/v2/playlist/media/add?playlistId=" + playlist.getString("idt_playlist") 
                + "&mediaId=" + mediaId);

        if (validateMessageJson(jsonResponse, 'S'))
        {
            logger.error("ERROR - return not valid - playlistId " + playlist.getString("idt_playlist") + " mediaId " + mediaId + " - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject listMedia(LoginCookie login, String playlistId) throws Exception
    {
        login.isAuthenticated();
        JSONObject jsonResponse = login.getjson("http://mais.uol.com.br/apiuol/v2/playlist/media/list?playlistId=" + playlistId);

        if (!validateMediaPageJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - playlistId " + playlistId + " - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject listMediaPublic(String playlistId) throws Exception
    {
        JSONObject jsonResponse = JsonRequest.get("http://mais.uol.com.br/apiuol/v2/playlist/media/list?playlistId=" + playlistId);

        if (!validateMediaPageJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - playlistId " + playlistId + " - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject moveMedia(LoginCookie login, String playlistId) throws Exception
    {
        login.isAuthenticated();

        int retry = 0;
        JSONObject media = null;
        JSONObject playlist = playlistFromApi(login, playlistId);

        while (playlist.getInt("numMedias") < 2)
        {
            media = mediaNotAdd(playlistId);
            login.getjson("http://mais.uol.com.br/apiuol/v2/playlist/media/add?playlistId=" + playlistId + "&mediaId=" + media.getString("idt_media"));
            playlist = playlistFromApi(login, playlistId);
        }

        JSONObject jPlaylistMedia = null;

        if (media == null)
        {
            jPlaylistMedia = JsonUtil.playlistMedia(playlistId);
        }
        else
        {
            jPlaylistMedia = JsonUtil.playlistMedia(playlistId, media.getString("idt_media"));
        }

        int to = (Integer.parseInt(jPlaylistMedia.getString("num_position")) > 1 ? 1 : 2);

        JSONObject jsonResponse = login.getjson("http://mais.uol.com.br/apiuol/v2/playlist/media/move?playlistId=" + playlistId
                + "&mediaId=" + jPlaylistMedia.getString("idt_media") + "&from=" + jPlaylistMedia.getString("num_position") + "&to=" + to);

        if (!validateMessageJson(jsonResponse, 'S'))
        {
            logger.error("ERROR - return not valid - playlistId " + playlistId + " mediaId " + jPlaylistMedia.getString("idt_media") + " - " + jsonResponse);
            return null;
        }

        JSONObject newJPlaylistMedia = JsonUtil.playlistMedia(playlistId, jPlaylistMedia.getString("idt_media"));

        while (newJPlaylistMedia.getString("num_position").equals(jPlaylistMedia.getString("num_position")) && retry < envConfig().getGlobal().getRetry())
        {
            logger.warn("retry playlistMedia after 1s - " + jPlaylistMedia);

            TestUtil.delay(1000);
            newJPlaylistMedia = JsonUtil.playlistMedia(playlistId, jPlaylistMedia.getString("idt_media"));
            retry++;
        }

        if (newJPlaylistMedia.getString("num_position").equals(jPlaylistMedia.getString("num_position")))
        {
            logger.error("ERROR - return not valid - position not match - position expected " + newJPlaylistMedia.getString("num_position")
                    + " playlist " + playlistId + " mediaId " + jPlaylistMedia.getString("idt_media"));
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject notMoveMediaPublic(LoginCookie login, String playlistId) throws Exception
    {
        login.isAuthenticated();

        JSONObject media = null;
        JSONObject playlist = playlistFromApi(login, playlistId);

        while (playlist.getInt("numMedias") < 2)
        {
            media = mediaNotAdd(playlistId);
            login.getjson("http://mais.uol.com.br/apiuol/v2/playlist/media/add?playlistId=" + playlistId + "&mediaId=" + media.getString("idt_media"));
            playlist = playlistFromApi(login, playlistId);
        }

        JSONObject jPlaylistMedia = JsonUtil.playlistMedia(playlistId, media.getString("idt_media"));
        int to = (Integer.parseInt(jPlaylistMedia.getString("num_position")) > 1 ? 1 : 2);

        JSONObject jsonResponse = JsonRequest.get("http://mais.uol.com.br/apiuol/v2/playlist/media/move?playlistId=" + playlistId
                + "&mediaId=" + media.getString("idt_media") + "&from=" + jPlaylistMedia.getString("num_position") + "&to=" + to);

        if (validateMessageJson(jsonResponse, 'S'))
        {
            logger.error("ERROR - return not valid - playlistId " + playlistId + " mediaId " + media.getString("idt_media") + " - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject removeMedia(LoginCookie login, String playlistId, Long mediaId) throws Exception
    {
        login.isAuthenticated();
        JSONObject playlist = JsonUtil.playlist(playlistId);
        JSONObject jsonResponse = login.getjson("http://mais.uol.com.br/apiuol/v2/playlist/media/remove?playlistId="
                + playlist.getString("idt_playlist") + "&mediaId=" + mediaId);

        if (!validateMessageJson(jsonResponse, 'S'))
        {
            logger.error("ERROR - return not valid - playlistId " + playlist.getString("idt_playlist") + " mediaId " + mediaId + " - " + jsonResponse);
            return null;
        }

        TestUtil.delay(TestUtil.ONE_SECOND);

        JSONObject playlistDet = JsonUtil.playlist(playlistId);
        JSONObject playlistMediaList = login.getjson("http://mais.uol.com.br/apiuol/v2/playlist/media/list?playlistId=" + playlistId);

        int item = Integer.parseInt(playlist.getString("num_medias")) - 1;

        if (item != Integer.parseInt(playlistDet.getString("num_medias"))
                || item != playlistMediaList.getJSONObject("playlist").getInt("numMedias")
                || (playlistMediaList.getJSONObject("paging").has("totalItems") && item != playlistMediaList.getJSONObject("paging")
                        .getInt("totalItems")))
        {
            logger.error("ERROR - return not valid - items not match - numMedia expected " + item + " playlist " + playlistDet
                    + " playlistMedia " + playlistMediaList);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject notRemoveMediaPublic(String playlistId, Long mediaId) throws Exception
    {
        JSONObject playlist = JsonRequest.get("http://mais.uol.com.br/apiuol/v2/playlist/detail?playlistId=" + playlistId);
        JSONObject jsonResponse = JsonRequest.get("http://mais.uol.com.br/apiuol/v2/playlist/media/remove?playlistId="
                + playlist.getJSONObject("result").getLong("idtPlaylist") + "&mediaId=" + mediaId);

        if (validateMessageJson(jsonResponse, 'S'))
        {
            logger.error("ERROR - return not valid - playlistId " + playlist.getJSONObject("result").getLong("idtPlaylist") + " mediaId "
                    + mediaId + " - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public String listPlaylistId(int limit) throws Exception
    {
        StringBuilder ids = null;
        JSONArray jarray = JsonUtil.playlists(limit);

        if (jarray != null && jarray.length() > 0)
        {
            ids = new StringBuilder();

            for (int i = 0; i < jarray.length(); i++)
            {
                ids.append((ids.length() > 0 ? "," : "") + jarray.getJSONObject(i).getString("idt_playlist"));
            }
        }

        return (ids != null ? ids.toString() : null);
    }

    public JSONObject mediaNotAdd(String playlistId) throws Exception
    {
        int limit = 10;
        int start = 0;
        JSONObject jsonobject = JsonUtil.mediaPublicPaging("V", start, limit);

        while (jsonobject != null && jsonobject.getJSONArray("data").length() > 0)
        {
            for (int i = 0; i < jsonobject.getJSONArray("data").length(); i++)
            {
                Integer index = JsonUtil.indexOf(jsonobject, "idt_media");
                if (!playlistContainsMedia(playlistId, jsonobject.getJSONArray("data").getJSONArray(i).getLong(index)))
                {
                    return JsonUtil.jsonArrayToObject(jsonobject.getJSONArray("columns"), jsonobject.getJSONArray("data").getJSONArray(i));
                }
            }

            start += limit;
            jsonobject = JsonUtil.mediaPublicPaging("V", start, limit);
        }

        return null;
    }

    private boolean playlistContainsMedia(String playlistId, Long mediaId) throws Exception
    {
        JSONObject playlistMedia = JsonUtil.playlistMedia(playlistId, mediaId.toString());

        if (playlistMedia != null && playlistMedia.has("idt_playlist") && playlistMedia.has("idt_media") && playlistMedia.has("num_position"))
        {
            return true;
        }

        return false;
    }

    private boolean apiPlaylistContainsMedia(LoginCookie login, String playlistId, Long mediaId) throws Exception
    {
        int page = 1;
        String url = "http://mais.uol.com.br/apiuol/v2/playlist/media/list?playlistId=" + playlistId + "&index.currentPage=";
        JSONObject playlistMediaList = login.getjson(url + page + "&nocache=" + Math.random());

        while (playlistMediaList.getJSONArray("medias").length() > 0)
        {
            for (int i = 0; i < playlistMediaList.getJSONArray("medias").length(); i++)
            {
                if (mediaId.longValue() == playlistMediaList.getJSONArray("medias").getJSONObject(i).getLong("idtMedia"))
                {
                    return true;
                }
            }

            page++;
            playlistMediaList = login.getjson(url + page + "&nocache=" + Math.random());
        }

        return false;
    }

    private JSONObject playlistFromApi(LoginCookie login, String playlistId) throws Exception
    {
        try
        {
            if (!exists(login, playlistId))
            {
                logger.error("ERROR - playlist not found - " + playlistId);
                return null;
            }

            int page = 1;
            String playlistListUrl = "http://mais.uol.com.br/apiuol/v2/playlist/list?index.currentPage=";
            JSONObject playlistList = login.getjson(playlistListUrl + page + "&nocache=" + Math.random());

            while (!playlistList.isNull("result") && playlistList.getJSONObject("result").getJSONArray("items").length() > 0)
            {
                for (int i = 0; i < playlistList.getJSONObject("result").getJSONArray("items").length(); i++)
                {
                    if (playlistList.getJSONObject("result").getJSONArray("items").getJSONObject(i).getLong("idtPlaylist") == Long
                            .parseLong(playlistId))
                    {
                        return playlistList.getJSONObject("result").getJSONArray("items").getJSONObject(i);
                    }
                }

                page++;
                playlistList = login.getjson(playlistListUrl + page + "&nocache=" + Math.random());
            }

            return null;
        }
        catch (Exception e)
        {
            logger.error(e.getMessage());
            return null;
        }
    }

    private boolean exists(LoginCookie login, String playlistId) throws Exception
    {
        JSONObject jsonResponse = login.getjson("http://mais.uol.com.br/apiuol/v2/playlist/detail?playlistId=" + playlistId + "&nocache="
                + Math.random());

        if (!jsonResponse.isNull("result") && jsonResponse.getJSONObject("result").has("idtPlaylist"))
        {
            return true;
        }

        return false;
    }

    public boolean createFull(LoginCookie login)
    {
        login.isAuthenticated();

        try
        {
            String playlistId = null;
            JSONObject playlist = JsonUtil.playlist(login.getJsonProfile().getJSONObject("item").getLong("codProfileHash"), 0);

            if (playlist == null)
            {
                HashMap<String, String> params = new HashMap<String, String>();
                JSONObject jsonCreateResponse = login.postjson("http://mais.uol.com.br/apiuol/v2/playlist/create?name=playlist"
                        + TestUtil.generateUniqueString() + "&visibility=T", params);

                if (!validateMessageJson(jsonCreateResponse, 'S'))
                {
                    logger.error("ERROR - create - return not valid - " + jsonCreateResponse);
                    return false;
                }

                JSONObject playlistList = login.getjson("http://mais.uol.com.br/apiuol/v2/playlist/list?codProfile="
                        + login.getJsonProfile().getJSONObject("item").getString("codProfile"));

                if (!validatePageJson(playlistList))
                {
                    logger.error("ERROR - list - return not valid - " + playlistList);
                    return false;
                }

                playlist = playlistList.getJSONObject("result").getJSONArray("items").getJSONObject(0);
                playlistId = String.valueOf(playlist.getLong("idtPlaylist"));
            }
            else
            {
                playlistId = playlist.getString("idt_playlist");
            }

            JSONObject media = mediaNotAdd(playlistId);
            int limit = 100;
            int item = 0;

            while (media != null && item < limit)
            {
                JSONObject jsonResponse = login.getjson("http://mais.uol.com.br/apiuol/v2/playlist/media/add?playlistId=" + playlistId
                        + "&mediaId=" + media.getString("idt_media"));
                item++;

                if (item <= limit)
                {
                    if (!validateMessageJson(jsonResponse, 'S'))
                    {
                        logger.error("ERROR - addMedia - return not valid - playlistId " + playlistId + " mediaId "
                                + media.getString("idt_media") + " - " + jsonResponse);
                        return false;
                    }
                }
                else
                {
                    if (!validateMessageJson(jsonResponse, 'W'))
                    {
                        logger.error("ERROR - addMedia - return not valid - playlistId " + playlistId + " mediaId "
                                + media.getString("idt_media") + " - " + jsonResponse);
                        return false;
                    }

                    break;
                }

                media = mediaNotAdd(playlistId);
            }

            JSONObject playlistDet = detailQs(login, playlistId);
            JSONObject playlistMediaList = listMedia(login, playlistId);

            if (item != playlistDet.getJSONObject("result").getInt("numMedias")
                    || item != playlistMediaList.getJSONObject("playlist").getInt("numMedias")
                    || item != playlistMediaList.getJSONObject("paging").getInt("totalItems"))
            {
                logger.error("ERROR - return not valid - items not match - playlist " + playlistDet + " playlistMedia " + playlistMediaList
                        + " total " + item);
                return false;
            }

            logger.debug("SUCCESS");

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERRO createFull - " + e.getMessage() + " - " + login.getJsonProfile());
            return false;
        }
    }

    private boolean validateMessageJson(JSONObject json, char type)
    {
        try
        {
            if (json == null || json.getJSONObject("_response").getInt("code") != HttpStatus.SC_OK)
            {
                return false;
            }

            json.getJSONObject("result");

            if (type == 'S')
            {
                json.getJSONObject("result").getJSONArray("success");

                if (json.getJSONObject("result").getJSONArray("success").length() < 1)
                {
                    throw new Exception("no has success message");
                }

                for (int i = 0; i < json.getJSONObject("result").getJSONArray("success").length(); i++)
                {
                    json.getJSONObject("result").getJSONArray("success").getJSONObject(i).getString("id");
                    json.getJSONObject("result").getJSONArray("success").getJSONObject(i).getString("description");

                    JsonUtil.validateValueJson(json.getJSONObject("result").getJSONArray("success").getJSONObject(i), new String[] { "" });
                }
            }
            else if (type == 'E')
            {
                json.getJSONObject("result").getJSONArray("errors");

                if (json.getJSONObject("result").getJSONArray("errors").length() < 1)
                {
                    throw new Exception("no has error message");
                }

                for (int i = 0; i < json.getJSONObject("result").getJSONArray("errors").length(); i++)
                {
                    json.getJSONObject("result").getJSONArray("errors").getJSONObject(i).getString("id");
                    json.getJSONObject("result").getJSONArray("errors").getJSONObject(i).getString("description");

                    JsonUtil.validateValueJson(json.getJSONObject("result").getJSONArray("errors").getJSONObject(i), new String[] { "" });
                }
            }
            else if (type == 'W')
            {
                json.getJSONObject("result").getJSONArray("warns");

                if (json.getJSONObject("result").getJSONArray("warns").length() < 1)
                {
                    throw new Exception("no has warn message");
                }

                for (int i = 0; i < json.getJSONObject("result").getJSONArray("warns").length(); i++)
                {
                    json.getJSONObject("result").getJSONArray("warns").getJSONObject(i).getString("id");
                    json.getJSONObject("result").getJSONArray("warns").getJSONObject(i).getString("description");

                    JsonUtil.validateValueJson(json.getJSONObject("result").getJSONArray("warns").getJSONObject(i), new String[] { "" });
                }
            }
            else
            {
                json.getJSONObject("result").getJSONArray("infos");

                if (json.getJSONObject("result").getJSONArray("infos").length() < 1)
                {
                    throw new Exception("no has info message");
                }

                for (int i = 0; i < json.getJSONObject("result").getJSONArray("infos").length(); i++)
                {
                    json.getJSONObject("result").getJSONArray("infos").getJSONObject(i).getString("id");
                    json.getJSONObject("result").getJSONArray("infos").getJSONObject(i).getString("description");

                    JsonUtil.validateValueJson(json.getJSONObject("result").getJSONArray("infos").getJSONObject(i), new String[] { "" });
                }
            }

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - message invalid - " + e.getMessage() + " - " + json);
            return false;
        }
    }

    private boolean validateUpdateJson(JSONObject jsonFromList, JSONObject jsonDetail)
    {
        try
        {
            if (!validateJson(jsonDetail))
            {
                return false;
            }

            if (!jsonFromList.getString("namPlaylist").equals(jsonDetail.getJSONObject("result").getString("namPlaylist")))
            {
                logger.error("ERROR - " + jsonFromList.getString("namPlaylist") + " - "
                        + jsonDetail.getJSONObject("result").getString("namPlaylist"));
                return false;
            }

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            return false;
        }
    }

    private boolean validateJson(JSONObject json)
    {
        try
        {
            if (json == null || json.getJSONObject("_response").getInt("code") != HttpStatus.SC_OK)
            {
                return false;
            }
            json.getJSONObject("result");
            json.getJSONObject("result").getLong("idtPlaylist");
            json.getJSONObject("result").getString("codProfile");
            json.getJSONObject("result").getString("indVisibility");
            json.getJSONObject("result").getString("namPlaylist");
            json.getJSONObject("result").getInt("numMedias");
            json.getJSONObject("result").getInt("numFriendsMedias");
            json.getJSONObject("result").getLong("datCreation");

            json.getJSONObject("result").getJSONObject("owner");
            json.getJSONObject("result").getJSONObject("owner").getString("codProfile");
            json.getJSONObject("result").getJSONObject("owner").getString("namNick");
            json.getJSONObject("result").getJSONObject("owner").getString("desUrlProfile");

            JsonUtil.validateValueJson(json.getJSONObject("result"), new String[] { "namPlaylist" });

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - json is not valid - " + e.getMessage() + " - " + json);
            return false;
        }
    }

    private boolean validateArrayJson(JSONObject json)
    {
        try
        {
            if (json == null || json.getJSONObject("_response").getInt("code") != HttpStatus.SC_OK)
            {
                return false;
            }

            json.getJSONArray("result");

            for (int i = 0; i < json.getJSONArray("result").length(); i++)
            {
                json.getJSONArray("result").getJSONObject(i).getLong("idtPlaylist");
                json.getJSONArray("result").getJSONObject(i).getString("codProfile");
                json.getJSONArray("result").getJSONObject(i).getString("indVisibility");
                json.getJSONArray("result").getJSONObject(i).getString("namPlaylist");
                json.getJSONArray("result").getJSONObject(i).getInt("numMedias");
                json.getJSONArray("result").getJSONObject(i).getInt("numFriendsMedias");
                json.getJSONArray("result").getJSONObject(i).getLong("datCreation");

                json.getJSONArray("result").getJSONObject(i).getJSONObject("owner");
                json.getJSONArray("result").getJSONObject(i).getJSONObject("owner").getString("codProfile");
                json.getJSONArray("result").getJSONObject(i).getJSONObject("owner").getString("namNick");
                json.getJSONArray("result").getJSONObject(i).getJSONObject("owner").getString("desUrlProfile");

                JsonUtil.validateValueJson(json.getJSONArray("result").getJSONObject(i), new String[] { "namPlaylist" });
            }

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - json is not valid - " + e.getMessage() + " - " + json);
            return false;
        }
    }

    private boolean validatePageJson(JSONObject json)
    {
        try
        {
            if (json == null || json.getJSONObject("_response").getInt("code") != HttpStatus.SC_OK)
            {
                return false;
            }
            json.getJSONObject("result");
            json.getJSONObject("result").getInt("currentPage");
            json.getJSONObject("result").getInt("itemsPerPage");
            json.getJSONObject("result").getInt("totalItems");
            json.getJSONObject("result").getInt("totalPages");
            json.getJSONObject("result").getInt("previousPage");
            json.getJSONObject("result").getJSONArray("previousPageCollection");
            json.getJSONObject("result").getInt("nextPage");
            json.getJSONObject("result").getJSONArray("nextPageCollection");
            json.getJSONObject("result").getString("sortBy");
            json.getJSONObject("result").getString("orderBy");
            json.getJSONObject("result").getJSONArray("items");

            for (int i = 0; i < json.getJSONObject("result").getJSONArray("items").length(); i++)
            {
                json.getJSONObject("result").getJSONArray("items").getJSONObject(i).getLong("idtPlaylist");
                json.getJSONObject("result").getJSONArray("items").getJSONObject(i).getString("codProfile");
                json.getJSONObject("result").getJSONArray("items").getJSONObject(i).getString("indVisibility");
                json.getJSONObject("result").getJSONArray("items").getJSONObject(i).getString("namPlaylist");
                json.getJSONObject("result").getJSONArray("items").getJSONObject(i).getInt("numMedias");
                json.getJSONObject("result").getJSONArray("items").getJSONObject(i).getInt("numFriendsMedias");
                json.getJSONObject("result").getJSONArray("items").getJSONObject(i).getLong("datCreation");

                JsonUtil.validateValueJson(json.getJSONObject("result").getJSONArray("items").getJSONObject(i),
                    new String[] { "namPlaylist" });
            }

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - pagejson is not valid - " + e.getMessage() + " - " + json);
            return false;
        }
    }

    private boolean validateMediaPageJson(JSONObject json)
    {
        try
        {
            if (json == null || json.getJSONObject("_response").getInt("code") != HttpStatus.SC_OK)
            {
                return false;
            }
            json.getJSONObject("playlist");
            json.getJSONObject("playlist").getLong("idtPlaylist");
            json.getJSONObject("playlist").getString("codProfile");
            json.getJSONObject("playlist").getString("indVisibility");
            json.getJSONObject("playlist").getString("namPlaylist");
            json.getJSONObject("playlist").getInt("numMedias");
            json.getJSONObject("playlist").getLong("datCreation");

            JsonUtil.validateValueJson(json.getJSONObject("playlist"), new String[] { "namPlaylist" });

            json.getJSONObject("playlist").getJSONObject("owner");
            json.getJSONObject("playlist").getJSONObject("owner").getString("namNick");
            json.getJSONObject("playlist").getJSONObject("owner").getString("desUrlProfile");

            JsonUtil.validateValueJson(json.getJSONObject("playlist").getJSONObject("owner"), new String[] { "" });

            json.getJSONObject("paging");
            json.getJSONObject("paging").getInt("currentPage");
            json.getJSONObject("paging").getInt("totalItems");
            json.getJSONObject("paging").getInt("totalPages");
            json.getJSONObject("paging").getInt("previousPage");
            json.getJSONObject("paging").getInt("nextPage");
            json.getJSONObject("paging").getString("sortBy");

            json.getJSONArray("medias");

            for (int i = 0; i < json.getJSONArray("medias").length(); i++)
            {
                json.getJSONArray("medias").getJSONObject(i).getInt("numPosition");
                json.getJSONArray("medias").getJSONObject(i).getLong("idtMedia");
                json.getJSONArray("medias").getJSONObject(i).getLong("datPublished");
                json.getJSONArray("medias").getJSONObject(i).getString("indVisibility");
                json.getJSONArray("medias").getJSONObject(i).getString("namSubject");
                json.getJSONArray("medias").getJSONObject(i).getString("indHot");
                json.getJSONArray("medias").getJSONObject(i).getLong("idtFile");
                json.getJSONArray("medias").getJSONObject(i).getString("desMedia");
                json.getJSONArray("medias").getJSONObject(i).getString("indMediaProtection");
                json.getJSONArray("medias").getJSONObject(i).getString("tags");

                json.getJSONArray("medias").getJSONObject(i).getString("duration");
                json.getJSONArray("medias").getJSONObject(i).getString("id");
                json.getJSONArray("medias").getJSONObject(i).getInt("idtSubject");
                json.getJSONArray("medias").getJSONObject(i).getInt("views");

                json.getJSONArray("medias").getJSONObject(i).getString("thumbnail");
                json.getJSONArray("medias").getJSONObject(i).getString("thumbSmall");
                json.getJSONArray("medias").getJSONObject(i).getString("thumbMedium");
                json.getJSONArray("medias").getJSONObject(i).getString("thumbLarge");
                json.getJSONArray("medias").getJSONObject(i).getString("thumbWmedium");
                json.getJSONArray("medias").getJSONObject(i).getString("thumbWlarge");

                if (json.getJSONArray("medias").getJSONObject(i).getString("tags").contains("$"))
                {
                    JsonUtil.validateValueJson(json.getJSONArray("medias").getJSONObject(i), new String[] { "namSubject", "desMedia",
                                                                                                           "tags" });
                }
                else
                {
                    JsonUtil.validateValueJson(json.getJSONArray("medias").getJSONObject(i), new String[] { "namSubject", "desMedia" });
                }

                json.getJSONArray("medias").getJSONObject(i).getJSONObject("owner");
                json.getJSONArray("medias").getJSONObject(i).getJSONObject("owner").getString("namNick");
                json.getJSONArray("medias").getJSONObject(i).getJSONObject("owner").getString("desUrlProfile");

                JsonUtil.validateValueJson(json.getJSONArray("medias").getJSONObject(i).getJSONObject("owner"), new String[] { "" });
            }

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - mediapagejson is not valid - " + e.getMessage() + " - " + json);
            return false;
        }
    }
}
