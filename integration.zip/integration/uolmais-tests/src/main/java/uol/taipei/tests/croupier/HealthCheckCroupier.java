/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         28/07/2016 Criacao inicial
 */

package uol.taipei.tests.croupier;

import java.io.IOException;

import org.apache.http.HttpStatus;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uol.taipei.request.JsonRequest;
import uol.taipei.tests.AbstractTest;

public class HealthCheckCroupier extends AbstractTest
{
    static final Logger logger = LoggerFactory.getLogger(HealthCheckCroupier.class);

    public static void main(String[] args)
    {
        if (!verifyParams(args))
        {
            return;
        }

        setUp(args[0]);

        logger.debug("-------------------------------------------------");
        logger.debug("tests health check croupier");

        try
        {
            HealthCheckCroupier healthCheckCroupier = new HealthCheckCroupier();

            healthCheckCroupier.probe();
        }
        catch (Exception e) 
        {
            logger.error(e.getMessage());            
        }
    }

    public HealthCheckCroupier()
    {
        this.host = "http://" + envConfig().getGlobal().getUrlcro();
    }

    public HealthCheckCroupier(String url)
    {
        this.host = url;
    }

    public boolean probe() throws IOException, JSONException
    {
        JSONObject jsonResponse = JsonRequest.get(host + "/probe");

        if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") != HttpStatus.SC_OK)
        {
            logger.error("ERROR - return not valid - " + jsonResponse);

            return false;
        }

        try
        {
            jsonResponse.getString("upTime");
            jsonResponse.getString("status");
            jsonResponse.getString("serverVersion");
        }
        catch (Exception e)
        {
            logger.error("ERROR - return not valid - " + e.getMessage() + " - " + jsonResponse);

            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }
}
