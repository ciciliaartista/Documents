/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         27/05/2014 Criacao inicial
 */

package uol.taipei.tests.ssl;

import java.io.IOException;

import org.apache.http.HttpStatus;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uol.taipei.request.FacileRequest;
import uol.taipei.request.FacileResponse;
import uol.taipei.request.JsonRequest;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.util.JsonUtil;
import uol.taipei.tests.util.RequestUtil;

public class ApiPlayerSsl extends AbstractTest
{
    static final Logger logger = LoggerFactory.getLogger(ApiPlayerSsl.class);

    public static void main(String[] args)
    {
        if (!verifyParams(args))
        {
            return;
        }

        setUp(args[0]);

        logger.debug("-------------------------------------------------");
        logger.debug("tests ssl api player");

        try
        {
            ApiPlayerSsl apiPlayerSsl = new ApiPlayerSsl();
            String mediaId = RequestUtil.mediaIdPublic("V");

            apiPlayerSsl.crossdomain();
            apiPlayerSsl.media(mediaId);
            apiPlayerSsl.related(mediaId);
            apiPlayerSsl.notifyMediaView(mediaId);

            apiPlayerSsl.playerMedia(mediaId);
            apiPlayerSsl.mediaView(mediaId);

            mediaId = RequestUtil.mediaIdPublic("P");

            apiPlayerSsl.playerMedia(mediaId);
        }
        catch (Exception e)
        {
            logger.error(e.getMessage());
        }
    }

    public boolean crossdomain() throws Exception
    {
        FacileRequest request = new FacileRequest();
        request.configureSSL();

        FacileResponse response = request.get("https://mais.uol.com.br/crossdomain.xml");

        if (response.getCode() != 200 && response.getCode() != 304)
        {
            logger.error("ERROR - return not valid - " + response.getCode());
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public JSONObject playerMedia(String mediaId) throws Exception
    {
        String url = "https://mais.uol.com.br/apiuol/v3/player/getMedia/" + mediaId + "?nocache=" + Math.random();
        JSONObject jsonResponse = JsonRequest.get(url);

        if (!validatePlayerJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse + " - " + url);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject mediaView(String mediaId) throws Exception
    {
        String url = "https://mais.uol.com.br/apiuol/v3/media/view/notify/" + mediaId;
        JSONObject jsonResponse = JsonRequest.get(url);

        if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") != 200)
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        try
        {
            jsonResponse.getJSONObject("response");
            jsonResponse.getJSONObject("response").getInt("code");
            jsonResponse.getJSONObject("response").getString("description");
        }
        catch (Exception e)
        {
            logger.error("ERROR - return not valid - " + e.getMessage() + " - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject media(String mediaId) throws IOException, JSONException
    {
        String url = "https://mais.uol.com.br/apiuol/player/media?action=showPlayer&p=mais&types=V&mediaId=" + mediaId + "&nocache="
                + Math.random();
        JSONObject jsonResponse = JsonRequest.get(url);

        if (!validateMediaJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse + " - " + url);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject related(String mediaId) throws IOException, JSONException
    {
        String url = "https://mais.uol.com.br/apiuol/player/related?index.itemsPerPage=21&types=V&mediaId=" + mediaId + "&nocache="
                + Math.random();
        JSONObject jsonResponse = JsonRequest.get(url);

        if (jsonResponse.getJSONObject("_response").getInt("code") == HttpStatus.SC_NOT_FOUND)
        {
            if (jsonResponse.getJSONObject("response").getInt("code") != HttpStatus.SC_NOT_FOUND)
            {
                logger.error("ERROR - invalid response - " + url + " - " + jsonResponse);
                return null;
            }
            else
            {
                logger.debug("SUCCESS");
                return jsonResponse;
            }
        }

        if (!validateRelatedJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse + " - " + url);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject notifyMediaView(String mediaId) throws IOException, JSONException
    {
        String url = "https://mais.uol.com.br/notifyMediaView?t=v&v=2&mediaId=" + mediaId;
        JSONObject jsonResponse = JsonRequest.get(url);

        if (!validateResultJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        if (!jsonResponse.getBoolean("result"))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    private boolean validatePlayerJson(JSONObject jsonResponse) throws JSONException
    {
        try
        {
            if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") != HttpStatus.SC_OK)
            {
                return false;
            }

            jsonResponse.getJSONObject("response");
            jsonResponse.getJSONObject("response").getInt("code");
            jsonResponse.getJSONObject("response").getString("description");

            jsonResponse.getJSONObject("item");
            jsonResponse.getJSONObject("item").getString("title");
            jsonResponse.getJSONObject("item").getLong("mediaId");
            jsonResponse.getJSONObject("item").getString("url");
            jsonResponse.getJSONObject("item").getString("mediaType");
            jsonResponse.getJSONObject("item").getString("duration");
    
            if (jsonResponse.getJSONObject("item").getString("mediaType").equals("P"))
            {
                jsonResponse.getJSONObject("item").getString("fileUrl");
            }

            if (jsonResponse.getJSONObject("item").getString("mediaType").equals("V"))
            {
                jsonResponse.getJSONObject("item").getString("thumbnail");
                jsonResponse.getJSONObject("item").getInt("thumbVersion");
                jsonResponse.getJSONObject("item").getBoolean("subscriberMedia");
                jsonResponse.getJSONObject("item").getBoolean("externalCDN");
                jsonResponse.getJSONObject("item").getString("codPublicity");

                jsonResponse.getJSONObject("item").getJSONArray("formats");

                for (int j = 0; j < jsonResponse.getJSONObject("item").getJSONArray("formats").length(); j++)
                {
                    jsonResponse.getJSONObject("item").getJSONArray("formats").getJSONObject(j).getInt("id");
                    jsonResponse.getJSONObject("item").getJSONArray("formats").getJSONObject(j).getString("secureUrl");
                    jsonResponse.getJSONObject("item").getJSONArray("formats").getJSONObject(j).getString("url");
                }

                jsonResponse.getJSONObject("item").getJSONArray("tags");

                for (int j = 0; j < jsonResponse.getJSONObject("item").getJSONArray("tags").length(); j++)
                {
                    jsonResponse.getJSONObject("item").getJSONArray("tags").getJSONObject(j).getLong("id");
                    jsonResponse.getJSONObject("item").getJSONArray("tags").getJSONObject(j).getString("description");
                }
            }

            jsonResponse.getJSONObject("item").getString("author");
            jsonResponse.getJSONObject("item").getString("codProfile");
            jsonResponse.getJSONObject("item").getBoolean("blockEmbed");
            jsonResponse.getJSONObject("item").getBoolean("geoBlocked");
            jsonResponse.getJSONObject("item").getInt("numRevision");
            jsonResponse.getJSONObject("item").getString("userIp");

            JsonUtil.validateValueJson(jsonResponse.getJSONObject("item"), new String[] { "title", "description" });

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - json is not valid - " + e.getMessage() + " - " + jsonResponse);
            return false;
        }
    }

    private boolean validateResultJson(JSONObject jsonResponse) throws JSONException
    {
        try
        {
            if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") != HttpStatus.SC_OK)
            {
                return false;
            }
            jsonResponse.getBoolean("result");
            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - jsonResult is not valid - " + e.getMessage() + " - " + jsonResponse);
            return false;
        }
    }

    private boolean validateMediaJson(JSONObject jsonResponse) throws JSONException
    {
        try
        {
            if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") != HttpStatus.SC_OK)
            {
                return false;
            }
            jsonResponse.getJSONObject("response");
            jsonResponse.getJSONObject("response").getInt("code");
            jsonResponse.getJSONObject("response").getString("description");
            jsonResponse.getJSONObject("response").getString("originalRequest");

            jsonResponse.getJSONObject("config");
            Boolean.parseBoolean(jsonResponse.getJSONObject("config").getString("sendlog"));
            Boolean.parseBoolean(jsonResponse.getJSONObject("config").getString("showrelated"));
            Boolean.parseBoolean(jsonResponse.getJSONObject("config").getString("shownext"));
            Boolean.parseBoolean(jsonResponse.getJSONObject("config").getString("showads"));
            Boolean.parseBoolean(jsonResponse.getJSONObject("config").getString("startplay"));
            Boolean.parseBoolean(jsonResponse.getJSONObject("config").getString("startloading"));
            Boolean.parseBoolean(jsonResponse.getJSONObject("config").getString("watermark"));
            Boolean.parseBoolean(jsonResponse.getJSONObject("config").getString("showbar"));
            Boolean.parseBoolean(jsonResponse.getJSONObject("config").getString("showplay"));
            Boolean.parseBoolean(jsonResponse.getJSONObject("config").getString("showlogo"));
            Boolean.parseBoolean(jsonResponse.getJSONObject("config").getString("showvolume"));
            Boolean.parseBoolean(jsonResponse.getJSONObject("config").getString("showfullscreen"));
            jsonResponse.getJSONObject("config").getString("skin");
            Boolean.parseBoolean(jsonResponse.getJSONObject("config").getString("uselink"));
            Boolean.parseBoolean(jsonResponse.getJSONObject("config").getString("relatedembed"));
            Boolean.parseBoolean(jsonResponse.getJSONObject("config").getString("sharedlink"));

            jsonResponse.getJSONObject("media");
            jsonResponse.getJSONObject("media").getString("title");
            jsonResponse.getJSONObject("media").getLong("mediaId");
            jsonResponse.getJSONObject("media").getString("url");
            jsonResponse.getJSONObject("media").getString("mediaType");
            jsonResponse.getJSONObject("media").getString("urlTvuol");
            jsonResponse.getJSONObject("media").getString("thumbnail");
            jsonResponse.getJSONObject("media").getString("player");
            jsonResponse.getJSONObject("media").getString("duration");

            jsonResponse.getJSONObject("media").getJSONArray("formats");

            for (int j = 0; j < jsonResponse.getJSONObject("media").getJSONArray("formats").length(); j++)
            {
                jsonResponse.getJSONObject("media").getJSONArray("formats").getJSONObject(j).getInt("id");
                jsonResponse.getJSONObject("media").getJSONArray("formats").getJSONObject(j).getString("secureUrl");
                jsonResponse.getJSONObject("media").getJSONArray("formats").getJSONObject(j).getString("url");
            }

            jsonResponse.getJSONObject("media").getString("embedUrl");
            jsonResponse.getJSONObject("media").getString("embedCode");
            jsonResponse.getJSONObject("media").getInt("thumbVersion");
            jsonResponse.getJSONObject("media").getString("description");
            Boolean.parseBoolean(jsonResponse.getJSONObject("media").getString("adultContent"));
            jsonResponse.getJSONObject("media").getString("author");
            jsonResponse.getJSONObject("media").getString("codProfile");
            Boolean.parseBoolean(jsonResponse.getJSONObject("media").getString("blockEmbed"));
            Boolean.parseBoolean(jsonResponse.getJSONObject("media").getString("subscriberMedia"));

            jsonResponse.getJSONObject("media").getJSONArray("tags");

            for (int j = 0; j < jsonResponse.getJSONObject("media").getJSONArray("tags").length(); j++)
            {
                jsonResponse.getJSONObject("media").getJSONArray("tags").getJSONObject(j).getLong("id");
                jsonResponse.getJSONObject("media").getJSONArray("tags").getJSONObject(j).getString("description");
            }

            jsonResponse.getJSONObject("media").getString("codPublicityDfp");
            jsonResponse.getJSONObject("media").getString("publishedAt");
            jsonResponse.getJSONObject("media").getInt("views");

            jsonResponse.getJSONObject("media").getJSONArray("profilesGroupsEditorial");

            for (int j = 0; j < jsonResponse.getJSONObject("media").getJSONArray("profilesGroupsEditorial").length(); j++)
            {
                jsonResponse.getJSONObject("media").getJSONArray("profilesGroupsEditorial").getInt(j);
            }

            jsonResponse.getJSONObject("media").getString("userIp");
            Boolean.parseBoolean(jsonResponse.getJSONObject("media").getString("dart"));
            Boolean.parseBoolean(jsonResponse.getJSONObject("media").getString("seek"));
            Boolean.parseBoolean(jsonResponse.getJSONObject("media").getString("akamai"));
            jsonResponse.getJSONObject("media").getString("isInBlacklistTag");

            JsonUtil.validateValueJson(jsonResponse.getJSONObject("media"), new String[] { "title", "description" });

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - json is not valid - " + e.getMessage() + " - " + jsonResponse);
            return false;
        }
    }

    private boolean validateRelatedJson(JSONObject jsonResponse) throws JSONException
    {
        try
        {
            if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") != HttpStatus.SC_OK)
            {
                return false;
            }
            jsonResponse.getJSONObject("response");
            jsonResponse.getJSONObject("response").getInt("code");
            jsonResponse.getJSONObject("response").getString("description");
            jsonResponse.getJSONObject("response").getString("originalRequest");

            jsonResponse.getJSONArray("related");

            for (int i = 0; i < jsonResponse.getJSONArray("related").length(); i++)
            {
                jsonResponse.getJSONArray("related").getJSONObject(i).getString("title");
                jsonResponse.getJSONArray("related").getJSONObject(i).getLong("mediaId");
                jsonResponse.getJSONArray("related").getJSONObject(i).getString("url");
                jsonResponse.getJSONArray("related").getJSONObject(i).getString("mediaType");
                jsonResponse.getJSONArray("related").getJSONObject(i).getString("urlTvuol");
                jsonResponse.getJSONArray("related").getJSONObject(i).getString("thumbnail");
                jsonResponse.getJSONArray("related").getJSONObject(i).getInt("thumbVersion");
                jsonResponse.getJSONArray("related").getJSONObject(i).getString("numGeneratedThumbs");
                jsonResponse.getJSONArray("related").getJSONObject(i).getString("player");
                jsonResponse.getJSONArray("related").getJSONObject(i).getString("duration");

                if (jsonResponse.getJSONArray("related").getJSONObject(i).has("description"))
                {
                    jsonResponse.getJSONArray("related").getJSONObject(i).getString("description");
                }

                Boolean.parseBoolean(jsonResponse.getJSONArray("related").getJSONObject(i).getString("adultContent"));
                Boolean.parseBoolean(jsonResponse.getJSONArray("related").getJSONObject(i).getString("subscriberMedia"));

                JsonUtil.validateValueJson(jsonResponse.getJSONArray("related").getJSONObject(i), new String[] { "title", "description" });
            }

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - json is not valid - " + e.getMessage() + " - " + jsonResponse);
            return false;
        }
    }
}
