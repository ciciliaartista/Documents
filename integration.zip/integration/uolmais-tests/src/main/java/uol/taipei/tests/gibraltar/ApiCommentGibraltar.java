/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         11/09/2014 Criacao inicial
 */

package uol.taipei.tests.gibraltar;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uol.taipei.request.JsonRequest;
import uol.taipei.tests.comment.ApiComment;
import uol.taipei.tests.util.JsonUtil;
import uol.taipei.tests.util.TestUtil;
import uol.taipei.webServiceClient.WSReturn;

public class ApiCommentGibraltar extends ApiComment
{
    static final Logger logger = LoggerFactory.getLogger(ApiCommentGibraltar.class);

    public static void main(String[] args)
    {
        if (!verifyParams(args))
        {
            return;
        }

        setUp(args[0]);

        if (envConfig().getUser() == null || envConfig().getUser().equals("") || envConfig().getPass() == null || envConfig().getPass().equals(""))
        {
            System.err.println("Invalid user " + envConfig().getUser());
            return;
        }

        logger.debug("-------------------------------------------------");
        logger.debug("tests api comment gibraltar");

        try
        {
            ApiCommentGibraltar apiCommentGibraltar = new ApiCommentGibraltar();

            JSONObject media = JsonUtil.mediaIdtSubject(false);
            Long idtMedia = Long.parseLong(JsonUtil.getParam(media, "idt_media").toString());

            apiCommentGibraltar.topicLink(idtMedia);
            apiCommentGibraltar.topicLinkNoModeration();
        }
        catch (Exception e)
        {
            logger.error(e.getMessage());
        }
    }

    public JSONObject topicLink(Long mediaId) throws Exception
    {
        int retry = 0;
        String url = "http://mais.uol.com.br/apiuol/v2/comment/topic/link.json?mediaId=" + mediaId;
        WSReturn ret = JsonUtil.wsReturn(JsonRequest.execGibraltar(url, "GET", null, null, 15000));

        while ((ret == null || ret.getResponseCode() != 200) && retry < 3)
        {
            logger.warn("retry - " + url);

            TestUtil.delay(5000);
            ret = JsonUtil.wsReturn(JsonRequest.execGibraltar(url, "GET", null, null, 15000));
            retry++;
        }

        if (ret.getResponseCode() != 200)
        {
            logger.error("ERROR - response not valid - " + url + " - " + ret.getResponseCode() + " - " + ret.getObjResponse());
            return null;
        }

        if (!validateContentJson(ret.getObjResponse()))
        {
            logger.error("ERROR - return not valid - " + ret.getObjResponse());
            return null;
        }

        if (ret.getObjResponse().getJSONObject("content").getJSONObject("media").getLong("idtSubject") == 0)
        {
            logger.error("ERROR - return not match - " + url + " - " + ret.getObjResponse());
            return null;
        }

        logger.debug("SUCCESS");

        return ret.getObjResponse();
    }

    public JSONObject topicLinkNoModeration() throws Exception
    {
        JSONObject media = JsonUtil.mediaIdtSubject(false);
        String url = "http://mais.uol.com.br/apiuol/v2/comment/topic/link.json?mediaId=" + media.getLong("idt_media") + "&moderationType=NOT";
        WSReturn ret = JsonUtil.wsReturn(JsonRequest.execGibraltar(url, "GET", null, null, 10000));

        if (ret.getResponseCode() != 200)
        {
            logger.error("ERROR - response not valid - " + url + " - " + ret.getResponseCode());
            return null;
        }

        if (!validateContentJson(ret.getObjResponse()))
        {
            logger.error("ERROR - return not valid - " + ret.getObjResponse());
            return null;
        }

        if (ret.getObjResponse().getJSONObject("content").getJSONObject("media").getLong("idtSubject") == 0)
        {
            logger.error("ERROR - return not match - " + url + " - " + ret.getObjResponse());
            return null;
        }

        logger.debug("SUCCESS");

        return ret.getObjResponse();
    }
}
