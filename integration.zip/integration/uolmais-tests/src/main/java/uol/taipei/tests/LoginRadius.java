/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         02/07/2014 Criacao inicial
 */

package uol.taipei.tests;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.params.ClientPNames;
import org.apache.http.client.params.CookiePolicy;
import org.apache.http.cookie.Cookie;
import org.apache.http.impl.client.BasicCookieStore;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uol.taipei.request.UsefulRequest;

public class LoginRadius extends UsefulRequest
{
    static final Logger logger = LoggerFactory.getLogger(LoginRadius.class);

    private BasicCookieStore cookieStore = new BasicCookieStore();

    public LoginRadius(String user, String pass) throws Exception
    {
        super();

        authenticate("http://videos.intranet.uol.com.br/j_security_check", user, pass);
    }

    private void authenticate(String url, String user, String pass)
    {
        try
        {
            client = new DefaultHttpClient();
            HttpPost authPost = new HttpPost(url);

            List<BasicNameValuePair> nvps = new ArrayList<BasicNameValuePair>();

            nvps.add(new BasicNameValuePair("j_username", user));
            nvps.add(new BasicNameValuePair("j_password", pass));

            authPost.setEntity(new UrlEncodedFormEntity(nvps, "UTF-8"));
            authPost.getParams().setParameter(ClientPNames.COOKIE_POLICY, CookiePolicy.BROWSER_COMPATIBILITY);
            authPost.setHeader("Content-Type", "application/x-www-form-urlencoded");

            HttpResponse responseLogin = client.execute(authPost);

            if (responseLogin != null && responseLogin.getEntity() != null)
            {
                responseLogin.getEntity().consumeContent();
            }
            else
            {
                logger.error(responseLogin.getStatusLine().getReasonPhrase() + " login");
            }

            for (Cookie cookie : ((DefaultHttpClient) client).getCookieStore().getCookies())
            {
                cookieStore.addCookie(cookie);
            }

            ((DefaultHttpClient) client).setCookieStore(cookieStore);

            authPost.abort();
            client.getConnectionManager().closeExpiredConnections();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    public boolean isAuthenticated()
    {
        try
        {
            JSONObject jsonResponse = getJson("http://videos.intranet.uol.com.br/maisAdm/mediaAdm.json");

            if (jsonResponse.getJSONObject("_response").getInt("code") == 200)
            {
                return true;
            }
        }
        catch (Exception e)
        {
            logger.error(e.getMessage(), e);
            return false;
        }

        return false;
    }
}
