/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * pcassiano                        	 13 de jun de 2017	Criacao inicial
 */

package uol.taipei.tests.drakkar;

import java.util.Arrays;
import java.util.LinkedList;

import org.apache.http.HttpStatus;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uol.taipei.request.FacileRequest;
import uol.taipei.request.JsonRequest;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.util.RequestUtil;

public class ApiV4Player extends AbstractTest
{
    static final Logger logger = LoggerFactory.getLogger(ApiV4Player.class);
    
    public static void main(String[] args)
    {
        if (!verifyParams(args))
        {
            return;
        }
        
        setUp(args[0]);
        
        if (envConfig().getUser() == null || envConfig().getUser().equals("") || envConfig().getPass() == null
                || envConfig().getPass().equals(""))
        {
            System.err.println("Invalid user " + envConfig().getUser());
            return;
        }

        logger.debug("-------------------------------------------------");
        logger.debug("tests api v4 player");
        
        try
        {
            ApiV4Player apiPlayer = new ApiV4Player(false);
            FacileRequest request = new FacileRequest();

            if (apiPlayer.isSSL)
            {
                request.configureSSL();
            }

            String mediaId = RequestUtil.mediaIdPublic("V");

            apiPlayer.configPlayer(mediaId, request);
            apiPlayer.dataPlayer(mediaId, request);
            apiPlayer.publicPermission(request);
            apiPlayer.restrictNobodyViewPermission(request);
            apiPlayer.restrictFriendViewPermission(request);
            apiPlayer.restrictDraftPermission(request);
            apiPlayer.restrictRemovedPermission(request);
            apiPlayer.restrictSubscriberPermission(request);
            apiPlayer.restrictProductPermission(request);

            mediaId = RequestUtil.mediaIdPublic("P");

            apiPlayer.configPlayer(mediaId, request);
            apiPlayer.dataPlayer(mediaId, request);
            
        }
        catch (Exception e)
        {
            logger.error(e.getMessage());
        }
    }

    private static final LinkedList<String> FORMATS_NAME = new LinkedList<>(
            Arrays.asList(new String[] { "3gp-240p", "3gp-144p", "1080p", "360p", "480p", "720p", "mobile", "HLS" }));

    /**
     * construtor
     * 
     * @param isSSL define http ou https
     */
    public ApiV4Player(boolean isSSL)
    {
        this.isSSL = isSSL;
        this.host = "http" + (isSSL ? "s" : "") + "://" + envConfig().getGlobal().getUrlapi();
    }

    /**
     * retorna o json da resposta da api para player/config/mediaId
     */
    public JSONObject configPlayer(String mediaId, FacileRequest request) throws Exception
    {
        String url = host + "/apiuol/v4/player/config/" + mediaId;

        JSONObject jsonResponse = getJsonResponse(url, request);

        if (!validateConfigJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse + " - " + url);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    /**
     * retorna o json da resposta da api para player/data/mediaId
     */
    public JSONObject dataPlayer(String mediaId, FacileRequest request) throws Exception
    {
        String url = host + "/apiuol/v4/player/data/" + mediaId;

        JSONObject jsonResponse = getJsonResponse(url, request);

        if (!validateDataJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse + " - " + url);
            return null;
        }

        logger.debug("SUCESS");
        return jsonResponse;
    }

    /**
     * Retorna se a permissao para midias publicas esta correto
     */
    public JSONObject publicPermission(FacileRequest request) throws Exception
    {
        String mediaId = RequestUtil.mediaIdPublic("V");
        String url = host + "/apiuol/v4/player/config/" + mediaId;
        JSONObject response = getJsonResponse(url, request);

        if (response.getJSONObject("response").getInt("code") != HttpStatus.SC_OK)
        {
            logger.error("ERROR - return not valid - code: " + response.getJSONObject("response").getInt("code"));
            return null;
        }

        if (!validatePermission(response, "HAS_PERMISSION"))
        {
            logger.error("ERROR - return not valid - " + response);
            return null;
        }

        logger.debug("SUCESS");
        return response;
    }

    /**
     * Retorna se a permissao de midias que estao fechadas somente para o autor
     * esta correta
     */
    public JSONObject restrictNobodyViewPermission(FacileRequest request) throws Exception
    {
        String mediaId = RequestUtil.mediaIdRestrict(10, "V", "N",
            false, false, false, false, false);
        String url = host + "/apiuol/v4/player/config/" + mediaId;
        JSONObject response = getJsonResponse(url, request);

        if (response.getJSONObject("response").getInt("code") != HttpStatus.SC_UNAUTHORIZED)
        {
            logger.error("ERROR - return not valid - code: " + response.getJSONObject("response").getInt("code"));
            return null;
        }

        if (!validatePermission(response, "NO_PERMISSION_JUST_OWNER"))
        {
            logger.error("ERROR - return not valid - " + response);
            return null;
        }

        logger.debug("SUCESS");
        return response;
    }

    /**
     * Retorna se a permissao de midias que estao fechadas somente para amigos
     * esta correta
     */
    public JSONObject restrictFriendViewPermission(FacileRequest request) throws Exception
    {
        String mediaId = RequestUtil.mediaIdRestrict(10, "V",
            "A", false, false, false, false, false);
        String url = host + "/apiuol/v4/player/config/" + mediaId;
        JSONObject response = getJsonResponse(url, request);

        if (response.getJSONObject("response").getInt("code") != HttpStatus.SC_UNAUTHORIZED)
        {
            logger.error("ERROR - return not valid - code: " + response.getJSONObject("response").getInt("code"));
            return null;
        }

        if (!validatePermission(response, "NO_PERMISSION_JUST_FRIENDS_UOLK"))
        {
            logger.error("ERROR - return not valid - " + response);
            return null;
        }

        logger.debug("SUCESS");
        return response;
    }

    /**
     * Retorna se a permissao de midias removidas estao corretas
     */
    public JSONObject restrictRemovedPermission(FacileRequest request) throws Exception
    {
        String mediaId = RequestUtil.mediaIdRestrictFile(20, "V",
            "T", false, false, false);
        String url = host + "/apiuol/v4/player/config/" + mediaId;
        JSONObject response = getJsonResponse(url, request);

        if (response.getJSONObject("response").getInt("code") != HttpStatus.SC_UNAUTHORIZED)
        {
            logger.error("ERROR - return not valid - code: " + response.getJSONObject("response").getInt("code"));
            return null;
        }

        if (!validatePermission(response, "REMOVED"))
        {
            logger.error("ERROR - return not valid - " + response);
            return null;
        }

        logger.debug("SUCESS");
        return response;
    }

    /**
     * Retorna se a permissao para midias que estao abertas somente para
     * assinantes esta correta
     */
    public JSONObject restrictSubscriberPermission(FacileRequest request) throws Exception
    {
        String mediaId = RequestUtil.mediaIdRestrict(10, "V", "T",
            false, true, false, false, false);
        String url = host + "/apiuol/v4/player/config/" + mediaId;
        JSONObject response = getJsonResponse(url, request);

        if (response.getJSONObject("response").getInt("code") != HttpStatus.SC_UNAUTHORIZED)
        {
            logger.error("ERROR - return not valid - code: " + response.getJSONObject("response").getInt("code"));
            return null;
        }

        if (!validatePermission(response, "NO_PERMISSION_SUBSCRIBER"))
        {
            logger.error("ERROR - return not valid - " + response);
            return null;
        }

        logger.debug("SUCESS");
        return response;
    }

    /**
     * Retorna se a permissao para midias que estao pendentes esta correta
     */
    public JSONObject restrictDraftPermission(FacileRequest request) throws Exception
    {
        String mediaId = RequestUtil.mediaIdRestrict(10, "V", "T", true,
            false, false, false, false);
        String url = host + "/apiuol/v4/player/config/" + mediaId;
        JSONObject response = getJsonResponse(url, request);

        if (response.getJSONObject("response").getInt("code") != HttpStatus.SC_UNAUTHORIZED)
        {
            logger.error("ERROR - return not valid - code: " + response.getJSONObject("response").getInt("code"));
            return null;
        }

        if (!validatePermission(response, "NO_PERMISSION_JUST_OWNER"))
        {
            logger.error("ERROR - return not valid - " + response);
            return null;
        }

        logger.debug("SUCESS");
        return response;
    }
    
    /**
     * Retorna se a permissao para midias exclusivas para alguns produtos esta
     * correta
     */
    public JSONObject restrictProductPermission(FacileRequest request) throws Exception
    {
        String mediaId = RequestUtil.mediaIdRestrict(10, "V", "T", false,
            false, false, false, true);
        String url = host + "/apiuol/v4/player/config/" + mediaId;
        JSONObject response = getJsonResponse(url, request);

        if (response.getJSONObject("response").getInt("code") != HttpStatus.SC_UNAUTHORIZED)
        {
            logger.error("ERROR - return not valid - code: " + response.getJSONObject("response").getInt("code"));
            return null;
        }

        if (!validatePermission(response, "NO_PERMISSION_BY_PRODUCT"))
        {
            logger.error("ERROR - return not valid - " + response);
            return null;
        }

        logger.debug("SUCESS");
        return response;
    }

    /**
     * Faz a requisicao para a url e retorna o json da resposta
     */
    private JSONObject getJsonResponse(String url, FacileRequest request) throws Exception
    {
        JSONObject jsonResponse = null;

        if (isSSL)
        {
            jsonResponse = request.get(url).getJson();
        }
        else
        {
            jsonResponse = JsonRequest.get(url);
        }
        return jsonResponse;
    }

    /**
     * Valida os parametros da resposta de player/config
     */
    private boolean validateConfigJson(JSONObject jsonResponse)
    {
        try
        {
            if (!validateReponse(jsonResponse) || !validatePermission(jsonResponse))
            {
                return false;
            }

            JSONObject item = jsonResponse.getJSONObject("item");

            item.getString("userIp");
            JSONObject playerParameters = item.getJSONObject("playerParameters");

            playerParameters.getString("dfp_on");
            playerParameters.getString("hls_allow_domain_regexp");
            //playerParameters.getString("hls_maisuol_enabled");
            //playerParameters.getString("test_enabled");
            playerParameters.getString("dfp_custom_timeout_request_time");
            playerParameters.getString("dfp_custom_timeout_adload_time");
            playerParameters.getString("hls_enabled");
            playerParameters.getString("hls_minimum_quality_visible");
            playerParameters.getString("dfp_native_timeout_on");
            playerParameters.getString("dfp_custom_timeout_buffer_time");
            playerParameters.getString("range_request");
            playerParameters.getString("hls_start_quality_mobile");
            playerParameters.getString("dfp_timeout");
            playerParameters.getString("hls_start_quality_desktop");
            playerParameters.getString("media_view_after_timeout");
            playerParameters.getString("dfp_native_timeout_time");
            playerParameters.getString("dfp_custom_timeout_on");

            return true;
        }
        catch (Exception e)
        {
            logger.error(e.getMessage());
            return false;
        }
    }

    /**
     * Valida os parametros da resposta de player/data
     */
    private boolean validateDataJson(JSONObject jsonResponse)
    {
        try
        {
            if (!validateReponse(jsonResponse))
            {
                return false;
            }

            JSONObject item = jsonResponse.getJSONObject("item");

            item.getString("author");
            item.getLong("mediaId");
            item.getString("title");
            item.getString("url");
            item.getInt("revision");
            item.getString("shareUrl");
            item.getString("codProfile");
            item.getString("hash");

            JSONObject duration = item.getJSONObject("duration");
            duration.getInt("seconds");
            duration.getString("formatted");

            item.getString("type");
            if (item.getString("type").equals("P"))
            {
                item.getString("audioUrl");
            }

            if (item.getString("type").equals("V"))
            {

                item.getString("thumbnail");
                item.getInt("generatedThumbs");
                item.getString("iu");
                item.getString("tags");

                JSONObject formats = item.getJSONObject("formats");

                for (int formatIndex = 0; formatIndex < formats.names().length(); formatIndex++)
                {
                    String formatName = formats.names().getString(formatIndex);

                    if (!FORMATS_NAME.contains(formatName))
                    {
                        logger.error("ERROR - video format is not valid - " + formatName + " - " + jsonResponse);
                        return false;
                    }
                    formats.getJSONObject(formatName).getString("filename");
                    formats.getJSONObject(formatName).getString("url");
                }
            }

            return true;
        }
        catch (Exception e)
        {
            logger.error(e.getMessage());
            return false;
        }
    }

    /**
     * Verifica se os status da resposta
     */
    private boolean validateReponse(JSONObject jsonResponse) throws JSONException
    {
        int codStatus = jsonResponse.getJSONObject("response").getInt("code");
        if (jsonResponse == null || (codStatus != HttpStatus.SC_OK && codStatus != HttpStatus.SC_UNAUTHORIZED))
        {
            return false;
        }
        jsonResponse.getJSONObject("response");
        jsonResponse.getJSONObject("response").getString("description");
        jsonResponse.getJSONObject("response").getString("originalRequest");

        return true;
    }

    /**
     * Verifica os dados de permissao
     */
    private boolean validatePermission(JSONObject jsonResponse) throws JSONException
    {
        if (jsonResponse == null)
        {
            return false;
        }

        jsonResponse.getJSONObject("item");
        jsonResponse.getJSONObject("item").getInt("http_sub_error_code");
        jsonResponse.getJSONObject("item").getString("permission");
        jsonResponse.getJSONObject("item").getString("error_filename");

        return true;
    }

    /**
     * Verifica se permissao na resposta esta de acordo com o tipo de permissao
     * passada como parametro
     */
    private boolean validatePermission(JSONObject jsonResponse, String permission) throws Exception
    {
        JSONObject item = jsonResponse.getJSONObject("item");

        if (item.getString("permission").equals(permission))
        {
            return true;
        }

        return false;
    }
}
