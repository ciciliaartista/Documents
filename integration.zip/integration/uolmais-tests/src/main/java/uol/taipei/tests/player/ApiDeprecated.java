/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         05/09/2016 Criacao inicial
 */

package uol.taipei.tests.player;

import java.io.IOException;

import org.apache.http.HttpStatus;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uol.taipei.request.JsonRequest;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.util.JsonUtil;
import uol.taipei.tests.util.RequestUtil;

public class ApiDeprecated extends AbstractTest
{
    static final Logger logger = LoggerFactory.getLogger(ApiDeprecated.class);

    public static void main(String[] args)
    {
        if (!verifyParams(args))
        {
            return;
        }

        setUp(args[0]);

        if (envConfig().getUser() == null || envConfig().getUser().equals("") || envConfig().getPass() == null
                || envConfig().getPass().equals(""))
        {
            System.err.println("Invalid user " + envConfig().getUser());
            return;
        }

        logger.debug("-------------------------------------------------");
        logger.debug("tests api deprecated");

        try
        {
            String mediaId = RequestUtil.mediaIdPublic("V");
            ApiDeprecated apiLegacy = new ApiDeprecated();

            apiLegacy.player(mediaId, "undefined", null);
            apiLegacy.player(mediaId, "", null);
            apiLegacy.player(mediaId, "bolvideos", null);
            apiLegacy.player(mediaId, "bolvideos_teste", null);
            apiLegacy.player(mediaId, "canaluol", null);
            apiLegacy.player(mediaId, "editorbol", null);
            apiLegacy.player(mediaId, "editoruol", null);
            apiLegacy.player(mediaId, "embed_start", null);
            apiLegacy.player(mediaId, "homesuol", null);
            apiLegacy.player(mediaId, "parceiro", null);
            apiLegacy.player(mediaId, "parceiroembed", null);
            apiLegacy.player(mediaId, "related", null);
            apiLegacy.player(mediaId, "tvuol", null);
            apiLegacy.player(mediaId, "tvuol_nova", null);
            apiLegacy.player(mediaId, "tvuol_novaembed", null);
            apiLegacy.player(mediaId, "tvuol_teste", null);
            apiLegacy.player(mediaId, "maish", null);
            apiLegacy.player(mediaId, "mais", null);
            apiLegacy.player(mediaId, "mais", "js");

            apiLegacy.related(mediaId, null);
            apiLegacy.related(mediaId, "js");

            apiLegacy.notify(mediaId);
        }
        catch (Exception e)
        {
            logger.error(e.getMessage());
        }
    }

    public JSONObject player(String mediaId, String p, String suffix) throws IOException, JSONException
    {
        JSONObject jsonResponse = JsonRequest.get("http://mais.uol.com.br/apiuol/player/media" 
                + (suffix != null ? "." + suffix : "") + "?p=" + p + "&types=V&action=showPlayer&mediaId=" + mediaId);

        if (!validateJsonPlayer(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        jsonResponse = JsonRequest.get("http://mais.uol.com.br/api/deprecated/player" 
                + (suffix != null ? "." + suffix : "") + "?p=" + p + "&types=V&action=showPlayer&mediaId=" + mediaId);

        if (!validateJsonPlayer(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject related(String mediaId, String suffix) throws IOException, JSONException
    {
        JSONObject jsonResponse = JsonRequest
                .get("http://mais.uol.com.br/apiuol/player/related" + (suffix != null ? "." + suffix : "") 
                    + "?index.itemsPerPage=21&types=V&mediaId=" + mediaId);

        if (!validateJsonRelated(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        jsonResponse = JsonRequest
                .get("http://mais.uol.com.br/api/deprecated/related" + (suffix != null ? "." + suffix : "") 
                    + "?index.itemsPerPage=21&types=V&mediaId=" + mediaId);

        if (!validateJsonRelated(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject notify(String mediaId) throws IOException, JSONException
    {
        JSONObject jsonResponse = JsonRequest.get("http://mais.uol.com.br/notifyMediaView?t=v&v=2&mediaId=" + mediaId);

        if (!validateJsonNotify(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        jsonResponse = JsonRequest.get("http://mais.uol.com.br/api/deprecated/notifyMediaView?mediaId=" + mediaId);

        if (!validateJsonNotify(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    private boolean validateJsonNotify(JSONObject jsonResponse) throws JSONException
    {
        try
        {
            if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") != HttpStatus.SC_OK 
                    && jsonResponse.getJSONObject("_response").getInt("code") != HttpStatus.SC_NOT_FOUND)
            {
                return false;
            }

            jsonResponse.getBoolean("result");

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - json is not valid - " + e.getMessage() + " - " + jsonResponse);
            return false;
        }
    }

    private boolean validateJsonPlayer(JSONObject jsonResponse) throws JSONException
    {
        try
        {
            if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") != HttpStatus.SC_OK)
            {
                return false;
            }

            jsonResponse.getJSONObject("response");
            jsonResponse.getJSONObject("response").getInt("code");
            jsonResponse.getJSONObject("response").getString("description");
            // jsonResponse.getJSONObject("response").getString("originalRequest");

            jsonResponse.getJSONObject("config");
            jsonResponse.getJSONObject("config").getBoolean("sendlog");
            jsonResponse.getJSONObject("config").getBoolean("showrelated");
            jsonResponse.getJSONObject("config").getBoolean("shownext");
            jsonResponse.getJSONObject("config").getBoolean("showads");
            jsonResponse.getJSONObject("config").getBoolean("startplay");
            jsonResponse.getJSONObject("config").getBoolean("startloading");
            jsonResponse.getJSONObject("config").getBoolean("watermark");
            jsonResponse.getJSONObject("config").getBoolean("showbar");
            jsonResponse.getJSONObject("config").getBoolean("showplay");
            jsonResponse.getJSONObject("config").getBoolean("showvolume");
            jsonResponse.getJSONObject("config").getBoolean("showfullscreen");
            jsonResponse.getJSONObject("config").getString("skin");
            jsonResponse.getJSONObject("config").getBoolean("uselink");
            jsonResponse.getJSONObject("config").getBoolean("relatedembed");

            if (jsonResponse.getJSONObject("config").has("sharedlink"))
            {
                jsonResponse.getJSONObject("config").getBoolean("sharedlink");
            }

            if (jsonResponse.getJSONObject("config").has("showlogo"))
            {
                jsonResponse.getJSONObject("config").getBoolean("showlogo");
            }

            jsonResponse.getJSONObject("media");
            jsonResponse.getJSONObject("media").getString("title");
            jsonResponse.getJSONObject("media").getLong("mediaId");
            jsonResponse.getJSONObject("media").getString("url");
            jsonResponse.getJSONObject("media").getString("mediaType");
            jsonResponse.getJSONObject("media").getString("urlTvuol");
            jsonResponse.getJSONObject("media").getString("thumbnail");
            jsonResponse.getJSONObject("media").getString("player");
            jsonResponse.getJSONObject("media").getString("duration");
            jsonResponse.getJSONObject("media").getString("embedUrl");
            jsonResponse.getJSONObject("media").getString("embedCode");
            jsonResponse.getJSONObject("media").getInt("thumbVersion");
            jsonResponse.getJSONObject("media").getString("description");
            jsonResponse.getJSONObject("media").getBoolean("adultContent");
            jsonResponse.getJSONObject("media").getString("author");
            jsonResponse.getJSONObject("media").getString("codProfile");
            jsonResponse.getJSONObject("media").getBoolean("blockEmbed");
            jsonResponse.getJSONObject("media").getBoolean("subscriberMedia");
            jsonResponse.getJSONObject("media").getBoolean("dfp_on");
            jsonResponse.getJSONObject("media").getInt("dfp_timeout");
            jsonResponse.getJSONObject("media").get("codPublicityDfp");
            jsonResponse.getJSONObject("media").getString("publishedAt");
            jsonResponse.getJSONObject("media").getLong("views");
            jsonResponse.getJSONObject("media").getString("userIp");
            jsonResponse.getJSONObject("media").getBoolean("dart");
            jsonResponse.getJSONObject("media").getBoolean("seek");
            jsonResponse.getJSONObject("media").getBoolean("akamai");
            jsonResponse.getJSONObject("media").getBoolean("isInBlacklistTag");

            jsonResponse.getJSONObject("media").getJSONArray("formats");

            for (int i = 0; i < jsonResponse.getJSONObject("media").getJSONArray("formats").length(); i++)
            {
                jsonResponse.getJSONObject("media").getJSONArray("formats").getJSONObject(i).getInt("id");
                jsonResponse.getJSONObject("media").getJSONArray("formats").getJSONObject(i).getString("secureUrl");
                jsonResponse.getJSONObject("media").getJSONArray("formats").getJSONObject(i).getString("url");
            }

            jsonResponse.getJSONObject("media").getJSONArray("tags");

            for (int i = 0; i < jsonResponse.getJSONObject("media").getJSONArray("tags").length(); i++)
            {
                jsonResponse.getJSONObject("media").getJSONArray("tags").getJSONObject(i).getLong("id");
                jsonResponse.getJSONObject("media").getJSONArray("tags").getJSONObject(i).getString("description");
            }

            jsonResponse.getJSONObject("media").getJSONArray("profilesGroupsEditorial");

            for (int i = 0; i < jsonResponse.getJSONObject("media").getJSONArray("profilesGroupsEditorial").length(); i++)
            {
                jsonResponse.getJSONObject("media").getJSONArray("profilesGroupsEditorial").getInt(i);
            }

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - json is not valid - " + e.getMessage() + " - " + jsonResponse);
            return false;
        }
    }

    private boolean validateJsonRelated(JSONObject jsonResponse) throws JSONException
    {
        try
        {
            if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") != HttpStatus.SC_OK)
            {
                return false;
            }

            jsonResponse.getJSONObject("response");
            jsonResponse.getJSONObject("response").getInt("code");
            jsonResponse.getJSONObject("response").getString("description");
            jsonResponse.getJSONObject("response").getString("originalRequest");

            jsonResponse.getJSONArray("related");

            for (int i = 0; i < jsonResponse.getJSONArray("related").length(); i++)
            {
                jsonResponse.getJSONArray("related").getJSONObject(i).getString("title");
                jsonResponse.getJSONArray("related").getJSONObject(i).getLong("mediaId");
                jsonResponse.getJSONArray("related").getJSONObject(i).getString("url");
                jsonResponse.getJSONArray("related").getJSONObject(i).getString("mediaType");
                jsonResponse.getJSONArray("related").getJSONObject(i).getString("description");
                Boolean.parseBoolean(jsonResponse.getJSONArray("related").getJSONObject(i).getString("adultContent"));
                Boolean.parseBoolean(jsonResponse.getJSONArray("related").getJSONObject(i).getString("subscriberMedia"));

                if (jsonResponse.getJSONArray("related").getJSONObject(i).has("urlTvuol"))
                {
                    jsonResponse.getJSONArray("related").getJSONObject(i).getString("urlTvuol");
                }

                if (jsonResponse.getJSONArray("related").getJSONObject(i).has("thumbnail"))
                {
                    jsonResponse.getJSONArray("related").getJSONObject(i).getString("thumbnail");
                }

                if (jsonResponse.getJSONArray("related").getJSONObject(i).has("thumbVersion"))
                {
                    jsonResponse.getJSONArray("related").getJSONObject(i).getInt("thumbVersion");
                }

                if (jsonResponse.getJSONArray("related").getJSONObject(i).has("numGeneratedThumbs"))
                {
                    jsonResponse.getJSONArray("related").getJSONObject(i).getString("numGeneratedThumbs");
                }

                if (jsonResponse.getJSONArray("related").getJSONObject(i).has("player"))
                {
                    jsonResponse.getJSONArray("related").getJSONObject(i).getString("player");
                }

                if (jsonResponse.getJSONArray("related").getJSONObject(i).has("duration"))
                {
                    jsonResponse.getJSONArray("related").getJSONObject(i).getString("duration");
                }

                JsonUtil.validateValueJson(jsonResponse.getJSONArray("related").getJSONObject(i),
                    new String[] { "title", "description" });
            }

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - json is not valid - " + e.getMessage() + " - " + jsonResponse);
            return false;
        }
    }
}
