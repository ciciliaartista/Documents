/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         11/07/2014 Criacao inicial
 */

package uol.taipei.tests.moderation;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uol.taipei.request.UsefulRequest;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.LogErrorTest;
import uol.taipei.tests.LoginCookie;
import uol.taipei.tests.LoginRadius;
import uol.taipei.tests.util.JsonUtil;
import uol.taipei.tests.util.TestUtil;

public class PublicityAdm extends AbstractTest
{
    static final Logger logger = LoggerFactory.getLogger(PublicityAdm.class);

    public static void main(String[] args)
    {
        if (!verifyParams(args))
        {
            return;
        }

        setUp(args[0]);

        if (envConfig().getUser() == null || envConfig().getUser().equals("") || envConfig().getPass() == null || envConfig().getPass().equals(""))
        {
            System.err.println("Invalid user " + envConfig().getUser());
            return;
        }

        logger.debug("-------------------------------------------------");
        logger.debug("tests administration publicity");

        try
        {
            PublicityAdm publicityAdm = new PublicityAdm();
            LoginCookie login = new LoginCookie(envConfig().getUser(), envConfig().getPass());
            UsefulRequest loginR = new LoginRadius(envConfig().getUserRadius(), envConfig().getPassRadius());

            publicityAdm.listDfp(loginR, login.getJsonProfile().getJSONObject("item").getString("codProfile"));
            publicityAdm.addDfp(loginR, login.getJsonProfile().getJSONObject("item").getString("codProfile"));

            long idtTag = publicityAdm.getIdtTag(login, loginR);

            publicityAdm.addTagDfp(loginR, idtTag);
            publicityAdm.blacklistTagDfp(loginR);
            publicityAdm.removeTagDfp(loginR, idtTag);
        }
        catch (Exception e)
        {
            logger.error(e.getMessage());
            LogErrorTest.error(e);
        }
    }

    public JSONObject listDfp(UsefulRequest login, String codProfile) throws Exception
    {
        JSONObject jsonResponse = login.getJson("http://videos.intranet.uol.com.br/maisAdm/publicityAdm.json?codProfile=" + codProfile
                + "&codDfp=&codPublicity=&action=update");

        if (!validateListDfpJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject addDfp(UsefulRequest login, String codProfile) throws Exception
    {
        String dfp = TestUtil.randomString(10);
        JSONObject jsonResponse = login.getJson("http://videos.intranet.uol.com.br/maisAdm/publicityAdm.json?codProfile=" + codProfile
                + "&codDfp=" + dfp + "&codPublicity=&action=update");

        if (!validateListDfpJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        if (!validateMessageJson(jsonResponse, 'S'))
        {
            logger.error("ERROR - message not valid - " + jsonResponse);
            return null;
        }

        if (!dfp.equals(jsonResponse.getJSONObject("profileMediaConfig").getString("codPartnerDfp")))
        {
            logger.error("ERROR - dfp was not inserted - " + dfp + " - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject blacklistTagDfp(UsefulRequest login) throws Exception
    {
        JSONObject jsonResponse = login.getJson("http://videos.intranet.uol.com.br/maisAdm/publicityAdm.json?action=showBlacklistTags");

        if (!validateBlackListTagDfpJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public boolean addTagDfp(UsefulRequest login, long idtTag) throws Exception
    {
        HttpResponse response = login.get("http://videos.intranet.uol.com.br/maisAdm/publicityAdm.json?idtBlacklistTag=" + idtTag
                + "&action=createBlacklistTag");

        if (response.getStatusLine().getStatusCode() != 302)
        {
            logger.error("ERROR - return not valid - " + response.getStatusLine());
            return false;
        }

        if (!response.getFirstHeader("location").getValue()
                .equals("http://videos.intranet.uol.com.br/maisAdm/publicityAdm?action=showBlacklistTags"))
        {
            logger.error("ERROR - return not valid - " + response.getFirstHeader("location").getValue());
            return false;
        }

        if (!hasBlackListTagDfp(login, idtTag))
        {
            logger.error("ERROR - tagdfp was not inserted - " + idtTag);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean removeTagDfp(UsefulRequest login, long idtTag) throws Exception
    {
        HttpResponse response = login
                .get("http://videos.intranet.uol.com.br/maisAdm/publicityAdm.json?action=deleteBlacklistTag&idtBlacklistTag=" + idtTag);

        if (response.getStatusLine().getStatusCode() != 302)
        {
            logger.error("ERROR - return not valid - " + response.getStatusLine());
            return false;
        }

        if (!response.getFirstHeader("location").getValue()
                .equals("http://videos.intranet.uol.com.br/maisAdm/publicityAdm?action=showBlacklistTags"))
        {
            logger.error("ERROR - return not valid - " + response.getFirstHeader("location").getValue());
            return false;
        }

        if (hasBlackListTagDfp(login, idtTag))
        {
            logger.error("ERROR - tagdfp was not removed - " + idtTag);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public long getIdtTag(LoginCookie loginC, UsefulRequest loginR) throws Exception
    {
        JSONObject jsonResponse = loginC.getjson("http://beta.mais.uol.com.br/sys/tags/author.json?index.itemsPerPage=20");

        if (jsonResponse.getJSONObject("tagCloudPage").getJSONArray("items").length() > 0)
        {
            for (int i = 0; i < jsonResponse.getJSONObject("tagCloudPage").getJSONArray("items").length(); i++)
            {
                if (!hasBlackListTagDfp(loginR,
                    jsonResponse.getJSONObject("tagCloudPage").getJSONArray("items").getJSONObject(i).getLong("idtTag")))
                {
                    return jsonResponse.getJSONObject("tagCloudPage").getJSONArray("items").getJSONObject(i).getLong("idtTag");
                }
            }
        }

        return 0;
    }

    private boolean hasBlackListTagDfp(UsefulRequest login, long idtTag) throws Exception
    {
        JSONObject jsonResponse = login.getJson("http://videos.intranet.uol.com.br/maisAdm/publicityAdm.json?action=showBlacklistTags");

        for (int i = 0; i < jsonResponse.getJSONArray("blacklistTags").length(); i++)
        {
            if (jsonResponse.getJSONArray("blacklistTags").getJSONObject(i).getInt("idtTag") == idtTag)
            {
                return true;
            }
        }

        return false;
    }

    private boolean validateListDfpJson(JSONObject jsonResponse) throws JSONException
    {
        try
        {
            if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") != HttpStatus.SC_OK)
            {
                return false;
            }

            jsonResponse.getJSONObject("profileMediaConfig");
            jsonResponse.getJSONObject("profileMediaConfig").getLong("codProfileHash");
            jsonResponse.getJSONObject("profileMediaConfig").getString("desSubject");
            jsonResponse.getJSONObject("profileMediaConfig").getString("indVisibility");
            jsonResponse.getJSONObject("profileMediaConfig").getString("indAllowNotes");
            jsonResponse.getJSONObject("profileMediaConfig").getInt("codTheme");
            jsonResponse.getJSONObject("profileMediaConfig").getString("indHot");
            jsonResponse.getJSONObject("profileMediaConfig").getInt("flgAllowVideoComment");
            jsonResponse.getJSONObject("profileMediaConfig").getInt("flgAllowAnonymousComment");
            jsonResponse.getJSONObject("profileMediaConfig").getInt("flgModerateNote");
            jsonResponse.getJSONObject("profileMediaConfig").getInt("flgNotifyComment");
            jsonResponse.getJSONObject("profileMediaConfig").getString("desHomepage");
            jsonResponse.getJSONObject("profileMediaConfig").getInt("flgBulletinRequester");
            jsonResponse.getJSONObject("profileMediaConfig").getInt("numServer");
            jsonResponse.getJSONObject("profileMediaConfig").getInt("numMedias");

            if (jsonResponse.getJSONObject("profileMediaConfig").has("indBlockCountry"))
            {
                jsonResponse.getJSONObject("profileMediaConfig").getString("indBlockCountry");
            }

            if (jsonResponse.getJSONObject("profileMediaConfig").has("flgBlockEmbed"))
            {
                jsonResponse.getJSONObject("profileMediaConfig").getInt("flgBlockEmbed");
            }

            jsonResponse.getJSONObject("profile");
            jsonResponse.getJSONObject("profile").getLong("codProfileHash");
            jsonResponse.getJSONObject("profile").getLong("idtPerson");
            jsonResponse.getJSONObject("profile").getString("indUserProfile");
            jsonResponse.getJSONObject("profile").getString("namNick");
            jsonResponse.getJSONObject("profile").getString("desUrlProfile");
            jsonResponse.getJSONObject("profile").getString("indStatus");
            jsonResponse.getJSONObject("profile").getString("namLogin");
            jsonResponse.getJSONObject("profile").getString("namNickUnique");

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - jsonListDfp is not valid - " + e.getMessage() + " - " + jsonResponse);
            LogErrorTest.error(e);
            return false;
        }
    }

    private boolean validateMessageJson(JSONObject json, char type)
    {
        try
        {
            if (json == null || json.getJSONObject("_response").getInt("code") != HttpStatus.SC_OK)
            {
                return false;
            }
            json.getJSONObject("messages");

            if (type == 'S')
            {
                json.getJSONObject("messages").getJSONArray("success");

                if (json.getJSONObject("messages").getJSONArray("success").length() < 1)
                {
                    throw new Exception("no has success message");
                }

                for (int i = 0; i < json.getJSONObject("messages").getJSONArray("success").length(); i++)
                {
                    json.getJSONObject("messages").getJSONArray("success").getJSONObject(i).getString("id");
                    json.getJSONObject("messages").getJSONArray("success").getJSONObject(i).getString("description");

                    JsonUtil.validateValueJson(json.getJSONObject("messages").getJSONArray("success").getJSONObject(i), new String[] { "" });
                }
            }
            else if (type == 'E')
            {
                json.getJSONObject("messages").getJSONArray("errors");

                if (json.getJSONObject("messages").getJSONArray("errors").length() < 1)
                {
                    throw new Exception("no has error message");
                }

                for (int i = 0; i < json.getJSONObject("messages").getJSONArray("errors").length(); i++)
                {
                    json.getJSONObject("messages").getJSONArray("errors").getJSONObject(i).getString("id");
                    json.getJSONObject("messages").getJSONArray("errors").getJSONObject(i).getString("description");

                    JsonUtil.validateValueJson(json.getJSONObject("result").getJSONArray("errors").getJSONObject(i), new String[] { "" });
                }
            }
            else if (type == 'W')
            {
                json.getJSONObject("messages").getJSONArray("warns");

                if (json.getJSONObject("messages").getJSONArray("warns").length() < 1)
                {
                    throw new Exception("no has warn message");
                }

                for (int i = 0; i < json.getJSONObject("messages").getJSONArray("warns").length(); i++)
                {
                    json.getJSONObject("messages").getJSONArray("warns").getJSONObject(i).getString("id");
                    json.getJSONObject("messages").getJSONArray("warns").getJSONObject(i).getString("description");

                    JsonUtil.validateValueJson(json.getJSONObject("messages").getJSONArray("warns").getJSONObject(i), new String[] { "" });
                }
            }
            else
            {
                json.getJSONObject("messages").getJSONArray("infos");

                if (json.getJSONObject("messages").getJSONArray("infos").length() < 1)
                {
                    throw new Exception("no has info message");
                }

                for (int i = 0; i < json.getJSONObject("messages").getJSONArray("infos").length(); i++)
                {
                    json.getJSONObject("messages").getJSONArray("infos").getJSONObject(i).getString("id");
                    json.getJSONObject("messages").getJSONArray("infos").getJSONObject(i).getString("description");

                    JsonUtil.validateValueJson(json.getJSONObject("messages").getJSONArray("infos").getJSONObject(i), new String[] { "" });
                }
            }

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - message invalid - " + e.getMessage() + " - " + json);
            LogErrorTest.error(e);
            return false;
        }
    }

    private boolean validateBlackListTagDfpJson(JSONObject jsonResponse) throws JSONException
    {
        try
        {
            if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") != HttpStatus.SC_OK)
            {
                return false;
            }
            jsonResponse.getJSONArray("blacklistTags");

            for (int i = 0; i < jsonResponse.getJSONArray("blacklistTags").length(); i++)
            {
                jsonResponse.getJSONArray("blacklistTags").getJSONObject(i).getInt("idtTag");
                jsonResponse.getJSONArray("blacklistTags").getJSONObject(i).getLong("datInsert");
            }

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - blackListTagDfp invalid - " + e.getMessage() + " - " + jsonResponse);
            LogErrorTest.error(e);
            return false;
        }
    }
}
