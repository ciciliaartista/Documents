/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         25/07/2014 Criacao inicial
 */

package uol.taipei.tests.moderation;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import org.apache.http.HttpStatus;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uol.taipei.request.JsonRequest;
import uol.taipei.request.UsefulRequest;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.LoginRadius;
import uol.taipei.tests.util.JsonUtil;
import uol.taipei.tests.util.RequestUtil;

public class SubscriptionAdm extends AbstractTest
{
    static final Logger logger = LoggerFactory.getLogger(SubscriptionAdm.class);

    public static void main(String[] args)
    {
        if (!verifyParams(args))
        {
            return;
        }

        setUp(args[0]);

        if (envConfig().getUserRadius() == null || envConfig().getUserRadius().equals("") || envConfig().getPassRadius() == null || envConfig().getPassRadius().equals(""))
        {
            System.err.println("Invalid user " + envConfig().getUser());
            return;
        }

        logger.debug("-------------------------------------------------");
        logger.debug("tests administration subscription");

        try
        {
            SubscriptionAdm subscriptionAdm = new SubscriptionAdm();
            UsefulRequest loginR = new LoginRadius(envConfig().getUserRadius(), envConfig().getPassRadius());

            subscriptionAdm.saveError(loginR);
            subscriptionAdm.saveCodProfileError(loginR);
            subscriptionAdm.saveEditorType(loginR);
            subscriptionAdm.saveTag(loginR);
            subscriptionAdm.saveTagService(loginR);
            subscriptionAdm.list(loginR);
            subscriptionAdm.previewUser(loginR);
            subscriptionAdm.previewTag(loginR);
            subscriptionAdm.remove(loginR);
        }
        catch (Exception e)
        {
            logger.error(e.getMessage());
        }
    }

    public JSONObject list(UsefulRequest login) throws Exception
    {
        JSONObject jsonResponse = login.getJson("http://videos.intranet.uol.com.br/maisAdm/subscriptionAdm/list.json");

        if (!validateListJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject saveError(UsefulRequest login) throws Exception
    {
        JSONObject jsonResponse = login.getJson("http://videos.intranet.uol.com.br/maisAdm/subscriptionAdm/save.json");

        if (jsonResponse.has("sucesso"))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject saveEditorType(UsefulRequest login) throws Exception
    {
        Integer idtEditorType = null;
        int i;
        JSONObject jsonResponse = login.getJson("http://videos.intranet.uol.com.br/maisAdm/mediaAdmEditor.json");

        if (jsonResponse.getJSONArray("editorTypes").length() > 0)
        {
            i = new Random().nextInt(jsonResponse.getJSONArray("editorTypes").length() - 1);
            idtEditorType = jsonResponse.getJSONArray("editorTypes").getJSONObject(i).getInt("idtEditorType");
        }

        if (idtEditorType == null)
        {
            logger.info("idtEditorType not found");
            return null;
        }

        HashMap<String, String> params = new HashMap<String, String>();
        params.put("idtEditorType", idtEditorType.toString());
        params.put("desFollowable", "segue editorType " + params.get("idtEditorType"));

        jsonResponse = login.postDataJson("http://videos.intranet.uol.com.br/maisAdm/subscriptionAdm/save.json", params);

        if (!validateSaveJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        if (jsonResponse.getJSONObject("followable").getInt("idtEditorType") != Integer.parseInt(params.get("idtEditorType")))
        {
            logger.error("ERROR - return not valid - idtEditorType not match - " + params.get("idtEditorType") + " - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject saveCodProfileError(UsefulRequest login) throws Exception
    {
        HashMap<String, String> params = new HashMap<String, String>();
        params.put("codProfile", JsonUtil.codProfile());
        params.put("desFollowable", "segue codProfile " + params.get("codProfile"));

        if (params.get("codProfile") == null)
        {
            logger.info("codProfile not found");
            return null;
        }

        JSONObject jsonResponse = login.postDataJson("http://videos.intranet.uol.com.br/maisAdm/subscriptionAdm/save.json", params);

        if (jsonResponse.has("sucesso"))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject saveTag(UsefulRequest login) throws Exception
    {
        JSONArray arrayTags = JsonUtil.tags(true);

        if (arrayTags == null || arrayTags.length() < 1)
        {
            logger.info("tags not found");
            return null;
        }

        Long idtTag = arrayTags.getJSONObject(0).getLong("id");
        HashMap<String, String> params = new HashMap<String, String>();
        params.put("tags", idtTag.toString());
        params.put("desFollowable", "segue tags " + params.get("tags"));

        JSONObject jsonResponse = login.postDataJson("http://videos.intranet.uol.com.br/maisAdm/subscriptionAdm/save.json", params);

        if (!validateSaveJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        if (jsonResponse.getJSONObject("followable").getJSONArray("tags").getJSONObject(0).getLong("idtTag") != idtTag.longValue())
        {
            logger.error("ERROR - return not valid - tags not match - " + params.get("tags") + " - " + jsonResponse);
            return null;
        }

        if (jsonResponse.getJSONObject("followable").getBoolean("editorTag"))
        {
            logger.error("ERROR - return not valid - is not editorTag - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject saveTagService(UsefulRequest login) throws Exception
    {
        String tagService = JsonUtil.tagService(true);

        if (tagService == null)
        {
            tagService = RequestUtil.tagService(true, 2, 10);
        }

        if (tagService == null)
        {
            logger.info("tagService not found");
            return null;
        }

        HashMap<String, String> params = new HashMap<String, String>();
        params.put("tags", tagService);
        params.put("editorTag", "true");
        params.put("desFollowable", "segue tagservice " + params.get("tags"));

        JSONObject jsonResponse = login.postDataJson("http://videos.intranet.uol.com.br/maisAdm/subscriptionAdm/save.json", params);

        if (!validateSaveJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        if (jsonResponse.getJSONObject("followable").getJSONArray("tags").getJSONObject(0).getLong("idtTag") != Integer
                .parseInt(tagService))
        {
            logger.error("ERROR - return not valid - tagservice not match - " + params.get("tags") + " - " + jsonResponse);
            return null;
        }

        if (!jsonResponse.getJSONObject("followable").getBoolean("editorTag"))
        {
            logger.error("ERROR - return not valid - is editorTag - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject remove(UsefulRequest login) throws Exception
    {
        JSONObject jsonResponse = null;
        List<Long> idtFollowables = new ArrayList<Long>();
        JSONObject followable = followable(login, true, false, false, false);

        if (followable != null && !followable.isNull("followable"))
        {
            idtFollowables.add(followable.getJSONObject("followable").getLong("idtFollowable"));
        }

        followable = followable(login, false, true, false, false);

        if (followable != null && !followable.isNull("followable"))
        {
            idtFollowables.add(followable.getJSONObject("followable").getLong("idtFollowable"));
        }

        followable = followable(login, false, true, true, false);

        if (followable != null && !followable.isNull("followable"))
        {
            idtFollowables.add(followable.getJSONObject("followable").getLong("idtFollowable"));
        }

        for (Long idtFollowable : idtFollowables)
        {
            jsonResponse = login.getJson("http://videos.intranet.uol.com.br/maisAdm/subscriptionAdm/remove.json?idtFollowable=" + idtFollowable);

            if (!validateListJson(jsonResponse))
            {
                logger.error("ERROR - return not valid - " + idtFollowable + " - " + jsonResponse);
                return null;
            }
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject previewUser(UsefulRequest login) throws Exception
    {
        JSONObject followable = followable(login, true, false, false, false);

        if (followable == null || followable.isNull("followable"))
        {
            logger.info("followable not found");
            return followable;
        }

        if (!followable.getJSONObject("followable").has("codProfile"))
        {
            logger.error("wrong followable, no codProfile " + followable);
            return null;
        }

        if (followable.getJSONObject("followable").has("tags"))
        {
            logger.error("wrong followable, has tag " + followable);
            return null;
        }

        if (followable.getJSONObject("followable").getBoolean("editorTag"))
        {
            logger.error("wrong followable, is editorTag " + followable);
            return null;
        }

        if (followable.getJSONObject("followable").getBoolean("flagAnd"))
        {
            logger.error("wrong followable, is and " + followable);
            return null;
        }

        String url = mountMediaList(followable);
        JSONObject jsonResponse = JsonRequest.get(url);

        if (!validatePageJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + url + " - " + jsonResponse);
            return null;
        }

        for (int i = 0; i < jsonResponse.getJSONArray("list").length(); i++)
        {
            if (!jsonResponse.getJSONArray("list").getJSONObject(i).getString("codProfile")
                    .equals(followable.getJSONObject("followable").getString("codProfile")))
            {
                logger.error("ERROR - codProfile not match - codProfile " + followable.getJSONObject("followable").getString("codProfile")
                        + " - " + jsonResponse);
                return null;
            }
        }

        logger.debug("SUCCESS");

        return followable;
    }

    public JSONObject previewTag(UsefulRequest login) throws Exception
    {
        boolean flgAnd = false;
        boolean contains = false;
        JSONObject followable = followable(login, false, true, false, flgAnd);

        if (followable == null || followable.isNull("followable"))
        {
            logger.info("followable not found");
            return followable;
        }

        if (followable.getJSONObject("followable").has("codProfile"))
        {
            logger.error("wrong followable, hs codProfile " + followable);
            return null;
        }

        if (!followable.getJSONObject("followable").has("tags"))
        {
            logger.error("wrong followable, no tag " + followable);
            return null;
        }

        if (followable.getJSONObject("followable").getBoolean("editorTag"))
        {
            logger.error("wrong followable, is editorTag " + followable);
            return null;
        }

        if (followable.getJSONObject("followable").getBoolean("flagAnd"))
        {
            logger.error("wrong followable, is and " + followable);
            return null;
        }

        String url = mountMediaList(followable);
        JSONObject jsonResponse = JsonRequest.get(url);

        if (!validatePageJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + url + " - " + jsonResponse);
            return null;
        }

        for (int i = 0; i < jsonResponse.getJSONArray("list").length(); i++)
        {
            for (int j = 0; j < followable.getJSONObject("followable").getJSONArray("tags").length(); j++)
            {
                if (!flgAnd)
                {
                    if (JsonUtil.containsTagId(jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("tags"), followable
                            .getJSONObject("followable").getJSONArray("tags").getJSONObject(j).getInt("idtTag")))
                    {
                        contains = true;
                        break;
                    }
                }
                else
                {
                    if (!JsonUtil.containsTagId(jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("tags"), followable
                            .getJSONObject("followable").getJSONArray("tags").getJSONObject(j).getInt("idtTag")))
                    {
                        logger.error("ERROR - tagIds not match - tags "
                                + followable.getJSONArray("tags").getJSONObject(j).getLong("idtTag") + " - " + jsonResponse);
                        return null;
                    }
                }
            }
        }

        if (!flgAnd && !contains && jsonResponse.getJSONArray("list").length() > 0)
        {
            logger.error("ERROR - tags not match - tags " + followable.getJSONObject("followable").getJSONArray("tags") + " - "
                    + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return followable;
    }

    private String mountMediaList(JSONObject followable) throws Exception
    {
        StringBuffer url = new StringBuffer("http://mais.uol.com.br/apiuol/v2/media/list");
        boolean set = false;

        if (followable.getJSONObject("followable").has("codProfile"))
        {
            url.append((set ? "" : "?") + "codProfile=" + followable.getJSONObject("followable").getString("codProfile"));
            set = true;
        }

        if (followable.getJSONObject("followable").has("tags"))
        {
            if (followable.getJSONObject("followable").getBoolean("editorTag"))
            {
                url.append((set ? "&" : "?") + "idtTagService=");
            }
            else
            {
                url.append((set ? "&" : "?") + "tagIds=");
            }

            boolean first = true;

            for (int i = 0; i < followable.getJSONObject("followable").getJSONArray("tags").length(); i++)
            {
                url.append((first ? "" : ",")
                        + followable.getJSONObject("followable").getJSONArray("tags").getJSONObject(i).getLong("idtTag"));
                first = false;
            }

            set = true;

            if (followable.getJSONObject("followable").getJSONArray("tags").length() > 1)
            {
                if (followable.getJSONObject("followable").getBoolean("editorTag"))
                {
                    url.append((set ? "&" : "?") + "qryServTag=");
                }
                else
                {
                    url.append((set ? "&" : "?") + "qryTag=");
                }

                if (followable.getJSONObject("followable").getBoolean("flagAnd"))
                {
                    url.append("and");
                }
                else
                {
                    url.append("or");
                }
            }
        }

        return url.toString();
    }

    private JSONObject followable(UsefulRequest login, boolean useUser, boolean useTag, boolean isTagservice, boolean isAnd)
            throws Exception
    {
        String url = "http://videos.intranet.uol.com.br/maisAdm/subscriptionAdm/list.json";
        JSONObject jsonResponse = login.getJson(url);
        JSONObject result = null;

        for (int i = 0; i < jsonResponse.getJSONObject("collection").getJSONArray("followables").length(); i++)
        {
            result = login.getJson("http://videos.intranet.uol.com.br/maisAdm/subscriptionAdm/show.json?idtFollowable="
                    + jsonResponse.getJSONObject("collection").getJSONArray("followables").getJSONObject(i).getInt("idtFollowable"));

            if (useTag)
            {
                if (result != null && !result.isNull("followable") && result.getJSONObject("followable").has("tags"))
                {
                    if (useUser)
                    {
                        if (isTagservice)
                        {
                            if (result.getJSONObject("followable").getBoolean("editorTag"))
                            {
                                if (isAnd)
                                {
                                    if (result.getJSONObject("followable").getBoolean("flagAnd")
                                            && result.getJSONObject("followable").has("codProfile"))
                                    {
                                        return result;
                                    }
                                }
                                else
                                {
                                    if (!result.getJSONObject("followable").getBoolean("flagAnd")
                                            && result.getJSONObject("followable").has("codProfile"))
                                    {
                                        return result;
                                    }
                                }
                            }
                        }
                        else
                        {
                            if (!result.getJSONObject("followable").getBoolean("editorTag"))
                            {
                                if (isAnd)
                                {
                                    if (result.getJSONObject("followable").getBoolean("flagAnd")
                                            && result.getJSONObject("followable").has("codProfile"))
                                    {
                                        return result;
                                    }
                                }
                                else
                                {
                                    if (!result.getJSONObject("followable").getBoolean("flagAnd")
                                            && result.getJSONObject("followable").has("codProfile"))
                                    {
                                        return result;
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        if (isTagservice)
                        {
                            if (result.getJSONObject("followable").getBoolean("editorTag"))
                            {
                                if (isAnd)
                                {
                                    if (result.getJSONObject("followable").getBoolean("flagAnd")
                                            && !result.getJSONObject("followable").has("codProfile"))
                                    {
                                        return result;
                                    }
                                }
                                else
                                {
                                    if (!result.getJSONObject("followable").getBoolean("flagAnd")
                                            && !result.getJSONObject("followable").has("codProfile"))
                                    {
                                        return result;
                                    }
                                }
                            }
                        }
                        else
                        {
                            if (!result.getJSONObject("followable").getBoolean("editorTag"))
                            {
                                if (isAnd)
                                {
                                    if (result.getJSONObject("followable").getBoolean("flagAnd")
                                            && !result.getJSONObject("followable").has("codProfile"))
                                    {
                                        return result;
                                    }
                                }
                                else
                                {
                                    if (!result.getJSONObject("followable").getBoolean("flagAnd")
                                            && !result.getJSONObject("followable").has("codProfile"))
                                    {
                                        return result;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            else
            {
                if (useUser)
                {
                    jsonResponse = login.getJson("http://mais.uol.com.br/apiuol/v2/subscription/followable/list?flgManualRegistered=false");
                    result = login.getJson("http://videos.intranet.uol.com.br/maisAdm/subscriptionAdm/show.json?idtFollowable="
                            + jsonResponse.getJSONObject("followableCollection").getJSONArray("followables").getJSONObject(0).getInt("idtFollowable"));
                    return result;
                }
            }
        }

        return null;
    }

    private boolean validateListJson(JSONObject jsonResponse) throws JSONException
    {
        try
        {
            if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") != HttpStatus.SC_OK)
            {
                return false;
            }
            jsonResponse.getJSONObject("collection");
            jsonResponse.getJSONObject("collection").getInt("numPages");
            jsonResponse.getJSONObject("collection").getInt("total");
            jsonResponse.getJSONObject("collection").getString("orderName");
            jsonResponse.getJSONObject("collection").getJSONArray("followables");

            for (int i = 0; i < jsonResponse.getJSONObject("collection").getJSONArray("followables").length(); i++)
            {
                jsonResponse.getJSONObject("collection").getJSONArray("followables").getJSONObject(i).getInt("idtFollowable");
                jsonResponse.getJSONObject("collection").getJSONArray("followables").getJSONObject(i).getInt("numSubscriptionQuantity");
                jsonResponse.getJSONObject("collection").getJSONArray("followables").getJSONObject(i).getBoolean("flgManualRegisted");
                jsonResponse.getJSONObject("collection").getJSONArray("followables").getJSONObject(i).getBoolean("flagAnd");
                jsonResponse.getJSONObject("collection").getJSONArray("followables").getJSONObject(i).getBoolean("editorTag");

                if (jsonResponse.getJSONObject("collection").getJSONArray("followables").getJSONObject(i).has("desFollowable"))
                {
                    jsonResponse.getJSONObject("collection").getJSONArray("followables").getJSONObject(i).getString("desFollowable");
                }

                if (jsonResponse.getJSONObject("collection").getJSONArray("followables").getJSONObject(i).has("idtEditorType"))
                {
                    jsonResponse.getJSONObject("collection").getJSONArray("followables").getJSONObject(i).getInt("idtEditorType");
                }

                if (jsonResponse.getJSONObject("collection").getJSONArray("followables").getJSONObject(i).has("codProfileHash"))
                {
                    jsonResponse.getJSONObject("collection").getJSONArray("followables").getJSONObject(i).getLong("codProfileHash");
                }

                if (jsonResponse.getJSONObject("collection").getJSONArray("followables").getJSONObject(i).has("codProfile"))
                {
                    jsonResponse.getJSONObject("collection").getJSONArray("followables").getJSONObject(i).getString("codProfile");
                }
            }

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - jsonList is not valid - " + e.getMessage() + " - " + jsonResponse);
            return false;
        }
    }

    private boolean validatePageJson(JSONObject jsonResponse) throws JSONException
    {
        try
        {
            if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") != HttpStatus.SC_OK)
            {
                return false;
            }
            jsonResponse.getJSONObject("response");
            jsonResponse.getJSONObject("response").getInt("code");
            jsonResponse.getJSONObject("response").getString("description");
            jsonResponse.getJSONObject("response").getString("originalRequest");

            jsonResponse.getJSONObject("paging");
            jsonResponse.getJSONObject("paging").getInt("currentPage");
            Boolean.parseBoolean(jsonResponse.getJSONObject("paging").getString("nextPage"));
            jsonResponse.getJSONObject("paging").getInt("pageSize");
            Boolean.parseBoolean(jsonResponse.getJSONObject("paging").getString("previousPage"));
            jsonResponse.getJSONObject("paging").getString("sort");
            jsonResponse.getJSONObject("paging").getInt("totalItems");
            jsonResponse.getJSONObject("paging").getInt("totalPages");

            jsonResponse.getJSONArray("list");

            int length = jsonResponse.getJSONArray("list").length();

            for (int i = 0; i < length; i++)
            {
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("title");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("id");
                jsonResponse.getJSONArray("list").getJSONObject(i).getLong("mediaId");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("url");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("mediaType");
                Boolean.parseBoolean(jsonResponse.getJSONArray("list").getJSONObject(i).getString("moderateNote"));
                Boolean.parseBoolean(jsonResponse.getJSONArray("list").getJSONObject(i).getString("allowAnonymousComment"));
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("allowNotes");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("edFilter");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("thumbnail");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("thumbSmall");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("thumbMedium");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("thumbLarge");
                jsonResponse.getJSONArray("list").getJSONObject(i).getLong("idtSubject");

                if (jsonResponse.getJSONArray("list").getJSONObject(i).getString("mediaType").equals("V"))
                {
                    jsonResponse.getJSONArray("list").getJSONObject(i).getString("player");
                    jsonResponse.getJSONArray("list").getJSONObject(i).getString("duration");
                    jsonResponse.getJSONArray("list").getJSONObject(i).getString("thumbWlarge");
                    jsonResponse.getJSONArray("list").getJSONObject(i).getString("thumbWmedium");

                    jsonResponse.getJSONArray("list").getJSONObject(i).getInt("numThumbnailIdentifier");

                    int formatLength = jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("formats").length();

                    for (int j = 0; j < formatLength; j++)
                    {
                        jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("formats").getDouble(j);
                    }

                    if (jsonResponse.getJSONArray("list").getJSONObject(i).has("idtProductList"))
                    {
                        jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("idtProductList");

                        for (int j = 0; j < jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("idtProductList").length(); j++)
                        {
                            jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("idtProductList").getInt(j);
                        }
                    }

                    jsonResponse.getJSONArray("list").getJSONObject(i).getString("embedCode");
                }

                if (jsonResponse.getJSONArray("list").getJSONObject(i).getString("mediaType").equals("P"))
                {
                    jsonResponse.getJSONArray("list").getJSONObject(i).getString("player");
                    jsonResponse.getJSONArray("list").getJSONObject(i).getString("duration");
                    jsonResponse.getJSONArray("list").getJSONObject(i).getString("embedCode");
                }

                if (!jsonResponse.getJSONArray("list").getJSONObject(i).getString("mediaType").equals("T")
                        && !jsonResponse.getJSONArray("list").getJSONObject(i).getString("mediaType").equals("P")
                        && !jsonResponse.getJSONArray("list").getJSONObject(i).getString("mediaType").equals("S"))
                {
                    jsonResponse.getJSONArray("list").getJSONObject(i).getInt("thumbVersion");
                }

                jsonResponse.getJSONArray("list").getJSONObject(i).getString("description");
                Boolean.parseBoolean(jsonResponse.getJSONArray("list").getJSONObject(i).getString("adultContent"));
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("author");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("authorPage");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("codProfile");
                jsonResponse.getJSONArray("list").getJSONObject(i).getInt("views");
                jsonResponse.getJSONArray("list").getJSONObject(i).getInt("comments");
                jsonResponse.getJSONArray("list").getJSONObject(i).getInt("favorites");
                jsonResponse.getJSONArray("list").getJSONObject(i).getDouble("rating");
                jsonResponse.getJSONArray("list").getJSONObject(i).getInt("votes");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("publishedAt");
                Boolean.parseBoolean(jsonResponse.getJSONArray("list").getJSONObject(i).getString("blockEmbed"));
                Boolean.parseBoolean(jsonResponse.getJSONArray("list").getJSONObject(i).getString("subscriberMedia"));

                int tagLength = jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("tags").length();

                for (int j = 0; j < tagLength; j++)
                {
                    jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("tags").getJSONObject(j).getLong("id");
                    jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("tags").getJSONObject(j).getString("description");
                }

                jsonResponse.getJSONArray("list").getJSONObject(i).getString("idtTagService");

                JsonUtil.validateValueJson(jsonResponse.getJSONArray("list").getJSONObject(i), new String[] { "title", "description",
                                                                                                             "embedCode" });
            }

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - pagejson is not valid - " + e.getMessage() + " - " + jsonResponse);
            return false;
        }
    }

    private boolean validateSaveJson(JSONObject jsonResponse) throws JSONException
    {
        try
        {
            if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") != HttpStatus.SC_OK)
            {
                return false;
            }
            jsonResponse.getString("sucesso");

            jsonResponse.getJSONObject("followable");
            jsonResponse.getJSONObject("followable").getLong("idtFollowable");
            jsonResponse.getJSONObject("followable").getBoolean("flgManualRegisted");
            jsonResponse.getJSONObject("followable").getBoolean("flagAnd");
            jsonResponse.getJSONObject("followable").getBoolean("editorTag");

            if (jsonResponse.getJSONObject("followable").has("codProfile"))
            {
                jsonResponse.getJSONObject("followable").getString("codProfile");
            }

            if (jsonResponse.getJSONObject("followable").has("idtEditorType"))
            {
                jsonResponse.getJSONObject("followable").getInt("idtEditorType");
            }

            if (jsonResponse.getJSONObject("followable").has("tags"))
            {
                jsonResponse.getJSONObject("followable").getJSONArray("tags");

                for (int i = 0; i < jsonResponse.getJSONObject("followable").getJSONArray("tags").length(); i++)
                {
                    jsonResponse.getJSONObject("followable").getJSONArray("tags").getJSONObject(i).getLong("idtTag");
                    jsonResponse.getJSONObject("followable").getJSONArray("tags").getJSONObject(i).getBoolean("flgEditorial");
                }
            }

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - jsonSave is not valid - " + e.getMessage() + " - " + jsonResponse);
            return false;
        }
    }
}
