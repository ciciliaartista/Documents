/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         02/07/2014 Criacao inicial
 */

package uol.taipei.tests.moderation;

import org.apache.http.HttpStatus;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uol.taipei.request.JsonRequest;
import uol.taipei.request.UsefulRequest;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.DateParsing;
import uol.taipei.tests.LoginCookie;
import uol.taipei.tests.LoginRadius;
import uol.taipei.tests.util.JsonUtil;
import uol.taipei.tests.util.TestUtil;

public class MediaAdm extends AbstractTest
{
    static final Logger logger = LoggerFactory.getLogger(MediaAdm.class);

    public static void main(String[] args)
    {
        if (!verifyParams(args))
        {
            return;
        }

        setUp(args[0]);

        if (envConfig().getUser() == null || envConfig().getUser().equals("") || envConfig().getPass() == null || envConfig().getPass().equals(""))
        {
            System.err.println("Invalid user " + envConfig().getUser());
            return;
        }

        logger.debug("-------------------------------------------------");
        logger.debug("tests administration media");

        try
        {
            MediaAdm mediaAdm = new MediaAdm();
            LoginCookie login = new LoginCookie(envConfig().getUser(), envConfig().getPass());
            JSONObject profile = login.getJsonProfile();
            UsefulRequest loginR = new LoginRadius(envConfig().getUserRadius(), envConfig().getPassRadius());

            JSONObject media = JsonUtil.mediaNoRestrictByParam("types=V&codProfile="
                    + profile.getJSONObject("item").getString("codProfile"));

            if (media == null)
            {
                media = JsonUtil.mediaNoRestrict("V");
            }

            mediaAdm.home(loginR);
            mediaAdm.show(loginR);
            mediaAdm.codProfile(loginR, profile);
            mediaAdm.media(loginR, media.getString("id"), true);
            mediaAdm.media(loginR, String.valueOf(media.getLong("mediaId")), false);
            mediaAdm.updateEditorialStatus(loginR, media.getLong("mediaId"));
            mediaAdm.updateFeatured(loginR, media.getLong("mediaId"));
            mediaAdm.updateHot(loginR, media.getLong("mediaId"));
            mediaAdm.reprove(loginR, media.getLong("mediaId"));
            mediaAdm.fileBlock(loginR, media.getLong("mediaId"));

            mediaAdm.updateContentStatus(media.getLong("mediaId"), 10, 2);
        }
        catch (Exception e)
        {
            logger.error(e.getMessage());
        }
    }

    public JSONObject home(UsefulRequest login) throws Exception
    {
        JSONObject jsonResponse = login.getJson("http://videos.intranet.uol.com.br/maisAdm/mediaAdm.json");

        if (!validateListJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject show(UsefulRequest login) throws Exception
    {
        DateParsing dateParsing = new DateParsing();
        String dataEnd = dateParsing.dateString();
        String dataInit = dateParsing.oneMonthBefore();
        int[] arrayEditorialStatus = new int[] { 1, 2, 4, 5, 6, 7 };
        JSONObject jsonResponse = null;
        String url = "http://videos.intranet.uol.com.br/maisAdm/mediaAdm.json?action=show&types=A&dtInit=" + dataInit + "&dtEnd=" + dataEnd
                + "&codProfile=&idtStatusEditorial=";

        for (int editorialStatus : arrayEditorialStatus)
        {
            jsonResponse = login.getJson(url + editorialStatus);

            if (!validateListJson(jsonResponse))
            {
                logger.error("ERROR - return not valid - " + jsonResponse);
                return null;
            }

            if (jsonResponse.has("editorialStatus") && editorialStatus != jsonResponse.getInt("editorialStatus"))
            {
                logger.error("ERROR - editorialStatus not match - " + editorialStatus + " - " + jsonResponse);
                return null;
            }

            if (jsonResponse.has("mediasPage"))
            {
                long dateMedia = 0;

                for (int i = 0; i < jsonResponse.getJSONObject("mediasPage").getJSONArray("items").length(); i++)
                {
                    dateMedia = jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getLong("datLastUpdate");

                    if (dateMedia < dateParsing.getDateInit())
                    {
                        logger.error("ERROR - date begin out of range - " + DateParsing.timeMillisToString(dateMedia) + " (" + dateMedia + ") < " 
                                + DateParsing.timeMillisToString(dateParsing.getDateInit()) + " (" + dateParsing.getDateInit() + ") - " + jsonResponse);
                        return null;
                    }

                    if (dateMedia > dateParsing.getDateEnd())
                    {
                        logger.error("ERROR - date end out of range - " + DateParsing.timeMillisToString(dateMedia) + " - (" + dateMedia + ") > "
                                + DateParsing.timeMillisToString(dateParsing.getDateEnd()) + " (" + dateParsing.getDateEnd() + ") - " + jsonResponse);
                        return null;
                    }

                    if (editorialStatus != jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i)
                            .getJSONObject("media").getInt("codEditorialStatus"))
                    {
                        logger.error("ERROR - editorialStatus not match - " + editorialStatus + " - " + jsonResponse);
                        return null;
                    }

                    if (jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("owner")
                            .getJSONObject("profile").getLong("codProfileHash") != jsonResponse.getJSONObject("mediasPage")
                            .getJSONArray("items").getJSONObject(i).getJSONObject("media").getLong("codProfileHash"))
                    {
                        logger.error("ERROR - owner not match - " + jsonResponse);
                        return null;
                    }
                }
            }
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject media(UsefulRequest login, String mediaId, boolean isHash) throws Exception
    {
        String url = "http://videos.intranet.uol.com.br/maisAdm/mediaAdm.json?action=media&query=" + (isHash ? "hashMedia" : "idtMedia")
                + "&media=" + mediaId;
        JSONObject jsonResponse = login.getJson(url);

        if (!validateMediaJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + url + " - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject codProfile(UsefulRequest login, JSONObject profile) throws Exception
    {
        DateParsing dateParsing = new DateParsing();
        String dataEnd = dateParsing.dateString();
        String dataInit = dateParsing.oneMonthBefore();
        String codProfile = profile.getJSONObject("item").getString("codProfile");
        int editorialStatus = 2;
        String url = "http://videos.intranet.uol.com.br/maisAdm/mediaAdm.json?action=show&types=A&dtInit=" + dataInit + "&dtEnd=" + dataEnd
                + "&idtStatusEditorial=" + editorialStatus + "&codProfile=" + codProfile;

        JSONObject jsonResponse = login.getJson(url);

        if (!validateListJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        if (jsonResponse.has("editorialStatus") && editorialStatus != jsonResponse.getInt("editorialStatus"))
        {
            logger.error("ERROR - editorialStatus not match - " + editorialStatus + " - " + jsonResponse);
            return null;
        }

        if (jsonResponse.has("mediasPage"))
        {
            long dateMedia = 0;

            for (int i = 0; i < jsonResponse.getJSONObject("mediasPage").getJSONArray("items").length(); i++)
            {
                dateMedia = jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                        .getLong("datScheduling");

                if (dateMedia < dateParsing.getDateInit())
                {
                    logger.error("ERROR - date begin out of range - " + DateParsing.timeMillisToString(dateMedia) + " (" + dateMedia + ") < " 
                            + DateParsing.timeMillisToString(dateParsing.getDateInit()) + " (" + dateParsing.getDateInit() + ") - " + jsonResponse);
                    return null;
                }

                if (dateMedia > dateParsing.getDateEnd())
                {
                    logger.error("ERROR - date end out of range - " + DateParsing.timeMillisToString(dateMedia) + " - (" + dateMedia + ") > "
                            + DateParsing.timeMillisToString(dateParsing.getDateEnd()) + " (" + dateParsing.getDateEnd() + ") - " + jsonResponse);
                    return null;
                }

                if (editorialStatus != jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i)
                        .getJSONObject("media").getInt("codEditorialStatus"))
                {
                    logger.error("ERROR - editorialStatus not match - " + editorialStatus + " - " + jsonResponse);
                    return null;
                }

                if (jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("owner")
                        .getJSONObject("profile").getLong("codProfileHash") != jsonResponse.getJSONObject("mediasPage")
                        .getJSONArray("items").getJSONObject(i).getJSONObject("media").getLong("codProfileHash"))
                {
                    logger.error("ERROR - owner not match - " + jsonResponse);
                    return null;
                }

                if (profile.getJSONObject("item").getLong("codProfileHash") != jsonResponse.getJSONObject("mediasPage")
                        .getJSONArray("items").getJSONObject(i).getJSONObject("media").getLong("codProfileHash"))
                {
                    logger.error("ERROR - codProfileHash not match - " + profile.getJSONObject("item").getLong("codProfileHash") + " - "
                            + jsonResponse);
                    return null;
                }
            }
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject updateEditorialStatus(UsefulRequest login, Long mediaId) throws Exception
    {
        int retry = 0;
        int[] arrayEditorialStatus = new int[] { 1, 2, 4, 6, 7 };
        JSONObject jsonResponse = null;
        JSONObject media = null;
        String url = "http://videos.intranet.uol.com.br/maisAdm/mediaAdm?variant=ajax&action=updateEditorialStatus&mediaId=" + mediaId
                + "&fromBlackList=0&codEditorial=";

        for (int editorialStatus : arrayEditorialStatus)
        {
            jsonResponse = login.getJson(url + editorialStatus);

            if (!validateResultJson(jsonResponse))
            {
                logger.error("ERROR - return not valid - " + jsonResponse);
                return null;
            }

            if (!jsonResponse.getBoolean("result"))
            {
                logger.error("ERROR - return not valid - " + jsonResponse);
                return null;
            }

            media = JsonUtil.media(mediaId.toString());

            // para dectar demora na replicacao de banco
            while (Integer.parseInt(media.getString("cod_editorial_status")) != editorialStatus && retry < 3)
            {
                logger.warn("retry after 1s - media " + mediaId + " - editorialStatus " + editorialStatus);

                TestUtil.delay(1000);
                media = JsonUtil.media(mediaId.toString());
                retry++;
            }

            if (Integer.parseInt(media.getString("cod_editorial_status")) != editorialStatus)
            {
                logger.error("ERROR - codEditorialStatus was not update - " + editorialStatus + " - " + media);
                return null;
            }
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject reprove(UsefulRequest login, Long mediaId) throws Exception
    {
        int retry = 0;
        JSONObject media = null;
        int editorialStatus = 5;
        String url = "http://videos.intranet.uol.com.br/maisAdm/mediaAdm?variant=ajax&action=updateEditorialStatus&mediaId=" + mediaId
                + "&fromBlackList=0&codEditorial=" + editorialStatus;

        JSONObject jsonResponse = login.getJson(url);

        if (!validateResultJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        if (!jsonResponse.getBoolean("result"))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        media = JsonUtil.media(mediaId.toString());

        // para dectar demora na replicacao de banco
        while (Integer.parseInt(media.getString("cod_editorial_status")) != editorialStatus && retry < 3)
        {
            logger.warn("retry after 1s - media " + mediaId + " - editorialStatus " + editorialStatus);

            TestUtil.delay(1000);
            media = JsonUtil.media(mediaId.toString());
            retry++;
        }

        if (Integer.parseInt(media.getString("cod_editorial_status")) != editorialStatus)
        {
            logger.error("ERROR - codEditorialStatus was not update - " + editorialStatus + " - " + media);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject updateHot(UsefulRequest login, Long mediaId) throws Exception
    {
        int retry = 0;
        JSONObject media = JsonRequest.get("http://mais.uol.com.br/apiuol/v2/media/detail.json?mediaId=" + mediaId);
        boolean isHot = ("N".equals(media.getJSONObject("content").getJSONObject("media").getString("indHot")) ? false : true);
        String url = "http://videos.intranet.uol.com.br/maisAdm/mediaAdm?variant=ajax&action=updateHotAdm&indHotAdm=" + "P"
                + "&mediaId=" + mediaId + "&fromBlackList=0";

        JSONObject jsonResponse = login.getJson(url);

        if (!validateResultJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        if (!jsonResponse.getBoolean("result"))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        media = JsonUtil.media(mediaId.toString());

        // para dectar demora na replicacao de banco
        while (!media.getString("ind_hot").equals("P") && retry < 3)
        {
            logger.warn("retry after 1s - media " + mediaId + " - hot permanent");

            TestUtil.delay(1000);
            media = JsonUtil.media(mediaId.toString());
            retry++;
        }

        if (!media.getString("ind_hot").equals("P"))
        {
            logger.error("ERROR - hot was not update - " + "P" + " - " + media);
            return null;
        }

        logger.debug("SUCCESS");

        if (!isHot)
        {
            // volta o dado original
            login.getJson("http://videos.intranet.uol.com.br/maisAdm/mediaAdm?variant=ajax&action=updateHotAdm&indHotAdm="
                    + "N" + "&mediaId=" + mediaId + "&fromBlackList=0");
        }

        return jsonResponse;
    }

    public JSONObject updateFeatured(UsefulRequest login, Long mediaId) throws Exception
    {
        int retry = 0;
        JSONObject media = null;
        int flgFeatured = 1;
        String url = "http://videos.intranet.uol.com.br/maisAdm/mediaAdm?variant=ajax&action=updateFeatured&flgFeatured=" + flgFeatured
                + "&mediaId=" + mediaId + "&fromBlackList=0";

        JSONObject jsonResponse = login.getJson(url);

        if (!validateResultJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        if (!jsonResponse.getBoolean("result"))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        media = JsonUtil.fullMedia(mediaId.toString());

        // para dectar demora na replicacao de banco
        while (!media.getString("flg_featured").equals("1") && retry < 3)
        {
            logger.warn("retry after 1s - media " + mediaId + " - flgFeatured");

            TestUtil.delay(1000);
            media = JsonUtil.fullMedia(mediaId.toString());
            retry++;
        }

        if (!media.getString("flg_featured").equals("1"))
        {
            logger.error("ERROR - flgFeatured was not update - " + flgFeatured + " - " + media);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject fileBlock(UsefulRequest login, Long mediaId) throws Exception
    {
        int retry = 0;
        int status = 11;
        JSONObject jsonResponse = null;
        JSONObject media = null;
        String url = "http://videos.intranet.uol.com.br/maisAdm/mediaAdm?variant=ajax&action=updateStatus&codStatus=" + status
                + "&mediaId=" + mediaId + "&fromBlackList=0";

        jsonResponse = login.getJson(url);

        if (!validateResultJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        if (!jsonResponse.getBoolean("result"))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        media = JsonUtil.media(mediaId.toString());

        // para dectar demora na replicacao de banco
        while (Integer.parseInt(media.getString("cod_status")) != status && retry < 3)
        {
            logger.warn("retry after 1s - media " + mediaId + " - status " + status);

            TestUtil.delay(1000);
            media = JsonUtil.media(mediaId.toString());
            retry++;
        }

        if (Integer.parseInt(media.getString("cod_status")) != status)
        {
            logger.error("ERROR - codStatus was not update - " + status + " - " + media);
            return null;
        }

        logger.debug("SUCCESS");

        // volta as midias do file bloqueado para disponivel
        new Thread(new UpdateFileThread(Long.parseLong(media.getString("idt_file")))).start();

        return jsonResponse;
    }

    public boolean updateAdmHot(UsefulRequest login, long mediaId, String indHot) throws Exception
    {
        String url = "http://videos.intranet.uol.com.br/maisAdm/mediaAdm?variant=ajax&action=updateHotAdm&indHotAdm=" + indHot
                + "&mediaId=" + mediaId + "&fromBlackList=0";

        JSONObject jsonResponse = login.getJson(url);

        if (!validateResultJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return false;
        }

        if (!jsonResponse.getBoolean("result"))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return false;
        }

        return true;
    }

    private boolean validateResultJson(JSONObject jsonResponse) throws JSONException
    {
        try
        {
            if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") != HttpStatus.SC_OK)
            {
                return false;
            }
            jsonResponse.getBoolean("result");

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - jsonResult is not valid - " + e.getMessage() + " - " + jsonResponse);
            return false;
        }
    }

    private boolean validateListJson(JSONObject jsonResponse) throws JSONException
    {
        try
        {
            if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") != HttpStatus.SC_OK)
            {
                return false;
            }
            jsonResponse.getString("dtInit");
            jsonResponse.getString("dtEnd");
            jsonResponse.getJSONArray("statusMedia");

            for (int i = 0; i < jsonResponse.getJSONArray("statusMedia").length(); i++)
            {
                jsonResponse.getJSONArray("statusMedia").getJSONObject(i).getInt("codEditorialStatus");
                jsonResponse.getJSONArray("statusMedia").getJSONObject(i).getString("desEditorialStatus");
            }

            if (jsonResponse.has("mediasPage"))
            {
                jsonResponse.getJSONObject("mediasPage");

                jsonResponse.getJSONObject("mediasPage").getInt("currentPage");
                jsonResponse.getJSONObject("mediasPage").getInt("itemsPerPage");
                jsonResponse.getJSONObject("mediasPage").getInt("totalItems");
                jsonResponse.getJSONObject("mediasPage").getInt("totalPages");
                jsonResponse.getJSONObject("mediasPage").getInt("previousPage");
                jsonResponse.getJSONObject("mediasPage").getInt("nextPage");
                jsonResponse.getJSONObject("mediasPage").getString("sortBy");
                jsonResponse.getJSONObject("mediasPage").getString("orderBy");

                jsonResponse.getJSONObject("mediasPage").getJSONArray("previousPageCollection");

                for (int i = 0; i < jsonResponse.getJSONObject("mediasPage").getJSONArray("previousPageCollection").length(); i++)
                {
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("previousPageCollection").getInt(i);
                }

                jsonResponse.getJSONObject("mediasPage").getJSONArray("nextPageCollection");

                for (int i = 0; i < jsonResponse.getJSONObject("mediasPage").getJSONArray("nextPageCollection").length(); i++)
                {
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("nextPageCollection").getInt(i);
                }

                jsonResponse.getJSONObject("mediasPage").getJSONArray("items");

                for (int i = 0; i < jsonResponse.getJSONObject("mediasPage").getJSONArray("items").length(); i++)
                {
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getLong("idtMedia");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getString("indMediaType");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getLong("codStatus");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getLong("datPublished");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getString("namSubject");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getString("indVisibility");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getString("indAllowNotes");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getString("indHot");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getInt("flgNotifyComment");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getLong("codProfileHash");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getLong("idtFile");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getInt("numTemporaryServer");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getInt("numRetry");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getInt("numAverageVote");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getInt("numSumVote");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getInt("numTotalVote");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getInt("numViews");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getInt("numComments");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getInt("numFavorited");
                    // jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media").getLong("datFirstViewPertime");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getInt("numSummarizeViewsPertime");
                    // jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media").getLong("datFirstViewPerday");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getInt("numSummarizeViewsPerday");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getInt("numHonors");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getInt("codEditorialStatus");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getLong("datScheduling");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getInt("flgDraft");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getInt("flgSendNotification");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getInt("flgFeatured");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getInt("flgBlockEmbed");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getString("indAuthorizedLists");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getLong("datLastUpdate");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media").getString("url");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getString("fileUrl");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getString("indMediaProtection");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getInt("flgSubscriberMedia");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getBoolean("flgBypass");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getInt("idtSubject");

                    if (jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .has("flgDefaultConfig"))
                    {
                        jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getInt("flgDefaultConfig");
                    }

                    if (jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media").has("tags"))
                    {
                        jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getString("tags");
                    }

                    if (jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .has("desMedia"))
                    {
                        jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                                .getString("desMedia");
                    }

                    if (jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .has("idtTagService"))
                    {
                        jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                                .getString("idtTagService");
                    }

                    if (jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .has("desHostname"))
                    {
                        jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                                .getString("desHostname");
                    }

                    if (jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .has("codHashIn"))
                    {
                        jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                                .getString("codHashIn");
                    }

                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("file");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("file")
                            .getInt("numServer");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("file")
                            .getInt("codStatus");

                    if (jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).has("tags"))
                    {
                        jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONArray("tags");
    
                        for (int j = 0; j < jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i)
                                .getJSONArray("tags").length(); j++)
                        {
                            jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONArray("tags")
                                    .getJSONObject(j).getLong("idtTag");
                            jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONArray("tags")
                                    .getJSONObject(j).getString("desTag");
                        }
                    }

                    if (jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).has("profileGroups"))
                    {
                        jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONArray("profileGroups");
    
                        for (int j = 0; j < jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i)
                                .getJSONArray("profileGroups").length(); j++)
                        {
                            jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONArray("profileGroups")
                                    .getJSONObject(j);
                        }
                    }

                    if (jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).has("formats"))
                    {
                        jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONArray("formats");
    
                        for (int j = 0; j < jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i)
                                .getJSONArray("formats").length(); j++)
                        {
                            jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONArray("formats").getInt(j);
                        }
                    }

                    if (jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).has("productList"))
                    {
                        jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONArray("productList");
    
                        for (int j = 0; j < jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i)
                                .getJSONArray("productList").length(); j++)
                        {
                            jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONArray("productList")
                                    .getInt(j);
                        }
                    }

                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("owner");

                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("owner")
                            .getJSONObject("profile");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("owner")
                            .getJSONObject("profile").getLong("codProfileHash");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("owner")
                            .getJSONObject("profile").getLong("idtPerson");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("owner")
                            .getJSONObject("profile").getString("indUserProfile");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("owner")
                            .getJSONObject("profile").getString("namNick");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("owner")
                            .getJSONObject("profile").getString("desUrlProfile");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("owner")
                            .getJSONObject("profile").getString("indStatus");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("owner")
                            .getJSONObject("profile").getString("namNickUnique");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("owner")
                            .getJSONObject("profile").getString("namLogin");

                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("owner")
                            .getJSONObject("mediaConfig");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("owner")
                            .getJSONObject("mediaConfig").getLong("codProfileHash");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("owner")
                            .getJSONObject("mediaConfig").getString("desSubject");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("owner")
                            .getJSONObject("mediaConfig").getString("indVisibility");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("owner")
                            .getJSONObject("mediaConfig").getString("indAllowNotes");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("owner")
                            .getJSONObject("mediaConfig").getInt("codTheme");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("owner")
                            .getJSONObject("mediaConfig").getString("indHot");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("owner")
                            .getJSONObject("mediaConfig").getInt("flgAllowVideoComment");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("owner")
                            .getJSONObject("mediaConfig").getInt("flgAllowAnonymousComment");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("owner")
                            .getJSONObject("mediaConfig").getInt("flgModerateNote");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("owner")
                            .getJSONObject("mediaConfig").getInt("flgNotifyComment");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("owner")
                            .getJSONObject("mediaConfig").getString("desHomepage");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("owner")
                            .getJSONObject("mediaConfig").getInt("flgBulletinRequester");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("owner")
                            .getJSONObject("mediaConfig").getInt("numServer");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("owner")
                            .getJSONObject("mediaConfig").getInt("numMedias");
                    // jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("owner").getJSONObject("mediaConfig").getString("codPartnerDfp");

                    if (jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("owner")
                            .has("flgDefaultConfig"))
                    {
                        jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("owner")
                            .getInt("flgDefaultConfig");
                    }

                    if ("V".equals(jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i)
                            .getJSONObject("media").getString("indMediaType")))
                    {
                        jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                                .getString("desExtraInformation");

                        if (jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                                .has("countryList"))
                        {
                            jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                                    .getString("countryList");
                        }

                        jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("mediaVideo");
                        jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("mediaVideo")
                                .getLong("idtMedia");
                        jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("mediaVideo")
                                .getInt("numDuration");
                        jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("mediaVideo")
                                .getInt("codVideoType");
                        jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("mediaVideo")
                                .getInt("numThumbnailIdentifier");
                        jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("mediaVideo")
                                .getInt("codExtensionFile");
                        jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("mediaVideo")
                                .getInt("numRevision");
                        jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("mediaVideo")
                                .getInt("numGeneratedThumbs");
                        jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("mediaVideo")
                                .getInt("numViewsMobile");
                        jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("mediaVideo")
                                .getInt("numEncodedPreset");

                        if (jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i)
                                .has("mediaOutputFormatCollection"))
                        {
                            jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i)
                                    .getJSONObject("mediaOutputFormatCollection");
                            jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i)
                                    .getJSONObject("mediaOutputFormatCollection").getInt("numPages");
                            jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i)
                                    .getJSONObject("mediaOutputFormatCollection").getInt("total");
                            jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i)
                                    .getJSONObject("mediaOutputFormatCollection").getString("orderName");
                            jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i)
                                    .getJSONObject("mediaOutputFormatCollection").getBoolean("mobileFormats");
                            jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i)
                                    .getJSONObject("mediaOutputFormatCollection").getBoolean("hdFormats");
                            jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i)
                                    .getJSONObject("mediaOutputFormatCollection").getJSONArray("mediaOutputFormats");

                            for (int j = 0; j < jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i)
                                    .getJSONObject("mediaOutputFormatCollection").getJSONArray("mediaOutputFormats").length(); j++)
                            {
                                jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i)
                                        .getJSONObject("mediaOutputFormatCollection").getJSONArray("mediaOutputFormats").getJSONObject(j)
                                        .getLong("idtMedia");
                                jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i)
                                        .getJSONObject("mediaOutputFormatCollection").getJSONArray("mediaOutputFormats").getJSONObject(j)
                                        .getInt("idtOutputFormat");
                                jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i)
                                        .getJSONObject("mediaOutputFormatCollection").getJSONArray("mediaOutputFormats").getJSONObject(j)
                                        .getInt("codStatus");
                                jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i)
                                        .getJSONObject("mediaOutputFormatCollection").getJSONArray("mediaOutputFormats").getJSONObject(j)
                                        .getLong("datStartEncoding");
                                jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i)
                                        .getJSONObject("mediaOutputFormatCollection").getJSONArray("mediaOutputFormats").getJSONObject(j)
                                        .getLong("datEndEncoding");
                                jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i)
                                        .getJSONObject("mediaOutputFormatCollection").getJSONArray("mediaOutputFormats").getJSONObject(j)
                                        .getInt("numPercEncoding");
                                jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i)
                                        .getJSONObject("mediaOutputFormatCollection").getJSONArray("mediaOutputFormats").getJSONObject(j)
                                        .getInt("numTemporaryServer");
                                jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i)
                                        .getJSONObject("mediaOutputFormatCollection").getJSONArray("mediaOutputFormats").getJSONObject(j)
                                        .getInt("numRetry");
                                jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i)
                                        .getJSONObject("mediaOutputFormatCollection").getJSONArray("mediaOutputFormats").getJSONObject(j)
                                        .getInt("numWidthVideo");
                                jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i)
                                        .getJSONObject("mediaOutputFormatCollection").getJSONArray("mediaOutputFormats").getJSONObject(j)
                                        .getInt("numHeightVideo");
                                jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i)
                                        .getJSONObject("mediaOutputFormatCollection").getJSONArray("mediaOutputFormats").getJSONObject(j)
                                        .getBoolean("flgBypass");
                            }
                        }
                    }

                    if ("P".equals(jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i)
                            .getJSONObject("media").getString("indMediaType")))
                    {
                        jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("mediaPodcast");
                        jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("mediaPodcast")
                                .getLong("idtMedia");
                        jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("mediaPodcast")
                                .getInt("numDuration");
                        jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("mediaPodcast")
                                .getInt("codExtensionFile");
                        jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("mediaPodcast")
                                .getInt("numRevision");
                    }
                    
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getBoolean("publicContent");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getString("urlHash");
                }
            }

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - jsonList is not valid - " + e.getMessage() + " - " + jsonResponse);
            return false;
        }
    }

    private boolean validateMediaJson(JSONObject jsonResponse) throws JSONException
    {
        try
        {
            if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") != HttpStatus.SC_OK)
            {
                return false;
            }
            jsonResponse.getString("dtInit");
            jsonResponse.getString("dtEnd");
            jsonResponse.getJSONArray("statusMedia");

            for (int i = 0; i < jsonResponse.getJSONArray("statusMedia").length(); i++)
            {
                jsonResponse.getJSONArray("statusMedia").getJSONObject(i).getInt("codEditorialStatus");
                jsonResponse.getJSONArray("statusMedia").getJSONObject(i).getString("desEditorialStatus");
            }

            if (jsonResponse.has("mediasPage"))
            {
                jsonResponse.getJSONObject("mediasPage");

                jsonResponse.getJSONObject("mediasPage").getInt("currentPage");
                jsonResponse.getJSONObject("mediasPage").getInt("itemsPerPage");
                jsonResponse.getJSONObject("mediasPage").getInt("totalItems");
                jsonResponse.getJSONObject("mediasPage").getInt("totalPages");
                jsonResponse.getJSONObject("mediasPage").getInt("previousPage");
                jsonResponse.getJSONObject("mediasPage").getInt("nextPage");
                jsonResponse.getJSONObject("mediasPage").getString("sortBy");
                jsonResponse.getJSONObject("mediasPage").getString("orderBy");

                jsonResponse.getJSONObject("mediasPage").getJSONArray("previousPageCollection");

                for (int i = 0; i < jsonResponse.getJSONObject("mediasPage").getJSONArray("previousPageCollection").length(); i++)
                {
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("previousPageCollection").getInt(i);
                }

                jsonResponse.getJSONObject("mediasPage").getJSONArray("nextPageCollection");

                for (int i = 0; i < jsonResponse.getJSONObject("mediasPage").getJSONArray("nextPageCollection").length(); i++)
                {
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("nextPageCollection").getInt(i);
                }

                jsonResponse.getJSONObject("mediasPage").getJSONArray("items");

                for (int i = 0; i < jsonResponse.getJSONObject("mediasPage").getJSONArray("items").length(); i++)
                {
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getLong("idtMedia");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getString("indMediaType");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getLong("codStatus");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getLong("datPublished");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getString("indVisibility");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getString("indAllowNotes");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getString("indHot");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getInt("flgNotifyComment");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getLong("codProfileHash");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getLong("idtFile");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getInt("numTemporaryServer");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getInt("numRetry");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getInt("numAverageVote");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getInt("numSumVote");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getInt("numTotalVote");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getInt("numViews");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getInt("numComments");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getInt("numFavorited");
                    // jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media").getLong("datFirstViewPertime");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getInt("numSummarizeViewsPertime");
                    // jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media").getLong("datFirstViewPerday");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getInt("numSummarizeViewsPerday");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getInt("numHonors");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getInt("codEditorialStatus");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getLong("datScheduling");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getInt("flgDraft");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getInt("flgSendNotification");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getInt("flgFeatured");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getInt("flgBlockEmbed");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getString("indAuthorizedLists");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getLong("datLastUpdate");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media").getString("url");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getString("fileUrl");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getString("indMediaProtection");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getInt("flgSubscriberMedia");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getBoolean("flgBypass");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getInt("idtSubject");

                    if (jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media").has("tags"))
                    {
                        jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .getString("tags");
                    }

                    if (jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .has("namSubject"))
                    {
                        jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                                .getString("namSubject");
                    }

                    if (jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .has("desMedia"))
                    {
                        jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                                .getString("desMedia");
                    }

                    if (jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .has("idtTagService"))
                    {
                        jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                                .getString("idtTagService");
                    }

                    if (jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .has("desHostname"))
                    {
                        jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                                .getString("desHostname");
                    }

                    if (jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                            .has("codHashIn"))
                    {
                        jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                                .getString("codHashIn");
                    }

                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("file");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("file")
                            .getInt("numServer");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("file")
                            .getInt("codStatus");

                    if (jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).has("tags"))
                    {
                        jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONArray("tags");
    
                        for (int j = 0; j < jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i)
                                .getJSONArray("tags").length(); j++)
                        {
                            jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONArray("tags")
                                    .getJSONObject(j).getLong("idtTag");
                            jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONArray("tags")
                                    .getJSONObject(j).getString("desTag");
                        }
                    }

                    if (jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).has("profileGroups"))
                    {
                        jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONArray("profileGroups");
    
                        for (int j = 0; j < jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i)
                                .getJSONArray("profileGroups").length(); j++)
                        {
                            jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONArray("profileGroups")
                                    .getJSONObject(j);
                        }
                    }

                    if (jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).has("formats"))
                    {
                        jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONArray("formats");
    
                        for (int j = 0; j < jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i)
                                .getJSONArray("formats").length(); j++)
                        {
                            jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONArray("formats").getInt(j);
                        }
                    }

                    if (jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).has("productList"))
                    {
                        jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONArray("productList");
    
                        for (int j = 0; j < jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i)
                                .getJSONArray("productList").length(); j++)
                        {
                            jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONArray("productList")
                                    .getInt(j);
                        }
                    }

                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("owner");

                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("owner")
                            .getJSONObject("profile");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("owner")
                            .getJSONObject("profile").getLong("codProfileHash");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("owner")
                            .getJSONObject("profile").getLong("idtPerson");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("owner")
                            .getJSONObject("profile").getString("indUserProfile");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("owner")
                            .getJSONObject("profile").getString("namNick");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("owner")
                            .getJSONObject("profile").getString("desUrlProfile");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("owner")
                            .getJSONObject("profile").getString("indStatus");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("owner")
                            .getJSONObject("profile").getString("namNickUnique");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("owner")
                            .getJSONObject("profile").getString("namLogin");

                    if ("V".equals(jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i)
                            .getJSONObject("media").getString("indMediaType")))
                    {
                        jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                                .getString("desExtraInformation");

                        if (jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                                .has("countryList"))
                        {
                            jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("media")
                                    .getString("countryList");
                        }

                        jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("mediaVideo");
                        jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("mediaVideo")
                                .getLong("idtMedia");
                        jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("mediaVideo")
                                .getInt("numDuration");
                        jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("mediaVideo")
                                .getInt("codVideoType");
                        jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("mediaVideo")
                                .getInt("numThumbnailIdentifier");
                        jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("mediaVideo")
                                .getInt("codExtensionFile");
                        jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("mediaVideo")
                                .getInt("numRevision");
                        jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("mediaVideo")
                                .getInt("numGeneratedThumbs");
                        jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("mediaVideo")
                                .getInt("numViewsMobile");
                        jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("mediaVideo")
                                .getInt("numEncodedPreset");

                        if (jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i)
                                .has("mediaOutputFormatCollection"))
                        {
                            jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i)
                                    .getJSONObject("mediaOutputFormatCollection");
                            jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i)
                                    .getJSONObject("mediaOutputFormatCollection").getInt("numPages");
                            jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i)
                                    .getJSONObject("mediaOutputFormatCollection").getInt("total");
                            jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i)
                                    .getJSONObject("mediaOutputFormatCollection").getString("orderName");
                            jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i)
                                    .getJSONObject("mediaOutputFormatCollection").getBoolean("mobileFormats");
                            jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i)
                                    .getJSONObject("mediaOutputFormatCollection").getBoolean("hdFormats");
                            jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i)
                                    .getJSONObject("mediaOutputFormatCollection").getJSONArray("mediaOutputFormats");

                            for (int j = 0; j < jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i)
                                    .getJSONObject("mediaOutputFormatCollection").getJSONArray("mediaOutputFormats").length(); j++)
                            {
                                jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i)
                                        .getJSONObject("mediaOutputFormatCollection").getJSONArray("mediaOutputFormats").getJSONObject(j)
                                        .getLong("idtMedia");
                                jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i)
                                        .getJSONObject("mediaOutputFormatCollection").getJSONArray("mediaOutputFormats").getJSONObject(j)
                                        .getInt("idtOutputFormat");
                                jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i)
                                        .getJSONObject("mediaOutputFormatCollection").getJSONArray("mediaOutputFormats").getJSONObject(j)
                                        .getInt("codStatus");
                                jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i)
                                        .getJSONObject("mediaOutputFormatCollection").getJSONArray("mediaOutputFormats").getJSONObject(j)
                                        .getLong("datStartEncoding");
                                jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i)
                                        .getJSONObject("mediaOutputFormatCollection").getJSONArray("mediaOutputFormats").getJSONObject(j)
                                        .getLong("datEndEncoding");
                                jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i)
                                        .getJSONObject("mediaOutputFormatCollection").getJSONArray("mediaOutputFormats").getJSONObject(j)
                                        .getInt("numPercEncoding");
                                jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i)
                                        .getJSONObject("mediaOutputFormatCollection").getJSONArray("mediaOutputFormats").getJSONObject(j)
                                        .getInt("numTemporaryServer");
                                jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i)
                                        .getJSONObject("mediaOutputFormatCollection").getJSONArray("mediaOutputFormats").getJSONObject(j)
                                        .getInt("numRetry");
                                jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i)
                                        .getJSONObject("mediaOutputFormatCollection").getJSONArray("mediaOutputFormats").getJSONObject(j)
                                        .getInt("numWidthVideo");
                                jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i)
                                        .getJSONObject("mediaOutputFormatCollection").getJSONArray("mediaOutputFormats").getJSONObject(j)
                                        .getInt("numHeightVideo");
                                jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i)
                                        .getJSONObject("mediaOutputFormatCollection").getJSONArray("mediaOutputFormats").getJSONObject(j)
                                        .getBoolean("flgBypass");
                            }
                        }
                    }

                    if ("P".equals(jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i)
                            .getJSONObject("media").getString("indMediaType")))
                    {
                        jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("mediaPodcast");
                        jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("mediaPodcast")
                                .getLong("idtMedia");
                        jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("mediaPodcast")
                                .getInt("numDuration");
                        jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("mediaPodcast")
                                .getInt("codExtensionFile");
                        jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getJSONObject("mediaPodcast")
                                .getInt("numRevision");
                    }

                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getBoolean("publicContent");
                    jsonResponse.getJSONObject("mediasPage").getJSONArray("items").getJSONObject(i).getString("urlHash");
                }
            }

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - jsonList is not valid - " + e.getMessage() + " - " + jsonResponse);
            return false;
        }
    }

    private class UpdateFileThread extends Thread
    {
        private long fileId;

        public UpdateFileThread(long fileId)
        {
            this.fileId = fileId;
        }

        public void run()
        {
            try
            {
                JSONObject result = JsonRequest.execQuery("SELECT idt_media FROM media WHERE cod_status = 11 AND idt_file = " + fileId);

                if (result != null && result.getJSONArray("data").length() > 0)
                {
                    for (int i = 0; i < result.getJSONArray("data").length(); i++)
                    {
                        updateContentStatus(
                            Long.parseLong(JsonUtil.getParam(result, "idt_media").toString()), 10, 2);
                    }
                }
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
        }
    }
}
