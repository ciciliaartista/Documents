/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         25/07/2016 Criacao inicial
 */

package uol.taipei.tests.drakkar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uol.taipei.request.FacileRequest;
import uol.taipei.request.FacileResponse;
import uol.taipei.tests.AbstractTest;

public class HealthCheckDrakkar extends AbstractTest
{
    static final Logger logger = LoggerFactory.getLogger(HealthCheckDrakkar.class);

    public static void main(String[] args)
    {
        if (!verifyParams(args))
        {
            return;
        }

        setUp(args[0]);

        logger.debug("-------------------------------------------------");
        logger.debug("tests health check drakkar");

        try
        {
            HealthCheckDrakkar healthCheckContent = new HealthCheckDrakkar(false, false);
            FacileRequest request = new FacileRequest();

            healthCheckContent.probe(request);
        }
        catch (Exception e) 
        {
            logger.error(e.getMessage());            
        }
    }

    /**
     * construtor
     * 
     * @param isSSL http ou https 
     * @param useSRV url de servico/interno(x.sys.intranet) ou dominio aberto(x.uol.com.br)
     */
    public HealthCheckDrakkar(boolean isSSL, boolean useSRV)
    {
        this.host = "http" + (isSSL ? "s" : "") + "://" + (useSRV ? envConfig().getGlobal().getUrlapisrv() : envConfig().getGlobal().getUrlapi());
    }

    public HealthCheckDrakkar(String url)
    {
        this.host = url;
    }

    public boolean probe(FacileRequest request) throws Exception
    {
        FacileResponse response = request.get(host + "/apiuol/v3/probe");

        if (response.getCode() != 200)
        {
            logger.error("ERROR - return not valid - " + response.getCode());
            return false;
        }

        try
        {
            response.getJson().getJSONObject("response");
            response.getJson().getJSONObject("response").getInt("code");
            response.getJson().getJSONObject("response").getString("description");
            response.getJson().getJSONObject("response").getString("originalRequest");

            if (response.getJson().getJSONObject("response").getInt("code") != 200)
            {
                logger.error("ERROR - return not valid - " + response.getJson());
                return false;
            }

            response.getJson().getJSONObject("item");
            response.getJson().getJSONObject("item").getInt("numConnectionsActive");
            response.getJson().getJSONObject("item").getString("upTime");
            response.getJson().getJSONObject("item").getString("status");
            response.getJson().getJSONObject("item").getString("serverVersion");
            response.getJson().getJSONObject("item").getString("managerCacheHitRate");
            response.getJson().getJSONObject("item").getString("requestCacheHitRate");
        }
        catch (Exception e)
        {
            logger.error("ERROR - return not valid - " + e.getMessage() + " - " + response.getBody());
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }
}
