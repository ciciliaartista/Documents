package uol.taipei.tests.content;

import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uol.taipei.request.FacileRequest;
import uol.taipei.request.FacileResponse;
import uol.taipei.tests.AbstractTest;

public class ApiContentErr extends AbstractTest
{
    static final Logger logger = LoggerFactory.getLogger(ApiContentErr.class);

    static private final String apiUrl = "http://mais.uol.com.br/apiuol/v2/";

    public static void main(String[] args)
    {
        if (!verifyParams(args))
        {
            return;
        }

        setUp(args[0]);

        if (envConfig().getUser() == null || envConfig().getUser().equals("") || envConfig().getPass() == null || envConfig().getPass().equals(""))
        {
            System.err.println("Invalid user " + envConfig().getUser());
            return;
        }

        logger.debug("-------------------------------------------------");
        logger.debug("tests api content err");

        try
        {
            ApiContentErr apiContentErr = new ApiContentErr();
            FacileRequest request = new FacileRequest();

            apiContentErr.listWithAdultFilterParam(request);
            apiContentErr.listWithCodProfileParam(request);
            apiContentErr.listWithCurrentPageParam(request);
            apiContentErr.listWithEdFilterParam(request);
            apiContentErr.listWithEditorParam(request);
            apiContentErr.listWithFormatParam(request);
            apiContentErr.listWithItemsPerPageParam(request);
            apiContentErr.listWithRelatedIdParam(request);
            apiContentErr.listWithRelatedListParam(request);
            apiContentErr.listWithTimeParam(request);
            apiContentErr.detail(request);
            apiContentErr.detailWithoutParam(request);
            apiContentErr.detailWithoutMediaId(request);
            apiContentErr.recommendedWithCurrentPageParam(request);
            apiContentErr.recommendedWithItemsPerPageParam(request);
        }
        catch (Exception e)
        {
            logger.error(e.getMessage());
        }
    }

    public boolean listWithCodProfileParam(FacileRequest request) throws Exception
    {
        String url = apiUrl + "media/list?codProfile=!@#";
        FacileResponse response = request.getNoBody(url);

        if (response.getCode() != HttpStatus.SC_BAD_REQUEST)
        {
            logger.error("ERROR - return status not valid - " + response.getCode() + " - " + url);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean listWithRelatedIdParam(FacileRequest request) throws Exception
    {
        String url = apiUrl + "media/list?mediaRelatedId=x";
        FacileResponse response = request.getNoBody(url);

        if (response.getCode() != HttpStatus.SC_BAD_REQUEST)
        {
            logger.error("ERROR - return status not valid - " + response.getCode() + " - " + url);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean listWithRelatedListParam(FacileRequest request) throws Exception
    {
        String url = apiUrl + "media/list?relatedList=x";
        FacileResponse response = request.getNoBody(url);

        if (response.getCode() != HttpStatus.SC_BAD_REQUEST)
        {
            logger.error("ERROR - return status not valid - " + response.getCode() + " - " + url);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean listWithItemsPerPageParam(FacileRequest request) throws Exception
    {
        String url = apiUrl + "media/list?index.itemsPerPage=x";
        FacileResponse response = request.getNoBody(url);

        if (response.getCode() != HttpStatus.SC_BAD_REQUEST)
        {
            logger.error("ERROR - return status not valid - " + response.getCode() + " - " + url);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean listWithCurrentPageParam(FacileRequest request) throws Exception
    {
        String url = apiUrl + "media/list?index.currentPage=x";
        FacileResponse response = request.getNoBody(url);

        if (response.getCode() != HttpStatus.SC_BAD_REQUEST)
        {
            logger.error("ERROR - return status not valid - " + response.getCode() + " - " + url);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean listWithTimeParam(FacileRequest request) throws Exception
    {
        String url = apiUrl + "media/list?time=x";
        FacileResponse response = request.getNoBody(url);

        if (response.getCode() != HttpStatus.SC_BAD_REQUEST)
        {
            logger.error("ERROR - return status not valid - " + response.getCode() + " - " + url);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean listWithEdFilterParam(FacileRequest request) throws Exception
    {
        String url = apiUrl + "media/list?edFilter=x";
        FacileResponse response = request.getNoBody(url);

        if (response.getCode() != HttpStatus.SC_BAD_REQUEST)
        {
            logger.error("ERROR - return status not valid - " + response.getCode() + " - " + url);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean listWithAdultFilterParam(FacileRequest request) throws Exception
    {
        String url = apiUrl + "media/list?adultFilter=x";
        FacileResponse response = request.getNoBody(url);

        if (response.getCode() != HttpStatus.SC_BAD_REQUEST)
        {
            logger.error("ERROR - return status not valid - " + response.getCode() + " - " + url);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean listWithFormatParam(FacileRequest request) throws Exception
    {
        String url = apiUrl + "media/list?format=x";
        FacileResponse response = request.getNoBody(url);

        if (response.getCode() != HttpStatus.SC_BAD_REQUEST)
        {
            logger.error("ERROR - return status not valid - " + response.getCode() + " - " + url);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean listWithEditorParam(FacileRequest request) throws Exception
    {
        String url = apiUrl + "media/list?editor=x";
        FacileResponse response = request.getNoBody(url);

        if (response.getCode() != HttpStatus.SC_BAD_REQUEST)
        {
            logger.error("ERROR - return status not valid - " + response.getCode() + " - " + url);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean detail(FacileRequest request) throws Exception
    {
        String url = apiUrl + "media/detail/xxxxxx";
        FacileResponse response = request.getNoBody(url);

        if (response.getCode() != HttpStatus.SC_BAD_REQUEST)
        {
            logger.error("ERROR - return status not valid - " + response.getCode() + " - " + url);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean detailWithoutParam(FacileRequest request) throws Exception
    {
        String url = apiUrl + "media/detail";
        FacileResponse response = request.getNoBody(url);

        if (response.getCode() != HttpStatus.SC_BAD_REQUEST)
        {
            logger.error("ERROR - return status not valid - " + response.getCode() + " - " + url);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean detailWithoutMediaId(FacileRequest request) throws Exception
    {
        String url = apiUrl + "media/detail?mediaId=";
        FacileResponse response = request.getNoBody(url);

        if (response.getCode() != HttpStatus.SC_BAD_REQUEST)
        {
            logger.error("ERROR - return status not valid - " + response.getCode() + " - " + url);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean recommendedWithCurrentPageParam(FacileRequest request) throws Exception
    {
        String url = apiUrl + "media/recommended?index.currentPage=x";
        FacileResponse response = request.getNoBody(url);

        if (response.getCode() != HttpStatus.SC_BAD_REQUEST)
        {
            logger.error("ERROR - return status not valid - " + response.getCode() + " - " + url);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean recommendedWithItemsPerPageParam(FacileRequest request) throws Exception
    {
        String url = apiUrl + "media/recommended?index.itemsPerPage=x";
        FacileResponse response = request.getNoBody(url);

        if (response.getCode() != HttpStatus.SC_BAD_REQUEST)
        {
            logger.error("ERROR - return status not valid - " + response.getCode() + " - " + url);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }
}