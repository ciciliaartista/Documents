/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         25/07/2016 Criacao inicial
 */

package uol.taipei.tests.drakkar;

import java.io.IOException;
import java.security.KeyManagementException;
import java.util.HashMap;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.http.HttpStatus;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uol.taipei.request.FacileRequest;
import uol.taipei.request.FacileResponse;
import uol.taipei.request.JsonRequest;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.DateParsing;
import uol.taipei.tests.LoginCookie;
import uol.taipei.tests.util.JsonUtil;
import uol.taipei.tests.util.TestUtil;
import uol.taipei.util.StringUtil;
import uol.taipei.util.hash.HashCode;
import uol.taipei.webServiceClient.WSReturn;

public class ApiV3Content extends AbstractTest
{
    static final Logger logger = LoggerFactory.getLogger(ApiV3Content.class);

    public static void main(String[] args)
    {
        if (!verifyParams(args))
        {
            return;
        }

        setUp(args[0]);

        if (envConfig().getUser() == null || envConfig().getUser().equals("") || envConfig().getPass() == null
                || envConfig().getPass().equals(""))
        {
            System.err.println("Invalid user " + envConfig().getUser());
            return;
        }

        logger.debug("-------------------------------------------------");
        logger.debug("tests api v3 content");

        try
        {
            ApiV3Content apiContent = new ApiV3Content(false, false);
            LoginCookie login = new LoginCookie(envConfig().getUser(), envConfig().getPass());

            apiContent.crossdomain();

            JSONObject media = JsonUtil.mediaDecored(10, "V", "T",
                false, false, false, false, false);
            HashMap<String, JSONObject> mapMedias = new HashMap<String, JSONObject>();
            mapMedias.put("V", media);

            apiContent.detailQs(mapMedias.get("V").getString("idt_media"), "V");
            apiContent.detailQs(mapMedias.get("V").getString("id"), "V");

            apiContent.detail(mapMedias.get("V").getString("idt_media"), "V");
            apiContent.detail(mapMedias.get("V").getString("id"), "V");

            media = JsonUtil.mediaDecored(10, "P", "T", false, false,
                false, false, false);
            mapMedias.put("P", media);

            apiContent.detailQs(mapMedias.get("P").getString("idt_media"), "P");
            apiContent.detailQs(mapMedias.get("P").getString("id"), "P");

            apiContent.detail(mapMedias.get("P").getString("idt_media"), "P");
            apiContent.detail(mapMedias.get("P").getString("id"), "P");

            apiContent.apacheCache(mapMedias.get("V").getString("idt_media"));
            apiContent.apacheCacheQs(mapMedias.get("V").getString("idt_media"));
            apiContent.apacheCache(mapMedias.get("V").getString("id"));
            apiContent.apacheCacheQs(mapMedias.get("V").getString("id"));

            apiContent.list();
            apiContent.codProfile(login.getJsonProfile().getJSONObject("item").getString("codProfile"));
            apiContent.itemsPerPage(4);
            apiContent.currentPage(2);
            apiContent.types();
            apiContent.publisherType();
            apiContent.adult();
            apiContent.related(mapMedias.get("V").getString("idt_media"));
            apiContent.subscriber();
            apiContent.format();
            apiContent.tagNames("teste");
            apiContent.tagIds("1", false);
            apiContent.tagService("1010", false);
            apiContent.sort();
            apiContent.editorialStatus();
            apiContent.formats(mapMedias.get("V").getString("idt_media"));
            apiContent.paging();
            apiContent.date();
            apiContent.followable();
        }
        catch (Exception e)
        {
            logger.error(e.getMessage());
        }
    }

    private static FacileRequest request = null;

    /**
     * construtor
     * 
     * @param isSSL define http ou https
     * @param useSRV dominio interno ou publico
     * @throws Exception 
     * @throws KeyManagementException 
     */
    public ApiV3Content(boolean isSSL, boolean useSRV) throws Exception
    {
        this.isSSL = isSSL;
        this.host = "http" + (isSSL ? "s" : "") + "://"
                + (useSRV ? envConfig().getGlobal().getUrlapisrv() : envConfig().getGlobal().getUrlapi());
        request = new FacileRequest();

        if (isSSL)
        {
            request.configureSSL();
        }
    }

    /**
     * construtor
     * 
     * @param url dominio para executar testes
     */
    public ApiV3Content(String url)
    {
        this.host = url;
    }

    public boolean crossdomain() throws Exception
    {
        FacileResponse response = request.get(host + "/crossdomain.xml");

        if (response.getCode() != 200)
        {
            logger.error("ERROR - return not valid - " + response.getCode());
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public JSONObject list() throws Exception
    {
        String url = host + "/apiuol/v3/media/list?nocache=" + Math.random();
        JSONObject jsonResponse = execRequest(url);

        if (!validatePageJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    /**
     * api de detalhes de uma midia. url em query string
     * 
     * @param mediaId
     * @param mediaType
     * @return JSONObject
     * @throws IOException
     * @throws JSONException
     */
    public JSONObject detailQs(String mediaId, String mediaType) throws Exception
    {
        String url = host + "/apiuol/v3/media/detail?mediaId=" + mediaId + "&nocache=" + Math.random();
        JSONObject jsonResponse = execRequest(url);

        if (!validateJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        if (!mediaType.equals(jsonResponse.getJSONObject("item").getString("type")))
        {
            logger.error("ERROR - mediaType not match - mediaType " + mediaType + " - " + jsonResponse);
            return null;
        }

        if (StringUtil.validateNumber(mediaId))
        {
            if (jsonResponse.getJSONObject("item").getLong("mediaId") != Long.parseLong(mediaId))
            {
                logger.error("ERROR - mediaId not match - mediaId " + mediaId + " - " + jsonResponse);
                return null;
            }
        }
        else
        {
            if (!jsonResponse.getJSONObject("item").getString("urlHash").endsWith(
                mediaId.substring(mediaId.lastIndexOf("-"))))
            {
                logger.error("ERROR - id not match - mediaId " + mediaId + " - " + jsonResponse);
                return null;
            }
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    /**
     * api de detalhes de uma midia. url em rest
     * 
     * @param mediaId
     * @param mediaType
     * @return JSONObject
     * @throws IOException
     * @throws JSONException
     */
    public JSONObject detail(String mediaId, String mediaType) throws Exception
    {
        String url = host + "/apiuol/v3/media/detail/" + mediaId;
        JSONObject jsonResponse = execRequest(url);

        if (!validateJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        if (!mediaType.equals(jsonResponse.getJSONObject("item").getString("type")))
        {
            logger.error("ERROR - mediaType not match - mediaType " + mediaType + " - " + jsonResponse);
            return null;
        }

        if (StringUtil.validateNumber(mediaId))
        {
            if (jsonResponse.getJSONObject("item").getLong("mediaId") != Long.parseLong(mediaId))
            {
                logger.error("ERROR - mediaId not match - mediaId " + mediaId + " - " + jsonResponse);
                return null;
            }
        }
        else
        {
            if (!jsonResponse.getJSONObject("item").getString("urlHash").endsWith(
                mediaId.substring(mediaId.lastIndexOf("-"))))
            {
                logger.error("ERROR - id not match - mediaId " + mediaId + " - " + jsonResponse);
                return null;
            }
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    /**
     * cache de api de detalhes de uma midia. url em query string
     * 
     * @param mediaId
     * @return boolean
     */
    public boolean apacheCacheQs(String mediaId)
    {
        try
        {
            JSONObject media = execRequest(host + "/apiuol/v3/media/detail?mediaId=" + mediaId);
            String id = (StringUtil.validateNumber(mediaId) ? mediaId : String.valueOf(media.getJSONObject("item")
                    .getLong("mediaId")));

            // a alteracao valida o dono da midia, entao precisa passar o codProfileHash
            Long codProfileHash = HashCode.encode(media.getJSONObject("item").getString("codProfile"));
            String url = "http://beta.mais.uol.com.br/apiuol/media/update?variant=json&mediaId=" + id
                    + "&codProfileHash=" + codProfileHash;
            String data = TestUtil.randomString(5);

            HashMap<String, String> params = new HashMap<String, String>();
            params.put("media.namSubject", data + " "
                    + (media.getJSONObject("item").has("title") ? media.getJSONObject("item").getString("title") : ""));
            params.put("media.desMedia", data
                    + " gibraltar - "
                    + (media.getJSONObject("item").has("description") ? media.getJSONObject("item").getString(
                        "description") : ""));

            WSReturn ret = JsonUtil.wsReturn(JsonRequest.execGibraltar(url, "POST", null, null, 10000, null, params));

            if (ret.getResponseCode() != 200)
            {
                logger.error("ERROR - response not valid - " + ret.getResponseCode());
                return false;
            }

            TestUtil.delay(500);
            JSONObject mediaCache = execRequest(host + "/apiuol/v3/media/detail?mediaId=" + mediaId);

            if (!media.getJSONObject("item").getString("title").equals(
                mediaCache.getJSONObject("item").getString("title"))
                    || !media.getJSONObject("item").getString("description").equals(
                        mediaCache.getJSONObject("item").getString("description")))
            {
                logger.error("ERROR - return not valid - media " + mediaId + " is not cacheable");
                return false;
            }

            logger.debug("SUCCESS");

            // volta dados originais
            params.put("media.namSubject", media.getJSONObject("item").getString("title"));
            params.put("media.desMedia", media.getJSONObject("item").getString("description"));
            new Thread(new GibraltarPostThread(url, params)).start();

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage() + " - " + mediaId);
            return false;
        }
    }

    /**
     * cache de api de detalhes de uma midia. url em rest
     * 
     * @param mediaId
     * @return boolean
     */
    public boolean apacheCache(String mediaId)
    {
        try
        {
            JSONObject media = execRequest(host + "/apiuol/v3/media/detail/" + mediaId);
            String id = (StringUtil.validateNumber(mediaId) ? mediaId : String.valueOf(media.getJSONObject("item")
                    .getLong("mediaId")));

            // a alteracao valida o dono da midia, entao precisa passar o codProfileHash
            Long codProfileHash = HashCode.encode(media.getJSONObject("item").getString("codProfile"));
            String url = "http://beta.mais.uol.com.br/apiuol/media/update?variant=json&mediaId=" + id
                    + "&codProfileHash=" + codProfileHash;
            String data = TestUtil.randomString(5);

            HashMap<String, String> params = new HashMap<String, String>();
            params.put("media.namSubject", data + " "
                    + (media.getJSONObject("item").has("title") ? media.getJSONObject("item").getString("title") : ""));
            params.put("media.desMedia", data
                    + " gibraltar - "
                    + (media.getJSONObject("item").has("description") ? media.getJSONObject("item").getString(
                        "description") : ""));

            WSReturn ret = JsonUtil.wsReturn(JsonRequest.execGibraltar(url, "POST", null, null, 10000, null, params));

            if (ret.getResponseCode() != 200)
            {
                logger.error("ERROR - response not valid - " + ret);
                return false;
            }

            TestUtil.delay(500);
            JSONObject mediaCache = execRequest(host + "/apiuol/v3/media/detail/" + mediaId);

            if (!media.getJSONObject("item").getString("title").equals(
                mediaCache.getJSONObject("item").getString("title"))
                    || !media.getJSONObject("item").getString("description").equals(
                        mediaCache.getJSONObject("item").getString("description")))
            {
                logger.error("ERROR - return not valid - media " + mediaId + " is not cacheable");
                return false;
            }

            logger.debug("SUCCESS");

            // volta dados originais
            params.put("media.namSubject", media.getJSONObject("item").getString("title"));
            params.put("media.desMedia", media.getJSONObject("item").getString("description"));
            new Thread(new GibraltarPostThread(url, params)).start();

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage() + " - " + mediaId);
            return false;
        }
    }

    public JSONObject codProfile(String codProfile) throws Exception
    {
        String url = host + "/apiuol/v3/media/list?codProfile=" + codProfile + "&nocache=" + Math.random();
        JSONObject jsonResponse = execRequest(url);

        if (!validatePageJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + url + " - " + jsonResponse);
            return null;
        }

        for (int i = 0; i < jsonResponse.getJSONArray("list").length(); i++)
        {
            if (!jsonResponse.getJSONArray("list").getJSONObject(i).getString("codProfile").equals(codProfile))
            {
                logger.error("ERROR - codProfile not match - codProfile " + codProfile + " - " + jsonResponse);
                return null;
            }
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject itemsPerPage(int itemsPerPage) throws Exception
    {
        String url = host + "/apiuol/v3/media/list?itemsPerPage=" + itemsPerPage + "&nocache=" + Math.random();
        JSONObject jsonResponse = execRequest(url);

        if (!validatePageJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + url + " - " + jsonResponse);
            return null;
        }

        // if (jsonResponse.getJSONObject("paging").getInt("pageSize") !=
        // itemsPerPage
        // || (jsonResponse.getJSONObject("paging").getInt("totalItems") >=
        // itemsPerPage && jsonResponse
        // .getJSONArray("list").length() != itemsPerPage))
        // {
        // logger.error("ERROR - itemsPerPage not match - " + jsonResponse);
        // return null;
        // }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject currentPage(int currentPage) throws Exception
    {
        String url = host + "/apiuol/v3/media/list/page/" + currentPage + "?nocache=" + Math.random();
        JSONObject jsonResponse = execRequest(url);

        if (!validatePageJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + url + " - " + jsonResponse);
            return null;
        }

        if (jsonResponse.getJSONObject("paging").getInt("currentPage") != currentPage)
        {
            logger.error("ERROR - currentPage not match - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject types() throws Exception
    {
        String url = host + "/apiuol/v3/media/list?types=";
        String[] arrayTypes = new String[] { "A", "V", "P" };
        JSONObject jsonResponse = null;

        for (String type : arrayTypes)
        {
            jsonResponse = execRequest(url + type + "&nocache=" + Math.random());

            if (!validatePageJson(jsonResponse))
            {
                logger.error("ERROR - return not valid - " + url + type + " - " + jsonResponse);
                return null;
            }

            for (int i = 0; i < jsonResponse.getJSONArray("list").length(); i++)
            {
                if ("A".equals(type))
                {
                    if (!ArrayUtils.contains(arrayTypes, jsonResponse.getJSONArray("list").getJSONObject(i).getString(
                        "type")))
                    {
                        logger.error("ERROR - mediaType not match - mediaType " + type + " - " + jsonResponse);
                        return null;
                    }
                }
                else
                {
                    if (!jsonResponse.getJSONArray("list").getJSONObject(i).getString("type").equals(type))
                    {
                        logger.error("ERROR - mediaType not match - mediaType " + type + " - " + jsonResponse);
                        return null;
                    }
                }
            }
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject publisherType() throws Exception
    {
        String url = host + "/apiuol/v3/media/list?publisherType=";
        JSONObject jsonResponse = null;
        String[] edFilter = new String[] { "user", "editorial", "all" };

        for (String ef : edFilter)
        {
            jsonResponse = execRequest(url + ef + "&nocache=" + Math.random());

            if (!validatePageJson(jsonResponse))
            {
                logger.error("ERROR - return not valid - " + url + ef + " - " + jsonResponse);
                return null;
            }

            for (int i = 0; i < jsonResponse.getJSONArray("list").length(); i++)
            {
                if ("all".equals(ef))
                {
                    if (!ArrayUtils.contains(edFilter, jsonResponse
                            .getJSONArray("list").getJSONObject(i).getString("authorType")))
                    {
                        logger.error("ERROR - edFilter not match - edFilter " + ef + " - " + jsonResponse);
                        return null;
                    }
                }
                else
                {
                    if (!jsonResponse.getJSONArray("list").getJSONObject(i).getString("authorType").equals(ef))
                    {
                        logger.error("ERROR - edFilter not match - edFilter " + ef + " - " + jsonResponse);
                        return null;
                    }
                }
            }
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject adult() throws Exception
    {
        String url = host + "/apiuol/v3/media/list?adult=";
        JSONObject jsonResponse = null;
        String[] adultFilter = new String[] { "safe", "unsafe", "all" };

        for (String af : adultFilter)
        {
            jsonResponse = execRequest(url + af + "&nocache=" + Math.random());

            if (!validatePageJson(jsonResponse))
            {
                logger.error("ERROR - return not valid - " + url + af + " - " + jsonResponse);
                return null;
            }

            for (int i = 0; i < jsonResponse.getJSONArray("list").length(); i++)
            {
                Boolean hot = Boolean.parseBoolean(jsonResponse.getJSONArray("list").getJSONObject(i).getString(
                    "isAdult"));

                if ("all".equals(af))
                {
                    if (hot == null)
                    {
                        logger.error("ERROR - adultFilter not valid - adultFilter " + adultFilter + " - "
                                + jsonResponse);
                        return null;
                    }
                }
                else if ("safe".equals(af))
                {
                    if (hot)
                    {
                        logger.error("ERROR - adultFilter not match - adultFilter " + adultFilter + " - "
                                + jsonResponse);
                        return null;
                    }
                }
                else if ("unsafe".equals(af))
                {
                    if (!hot)
                    {
                        logger.error("ERROR - adultFilter not match - adultFilter " + adultFilter + " - "
                                + jsonResponse);
                        return null;
                    }
                }
                else
                {
                    logger.error("ERROR - adultFilter not valid - adultFilter " + adultFilter + " - " + jsonResponse);
                    return null;
                }
            }
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject related(String mediaId)
    {
        try
        {
            String url = host + "/apiuol/v3/media/list?relatedList=true&mediaRelatedId=" + mediaId + "&types=A";
            JSONObject jsonResponse = execRequest(url + "&nocache=" + Math.random());

            if (jsonResponse.getJSONObject("response").getInt("code") == HttpStatus.SC_NOT_FOUND)
            {
                if (!validateResponseNotOKJson(jsonResponse, HttpStatus.SC_NOT_FOUND))
                {
                    logger.error("ERROR - return not valid - " + url + " - " + jsonResponse);
                    return null;
                }
            }
            else
            {
                if (!validatePageJson(jsonResponse))
                {
                    logger.error("ERROR - return not valid - " + url + " - " + jsonResponse);
                    return null;
                }

                JSONObject media = execRequest(host + "/apiuol/v3/media/detail/" + mediaId);

                if (!isRelated(jsonResponse.getJSONArray("list"), media))
                {
                    logger.error("ERROR - return not valid - there is not related - " + jsonResponse + " - " + media);
                    return null;
                }
            }

            logger.debug("SUCCESS");

            return jsonResponse;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage() + " - " + mediaId);
            return null;
        }
    }

    public JSONObject subscriber() throws Exception
    {
        String url = host + "/apiuol/v3/media/list?subscriber=";
        JSONObject jsonResponse = null;
        String[] subscriberFilter = new String[] { "open", "subscriber", "all" };

        for (String sf : subscriberFilter)
        {
            jsonResponse = execRequest(url + sf + "&nocache=" + Math.random());

            if (!validatePageJson(jsonResponse))
            {
                logger.error("ERROR - return not valid - " + url + sf + " - " + jsonResponse);
                return null;
            }

            for (int i = 0; i < jsonResponse.getJSONArray("list").length(); i++)
            {
                Boolean subscriber = Boolean.parseBoolean(jsonResponse.getJSONArray("list").getJSONObject(i).getString(
                    "isSubscriberExclusive"));

                if ("all".equals(sf))
                {
                    if (subscriber == null)
                    {
                        logger.error("ERROR - subscriberMedia not valid - subscriberMedia " + sf + " - "
                                + jsonResponse);
                        return null;
                    }
                }
                else if ("open".equals(sf))
                {
                    if (subscriber)
                    {
                        logger.error("ERROR - subscriberMedia not match - subscriberMedia " + sf + " - "
                                + jsonResponse);
                        return null;
                    }
                }
                else if ("subscriber".equals(sf))
                {
                    if (!subscriber)
                    {
                        logger.error("ERROR - subscriberMedia not match - subscriberMedia " + sf + " - "
                                + jsonResponse);
                        return null;
                    }
                }
                else
                {
                    logger.error("ERROR - subscriberMedia not valid - subscriberMedia " + sf + " - "
                            + jsonResponse);
                    return null;
                }
            }
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject format() throws Exception
    {
        String url = host + "/apiuol/v3/media/list?format=";
        String[] arrayFormats = new String[] { "2", "5", "6", "7", "8", "9" };
        JSONObject jsonResponse = null;

        for (String format : arrayFormats)
        {
            jsonResponse = execRequest(url + format + "&nocache=" + Math.random());

            if (!validatePageJson(jsonResponse))
            {
                logger.error("ERROR - return not valid - " + url + format + " - " + jsonResponse);
                return null;
            }

            for (int i = 0; i < jsonResponse.getJSONArray("list").length(); i++)
            {
                if (!JsonUtil.contains(jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("formats"),
                    Integer.valueOf(format)))
                {
                    logger.error("ERROR - format not match - " + format + " - " + jsonResponse);
                    return null;
                }
            }
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject tagNames(String tags) throws Exception
    {
        String url = host + "/apiuol/v3/media/list?tagNames=" + tags + "&nocache=" + Math.random();
        JSONObject jsonResponse = execRequest(url);

        if (!validatePageJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + url + " - " + jsonResponse);
            return null;
        }

        for (int i = 0; i < jsonResponse.getJSONArray("list").length(); i++)
        {
            if (!JsonUtil
                    .containsTagName(jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("tags"), tags))
            {
                logger.error("ERROR - tagNames not match - tags " + tags + " - " + jsonResponse);
                return null;
            }
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject tagIds(String tags, boolean or) throws Exception
    {
        boolean contains = false;
        String url = host + "/apiuol/v3/media/list?tagIds=" + tags + (or ? "&qryTagIds=or" : "") + "&nocache="
                + Math.random();
        JSONObject jsonResponse = execRequest(url);

        if (!validatePageJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + url + " - " + jsonResponse);
            return null;
        }

        for (int i = 0; i < jsonResponse.getJSONArray("list").length(); i++)
        {
            for (String tag : tags.split(","))
            {
                if (or)
                {
                    if (JsonUtil.containsTagId(jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("tags"),
                        Integer.parseInt(tag)))
                    {
                        contains = true;
                        break;
                    }
                }
                else
                {
                    if (!JsonUtil.containsTagId(
                        jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("tags"), Integer.parseInt(tag)))
                    {
                        logger.error("ERROR - tagIds not match - tags " + tags + " - " + jsonResponse);
                        return null;
                    }
                }
            }
        }

        if (or && !contains)
        {
            logger.error("ERROR - tags not match - tags " + tags + " - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject tagService(String tagService, boolean or) throws Exception
    {
        boolean contains = false;
        String url = host + "/apiuol/v3/media/list?tagSrvIds=" + tagService + (or ? "&qryTagSrvIds=or" : "")
                + "&nocache=" + Math.random();
        JSONObject jsonResponse = execRequest(url);

        if (!validatePageJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + url + " - " + jsonResponse);
            return null;
        }

        for (int i = 0; i < jsonResponse.getJSONArray("list").length(); i++)
        {
            for (String tag : tagService.split(";"))
            {
                if (or)
                {
                    if (ArrayUtils.contains(jsonResponse.getJSONArray("list").getJSONObject(i).getString("tagSrv")
                            .split(","), tag))
                    {
                        contains = true;
                        break;
                    }
                }
                else
                {
                    if (!ArrayUtils.contains(jsonResponse.getJSONArray("list").getJSONObject(i).getString("tagSrv")
                            .split(","), tag))
                    {
                        logger.error("ERROR - tags not match - tags " + tagService + " - " + jsonResponse);
                        return null;
                    }
                }
            }
        }

        if (or && !contains)
        {
            logger.error("ERROR - tagservice not match - tags " + tagService + " - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject sort() throws Exception
    {
        String url = host + "/apiuol/v3/media/list?sort=";
        JSONObject jsonResponse = null;
        String[] mediaSort = new String[] { "mostPopular", 
                                            "mostVoted", 
                                            "mostFavorited", 
                                            "mostRecent", 
                                            "alphabetic", 
                                            "profileUpdate", 
                                            "recentlyViewed",
                                            "todayViewed",
                                            "lastUpdate", 
                                            "mostRelevant" };

        for (String order : mediaSort)
        {
            jsonResponse = execRequest(url + order.toString() + "&nocache=" + Math.random());

            if (jsonResponse.getJSONObject("response").getInt("code") == HttpStatus.SC_NOT_FOUND
                    && (order.equals("recentlyViewed") || order.equals("todayViewed")))
            {
                if (!validateResponseNotOKJson(jsonResponse, HttpStatus.SC_NOT_FOUND))
                {
                    logger.error("ERROR - invalid response - " + url + order + " - " + jsonResponse);
                    return null;
                }
            }
            else
            {
                if (!validatePageJson(jsonResponse))
                {
                    logger.error("ERROR - return not valid - " + url + order + " - " + jsonResponse);
                    return null;
                }
            }
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject editorialStatus() throws Exception
    {
        String url = host + "/apiuol/v3/media/list?editorialStatus=aproved";
        JSONObject jsonResponse = null;
        JSONObject media = null;

        jsonResponse = execRequest(url + "&nocache=" + Math.random());

        if (!validatePageJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + url + " - " + jsonResponse);
            return null;
        }

        for (int i = 0; i < jsonResponse.getJSONArray("list").length(); i++)
        {
            media = JsonUtil.media(String
                    .valueOf(jsonResponse.getJSONArray("list").getJSONObject(i).getLong("mediaId")));

            if (Integer.parseInt(media.getString("cod_editorial_status")) != 2)
            {
                logger.error("ERROR - editorialStatus not match - "
                        + jsonResponse.getJSONArray("list").getJSONObject(i).getLong("mediaId") + " "
                        + media.getString("cod_editorial_status"));
                return null;
            }
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject formats(String mediaId) throws Exception
    {
        String url = host + "/apiuol/v3/media/format/" + mediaId + "?nocache=" + Math.random();
        JSONObject jsonResponse = execRequest(url);

        if (!validateFormatsJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + url + " - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject paging() throws Exception
    {
        int page = 1;
        JSONObject jsonResponse = execRequest(host + "/apiuol/v3/media/list/page/" + page + "?nocache="
                + Math.random());

        while (jsonResponse.has("list") && jsonResponse.getJSONArray("list").length() > 0)
        {
            if (!validatePageJson(jsonResponse))
            {
                logger.error("ERROR - return not valid - " + jsonResponse);
                return null;
            }

            page++;
            jsonResponse = execRequest(host + "/apiuol/v3/media/list/page/" + page + "?nocache=" + Math.random());
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject date() throws Exception
    {
        int page = 1;
        JSONObject media = JsonUtil.apiMedia("V");

        if (media == null)
        {
            logger.error("ERROR - none media found");
            return null;
        }

        DateParsing dateParsing = new DateParsing(media.getString("publishedAt"), "YYYY-MM-dd HH:mm:ss");
        String url = host + "/apiuol/v3/media/list/page/" + page + "?date=" + dateParsing.dateString();
        JSONObject jsonResponse = execRequest(url + page + "&nocache=" + Math.random());

        while (jsonResponse.has("list") && jsonResponse.getJSONArray("list").length() > 0)
        {
            for (int i = 0; i < jsonResponse.getJSONArray("list").length(); i++)
            {
                if (!validatePageJson(jsonResponse))
                {
                    logger.error("ERROR - json not valid from media list - " + url + " - " + jsonResponse);
                    return null;
                }

                if (!jsonResponse.getJSONArray("list").getJSONObject(i).getString("publishedAt").startsWith(
                    dateParsing.getYear() + "-" + (dateParsing.getMonth() < 10 ? "0" + dateParsing.getMonth() : dateParsing.getMonth()) 
                    + "-" + dateParsing.getDay()))
                {
                    logger.error("ERROR - media not valid - " + media + " - "
                            + jsonResponse.getJSONArray("list").getJSONObject(i));
                    return null;
                }
            }

            page++;
            url = host + "/apiuol/v3/media/list/page/" + page + "?date=" + dateParsing.dateString();
            jsonResponse = execRequest(url + page + "&nocache=" + Math.random());
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject followable() throws Exception
    {
        int page = 1;
        JSONObject jsonfollowable = JsonUtil.followable();

        if (jsonfollowable == null)
        {
            logger.error("ERROR - none followable found");
            return null;
        }

        String url = host + "/apiuol/v3/media/list/page/" + page + "?followableId="
                + jsonfollowable.getString("idt_followable");
        JSONObject jsonResponse = execRequest(url + "&nocache=" + Math.random());

        while (jsonResponse.has("list") && jsonResponse.getJSONArray("list").length() > 0)
        {
            for (int i = 0; i < jsonResponse.getJSONArray("list").length(); i++)
            {
                if (!validatePageJson(jsonResponse))
                {
                    logger.error("ERROR - json not valid from media list - " + url + " - " + jsonResponse);
                    return null;
                }

                if (!validateFollowable(jsonfollowable, jsonResponse.getJSONArray("list").getJSONObject(i)))
                {
                    logger.error("ERROR - followable not valid - " + jsonfollowable + " - "
                            + jsonResponse.getJSONArray("list").getJSONObject(i));
                    return null;
                }
            }

            page++;
            url = host + "/apiuol/v3/media/list/page/" + page + "?followableId="
                    + jsonfollowable.getString("idt_followable");
            jsonResponse = execRequest(url + "&nocache=" + Math.random());
        }

        logger.debug("SUCCESS");

        return jsonfollowable;
    }

    private JSONObject execRequest(String url) throws Exception
    {
        if (isSSL)
        {
            FacileResponse response = request.get(url);

            return response.getJson();
        }
        else
        {
            return JsonRequest.get(url);
        }
    }

    private boolean isRelated(JSONArray listRelated, JSONObject media) throws Exception
    {
        for (String q : media.getJSONObject("item").getString("title").split(" "))
        {
            if (JsonUtil.containsTerms(listRelated, q))
            {
                return true;
            }
        }

        if (media.getJSONObject("item").has("description"))
        {
            for (String q : media.getJSONObject("item").getString("description").split(" "))
            {
                if (JsonUtil.containsTerms(listRelated, q))
                {
                    return true;
                }
            }
        }

        for (int j = 0; j < media.getJSONObject("item").getJSONArray("tags").length(); j++)
        {
            if (JsonUtil.containsTerms(listRelated, media.getJSONObject("item").getJSONArray("tags").getJSONObject(j)
                    .getString("description")))
            {
                return true;
            }
        }

        if (JsonUtil.containsTerms(listRelated, media.getJSONObject("item").getString("author")))
        {
            return true;
        }

        return false;
    }

    private boolean validateResponseNotOKJson(JSONObject json, int httpStatus)
    {
        try
        {
            json.getJSONObject("response");
            json.getJSONObject("response").getInt("code");
            json.getJSONObject("response").getString("description");
            json.getJSONObject("response").getString("originalRequest");

            if (!json.has("error"))
            {
                logger.error("ERROR - response invalid - no error - " + json);
                return false;
            }

            if (!json.isNull("error"))
            {
                json.getJSONObject("error");
                json.getJSONObject("error").getString("message");
            }

            if (json.getJSONObject("response").getInt("code") != httpStatus)
            {
                logger.error("ERROR - response invalid - wrong code " + json);
                return false;
            }

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - response invalid - " + e.getMessage() + " - " + json);
            return false;
        }
    }

    private boolean validateJson(JSONObject jsonResponse) throws JSONException
    {
        try
        {
            if (jsonResponse == null || jsonResponse.getJSONObject("response").getInt("code") != HttpStatus.SC_OK)
            {
                return false;
            }

            jsonResponse.getJSONObject("response");
            jsonResponse.getJSONObject("response").getInt("code");
            jsonResponse.getJSONObject("response").getString("description");
            jsonResponse.getJSONObject("response").getString("originalRequest");

            jsonResponse.getJSONObject("item");
            jsonResponse.getJSONObject("item").getString("title");
            jsonResponse.getJSONObject("item").getString("urlHash");
            jsonResponse.getJSONObject("item").getLong("mediaId");
            jsonResponse.getJSONObject("item").getString("url");
            jsonResponse.getJSONObject("item").getString("type");
            jsonResponse.getJSONObject("item").getString("authorType");
            jsonResponse.getJSONObject("item").getString("thumbSmall");
            jsonResponse.getJSONObject("item").getString("thumbMedium");
            jsonResponse.getJSONObject("item").getString("thumbLarge");
            jsonResponse.getJSONObject("item").getLong("babelSubjectId");

            if (jsonResponse.getJSONObject("item").getString("type").equals("V"))
            {
                jsonResponse.getJSONObject("item").getString("duration");
                jsonResponse.getJSONObject("item").getString("thumbWlarge");
                jsonResponse.getJSONObject("item").getString("thumbWmedium");
                jsonResponse.getJSONObject("item").getString("thumbXlarge");

                if (!jsonResponse.getJSONObject("item").isNull("formats"))
                {
                    for (int j = 0; j < jsonResponse.getJSONObject("item").getJSONArray("formats").length(); j++)
                    {
                        jsonResponse.getJSONObject("item").getJSONArray("formats").getInt(j);
                    }
                }

                if (!jsonResponse.getJSONObject("item").isNull("productList"))
                {
                    jsonResponse.getJSONObject("item").getJSONArray("productList");

                    for (int i = 0; i < jsonResponse.getJSONObject("item").getJSONArray("productList").length(); i++)
                    {
                        jsonResponse.getJSONObject("item").getJSONArray("productList").getInt(i);
                    }
                }

                jsonResponse.getJSONObject("item").getString("embedCode");
            }

            if (jsonResponse.getJSONObject("item").getString("type").equals("P"))
            {
                jsonResponse.getJSONObject("item").getString("duration");
                jsonResponse.getJSONObject("item").getString("embedCode");
            }

            if (!jsonResponse.getJSONObject("item").isNull("description"))
            {
                jsonResponse.getJSONObject("item").getString("description");
            }

            Boolean.parseBoolean(jsonResponse.getJSONObject("item").getString("isAdult"));
            jsonResponse.getJSONObject("item").getString("author");
            jsonResponse.getJSONObject("item").getString("codProfile");
            jsonResponse.getJSONObject("item").getInt("viewsQtty");
            jsonResponse.getJSONObject("item").getString("publishDate");
            Boolean.parseBoolean(jsonResponse.getJSONObject("item").getString("isEmbedBlocked"));
            Boolean.parseBoolean(jsonResponse.getJSONObject("item").getString("isSubscriberExclusive"));

            int tagLength = jsonResponse.getJSONObject("item").getJSONArray("tags").length();

            for (int j = 0; j < tagLength; j++)
            {
                jsonResponse.getJSONObject("item").getJSONArray("tags").getJSONObject(j).getLong("id");
                jsonResponse.getJSONObject("item").getJSONArray("tags").getJSONObject(j).getString("description");
            }

            if (!jsonResponse.getJSONObject("item").isNull("tagSrv"))
            {
                jsonResponse.getJSONObject("item").getString("tagSrv");
            }

            JsonUtil.validateValueJson(jsonResponse.getJSONObject("item"), new String[] { "title", "description" });

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - json is not valid - " + e.getMessage() + " - " + jsonResponse);
            return false;
        }
    }

    private boolean validatePageJson(JSONObject jsonResponse) throws JSONException
    {
        try
        {
            jsonResponse.getJSONObject("response");
            jsonResponse.getJSONObject("response").getInt("code");
            jsonResponse.getJSONObject("response").getString("description");
            jsonResponse.getJSONObject("response").getString("originalRequest");

            if (jsonResponse == null || jsonResponse.getJSONObject("response").getInt("code") != HttpStatus.SC_OK)
            {
                return false;
            }

            jsonResponse.getJSONObject("paging");
            jsonResponse.getJSONObject("paging").getInt("currentPage");
            Boolean.parseBoolean(jsonResponse.getJSONObject("paging").getString("nextPage"));
            jsonResponse.getJSONObject("paging").getInt("pageSize");
            Boolean.parseBoolean(jsonResponse.getJSONObject("paging").getString("previousPage"));
            jsonResponse.getJSONObject("paging").getString("sort");
            jsonResponse.getJSONObject("paging").getInt("totalItems");
            jsonResponse.getJSONObject("paging").getInt("totalPages");

            jsonResponse.getJSONArray("list");

            int length = jsonResponse.getJSONArray("list").length();

            for (int i = 0; i < length; i++)
            {
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("title");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("urlHash");
                jsonResponse.getJSONArray("list").getJSONObject(i).getLong("mediaId");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("url");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("type");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("authorType");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("thumbSmall");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("thumbMedium");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("thumbLarge");
                jsonResponse.getJSONArray("list").getJSONObject(i).getLong("babelSubjectId");

                if (jsonResponse.getJSONArray("list").getJSONObject(i).getString("type").equals("V"))
                {
                    jsonResponse.getJSONArray("list").getJSONObject(i).getString("duration");
                    jsonResponse.getJSONArray("list").getJSONObject(i).getString("thumbWlarge");
                    jsonResponse.getJSONArray("list").getJSONObject(i).getString("thumbWmedium");
                    jsonResponse.getJSONArray("list").getJSONObject(i).getString("thumbXlarge");

                    if (!jsonResponse.getJSONArray("list").getJSONObject(i).isNull("formats"))
                    {
                        for (int j = 0; j < jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("formats")
                                .length(); j++)
                        {
                            jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("formats").getDouble(j);
                        }
                    }

                    if (!jsonResponse.getJSONArray("list").getJSONObject(i).isNull("productList"))
                    {
                        jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("productList");

                        for (int j = 0; j < jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray(
                            "productList").length(); j++)
                        {
                            jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("productList").getInt(j);
                        }
                    }
                }

                if (jsonResponse.getJSONArray("list").getJSONObject(i).getString("type").equals("P"))
                {
                    jsonResponse.getJSONArray("list").getJSONObject(i).getString("duration");
                }

                if (!jsonResponse.getJSONArray("list").getJSONObject(i).isNull("description"))
                {
                    jsonResponse.getJSONArray("list").getJSONObject(i).getString("description");
                }

                Boolean.parseBoolean(jsonResponse.getJSONArray("list").getJSONObject(i).getString("isAdult"));
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("author");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("codProfile");
                jsonResponse.getJSONArray("list").getJSONObject(i).getInt("viewsQtty");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("publishDate");
                Boolean.parseBoolean(jsonResponse.getJSONArray("list").getJSONObject(i).getString("isEmbedBlocked"));
                Boolean.parseBoolean(jsonResponse.getJSONArray("list").getJSONObject(i).getString(
                    "isSubscriberExclusive"));

                for (int j = 0; j < jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("tags").length(); j++)
                {
                    jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("tags").getJSONObject(j).getLong(
                        "id");
                    jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("tags").getJSONObject(j).getString(
                        "description");
                }

                if (!jsonResponse.getJSONArray("list").getJSONObject(i).isNull("tagSrv"))
                {
                    jsonResponse.getJSONArray("list").getJSONObject(i).getString("tagSrv");
                }

                JsonUtil.validateValueJson(jsonResponse.getJSONArray("list").getJSONObject(i),
                    new String[] { "title", "description" });
            }

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - pagejson is not valid - " + e.getMessage() + " - " + jsonResponse);
            return false;
        }
    }

    private boolean validateFormatsJson(JSONObject jsonResponse)
    {
        try
        {
            jsonResponse.getJSONObject("item");
            jsonResponse.getJSONObject("item").getLong("mediaId");
            jsonResponse.getJSONObject("item").getBoolean("hasHdFormats");
            jsonResponse.getJSONObject("item").getBoolean("hasMobileFormats");
            jsonResponse.getJSONObject("item").getJSONArray("formats");

            for (int i = 0; i < jsonResponse.getJSONObject("item").getJSONArray("formats").length(); i++)
            {
                jsonResponse.getJSONObject("item").getJSONArray("formats").getJSONObject(i).getInt("id");
                jsonResponse.getJSONObject("item").getJSONArray("formats").getJSONObject(i).getInt("widthVideo");
                jsonResponse.getJSONObject("item").getJSONArray("formats").getJSONObject(i).getInt("heightVideo");
            }

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - formatsjson is not valid - " + e.getMessage() + " - " + jsonResponse);
            return false;
        }
    }

    private boolean validateFollowable(JSONObject followable, JSONObject media) throws Exception
    {
        if (followable == null)
        {
            logger.error("ERROR - followable is null");
            return false;
        }

        if (followable.has("tags") && !followable.isNull("tags"))
        {
            if (followable.has("cod_profile_hash") && !followable.isNull("cod_profile_hash"))
            {
                if (!media.getString("codProfile").equals(
                    HashCode.decode(Long.valueOf(followable.getString("cod_profile_hash")))))
                {
                    logger.error("ERROR - followable not match user and tag");
                    return false;
                }
            }

            if (followable.has("flg_editorial") && followable.getString("flg_editorial").equals("1"))
            {
                for (String tag : followable.getString("tags").split(","))
                {
                    if (followable.has("flg_and") && followable.getString("flg_and").equals("1"))
                    {
                        if (!media.getString("tagSrv").contains(tag))
                        {
                            logger.error("ERROR - followable not match tag");
                            return false;
                        }
                    }
                    else
                    {
                        if (media.getString("tagSrv").contains(tag))
                        {
                            return true;
                        }
                    }
                }
            }
            else
            {
                for (String tag : followable.getString("tags").split(","))
                {
                    if (followable.has("flg_and") && followable.getString("flg_and").equals("1"))
                    {
                        if (!JsonUtil.containsTagId(media.getJSONArray("tags"), Integer.parseInt(tag)))
                        {
                            logger.error("ERROR - followable not match tagservice");
                            return false;
                        }
                    }
                    else
                    {
                        if (JsonUtil.containsTagId(media.getJSONArray("tags"), Integer.parseInt(tag)))
                        {
                            return true;
                        }
                    }
                }
            }
        }
        else if (followable.has("cod_profile_hash") && !followable.isNull("cod_profile_hash"))
        {
            if (!media.getString("codProfile").equals(
                HashCode.decode(Long.valueOf(followable.getString("cod_profile_hash")))))
            {
                logger.error("ERROR - followable not match user");
                return false;
            }
            else
            {
                return true;
            }
        }

        if (followable.has("idt_editor_type") && !followable.isNull("idt_editor_type"))
        {
            if (!existsEditorType(followable.getString("cod_profile_hash"), followable.getString("idt_editor_type")))
            {
                logger.error("ERROR - followable not match editorType");
                return false;
            }
            else
            {
                return true;
            }
        }

        return false;
    }

    private boolean existsEditorType(String codProfileHash, String idtEditorType) throws Exception
    {
        String query = "SELECT * FROM profile_editor_type WHERE cod_profile_hash = " + codProfileHash
                + " AND idt_editor_type = " + idtEditorType;
        JSONObject result = JsonRequest.execQuery(query);

        if (result != null && result.has("data") && result.getJSONArray("data").length() > 0)
        {
            return true;
        }

        return false;
    }
}
