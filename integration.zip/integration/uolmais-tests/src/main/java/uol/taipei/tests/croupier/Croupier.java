/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         25/04/2014 Criacao inicial
 */

package uol.taipei.tests.croupier;

import java.util.Arrays;
import java.util.LinkedList;

import org.apache.http.HttpStatus;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uol.taipei.request.FacileRequest;
import uol.taipei.request.FacileResponse;
import uol.taipei.request.JsonRequest;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.util.JsonUtil;
import uol.taipei.tests.util.RequestUtil;

public class Croupier extends AbstractTest
{
    static final Logger logger = LoggerFactory.getLogger(Croupier.class);

    public static void main(String[] args)
    {
        if (!verifyParams(args))
        {
            return;
        }

        setUp(args[0]);

        logger.debug("-------------------------------------------------");
        logger.debug("tests croupier");

        try
        {
            Croupier croupier = new Croupier(false, false);

            croupier.crossdomain();
            

            String mediaId = RequestUtil.mediaIdPublic("V");
            croupier.formats(mediaId);
            croupier.video(mediaId);
            croupier.show(mediaId);
            croupier.v3media(mediaId);

            mediaId = RequestUtil.mediaIdPublic("P");
            croupier.show(mediaId);
            croupier.v3media(mediaId);
        }
        catch (Exception e)
        {
            logger.error(e.getMessage());
        }
    }

    /**
     * construtor
     * 
     * @param isSSL define http ou https
     * @param useSRV dominio interno ou publico
     */
    public Croupier(boolean isSSL, boolean useSRV)
    {
        this.host = "http" + (isSSL ? "s" : "") + "://"
                + (useSRV ? envConfig().getGlobal().getUrlcrosrv() : envConfig().getGlobal().getUrlcro());
    }

    public Croupier(String url)
    {
        this.host = url;
    }

    public boolean crossdomain() throws Exception
    {
        FacileRequest request = new FacileRequest();
        FacileResponse response = request.get(host + "/crossdomain.xml");

        if (response.getCode() != 200)
        {
            logger.error("ERROR - return not valid - " + response.getCode());
            return false;
        }

        logger.info("Crossdomain Test - SUCCESS");

        return true;
    }

    public JSONObject video(String mediaId) throws Exception
    {
        //String mediaId = RequestUtil.mediaIdPublic("V");
        JSONObject jsonResponse = JsonRequest.get(host + "/video/" + mediaId);

        if (!validateJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        logger.info("Video Test [mediaId=" + mediaId + "] - SUCCESS");

        return jsonResponse;
    }

    public JSONObject show(String mediaId) throws Exception
    {
        JSONObject jsonResponse = JsonRequest.get(host + "/show/" + mediaId);

        if (!validateJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        logger.info("Show Test [mediaId=" + mediaId + "] - SUCCESS");

        return jsonResponse;
    }

    public JSONObject v3media(String mediaId) throws Exception
    {
        JSONObject jsonResponse = JsonRequest.get(host + "/v3/media/" + mediaId);

        if (!validateJsonV3media(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        logger.info("v3media Test [mediaId=" + mediaId + "] - SUCCESS");

        return jsonResponse;
    }
    
    public JSONObject formats(String mediaId) throws Exception
    {
        JSONObject formatsJson = JsonRequest.get(host + "/v3/formats/" + mediaId + "/jsonp");
        JSONObject response = formatsJson.getJSONObject("_response");
        formatsJson.remove("_response");
        
        if (response.getInt("code") != 200 || !validateJsonFormats(formatsJson))
        {
            formatsJson.put("_response", response);
            logger.error("ERROR - return not valid - " + formatsJson);
            return null;
        }
        
        logger.info("Formats Test [mediaId=" + mediaId + "] - SUCCESS");
        
        return formatsJson;
    }

    private boolean validateJson(JSONObject jsonResponse) throws JSONException
    {
        try
        {
            if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") != HttpStatus.SC_OK)
            {
                return false;
            }

            jsonResponse.getString("title");
            jsonResponse.getLong("mediaId");
            jsonResponse.getString("url");
            jsonResponse.getString("mediaType");

            if (jsonResponse.getString("mediaType").equals("P"))
            {
                jsonResponse.getString("fileUrl");
            }

            if (jsonResponse.getString("mediaType").equals("V"))
            {
                jsonResponse.getString("desMedia");
                jsonResponse.getString("thumbnail");
                jsonResponse.getString("desExtraInformation");
                jsonResponse.getInt("numGeneratedThumbs");
                jsonResponse.getInt("thumbVersion");
                //jsonResponse.getString("codPublicity");
                Boolean.parseBoolean(jsonResponse.getString("subscriberMedia"));
                Boolean.parseBoolean(jsonResponse.getString("externalCDN"));
                Boolean.parseBoolean(jsonResponse.getString("popular"));

                int formatLength = jsonResponse.getJSONArray("formats").length();

                for (int j = 0; j < formatLength; j++)
                {
                    jsonResponse.getJSONArray("formats").getJSONObject(j).getInt("id");
                    jsonResponse.getJSONArray("formats").getJSONObject(j).getString("url");
                    jsonResponse.getJSONArray("formats").getJSONObject(j).getString("secureUrl");
                    
                    for (int k = 0; k < jsonResponse.getJSONArray("formats").getJSONObject(j).getJSONArray("alternatives").length(); k++)
                    {
                        jsonResponse.getJSONArray("formats").getJSONObject(j).getJSONArray("alternatives").getString(k);
                    }
                }

                int tagLength = jsonResponse.getJSONArray("tags").length();

                for (int j = 0; j < tagLength; j++)
                {
                    jsonResponse.getJSONArray("tags").getJSONObject(j).getLong("id");
                    jsonResponse.getJSONArray("tags").getJSONObject(j).getString("description");
                }
            }

            jsonResponse.getString("author");
            jsonResponse.getString("codProfile");
            Boolean.parseBoolean(jsonResponse.getString("blockEmbed"));
            jsonResponse.getString("duration");
            Boolean.parseBoolean(jsonResponse.getString("geoBlocked"));
            jsonResponse.getInt("numRevision");
            jsonResponse.getString("userIp");

            JsonUtil.validateValueJson(jsonResponse, new String[] { "title", "desMedia", "desExtraInformation" });

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - json is not valid - " + e.getMessage() + " - " + jsonResponse);
            return false;
        }
    }

    private boolean validateJsonV3media(JSONObject jsonResponse) throws JSONException
    {
        try
        {
            if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") != HttpStatus.SC_OK)
            {
                return false;
            }

            jsonResponse.getString("title");
            jsonResponse.getLong("mediaId");
            jsonResponse.getString("url");
            jsonResponse.getString("type");
            jsonResponse.getString("author");
            jsonResponse.getString("codProfile");
            jsonResponse.getString("userIp");

            if (jsonResponse.getString("type").equals("P"))
            {
                jsonResponse.getString("audioUrl");
                jsonResponse.getInt("revision");
            }

            if (jsonResponse.getString("type").equals("V"))
            {
                if (!jsonResponse.isNull("audioUrl"))
                {
                    logger.error("ERROR - json is not valid - " + jsonResponse.getString("audioUrl") + " - "
                            + jsonResponse);

                    return false;
                }

                jsonResponse.getString("thumbnail");
                jsonResponse.getInt("generatedThumbs");
                jsonResponse.getInt("revision");
                jsonResponse.getString("tags");

                if (!jsonResponse.isNull("iu"))
                {
                    jsonResponse.getString("iu");
                }

                jsonResponse.getJSONObject("formats");

                /*
                if (!validateJsonFormats(jsonResponse.getJSONObject("formats")))
                {
                    return false;
                }
                */
            }

            jsonResponse.getJSONObject("duration");
            jsonResponse.getJSONObject("duration").getInt("seconds");
            jsonResponse.getJSONObject("duration").getString("formatted");

            JsonUtil.validateValueJson(jsonResponse, new String[] { "title" });

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - json is not valid - " + e.getMessage() + " - " + jsonResponse);
            return false;
        }
    }
    
    private boolean validateJsonFormats(JSONObject formats) throws JSONException
    {
        for (int j = 0; j < formats.names().length(); j++)
        {
            String formatName = formats.names().getString(j);

            if (!FORMATS_NAME.contains(formatName))
            {
                logger.error("ERROR - json is not valid - " + formatName + " - " + formats);

                return false;
            }

            formats.getJSONObject(formatName).getString("url");
            formats.getJSONObject(formatName).getString("filename");
            formats.getJSONObject(formatName).getBoolean("externalCDN");

            for (int k = 0; k < formats.getJSONObject(formatName).getJSONArray("alternatives").length(); k++)
            {
                formats.getJSONObject(formatName).getJSONArray("alternatives").getString(k);
            }
        }
        return true;
    }

    private static final LinkedList<String> FORMATS_NAME = new LinkedList<>(Arrays.asList(new String[] { "3gp-240p",
                                                                                                        "3gp-144p",
                                                                                                        "1080p",
                                                                                                        "360p", 
                                                                                                        "720p",
                                                                                                        "mobile",
                                                                                                        "HLS" }));
}
