/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         08/07/2014 Criacao inicial
 */

package uol.taipei.tests.moderation;

import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uol.taipei.request.JsonRequest;
import uol.taipei.request.UsefulRequest;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.LoginCookie;
import uol.taipei.tests.LoginRadius;
import uol.taipei.tests.util.JsonUtil;

public class ProfileAdm extends AbstractTest
{
    static final Logger logger = LoggerFactory.getLogger(ProfileAdm.class);

    public static void main(String[] args)
    {
        if (!verifyParams(args))
        {
            return;
        }

        setUp(args[0]);

        if (envConfig().getUser() == null || envConfig().getUser().equals("") || envConfig().getPass() == null || envConfig().getPass().equals(""))
        {
            System.err.println("Invalid user " + envConfig().getUser());
            return;
        }

        logger.debug("-------------------------------------------------");
        logger.debug("tests administration profile");

        try
        {
            ProfileAdm profileAdm = new ProfileAdm();
            LoginCookie login = new LoginCookie(envConfig().getUser(), envConfig().getPass());
            UsefulRequest loginR = new LoginRadius(envConfig().getUserRadius(), envConfig().getPassRadius());

            profileAdm.identify(loginR, login.getJsonProfile().getJSONObject("item").getString("codProfile"));
            
            // tem chache local/manager nao da para validar. Nao pode ser executado na ferramenta
            profileAdm.changeByCodProfile(loginR, login.getJsonProfile().getJSONObject("item").getString("codProfile"));
            profileAdm.changeByCodProfileHash(loginR, login.getJsonProfile().getJSONObject("item").getLong("codProfileHash"));
            profileAdm.changeByLogin(loginR, envConfig().getUser());
        }
        catch (Exception e)
        {
            logger.error(e.getMessage());
        }
    }

    public JSONObject identify(UsefulRequest login, String codProfile) throws Exception
    {
        JSONObject jsonResponse = login.getJson("http://videos.intranet.uol.com.br/maisAdm/profileAdm/profile.json?"
                + "by=codProfile&user="+ codProfile);

        if (!validateIdentifyJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject changeByCodProfile(UsefulRequest login, String codProfile) throws Exception
    {
        JSONObject profile = JsonRequest.get("http://maxima.mais.sys.intranet/profile?mode=codProfile&user=" + codProfile);

        String url = "http://videos.intranet.uol.com.br/maisAdm/profileAdm/change.json?by=codProfile&user=" + codProfile;
        JSONObject jsonResponse = login.getJson(url);

        if (!validateMessageJson(jsonResponse, 'I'))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        if (!validateResponse(profile, jsonResponse))
        {
            logger.error("ERROR - return not valid");
            return null;
        }

        profile = JsonRequest.get("http://maxima.mais.sys.intranet/profile?mode=codProfile&user=" + codProfile);
        jsonResponse = login.getJson(url);

        if (!validateMessageJson(jsonResponse, 'I'))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject changeByCodProfileHash(UsefulRequest login, Long codProfileHash) throws Exception
    {
        JSONObject profile = JsonRequest.get("http://maxima.mais.sys.intranet/profile?mode=codProfileHash&user=" + codProfileHash);

        String url = "http://videos.intranet.uol.com.br/maisAdm/profileAdm/change.json?by=codProfileHash&user=" + codProfileHash;
        JSONObject jsonResponse = login.getJson(url);

        if (!validateMessageJson(jsonResponse, 'I'))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        if (!validateResponse(profile, jsonResponse))
        {
            logger.error("ERROR - return not valid");
            return null;
        }

        profile = JsonRequest.get("http://maxima.mais.sys.intranet/profile?mode=codProfileHash&user=" + codProfileHash);
        jsonResponse = login.getJson(url);

        if (!validateMessageJson(jsonResponse, 'I'))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject changeByLogin(UsefulRequest login, String namLogin) throws Exception
    {
        JSONObject profile = JsonRequest.get("http://maxima.mais.sys.intranet/profile?mode=namLogin&user=" + namLogin);

        String url = "http://videos.intranet.uol.com.br/maisAdm/profileAdm/change.json?by=namLogin&user=" + namLogin;
        JSONObject jsonResponse = login.getJson(url);

        if (!validateMessageJson(jsonResponse, 'I'))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        if (!validateResponse(profile, jsonResponse))
        {
            logger.error("ERROR - return not valid");
            return null;
        }

        profile = JsonRequest.get("http://maxima.mais.sys.intranet/profile?mode=namLogin&user=" + namLogin);
        jsonResponse = login.getJson(url);

        if (!validateMessageJson(jsonResponse, 'I'))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    private boolean validateResponse(JSONObject profile, JSONObject jsonResponse) throws JSONException
    {
        try
        {
            if (profile.getJSONObject("maker").getJSONObject("profile").getInt("flgEditorialProfile") == 0
                    && jsonResponse.getString("verify").equals("editorial"))
            {
                logger.error("ERROR - result not match - "
                        + profile.getJSONObject("maker").getJSONObject("profile").getInt("flgEditorialProfile") + " - " + jsonResponse);
                return false;
            }

            if (profile.getJSONObject("maker").getJSONObject("profile").getInt("flgEditorialProfile") == 1
                    && jsonResponse.getString("verify").equals("regular"))
            {
                logger.error("ERROR - result not match - "
                        + profile.getJSONObject("maker").getJSONObject("profile").getInt("flgEditorialProfile") + " - " + jsonResponse);
                return false;
            }

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - jsonResponse is not valid - " + e.getMessage() + " - " + jsonResponse);
            return false;
        }
    }

    private boolean validateIdentifyJson(JSONObject jsonResponse) throws JSONException
    {
        try
        {
            jsonResponse.getJSONObject("profile");
            jsonResponse.getJSONObject("profile").getLong("idtPerson");
            jsonResponse.getJSONObject("profile").getString("namNick");
            jsonResponse.getJSONObject("profile").getLong("codProfileHash");
            jsonResponse.getJSONObject("profile").getString("namLogin");
            jsonResponse.getJSONObject("profileMediaConfig");
            jsonResponse.getJSONObject("profileMediaConfig").getInt("flgEditorialProfile");

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - jsonIdentify is not valid - " + e.getMessage() + " - " + jsonResponse);
            return false;
        }
    }

    private boolean validateMessageJson(JSONObject json, char type)
    {
        try
        {
            json.getString("verify");
            json.getJSONObject("messages");

            if (type == 'S')
            {
                json.getJSONObject("messages").getJSONArray("success");

                if (json.getJSONObject("messages").getJSONArray("success").length() < 1)
                {
                    throw new Exception("no has success message");
                }

                for (int i = 0; i < json.getJSONObject("messages").getJSONArray("success").length(); i++)
                {
                    json.getJSONObject("messages").getJSONArray("success").getJSONObject(i).getString("id");
                    json.getJSONObject("messages").getJSONArray("success").getJSONObject(i).getString("description");

                    JsonUtil.validateValueJson(json.getJSONObject("messages").getJSONArray("success").getJSONObject(i), new String[] { "" });
                }
            }
            else if (type == 'E')
            {
                json.getJSONObject("messages").getJSONArray("errors");

                if (json.getJSONObject("messages").getJSONArray("errors").length() < 1)
                {
                    throw new Exception("no has error message");
                }

                for (int i = 0; i < json.getJSONObject("messages").getJSONArray("errors").length(); i++)
                {
                    json.getJSONObject("messages").getJSONArray("errors").getJSONObject(i).getString("id");
                    json.getJSONObject("messages").getJSONArray("errors").getJSONObject(i).getString("description");

                    JsonUtil.validateValueJson(json.getJSONObject("result").getJSONArray("errors").getJSONObject(i), new String[] { "" });
                }
            }
            else if (type == 'W')
            {
                json.getJSONObject("messages").getJSONArray("warns");

                if (json.getJSONObject("messages").getJSONArray("warns").length() < 1)
                {
                    throw new Exception("no has warn message");
                }

                for (int i = 0; i < json.getJSONObject("messages").getJSONArray("warns").length(); i++)
                {
                    json.getJSONObject("messages").getJSONArray("warns").getJSONObject(i).getString("id");
                    json.getJSONObject("messages").getJSONArray("warns").getJSONObject(i).getString("description");

                    JsonUtil.validateValueJson(json.getJSONObject("messages").getJSONArray("warns").getJSONObject(i), new String[] { "" });
                }
            }
            else
            {
                json.getJSONObject("messages").getJSONArray("infos");

                if (json.getJSONObject("messages").getJSONArray("infos").length() < 1)
                {
                    throw new Exception("no has info message");
                }

                for (int i = 0; i < json.getJSONObject("messages").getJSONArray("infos").length(); i++)
                {
                    json.getJSONObject("messages").getJSONArray("infos").getJSONObject(i).getString("id");
                    json.getJSONObject("messages").getJSONArray("infos").getJSONObject(i).getString("description");

                    JsonUtil.validateValueJson(json.getJSONObject("messages").getJSONArray("infos").getJSONObject(i), new String[] { "" });
                }
            }

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - message invalid - " + e.getMessage() + " - " + json);
            return false;
        }
    }
}
