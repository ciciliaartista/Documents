/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         02/06/2014 Criacao inicial
 */

package uol.taipei.tests.comment;

import java.io.IOException;

import org.apache.http.HttpStatus;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uol.taipei.request.JsonRequest;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.LoginCookie;
import uol.taipei.tests.util.JsonUtil;
import uol.taipei.tests.util.TestUtil;

public class ApiComment extends AbstractTest
{
    public static final Logger logger = LoggerFactory.getLogger(ApiComment.class);

    public static void main(String[] args)
    {
        if (!verifyParams(args))
        {
            return;
        }

        setUp(args[0]);

        if (envConfig().getUser() == null || envConfig().getUser().equals("") || envConfig().getPass() == null || envConfig().getPass().equals(""))
        {
            System.err.println("Invalid user " + envConfig().getUser());
            return;
        }

        logger.debug("-------------------------------------------------");
        logger.debug("tests api comment");

        try
        {
            ApiComment apiComment = new ApiComment();
            LoginCookie login = new LoginCookie(envConfig().getUser(), envConfig().getPass());
            JSONObject media = JsonUtil.mediaIdtSubject(false);
            Long idtMedia = Long.parseLong(JsonUtil.getParam(media, "idt_media").toString());

            apiComment.topicLink(login, idtMedia);
            apiComment.topicLinkNoModeration(login);

            media = JsonUtil.mediaIdtSubject(true);

            if (media == null)
            {
                logger.info("idtSubject not found");
                return;
            }
            Long idtSubject = Long.parseLong(JsonUtil.getParam(media, "idt_subject").toString());
            apiComment.topicMedia(idtSubject);
            apiComment.topicTheme();
        }
        catch (Exception e)
        {
            logger.error(e.getMessage());
        }
    }

    public JSONObject topicLink(LoginCookie login, Long mediaId) throws Exception
    {
        int retry = 0;
        String url = "http://mais.uol.com.br/apiuol/v2/comment/topic/link.json?mediaId=" + mediaId;
        JSONObject jsonResponse = login.getjson(url);

        while ((jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") != HttpStatus.SC_OK) && retry < 3)
        {
            logger.warn("retry - " + url);

            TestUtil.delay(5000);
            jsonResponse = login.getjson(url);
            retry++;
        }

        if (!validateContentJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        if (jsonResponse.getJSONObject("content").getJSONObject("media").getLong("idtSubject") == 0)
        {
            logger.error("ERROR - return not match - " + url + " - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject topicLinkNoModeration(LoginCookie login) throws Exception
    {
        int retry = 0;
        JSONObject media = JsonUtil.mediaIdtSubject(false);

        if (media == null)
        {
            logger.error("ERROR - cannot test topicLinkNoModeration because media is null");
            return null;
        }

        Long idtMedia = Long.parseLong(JsonUtil.getParam(media, "idt_media").toString());
        String url = "http://mais.uol.com.br/apiuol/v2/comment/topic/link.json?mediaId=" + idtMedia + "&moderationType=NOT";
        JSONObject jsonResponse = login.getjson(url);

        while (jsonResponse != null && jsonResponse.getJSONObject("_response").getInt("code") != HttpStatus.SC_OK && retry < 3)
        {
            logger.warn("retry after 1s - " + url);

            TestUtil.delay(1000);
            jsonResponse = login.getjson(url);
            retry++;
        }

        if (!validateContentJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        if (jsonResponse.getJSONObject("content").getJSONObject("media").getLong("idtSubject") == 0)
        {
            logger.error("ERROR - return not match - " + url + " - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject topicMedia(long subjectId) throws IOException, JSONException
    {
        String url = "http://mais.uol.com.br/apiuol/v2/comment/topic/media.json?subjectId=" + subjectId;
        JSONObject jsonResponse = JsonRequest.get(url);

        if (!validateContentJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        if (jsonResponse.getJSONObject("content").getJSONObject("media").getLong("idtSubject") != subjectId)
        {
            logger.error("ERROR - return not match - " + subjectId + " " + url + " - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject topicTheme() throws IOException, JSONException
    {
        String url = "http://mais.uol.com.br/apiuol/v2/comment/topic/theme";
        JSONObject jsonResponse = JsonRequest.get(url);

        if (!validateThemeJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    protected boolean validateContentJson(JSONObject jsonResponse) throws JSONException
    {
        try
        {
            if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") != HttpStatus.SC_OK)
            {
                return false;
            }
            jsonResponse.getJSONObject("content");
            jsonResponse.getJSONObject("content").getJSONObject("media");
            jsonResponse.getJSONObject("content").getJSONObject("media").getLong("idtMedia");
            jsonResponse.getJSONObject("content").getJSONObject("media").getString("indMediaType");
            jsonResponse.getJSONObject("content").getJSONObject("media").getLong("codStatus");
            jsonResponse.getJSONObject("content").getJSONObject("media").getLong("datPublished");
            jsonResponse.getJSONObject("content").getJSONObject("media").getString("indVisibility");
            jsonResponse.getJSONObject("content").getJSONObject("media").getString("indAllowNotes");
            jsonResponse.getJSONObject("content").getJSONObject("media").getString("indHot");
            jsonResponse.getJSONObject("content").getJSONObject("media").getInt("flgNotifyComment");
            jsonResponse.getJSONObject("content").getJSONObject("media").getLong("codProfileHash");
            jsonResponse.getJSONObject("content").getJSONObject("media").getInt("numTemporaryServer");
            jsonResponse.getJSONObject("content").getJSONObject("media").getInt("numRetry");
            jsonResponse.getJSONObject("content").getJSONObject("media").getInt("numAverageVote");
            jsonResponse.getJSONObject("content").getJSONObject("media").getInt("numSumVote");
            jsonResponse.getJSONObject("content").getJSONObject("media").getInt("numTotalVote");
            jsonResponse.getJSONObject("content").getJSONObject("media").getInt("numViews");
            jsonResponse.getJSONObject("content").getJSONObject("media").getInt("numComments");
            jsonResponse.getJSONObject("content").getJSONObject("media").getInt("numFavorited");
            jsonResponse.getJSONObject("content").getJSONObject("media").getInt("numSummarizeViewsPertime");
            jsonResponse.getJSONObject("content").getJSONObject("media").getInt("numSummarizeViewsPerday");
            jsonResponse.getJSONObject("content").getJSONObject("media").getInt("numHonors");
            jsonResponse.getJSONObject("content").getJSONObject("media").getInt("codEditorialStatus");
            jsonResponse.getJSONObject("content").getJSONObject("media").getLong("datScheduling");
            jsonResponse.getJSONObject("content").getJSONObject("media").getInt("flgDraft");
            jsonResponse.getJSONObject("content").getJSONObject("media").getInt("flgSendNotification");
            jsonResponse.getJSONObject("content").getJSONObject("media").getInt("flgFeatured");
            jsonResponse.getJSONObject("content").getJSONObject("media").getInt("flgBlockEmbed");
            jsonResponse.getJSONObject("content").getJSONObject("media").getString("indAuthorizedLists");
            jsonResponse.getJSONObject("content").getJSONObject("media").getInt("numAlbums");
            jsonResponse.getJSONObject("content").getJSONObject("media").getLong("datLastUpdate");
            jsonResponse.getJSONObject("content").getJSONObject("media").getString("url");
            jsonResponse.getJSONObject("content").getJSONObject("media").getString("fileUrl");
            jsonResponse.getJSONObject("content").getJSONObject("media").getString("indMediaProtection");
            jsonResponse.getJSONObject("content").getJSONObject("media").getInt("flgSubscriberMedia");
            jsonResponse.getJSONObject("content").getJSONObject("media").getBoolean("flgBypass");
            jsonResponse.getJSONObject("content").getJSONObject("media").getInt("idtSubject");

            if (jsonResponse.getJSONObject("content").getJSONObject("media").has("flgDefaultConfig"))
            {
                jsonResponse.getJSONObject("content").getJSONObject("media").getInt("flgDefaultConfig");
            }

            if (jsonResponse.getJSONObject("content").getJSONObject("media").has("tags"))
            {
                jsonResponse.getJSONObject("content").getJSONObject("media").getString("tags");
            }

            if (jsonResponse.getJSONObject("content").getJSONObject("media").has("namSubject"))
            {
                jsonResponse.getJSONObject("content").getJSONObject("media").getString("namSubject");
            }

            if (jsonResponse.getJSONObject("content").getJSONObject("media").has("desMedia"))
            {
                jsonResponse.getJSONObject("content").getJSONObject("media").getString("desMedia");
            }

            if (jsonResponse.getJSONObject("content").getJSONObject("media").has("idtTagService"))
            {
                jsonResponse.getJSONObject("content").getJSONObject("media").getString("idtTagService");
            }

            if (jsonResponse.getJSONObject("content").getJSONObject("media").has("desHostname"))
            {
                jsonResponse.getJSONObject("content").getJSONObject("media").getString("desHostname");
            }

            if (jsonResponse.getJSONObject("content").getJSONObject("media").has("codHashIn"))
            {
                jsonResponse.getJSONObject("content").getJSONObject("media").getString("codHashIn");
            }

            if (jsonResponse.getJSONObject("content").getJSONObject("media").has("idtFile"))
            {
                jsonResponse.getJSONObject("content").getJSONObject("media").getLong("idtFile");
            }

            if (jsonResponse.getJSONObject("content").has("file"))
            {
                jsonResponse.getJSONObject("content").getJSONObject("file");
                jsonResponse.getJSONObject("content").getJSONObject("file").getInt("codStatus");

                if (jsonResponse.getJSONObject("content").getJSONObject("file").has("numServer"))
                {
                    jsonResponse.getJSONObject("content").getJSONObject("file").getInt("numServer");
                }
            }

            if (jsonResponse.getJSONObject("content").has("tags"))
            {
                jsonResponse.getJSONObject("content").getJSONArray("tags");
    
                for (int i = 0; i < jsonResponse.getJSONObject("content").getJSONArray("tags").length(); i++)
                {
                    jsonResponse.getJSONObject("content").getJSONArray("tags").getJSONObject(i).getLong("idtTag");
                    jsonResponse.getJSONObject("content").getJSONArray("tags").getJSONObject(i).getString("desTag");
                }
            }

            if ("V".equals(jsonResponse.getJSONObject("content").getJSONObject("media")
                    .getString("indMediaType")))
            {
                if (jsonResponse.getJSONObject("content").has("formats"))
                {
                    jsonResponse.getJSONObject("content").getJSONArray("formats");
    
                    for (int i = 0; i < jsonResponse.getJSONObject("content").getJSONArray("formats").length(); i++)
                    {
                        jsonResponse.getJSONObject("content").getJSONArray("formats").getInt(i);
                    }
                }

                jsonResponse.getJSONObject("content").getJSONObject("media").getString("desExtraInformation");

                if (jsonResponse.getJSONObject("content").getJSONObject("media").has("countryList"))
                {
                    jsonResponse.getJSONObject("content").getJSONObject("media").getString("countryList");
                }

                jsonResponse.getJSONObject("content").getJSONObject("mediaVideo");
                jsonResponse.getJSONObject("content").getJSONObject("mediaVideo").getLong("idtMedia");
                jsonResponse.getJSONObject("content").getJSONObject("mediaVideo").getInt("numDuration");
                jsonResponse.getJSONObject("content").getJSONObject("mediaVideo").getInt("codVideoType");
                jsonResponse.getJSONObject("content").getJSONObject("mediaVideo").getInt("numThumbnailIdentifier");
                jsonResponse.getJSONObject("content").getJSONObject("mediaVideo").getInt("codExtensionFile");
                jsonResponse.getJSONObject("content").getJSONObject("mediaVideo").getInt("numRevision");
                jsonResponse.getJSONObject("content").getJSONObject("mediaVideo").getInt("numGeneratedThumbs");
                jsonResponse.getJSONObject("content").getJSONObject("mediaVideo").getInt("numViewsMobile");
                jsonResponse.getJSONObject("content").getJSONObject("mediaVideo").getInt("numEncodedPreset");
            }

            if ("P".equals(jsonResponse.getJSONObject("content").getJSONObject("media")
                    .getString("indMediaType")))
            {
                jsonResponse.getJSONObject("content").getJSONObject("mediaPodcast");
                jsonResponse.getJSONObject("content").getJSONObject("mediaPodcast").getLong("idtMedia");
                jsonResponse.getJSONObject("content").getJSONObject("mediaPodcast").getInt("numDuration");
                jsonResponse.getJSONObject("content").getJSONObject("mediaPodcast").getInt("codExtensionFile");
                jsonResponse.getJSONObject("content").getJSONObject("mediaPodcast").getInt("numRevision");
            }

            JsonUtil.validateValueJson(jsonResponse.getJSONObject("content").getJSONObject("media"),
                new String[] { "namSubject", "desMedia" });

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - contentjson is not valid - " + e.getMessage() + " - " + jsonResponse);
            return false;
        }
    }

    private boolean validateThemeJson(JSONObject jsonResponse) throws JSONException
    {
        try
        {
            if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") != HttpStatus.SC_OK)
            {
                return false;
            }
            jsonResponse.getJSONObject("response");
            jsonResponse.getJSONObject("response").getInt("code");
            jsonResponse.getJSONObject("response").getString("description");
            jsonResponse.getJSONObject("response").getString("originalRequest");

            jsonResponse.getJSONObject("themes");
            jsonResponse.getJSONObject("themes").getString("themeNot");
            jsonResponse.getJSONObject("themes").getString("themePre");

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - json is not valid - " + e.getMessage() + " - " + jsonResponse);
            return false;
        }
    }
}
