/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         04/03/2015 Criacao inicial
 */

package uol.taipei.tests.moderation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uol.taipei.request.FacileRequest;
import uol.taipei.request.FacileResponse;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.util.RequestUtil;

public class MediaProxy extends AbstractTest
{
    static final Logger logger = LoggerFactory.getLogger(MediaProxy.class);

    public static void main(String[] args)
    {
        if (!verifyParams(args))
        {
            return;
        }

        setUp(args[0]);

        logger.debug("-------------------------------------------------");
        logger.debug("tests media proxy");

        try
        {
            MediaProxy mediaProxy = new MediaProxy();
            FacileRequest request = new FacileRequest();

            mediaProxy.restrictNobodyViewVideo(request);
            mediaProxy.restrictRemovedStatusVideo(request);
            mediaProxy.restrictSubscriberVideo(request);
            mediaProxy.restrictProductVideo(request);
            mediaProxy.restrictNobodyViewAudio(request);
            mediaProxy.restrictRemovedStatusAudio(request);
            mediaProxy.restrictNobodyViewThumbVideo(request);
            mediaProxy.restrictRemovedStatusThumbVideo(request);
            mediaProxy.restrictDraftThumbVideo(request);
            mediaProxy.restrictSubscriberThumbVideo(request);
            mediaProxy.restrictProductThumbVideo(request);
        }
        catch (Exception e)
        {
            logger.error(e.getMessage());
        }
    }

    public boolean restrictNobodyViewVideo(FacileRequest request) throws Exception
    {
        String mediaId = RequestUtil.mediaIdRestrictFile(10, "V", "N", false, false, false);
        String url = "http://videos.intranet.uol.com.br/mediaProxy/" + mediaId + ".flv";
        FacileResponse response = request.get(url);

        if (response.getCode() == 404)
        {
            url = "http://videos.intranet.uol.com.br/mediaProxy/" + mediaId + ".mp4";
            response = request.get(url);
        }

        if (response.getCode() != 200 && response.getCode() != 304)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean restrictRemovedStatusVideo(FacileRequest request) throws Exception
    {
        String mediaId = RequestUtil.mediaIdRestrictFile(20, "V", "T", false, false, false);
        String url = "http://videos.intranet.uol.com.br/mediaProxy/" + mediaId + ".flv";
        FacileResponse response = request.get(url);
        ;

        if (response.getCode() == 404)
        {
            url = "http://videos.intranet.uol.com.br/mediaProxy/" + mediaId + ".mp4";
            response = request.get(url);
        }

        if (response.getCode() != 200 && response.getCode() != 304)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean restrictDraftVideo(FacileRequest request) throws Exception
    {
        String mediaId = RequestUtil.mediaIdRestrictFile(10, "V", "T", true, false, false);
        String url = "http://videos.intranet.uol.com.br/mediaProxy/" + mediaId + ".flv";
        FacileResponse response = request.get(url);
        ;

        if (response.getCode() == 404)
        {
            url = "http://videos.intranet.uol.com.br/mediaProxy/" + mediaId + ".mp4";
            response = request.get(url);
        }

        if (response.getCode() != 200 && response.getCode() != 304)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean restrictSubscriberVideo(FacileRequest request) throws Exception
    {
        String mediaId = RequestUtil.mediaIdRestrictFile(10, "V", "T", false, true, false);
        String url = "http://videos.intranet.uol.com.br/mediaProxy/" + mediaId + ".flv";
        FacileResponse response = request.get(url);
        ;

        if (response.getCode() == 404)
        {
            url = "http://videos.intranet.uol.com.br/mediaProxy/" + mediaId + ".mp4";
            response = request.get(url);
        }

        if (response.getCode() != 200 && response.getCode() != 304)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean restrictProductVideo(FacileRequest request) throws Exception
    {
        String mediaId = RequestUtil.mediaIdRestrictProduct("V");
        String url = "http://videos.intranet.uol.com.br/mediaProxy/" + mediaId + ".flv";
        FacileResponse response = request.get(url);
        ;

        if (response.getCode() == 404)
        {
            url = "http://videos.intranet.uol.com.br/mediaProxy/" + mediaId + ".mp4";
            response = request.get(url);
        }

        if (response.getCode() != 200 && response.getCode() != 304)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean restrictNobodyViewAudio(FacileRequest request) throws Exception
    {
        String mediaId = RequestUtil.mediaIdRestrictFile(10, "P", "N", false, false, false);
        String url = "http://videos.intranet.uol.com.br/mediaProxy/" + mediaId + ".mp3";
        FacileResponse response = request.get(url);
        ;

        if (response.getCode() != 200 && response.getCode() != 304)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean restrictRemovedStatusAudio(FacileRequest request) throws Exception
    {
        String mediaId = RequestUtil.mediaIdRestrictFile(20, "P", "T", false, false, false);
        String url = "http://videos.intranet.uol.com.br/mediaProxy/" + mediaId + ".mp3";
        FacileResponse response = request.get(url);
        ;

        if (response.getCode() != 200 && response.getCode() != 304)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean restrictNobodyViewThumbVideo(FacileRequest request) throws Exception
    {
        String mediaId = RequestUtil.mediaIdRestrictFile(10, "V", "N", false, false, false);
        FacileResponse response = null;
        String url = "http://videos.intranet.uol.com.br/mediaProxy/";
        String[] thumbs = new String[] { mediaId + ".jpg", mediaId + "-small.jpg", mediaId + "-medium.jpg",
                                         mediaId + "-large.jpg", mediaId + "-wmedium.jpg", mediaId + "-wlarge.jpg",
                                         mediaId + "-xlarge.jpg" };

        for (String uri : thumbs)
        {
            response = request.get(url + uri);

            if (response.getCode() != 200 && response.getCode() != 304)
            {
                logger.error("ERROR - return not valid - " + response.getCode() + " - " + url + uri);
                return false;
            }
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean restrictRemovedStatusThumbVideo(FacileRequest request) throws Exception
    {
        String mediaId = RequestUtil.mediaIdRestrictFile(20, "V", "T", false, false, false);
        FacileResponse response = null;
        String url = "http://videos.intranet.uol.com.br/mediaProxy/";
        String[] thumbs = new String[] { mediaId + ".jpg", mediaId + "-small.jpg", mediaId + "-medium.jpg",
                                         mediaId + "-large.jpg", mediaId + "-wmedium.jpg", mediaId + "-wlarge.jpg",
                                         mediaId + "-xlarge.jpg" };

        for (String uri : thumbs)
        {
            response = request.get(url + uri);

            if (response.getCode() != 200 && response.getCode() != 304)
            {
                logger.error("ERROR - return not valid - " + response.getCode() + " - " + url + uri);
                return false;
            }
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean restrictDraftThumbVideo(FacileRequest request) throws Exception
    {
        String mediaId = RequestUtil.mediaIdRestrictFile(10, "V", "T", true, false, false);
        FacileResponse response = null;
        String url = "http://videos.intranet.uol.com.br/mediaProxy/";
        String[] thumbs = new String[] { mediaId + ".jpg", mediaId + "-small.jpg", mediaId + "-medium.jpg",
                                         mediaId + "-large.jpg", mediaId + "-wmedium.jpg", mediaId + "-wlarge.jpg",
                                         mediaId + "-xlarge.jpg" };

        for (String uri : thumbs)
        {
            response = request.get(url + uri);

            if (response.getCode() != 200 && response.getCode() != 304)
            {
                logger.error("ERROR - return not valid - " + response.getCode() + " - " + url + uri);
                return false;
            }
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean restrictSubscriberThumbVideo(FacileRequest request) throws Exception
    {
        String mediaId = RequestUtil.mediaIdRestrictFile(10, "V", "T", false, true, false);
        FacileResponse response = null;
        String url = "http://videos.intranet.uol.com.br/mediaProxy/";
        String[] thumbs = new String[] { mediaId + ".jpg", mediaId + "-small.jpg", mediaId + "-medium.jpg",
                                         mediaId + "-large.jpg", mediaId + "-wmedium.jpg", mediaId + "-wlarge.jpg",
                                         mediaId + "-xlarge.jpg" };

        for (String uri : thumbs)
        {
            response = request.get(url + uri);

            if (response.getCode() != 200 && response.getCode() != 304)
            {
                logger.error("ERROR - return not valid - " + response.getCode() + " - " + url + uri);
                return false;
            }
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean restrictProductThumbVideo(FacileRequest request) throws Exception
    {
        String mediaId = RequestUtil.mediaIdRestrictProduct("V");
        FacileResponse response = null;
        String url = "http://videos.intranet.uol.com.br/mediaProxy/";
        String[] thumbs = new String[] { mediaId + ".jpg", mediaId + "-small.jpg", mediaId + "-medium.jpg",
                                         mediaId + "-large.jpg", mediaId + "-wmedium.jpg", mediaId + "-wlarge.jpg",
                                         mediaId + "-xlarge.jpg" };

        for (String uri : thumbs)
        {
            response = request.get(url + uri);

            if (response.getCode() != 200 && response.getCode() != 304)
            {
                logger.error("ERROR - return not valid - " + response.getCode() + " - " + url + uri);
                return false;
            }
        }

        logger.debug("SUCCESS");

        return true;
    }

}
