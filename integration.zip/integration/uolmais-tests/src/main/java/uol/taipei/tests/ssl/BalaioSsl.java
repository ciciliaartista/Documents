/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         30/09/2014 Criacao inicial
 */

package uol.taipei.tests.ssl;

import java.util.Arrays;
import java.util.HashMap;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uol.taipei.request.FacileRequest;
import uol.taipei.request.FacileResponse;
import uol.taipei.request.JsonRequest;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.DateParsing;
import uol.taipei.tests.LogErrorTest;
import uol.taipei.tests.util.RequestUtil;

public class BalaioSsl extends AbstractTest
{
    static final Logger logger = LoggerFactory.getLogger(BalaioSsl.class);

    public static void main(String[] args)
    {
        if (!verifyParams(args))
        {
            return;
        }

        setUp(args[0]);

        logger.debug("-------------------------------------------------");
        logger.debug("tests ssl balaio");

        try
        {
            BalaioSsl balaioSsl = new BalaioSsl();

            balaioSsl.probe();

            balaioSsl.downloadVideo();
            balaioSsl.downloadPodcast();
            balaioSsl.downloadPodcastMobile();

            FacileRequest request = new FacileRequest();
            request.configureSSL();

            balaioSsl.restrictNobodyViewVideo(request);
            balaioSsl.restrictRemovedStatusVideo(request);
            balaioSsl.restrictSubscriberVideo(request);
            balaioSsl.restrictProductVideo(request);
            balaioSsl.noUri(request);
            balaioSsl.noExtension(request);
            balaioSsl.invalidFile(request);
            balaioSsl.post(request);
            balaioSsl.head(request);
            balaioSsl.video(request);
            balaioSsl.videoStart(request);
            balaioSsl.videoUAWinChrome(request);
            balaioSsl.videoUAMacSafari(request);
            balaioSsl.videoNoReferer(request);
            balaioSsl.videoWithWildcard(request);
            balaioSsl.videoWithWildcardNoUseragent(request);
        }
        catch (Exception e)
        {
            logger.error(e.getMessage());
            LogErrorTest.error(e);
        }
    }

    public BalaioSsl()
    {
        host = "https://video17.mais.uol.com.br";
    }

    public BalaioSsl(String url)
    {
        host = url;
    }

    public JSONObject probe() throws Exception
    {
        JSONObject jsonResponse = JsonRequest.get(host + "/probe");

        if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") != 200)
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        try
        {
            jsonResponse.getString("upTime");
            jsonResponse.getString("serverVersion");
        }
        catch (Exception e)
        {
            logger.error("ERROR - return not valid - " + e.getMessage() + " - " + jsonResponse);
            LogErrorTest.error(e);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public boolean downloadVideo() throws Exception
    {
        FacileRequest request = new FacileRequest(60000, true);
        request.configureSSL();

        String mediaId = RequestUtil.mediaIdPublic("V");
        JSONObject jsonResponse = JsonRequest.get("https://mais.uol.com.br/apiuol/player/media?action=showPlayer&p=mais&types=V&mediaId="
                + mediaId + "&nocache=" + Math.random());
        String fileName = null;
        String url = null;

        for (int j = 0; j < jsonResponse.getJSONObject("media").getJSONArray("formats").length(); j++)
        {
            url = jsonResponse.getJSONObject("media").getJSONArray("formats").getJSONObject(j).getString("secureUrl");
            fileName = System.getenv("PATH_FILE_TEST") + java.io.File.separator
                    + url.substring(url.lastIndexOf('/') + 1, (url.contains("?") ? url.indexOf('?') : url.length()));

            if (!request.download(url, fileName, true))
            {
                logger.error("ERROR - could not download - " + url + " to " + fileName);
                return false;
            }
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean downloadPodcast() throws Exception
    {
        FacileRequest request = new FacileRequest();
        request.configureSSL();

        String mediaId = RequestUtil.mediaIdPublic("P");
        String fileName = System.getenv("PATH_FILE_TEST") + java.io.File.separator + mediaId + ".mp3";
        String url = "https://storage.mais.uol.com.br/" + mediaId + ".mp3";

        if (!request.download(url, fileName, true))
        {
            logger.error("ERROR - could not download - " + url + " to " + fileName);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean downloadPodcastMobile() throws Exception
    {
        FacileRequest request = new FacileRequest();
        request.configureSSL();

        String mediaId = RequestUtil.mediaIdPublic("P");
        String fileName = System.getenv("PATH_FILE_TEST") + java.io.File.separator + mediaId + ".mp3";
        String url = "https://video.m.mais.uol.com.br/" + mediaId + ".mp3";

        if (!request.download(url, fileName, true))
        {
            logger.error("ERROR - could not download - " + url + " to " + fileName);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean restrictNobodyViewVideo(FacileRequest request) throws Exception
    {
        // vd_autor.mp4
        String mediaId = RequestUtil.mediaIdRestrict(10, "V", "N", false, false, false, false, false);
        String url = host + "/" + mediaId + ".mp4";
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put("Referer", "http://mais.uol.com.br");
        FacileResponse response = request.get(url, headers);

        if (response.getCode() != 401)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        if (request.getConn().getHeaderField("Failure") != null && request.getConn().getHeaderField("Failure").length() > 0)
        {
            logger.error("ERROR - " + Arrays.asList(request.getConn().getHeaderField("Failure")).toString() + " - " + mediaId);
            return false;
        }

        if (request.getConn().getHeaderField("X-Cache-Error") == null || request.getConn().getHeaderField("X-Cache-Error").length() < 1)
        {
            logger.error("ERROR - invalid video restrict not found" + " - " + mediaId);
            return false;
        }

        if (!Arrays.asList(request.getConn().getHeaderField("X-Cache-Error")).toString().contains("vd_autor"))
        {
            logger.error("ERROR - invalid video restrict not found" + " - " + mediaId);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean restrictRemovedStatusVideo(FacileRequest request) throws Exception
    {
        // vd_remov-mais.mp4
        String mediaId = RequestUtil.mediaIdRestrictFile(20, "V", "T", false, false, false);
        String url = host + "/" + mediaId + ".mp4";
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put("Referer", "http://mais.uol.com.br");
        FacileResponse response = request.get(url, headers);

        if (response.getCode() != 401)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        if (request.getConn().getHeaderField("Failure") != null && request.getConn().getHeaderField("Failure").length() > 0)
        {
            logger.error("ERROR - " + Arrays.asList(request.getConn().getHeaderField("Failure")).toString() + " - " + mediaId);
            return false;
        }

        if (request.getConn().getHeaderField("X-Cache-Error") == null || request.getConn().getHeaderField("X-Cache-Error").length() < 1)
        {
            logger.error("ERROR - invalid video restrict not found" + " - " + mediaId);
            return false;
        }

        if (!Arrays.asList(request.getConn().getHeaderField("X-Cache-Error")).toString().contains("vd_remov-mais"))
        {
            logger.error("ERROR - invalid video restrict not found" + " - " + mediaId);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean restrictSubscriberVideo(FacileRequest request) throws Exception
    {
        // vd_exc-ass.mp4
        String mediaId = RequestUtil.mediaIdRestrict(10, "V", "T", false, true, false, false, false);
        String url = host + "/" + mediaId + ".mp4";
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put("Referer", "http://mais.uol.com.br");
        FacileResponse response = request.get(url, headers);

        if (response.getCode() != 401)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        if (request.getConn().getHeaderField("Failure") != null && request.getConn().getHeaderField("Failure").length() > 0)
        {
            logger.error("ERROR - " + Arrays.asList(request.getConn().getHeaderField("Failure")).toString() + " - " + mediaId);
            return false;
        }

        if (request.getConn().getHeaderField("X-Cache-Error") == null || request.getConn().getHeaderField("X-Cache-Error").length() < 1)
        {
            logger.error("ERROR - invalid video restrict not found" + " - " + mediaId);
            return false;
        }

        if (!Arrays.asList(request.getConn().getHeaderField("X-Cache-Error")).toString().contains("vd_exc-ass"))
        {
            logger.error("ERROR - invalid video restrict not found" + " - " + mediaId);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean restrictProductVideo(FacileRequest request) throws Exception
    {
        // vd_product_perm.mp4
        String mediaId = RequestUtil.mediaIdRestrictProduct("V");
        String url = host + "/" + mediaId + ".mp4";
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put("Referer", "http://mais.uol.com.br");
        FacileResponse response = request.get(url, headers);

        if (response.getCode() != 200)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        if (request.getConn().getHeaderField("Failure") != null && request.getConn().getHeaderField("Failure").length() > 0)
        {
            logger.error("ERROR - " + Arrays.asList(request.getConn().getHeaderField("Failure")).toString() + " - " + mediaId);
            return false;
        }

        if (request.getConn().getHeaderField("X-Cache-Error") == null || request.getConn().getHeaderField("X-Cache-Error").length() < 1)
        {
            logger.error("ERROR - invalid video restrict not found" + " - " + mediaId);
            return false;
        }

        // if (!Arrays.asList(request.getConn().getHeaderField("Cache-Error")).toString().contains("vd_product_perm"))
        if (!Arrays.asList(request.getConn().getHeaderField("X-Cache-Error")).toString().contains("vd_exc-ass"))
        {
            logger.error("ERROR - invalid video restrict not found" + " - " + mediaId);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean noUri(FacileRequest request) throws Exception
    {
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put("Referer", "http://mais.uol.com.br");
        FacileResponse response = request.get(host, headers);

        if (response.getCode() != 400)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + host);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean noExtension(FacileRequest request) throws Exception
    {
        String url = host + "/x";
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put("Referer", "http://mais.uol.com.br");
        FacileResponse response = request.get(url, headers);

        if (response.getCode() != 400)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean invalidFile(FacileRequest request) throws Exception
    {
        String url = host + "/file.ext";
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put("Referer", "http://mais.uol.com.br");
        FacileResponse response = request.get(url, headers);

        if (response.getCode() != 400)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean post(FacileRequest request) throws Exception
    {
        String mediaId = RequestUtil.mediaIdPublic("V");
        String url = host + "/" + mediaId + ".mp4";
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put("Referer", "http://mais.uol.com.br");
        FacileResponse response = request.post(url, headers, null);

        if (response.getCode() != 405)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean head(FacileRequest request) throws Exception
    {
        String mediaId = RequestUtil.mediaIdPublic("V");
        String url = host + "/" + mediaId + ".mp4";
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put("Referer", "http://mais.uol.com.br");
        FacileResponse response = request.head(url, headers);

        if (response.getCode() != 200)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean video(FacileRequest request) throws Exception
    {
        String mediaId = RequestUtil.mediaIdPublic("V");
        String url = host + "/" + mediaId + ".mp4";
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put("Referer", "http://mais.uol.com.br");
        FacileResponse response = request.get(url, headers);
    
        if (response.getCode() != 200)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }
    
        if (request.getConn().getHeaderField("Failure") != null && request.getConn().getHeaderField("Failure").length() > 0)
        {
            logger.error("ERROR - " + Arrays.asList(request.getConn().getHeaderField("Failure")).toString() + " - " + mediaId);
            return false;
        }
    
        logger.debug("SUCCESS");
    
        return true;
    }

    public boolean videoStart(FacileRequest request) throws Exception
    {
        String mediaId = RequestUtil.mediaIdPublic("V");
        JSONObject media = JsonRequest.get("http://mais.uol.com.br/apiuol/v3/player/getMedia/" + mediaId);
        DateParsing dateParsing = new DateParsing(DateParsing.timeHourString(media.getJSONObject("item").getString("duration")), "HH:mm:ss");
        int start = Math.round((int) dateParsing.timeInSeconds() / 2);
        String url = host + "/" + mediaId + ".mp4?start=" + start;
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put("Referer", "http://mais.uol.com.br");

        FacileResponse response = request.get(url, headers, 1);

        if (response.getCode() != 200)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        if (request.getConn().getHeaderField("Failure") != null && request.getConn().getHeaderField("Failure").length() > 0)
        {
            logger.error("ERROR - " + Arrays.asList(request.getConn().getHeaderField("Failure")).toString() + " - " + mediaId);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean videoUAWinChrome(FacileRequest request) throws Exception
    {
        String mediaId = RequestUtil.mediaIdPublic("V");
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put("Referer", "http://mais.uol.com.br");
        headers.put("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.106 Safari/537.36");
        String url = host + "/" + mediaId + ".mp4";
        FacileResponse response = request.get(url, headers);

        if (response.getCode() != 200 && response.getCode() != 206)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        if (response.getBody().contains("Failure"))
        {
            logger.error("ERROR - " + response.getBody() + " - " + mediaId);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean videoUAMacSafari(FacileRequest request) throws Exception
    {
        String mediaId = RequestUtil.mediaIdPublic("V");
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put("Referer", "http://mais.uol.com.br");
        headers.put("User-Agent", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_2) AppleWebKit/601.3.9 (KHTML, like Gecko) Version/9.0.2 Safari/601.3.9");

        String url = host + "/" + mediaId + ".mp4";
        FacileResponse response = request.get(url, headers);

        if (response.getCode() != 200 && response.getCode() != 206)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        if (response.getBody().contains("Failure"))
        {
            logger.error("ERROR - " + response.getBody() + " - " + mediaId);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean videoNoReferer(FacileRequest request) throws Exception
    {
        String mediaId = RequestUtil.mediaIdPublic("V");
        String url = host + "/" + mediaId + ".mp4";
        FacileResponse response = request.get(url);
    
        if (response.getCode() != 403)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }
    
        if (!response.getBody().contains("Failure"))
        {
            logger.error("ERROR - " + response.getBody() + " - " + mediaId);
            return false;
        }
    
        logger.debug("SUCCESS");
    
        return true;
    }

    /**
     * request para video do balaio com parametro r
     * 
     * @param request
     * @return boolean
     * @throws Exception
     */
    public boolean videoWithWildcard(FacileRequest request) throws Exception
    {
        String mediaId = RequestUtil.mediaIdPublic("V");
        String url = host + "/" + mediaId + ".mp4?r=http://mais.uol.com.br";
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.93 Safari/537.36");
        FacileResponse response = request.get(url, headers);

        if (response.getCode() != 200)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }
    
        if (response.getBody().contains("Failure"))
        {
            logger.error("ERROR - " + response.getBody() + " - " + mediaId);
            return false;
        }
    
        logger.debug("SUCCESS");
    
        return true;
    }

    public boolean videoWithWildcardNoUseragent(FacileRequest request) throws Exception
    {
        String mediaId = RequestUtil.mediaIdPublic("V");
        String url = host + "/" + mediaId + ".mp4?r=http://mais.uol.com.br";
        FacileResponse response = request.get(url);
    
        if (response.getCode() != 403)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        if (!response.getBody().contains("Failure"))
        {
            logger.error("ERROR - " + response.getBody() + " - " + mediaId);
            return false;
        }
    
        logger.debug("SUCCESS");
    
        return true;
    }
}
