/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         04/08/2014 Criacao inicial
 */

package uol.taipei.tests.ssl;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uol.taipei.request.FacileRequest;
import uol.taipei.request.FacileResponse;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.util.JsonUtil;
import uol.taipei.tests.util.RequestUtil;

public class ThumbSsl extends AbstractTest
{
    static final Logger logger = LoggerFactory.getLogger(ThumbSsl.class);

    public static void main(String[] args)
    {
        if (!verifyParams(args))
        {
            return;
        }

        setUp(args[0]);

        logger.debug("-------------------------------------------------");
        logger.debug("tests ssl thumb");

        try
        {
            ThumbSsl thumbSsl = new ThumbSsl();
            FacileRequest request = new FacileRequest();
            request.configureSSL();

            thumbSsl.noUri(request);
            thumbSsl.noExtension(request);
            thumbSsl.invalidExtension(request);
            thumbSsl.probe(request);
            thumbSsl.crossdomain(request);
            thumbSsl.thumbVideo(request);
        }
        catch (Exception e)
        {
            logger.error(e.getMessage());
        }
    }

    public boolean noUri(FacileRequest request) throws Exception
    {
        FacileResponse response = request.get("https://thumb.mais.uol.com.br");

        if (response.getCode() != 500)
        {
            logger.error("ERROR - return not valid - " + response.getCode());
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean noExtension(FacileRequest request) throws Exception
    {
        FacileResponse response = request.get("https://thumb.mais.uol.com.br/x");

        if (response.getCode() != 500)
        {
            logger.error("ERROR - return not valid - " + response.getCode());
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean invalidExtension(FacileRequest request) throws Exception
    {
        String mediaId = RequestUtil.mediaIdPublic("V");
        FacileResponse response = request.get("https://thumb.mais.uol.com.br/" + mediaId + ".ext");

        if (response.getCode() != 404)
        {
            logger.error("ERROR - return not valid - " + response.getCode());
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean probe(FacileRequest request) throws Exception
    {
        FacileResponse response = request.get("https://thumb.mais.uol.com.br/probe.html");

        if (response.getCode() != 200)
        {
            logger.error("ERROR - return not valid - " + response.getCode());
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean crossdomain(FacileRequest request) throws Exception
    {
        request.setFollowRedirects(true);
        FacileResponse response = request.get("https://thumb.mais.uol.com.br/crossdomain.xml");

        if (response.getCode() != 200 && response.getCode() != 304)
        {
            logger.error("ERROR - return not valid - " + response.getCode());
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean thumbVideo(FacileRequest request) throws Exception
    {
        JSONObject media = JsonUtil.mediaNoRestrict("V");
        request.setFollowRedirects(true);
        FacileResponse response = null;
        String urlssl = null;
        String[] thumbs = new String[] { media.getString("thumbSmall"), media.getString("thumbMedium"), media.getString("thumbLarge"),
                                        media.getString("thumbWmedium"), media.getString("thumbWlarge"),
                                        "http://thumb.mais.uol.com.br/" + media.getLong("mediaId") + "-xlarge.jpg" };

        for (String url : thumbs)
        {
            urlssl = url.replace("http:", "https:");
            response = request.get(urlssl);

            if (response.getCode() != 200)
            {
                logger.error("ERROR - return not valid - " + response.getCode() + " - " + urlssl);
                return false;
            }
        }

        logger.debug("SUCCESS");

        return true;
    }
}
