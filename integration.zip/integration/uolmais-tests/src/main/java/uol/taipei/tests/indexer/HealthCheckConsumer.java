/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         24/01/2017 Criacao inicial
 */

package uol.taipei.tests.indexer;

import java.util.HashMap;

import javax.xml.bind.DatatypeConverter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uol.taipei.request.FacileRequest;
import uol.taipei.request.FacileResponse;
import uol.taipei.tests.AbstractTest;

public class HealthCheckConsumer extends AbstractTest
{
    static final Logger logger = LoggerFactory.getLogger(HealthCheckConsumer.class);

    public static void main(String[] args)
    {
        if (!verifyParams(args))
        {
            return;
        }

        setUp(args[0]);

        logger.debug("-------------------------------------------------");
        logger.debug("tests health check consumer");

        try
        {
            HealthCheckConsumer healthCheckConsumer = new HealthCheckConsumer();
            FacileRequest request = new FacileRequest();

            healthCheckConsumer.check(request);
        }
        catch (Exception e)
        {
            logger.error(e.getMessage());
        }
    }

    public HealthCheckConsumer()
    {
        this.host = envConfig().getUrlQueue();
    }

    public HealthCheckConsumer(String url)
    {
        this.host = url;
    }

    public boolean check(FacileRequest request) throws Exception
    {
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put("Authorization", "Basic " + DatatypeConverter.printBase64Binary("admin:admin".getBytes("UTF-8")));

        FacileResponse response = request.get(host + "/api/jolokia/read/org.apache.activemq:type=Broker,brokerName=localhost", headers);

        if (response == null || response.getCode() != 200)
        {
            logger.error("ERROR - response not valid - " + response);
            return false;
        }

        try
        {
            if (response.getJson().getJSONObject("value").getInt("TotalConsumerCount") < 1)
            {
                logger.error("ERROR - no consumer - " + response.getJson());
                return false;
            }
        }
        catch (Exception e)
        {
            logger.error("ERROR - return not valid - " + e.getMessage() + " - " + response.getJson());
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }
}
