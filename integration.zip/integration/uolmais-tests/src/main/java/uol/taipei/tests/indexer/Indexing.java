/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         11/09/2014 Criacao inicial
 */

package uol.taipei.tests.indexer;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uol.taipei.request.JsonRequest;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.LogErrorTest;
import uol.taipei.tests.util.JsonUtil;
import uol.taipei.tests.util.RequestUtil;
import uol.taipei.webServiceClient.WSReturn;

public class Indexing extends AbstractTest
{
    static final Logger logger = LoggerFactory.getLogger(Indexing.class);

    public static void main(String[] args)
    {
        if (!verifyParams(args))
        {
            return;
        }

        setUp(args[0]);

        logger.debug("-------------------------------------------------");
        logger.debug("tests indexing");

        try
        {
            Indexing indexing = new Indexing();
            WSReturn wsprofile = JsonUtil.profile(envConfig().getUser());
            String mediaId = RequestUtil.mediaIdPublic("V", wsprofile.getObjResponse().getLong("codProfileHash"));

            if (mediaId == null)
            {
                mediaId = RequestUtil.mediaIdPublic("V");
            }

            indexing.getDocument(Long.valueOf(mediaId));
            indexing.removeDocument(Long.valueOf(mediaId));
            indexing.addDocument(Long.valueOf(mediaId));
            indexing.removeMedia(Long.valueOf(mediaId));
            indexing.addMedia(Long.valueOf(mediaId));
        }
        catch (Exception e)
        {
            logger.error(e.getMessage());
            LogErrorTest.error(e);
        }
    }

    public JSONObject getDocument(Long mediaId)
    {
        try
        {
            String url = envConfig().getUrlSolrSlave() + "/solr/collection1/select?q=media_id%3A" + mediaId + "&wt=json&_=" + System.currentTimeMillis();

            JSONObject jsonDoc = JsonRequest.get(url);

            if (jsonDoc == null)
            {
                logger.error("ERROR - invalid jsonDoc null");
                return null;
            }

            if (jsonDoc.getJSONObject("_response").getInt("code") != 200)
            {
                logger.error("ERROR - invalid code response - " + jsonDoc.getJSONObject("_response").getInt("code"));
                return null;
            }

            if (!validateDocJson(jsonDoc))
            {
                logger.error("ERROR - return not valid - " + url);
                return null;
            }

            if (jsonDoc.getJSONObject("response").getInt("numFound") != 1 && jsonDoc.getJSONObject("response").getJSONArray("docs").length() != 1)
            {
                logger.error("ERROR - return not match numDocs - " + jsonDoc);
                return null;
            }

            if (jsonDoc.getJSONObject("response").getJSONArray("docs").getJSONObject(0).getLong("media_id") != mediaId)
            {
                logger.error("ERROR - return not match mediaId - " + jsonDoc);
                return null;
            }

            logger.debug("SUCCESS");

            return jsonDoc;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            LogErrorTest.error(e);
            return null;
        }
    }

    public boolean removeDocument(Long mediaId)
    {
        try
        {
            JSONObject jsonDoc = JsonRequest.get(envConfig().getUrlSolrMaster() + "/solr/collection1/update?stream.body=<delete><query>media_id:"
                    + mediaId + "</query></delete>&commit=true&wt=json&_=" + System.currentTimeMillis());

            if (jsonDoc.getJSONObject("_response").getInt("code") != 200)
            {
                logger.error("ERROR - invalid code response - " + jsonDoc.getJSONObject("_response").getInt("code"));
                return false;
            }

            jsonDoc = JsonRequest.get(envConfig().getUrlSolrSlave() + "/solr/collection1/replication?command=fetchindex&wt=json&_=" + System.currentTimeMillis());

            if (jsonDoc.getJSONObject("_response").getInt("code") != 200)
            {
                logger.error("ERROR - invalid code response - " + jsonDoc.getJSONObject("_response").getInt("code"));
                return false;
            }

            int retry = 0;

            do
            {
                retry++;
                Thread.sleep(3000);

                jsonDoc = JsonRequest.get(envConfig().getUrlSolrSlave() + "/solr/collection1/select?q=media_id%3A" + mediaId + "&wt=json&_=" + System.currentTimeMillis());
            } 
            while ((jsonDoc.getJSONObject("response").getInt("numFound") > 0 || jsonDoc.getJSONObject("response").getJSONArray("docs").length() > 0) && retry <= 4);

            if (jsonDoc.getJSONObject("response").getInt("numFound") > 0 && jsonDoc.getJSONObject("response").getJSONArray("docs").length() > 0)
            {
                logger.error("ERROR - return not match numDocs - " + jsonDoc);
                return false;
            }

            logger.debug("SUCCESS");

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            LogErrorTest.error(e);
            return false;
        }
    }

    public boolean addDocument(Long mediaId)
    {
        try
        {
            JSONObject jsonDoc = JsonRequest.get("http://maxima.mais.sys.intranet/queue/send/messages?type=M&ids=" + mediaId);

            if (jsonDoc.getJSONObject("_response").getInt("code") != 200)
            {
                logger.error("ERROR - invalid code response - " + jsonDoc.getJSONObject("_response").getInt("code"));
                return false;
            }

            // tenta garantir que o indexer ja pegou a midia
            Thread.sleep(30000);

            JsonRequest.get(envConfig().getUrlSolrMaster() + "/solr/update?commit=true&wt=json&_=" + System.currentTimeMillis());
            jsonDoc = JsonRequest.get(envConfig().getUrlSolrSlave() + "/solr/collection1/replication?command=fetchindex&wt=json&_=" + System.currentTimeMillis());

            if (jsonDoc.getJSONObject("_response").getInt("code") != 200)
            {
                logger.error("ERROR - invalid code response - " + jsonDoc.getJSONObject("_response").getInt("code"));
                return false;
            }

            int retry = 0;

            do
            {
                retry++;
                Thread.sleep(30000);

                jsonDoc = JsonRequest.get(envConfig().getUrlSolrSlave() + "/solr/collection1/select?q=media_id%3A" + mediaId + "&wt=json&_=" + System.currentTimeMillis());
            }
            while ((jsonDoc.getJSONObject("response").getInt("numFound") < 1 || jsonDoc.getJSONObject("response").getJSONArray("docs").length() < 1) && retry <= 4);

            if (jsonDoc.getJSONObject("response").getInt("numFound") < 1 && jsonDoc.getJSONObject("response").getJSONArray("docs").length() < 1)
            {
                logger.error("ERROR - return not match numDocs - " + jsonDoc);
                return false;
            }

            logger.debug("SUCCESS");

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            LogErrorTest.error(e);
            return false;
        }
    }

    public boolean removeMedia(Long mediaId)
    {
        try
        {
            JSONObject jsonDoc = JsonRequest.get(envConfig().getUrlSolrSlave() + "/solr/collection1/select?q=media_id%3A" + mediaId + "&wt=json");
            updateContentStatus(mediaId, 20, 2);

            int n = 0;
            long wait = (5 * 60 * 1000);

            while (n < 4 && jsonDoc != null && (jsonDoc.getJSONObject("response").getInt("numFound") > 0 
                    || jsonDoc.getJSONObject("response").getJSONArray("docs").length() > 0))
            {
                Thread.sleep(wait);
                jsonDoc = JsonRequest.get(envConfig().getUrlSolrSlave() + "/solr/collection1/select?q=media_id%3A" + mediaId + "&wt=json");

                n++;
            }

            if (jsonDoc != null && (jsonDoc.getJSONObject("response").getInt("numFound") > 0 
                    || jsonDoc.getJSONObject("response").getJSONArray("docs").length() > 0))
            {
                logger.error("ERROR - did not remove media " + mediaId + " from index - " + jsonDoc);
                return false;
            }

            logger.debug("SUCCESS");

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            LogErrorTest.error(e);
            return false;
        }
    }

    public boolean addMedia(Long mediaId)
    {
        try
        {
            JSONObject jsonDoc = JsonRequest.get(envConfig().getUrlSolrSlave() + "/solr/collection1/select?q=media_id%3A" + mediaId + "&wt=json");
            updateContentStatus(mediaId, 10, 2);

            int n = 0;
            long wait = (5 * 60 * 1000);

            while (n < 4 && (jsonDoc == null || jsonDoc.getJSONObject("response").getInt("numFound") < 1 
                    || jsonDoc.getJSONObject("response").getJSONArray("docs").length() < 1))
            {
                Thread.sleep(wait);
                jsonDoc = JsonRequest.get(envConfig().getUrlSolrSlave() + "/solr/collection1/select?q=media_id%3A" + mediaId + "&wt=json");

                n++;
            }

            if (jsonDoc == null || jsonDoc.getJSONObject("response").getInt("numFound") < 1 
                    || jsonDoc.getJSONObject("response").getJSONArray("docs").length() < 1)
            {
                logger.error("ERROR - did not add media " + mediaId + " to index - " + jsonDoc);
                return false;
            }

            logger.debug("SUCCESS");

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage());
            LogErrorTest.error(e);
            return false;
        }
    }

    private boolean validateDocJson(JSONObject json)
    {
        try
        {
            json.getJSONObject("response");
            json.getJSONObject("response").getInt("start");
            json.getJSONObject("response").getInt("numFound");
            json.getJSONObject("response").getJSONArray("docs");

            for (int i = 0; i < json.getJSONObject("response").getJSONArray("docs").length(); i++)
            {
                json.getJSONObject("response").getJSONArray("docs").getJSONObject(i).getString("media_visibility");
                json.getJSONObject("response").getJSONArray("docs").getJSONObject(i).getBoolean("publisher_allow_anonymous_comment");
                json.getJSONObject("response").getJSONArray("docs").getJSONObject(i).getInt("num_views_recently");
                json.getJSONObject("response").getJSONArray("docs").getJSONObject(i).getString("media_authorized_lists");
                json.getJSONObject("response").getJSONArray("docs").getJSONObject(i).getInt("media_subject");
                json.getJSONObject("response").getJSONArray("docs").getJSONObject(i).getString("type");
                json.getJSONObject("response").getJSONArray("docs").getJSONObject(i).getInt("media_duration");
                json.getJSONObject("response").getJSONArray("docs").getJSONObject(i).getString("id");
                json.getJSONObject("response").getJSONArray("docs").getJSONObject(i).getString("last_update");
                json.getJSONObject("response").getJSONArray("docs").getJSONObject(i).getString("title");
                json.getJSONObject("response").getJSONArray("docs").getJSONObject(i).getString("publisher_name");
                json.getJSONObject("response").getJSONArray("docs").getJSONObject(i).getBoolean("block_embed");
                json.getJSONObject("response").getJSONArray("docs").getJSONObject(i).getString("publisher_cod_profile");
                json.getJSONObject("response").getJSONArray("docs").getJSONObject(i).getString("publisher_status");
                json.getJSONObject("response").getJSONArray("docs").getJSONObject(i).getLong("publisher_cod_profile_hash");
                json.getJSONObject("response").getJSONArray("docs").getJSONObject(i).getString("allow_notes");
                json.getJSONObject("response").getJSONArray("docs").getJSONObject(i).getInt("num_favorited");
                json.getJSONObject("response").getJSONArray("docs").getJSONObject(i).getString("publish_date");
                json.getJSONObject("response").getJSONArray("docs").getJSONObject(i).getInt("num_total_vote");
                json.getJSONObject("response").getJSONArray("docs").getJSONObject(i).getInt("num_revision");
                json.getJSONObject("response").getJSONArray("docs").getJSONObject(i).getString("full_description");
                json.getJSONObject("response").getJSONArray("docs").getJSONObject(i).getLong("media_id");
                json.getJSONObject("response").getJSONArray("docs").getJSONObject(i).getInt("num_views_today");
                json.getJSONObject("response").getJSONArray("docs").getJSONObject(i).getBoolean("publisher_moderate_note");
                json.getJSONObject("response").getJSONArray("docs").getJSONObject(i).getString("media_adult");
                json.getJSONObject("response").getJSONArray("docs").getJSONObject(i).getBoolean("draft");
                json.getJSONObject("response").getJSONArray("docs").getJSONObject(i).getInt("num_comments");
                json.getJSONObject("response").getJSONArray("docs").getJSONObject(i).getInt("media_cod_status");
                json.getJSONObject("response").getJSONArray("docs").getJSONObject(i).getInt("num_views");
                json.getJSONObject("response").getJSONArray("docs").getJSONObject(i).getString("media_id_hash");
                json.getJSONObject("response").getJSONArray("docs").getJSONObject(i).getInt("num_average_vote");
                json.getJSONObject("response").getJSONArray("docs").getJSONObject(i).getBoolean("publisher_editorial");
                json.getJSONObject("response").getJSONArray("docs").getJSONObject(i).getBoolean("subscriber_media");
                json.getJSONObject("response").getJSONArray("docs").getJSONObject(i).getString("tags_xml");
                json.getJSONObject("response").getJSONArray("docs").getJSONObject(i).getInt("cod_editorial_status");

                if (json.getJSONObject("response").getJSONArray("docs").getJSONObject(i).has("description"))
                {
                    json.getJSONObject("response").getJSONArray("docs").getJSONObject(i).getString("description");
                }

                for (int j = 0; j < json.getJSONObject("response").getJSONArray("docs").getJSONObject(i).getJSONArray("media_formats")
                        .length(); j++)
                {
                    json.getJSONObject("response").getJSONArray("docs").getJSONObject(i).getJSONArray("media_formats").getInt(j);
                }

                if (json.getJSONObject("response").getJSONArray("docs").getJSONObject(i).has("publisher_editorial_type"))
                {
                    for (int j = 0; j < json.getJSONObject("response").getJSONArray("docs").getJSONObject(i)
                            .getJSONArray("publisher_editorial_type").length(); j++)
                    {
                        json.getJSONObject("response").getJSONArray("docs").getJSONObject(i).getJSONArray("publisher_editorial_type").getInt(j);
                    }
                }

                for (int j = 0; j < json.getJSONObject("response").getJSONArray("docs").getJSONObject(i).getJSONArray("tags").length(); j++)
                {
                    json.getJSONObject("response").getJSONArray("docs").getJSONObject(i).getJSONArray("tags").getString(j);
                }

                for (int j = 0; j < json.getJSONObject("response").getJSONArray("docs").getJSONObject(i).getJSONArray("tag_ids").length(); j++)
                {
                    json.getJSONObject("response").getJSONArray("docs").getJSONObject(i).getJSONArray("tag_ids").getLong(j);
                }
            }

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - docjson is not valid - " + e.getMessage() + " - " + json);
            LogErrorTest.error(e);
            return false;
        }
    }
}
