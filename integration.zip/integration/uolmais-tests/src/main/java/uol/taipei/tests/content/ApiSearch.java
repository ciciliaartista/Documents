/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         02/06/2014 Criacao inicial
 */

package uol.taipei.tests.content;

import java.io.IOException;
import java.net.URLEncoder;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpStatus;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uol.taipei.request.JsonRequest;
import uol.taipei.request.UsefulRequest;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.LoginCookie;
import uol.taipei.tests.util.JsonUtil;
import uol.taipei.tests.util.TestUtil;
import uol.taipei.util.StringUtil;

public class ApiSearch extends AbstractTest
{
    static final Logger logger = LoggerFactory.getLogger(ApiSearch.class);

    protected static final String STOP_WORDS = "a ainda alem alguns ambas ambos antes ao aonde aos apos aquele aqueles as assim com como contra "
            + "contudo cuja cujas cujo cujos da das de dela dele deles demais depois desde desta deste dispoe dispoem diversa diversas diversos do "
            + "dos durante e ela elas ele eles em entao entre essa essas esse esses esta estas este estes ha isso isto logo mais mas mediante menos "
            + "mesma mesmas mesmo mesmos na nas nao nas nem nesse neste no nos o os ou outra outras outro outros para pelas pelas pelo pelos perante "
            + "pois por porque portanto proprio propios quais qual qualquer quando quanto que quem quer se seja sem sendo seu seus sob sobre sua "
            + "suas tal tambem teu teus toda todas todo todos tua tuas tudo um uma umas uns";

    public static void main(String[] args)
    {
        if (!verifyParams(args))
        {
            return;
        }

        setUp(args[0]);

        if (envConfig().getUser() == null || envConfig().getUser().equals("") || envConfig().getPass() == null
                || envConfig().getPass().equals(""))
        {
            System.err.println("Invalid user " + envConfig().getUser());
            return;
        }

        logger.debug("-------------------------------------------------");
        logger.debug("tests api search");

        try
        {
            ApiSearch apiSearch = new ApiSearch();
            UsefulRequest login = new LoginCookie(envConfig().getUser(), envConfig().getPass());
            JSONObject media = apiSearch.getValidMedia();

            apiSearch.list();
            apiSearch.types();
            apiSearch.codProfile(media);
            apiSearch.safeSearch();
            apiSearch.order();
            apiSearch.edFilter();
            apiSearch.loggedList(login);
            apiSearch.loggedCodProfile(login, media);
            apiSearch.aleatorySearch();
            apiSearch.exactSearch();
            apiSearch.emptyQuery();
        }
        catch (Exception e)
        {
            logger.error(e.getMessage());
        }
    }

    public JSONObject list() throws IOException, JSONException
    {
        int retry = 0;
        String q = titleTermFromParam(null);
        String url = "http://mais.b.uol.com.br/apiuol/index?num=12&start=1&lm=1&order=0&types=A&edFilter=&safeSearch=on&viewHotContent=0&q="
                + URLEncoder.encode(q, "UTF-8");
        JSONObject jsonResponse = JsonRequest.get(url, 1);

        while (jsonResponse.getJSONArray("list").length() < 1 && retry < envConfig().getGlobal().getRetry())
        {
            logger.warn("retry after 1s - " + url);

            TestUtil.delay(1000);
            jsonResponse = JsonRequest.get(url, 1);
            retry++;
        }

        if (jsonResponse.getJSONArray("list").length() < 1)
        {
            logger.warn("WARN - term not searchable - " + q + " " + url);
            return null;
        }

        if (!validatePageJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        if (!JsonUtil.containsTerms(jsonResponse.getJSONArray("list"), q))
        {
            logger.error("ERROR - return not match - " + url + " - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject exactSearch() throws IOException, JSONException
    {
        int retry = 0;
        JSONObject jsonTitle = getTitleNoQuotes();
        String q = "\"" + StringUtil.normalize(jsonTitle.getString("title")) + "\"";
        String url = "http://mais.b.uol.com.br/apiuol/index?num=12&start=1&lm=1&order=0&types=A&edFilter=&safeSearch=on&viewHotContent=0&q="
                + URLEncoder.encode(q, "UTF-8");
        JSONObject jsonResponse = JsonRequest.get(url, 1);

        while (jsonResponse.getJSONArray("list").length() < 1 && retry < envConfig().getGlobal().getRetry())
        {
            logger.warn("retry after 1s - " + url);

            TestUtil.delay(1000);
            jsonResponse = JsonRequest.get(url, 1);
            retry++;
        }

        if (!validatePageJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        if (!JsonUtil.containsTerms(jsonResponse.getJSONArray("list"), jsonTitle.getString("title")))
        {
            logger.error("ERROR - return not match - " + url + " - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject types() throws IOException, JSONException
    {
        int retry = 0;
        String url = null;
        String q = null;
        String[] arrayTypes = new String[] { "A", "V", "P" };
        JSONObject jsonResponse = null;

        for (String type : arrayTypes)
        {
            retry = 0;
            q = titleTermFromParam("types=" + type);
            url = "http://mais.b.uol.com.br/apiuol/index?num=12&start=1&lm=1&order=0&edFilter=&safeSearch=on&viewHotContent=0&q="
                    + URLEncoder.encode(q, "UTF-8") + "&types=";
            jsonResponse = JsonRequest.get(url + type, 1);

            while (jsonResponse.getJSONArray("list").length() < 1 && retry < envConfig().getGlobal().getRetry())
            {
                logger.warn("retry after 1s - " + url);

                TestUtil.delay(1000);
                jsonResponse = JsonRequest.get(url, 1);
                retry++;
            }

            if (!validatePageJson(jsonResponse))
            {
                logger.error("ERROR - return not valid - " + url + type + " - " + jsonResponse);
                return null;
            }

            for (int i = 0; i < jsonResponse.getJSONArray("list").length(); i++)
            {
                if ("A".equals(type))
                {
                    if (!ArrayUtils.contains(arrayTypes,
                        jsonResponse.getJSONArray("list").getJSONObject(i).getString("mediaType")))
                    {
                        logger.error("ERROR - mediaType not match - expected " + type + "/returned "
                                + jsonResponse.getJSONArray("list").getJSONObject(i).getString("mediaType") + " - "
                                + jsonResponse);
                        return null;
                    }
                }
                else
                {
                    if (!jsonResponse.getJSONArray("list").getJSONObject(i).getString("mediaType").equals(type))
                    {
                        logger.error("ERROR - mediaType not match - expected " + type + "/returned "
                                + jsonResponse.getJSONArray("list").getJSONObject(i).getString("mediaType") + " - "
                                + jsonResponse);
                        return null;
                    }
                }
            }

            if (!JsonUtil.containsTerms(jsonResponse.getJSONArray("list"), q))
            {
                logger.error("ERROR - return not match - " + url + type + " - " + jsonResponse);
                return null;
            }
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject codProfile(JSONObject media) throws IOException, JSONException
    {
        int retry = 0;
        String q = getValidTerm(media.getJSONObject("media").getString("title").split(" "), 3);
        String url = "http://mais.b.uol.com.br/apiuol/index?num=12&start=1&lm=1&order=1&types=&edFilter=&safeSearch=on&viewHotContent=0&userNickname="
                + URLEncoder.encode(media.getJSONObject("media").getString("author"), "UTF-8")
                + "&codProfile="
                + media.getJSONObject("media").getString("codProfile")
                + "&q="
                + URLEncoder.encode(StringUtil.normalize(q).toLowerCase(), "UTF-8")
                + "&nocache=" + Math.random();
        JSONObject jsonResponse = JsonRequest.get(url, 1);

        while (jsonResponse.getJSONArray("list").length() < 1 && retry < 2)
        {
            logger.warn("retry after 1s - " + url);

            TestUtil.delay(1000);
            jsonResponse = JsonRequest.get(url, 1);
            retry++;
        }

        if (!validatePageJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + url + " - " + jsonResponse + " - " + media);
            return null;
        }

        for (int i = 0; i < jsonResponse.getJSONArray("list").length(); i++)
        {
            if (!jsonResponse.getJSONArray("list").getJSONObject(i).getString("codProfile")
                    .equals(media.getJSONObject("media").getString("codProfile")))
            {
                logger.error("ERROR - codProfile not match - " + media.getJSONObject("media").getString("codProfile")
                        + " - " + jsonResponse);
                return null;
            }
        }

        if (!JsonUtil.containsTerms(jsonResponse.getJSONArray("list"), q))
        {
            logger.error("ERROR - return not match - " + url + " - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject safeSearch() throws IOException, JSONException
    {
        int retry = 0;
        String url = null;
        String q = null;
        String[] safeSearchFilter = new String[] { "on", "off" };
        JSONObject jsonResponse = null;

        for (String safeFilter : safeSearchFilter)
        {
            retry = 0;
            q = titleTermFromParam("adultFilter=" + (safeFilter.equals("on") ? "safe" : "unsafe"));
            url = "http://mais.b.uol.com.br/apiuol/index?num=12&start=1&lm=1&order=1&types=A&viewHotContent=0&q="
                    + URLEncoder.encode(q, "UTF-8") + "&edFilter=&safeSearch=";
            jsonResponse = JsonRequest.get(url + safeFilter, 1);

            while (jsonResponse.getJSONArray("list").length() < 1 && retry < envConfig().getGlobal().getRetry())
            {
                logger.warn("retry after 1s - " + url);

                TestUtil.delay(1000);
                jsonResponse = JsonRequest.get(url, 1);
                retry++;
            }

            if (!validatePageJson(jsonResponse))
            {
                logger.error("ERROR - return not valid - " + url + safeFilter + " - " + jsonResponse);
                return null;
            }

            for (int i = 0; i < jsonResponse.getJSONArray("list").length(); i++)
            {
                Boolean hot = Boolean.parseBoolean(jsonResponse.getJSONArray("list").getJSONObject(i)
                        .getString("adultContent"));

                if (safeFilter.equals("on") && hot)
                {
                    logger.error("ERROR - safeSearch not valid - " + safeFilter + " - " + jsonResponse);
                    return null;
                }
            }

            if (!JsonUtil.containsTerms(jsonResponse.getJSONArray("list"), q))
            {
                logger.error("ERROR - return not match - " + url + " - " + jsonResponse);
                return null;
            }
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject order() throws IOException, JSONException
    {
        int retry = 0;
        String q = titleTermFromParam(null);
        String url = "http://mais.b.uol.com.br/apiuol/index?num=12&start=1&lm=1&types=A&viewHotContent=0&q="
                + URLEncoder.encode(q, "UTF-8") + "&edFilter=&safeSearch=&order=";
        String[] sortFilter = new String[] { "0", "1" };
        JSONObject jsonResponse = null;

        for (String sort : sortFilter)
        {
            retry = 0;
            jsonResponse = JsonRequest.get(url + sort, 1);

            while (jsonResponse.getJSONArray("list").length() < 1 && retry < envConfig().getGlobal().getRetry())
            {
                logger.warn("retry after 1s - " + url);

                TestUtil.delay(1000);
                jsonResponse = JsonRequest.get(url, 1);
                retry++;
            }

            if (!validatePageJson(jsonResponse))
            {
                logger.error("ERROR - return not valid - " + url + sort + " - " + jsonResponse);
                return null;
            }

            if (!JsonUtil.containsTerms(jsonResponse.getJSONArray("list"), q))
            {
                logger.error("ERROR - return not match - " + url + " - " + jsonResponse);
                return null;
            }
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject edFilter() throws IOException, JSONException
    {
        int retry = 0;
        String q = null;
        String url = null;
        JSONObject jsonResponse = null;
        String[] edFilter = new String[] { "user", "editorial", "all" };

        for (String ef : edFilter)
        {
            retry = 0;
            q = titleTermFromParam("edFilter=" + ef);
            url = "http://mais.b.uol.com.br/apiuol/index?num=12&start=1&lm=1&order=0&types=A&safeSearch=on&viewHotContent=0&q="
                    + URLEncoder.encode(q, "UTF-8") + "&edFilter=";
            jsonResponse = JsonRequest.get(url + ef, 1);

            while (jsonResponse.getJSONArray("list").length() < 1 && retry < envConfig().getGlobal().getRetry())
            {
                logger.warn("retry after 1s - " + url);

                TestUtil.delay(1000);
                jsonResponse = JsonRequest.get(url, 1);
                retry++;
            }

            if (!validatePageJson(jsonResponse))
            {
                logger.error("ERROR - return not valid - " + url + ef + " - " + jsonResponse);
                return null;
            }

            for (int i = 0; i < jsonResponse.getJSONArray("list").length(); i++)
            {
                if ("all".equals(ef))
                {
                    if (!ArrayUtils.contains(
                        edFilter, jsonResponse.getJSONArray("list").getJSONObject(i).getString("edFilter")))
                    {
                        logger.error("ERROR - edFilter not match - edFilter " + ef + " - " + jsonResponse);
                        return null;
                    }
                }
                else
                {
                    if (!jsonResponse.getJSONArray("list").getJSONObject(i).getString("edFilter")
                            .equals(ef))
                    {
                        logger.error("ERROR - edFilter not match - edFilter " + ef + " - " + jsonResponse);
                        return null;
                    }
                }
            }

            if (!JsonUtil.containsTerms(jsonResponse.getJSONArray("list"), q))
            {
                logger.error("ERROR - return not match - " + q + " - " + jsonResponse);
                return null;
            }
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject loggedList(UsefulRequest login) throws Exception
    {
        int retry = 0;
        String q = titleTermFromParam(null);
        String url = "http://mais.b.uol.com.br/apiuol/index?num=12&start=1&lm=1&order=0&types=A&edFilter=&safeSearch=on&viewHotContent=0&q="
                + URLEncoder.encode(q, "UTF-8");
        JSONObject jsonResponse = login.getJson(url);

        while (jsonResponse.getJSONArray("list").length() < 1 && retry < envConfig().getGlobal().getRetry())
        {
            logger.warn("retry after 1s - " + url);

            TestUtil.delay(1000);
            jsonResponse = JsonRequest.get(url, 1);
            retry++;
        }

        if (!validatePageJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        if (!JsonUtil.containsTerms(jsonResponse.getJSONArray("list"), q))
        {
            logger.error("ERROR - return not match - " + url + " - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject loggedCodProfile(UsefulRequest login, JSONObject media) throws Exception
    {
        int retry = 0;
        String q = getValidTerm(media.getJSONObject("media").getString("title").split(" "), 3);
        String url = "http://mais.b.uol.com.br/apiuol/index?num=12&start=1&lm=1&order=1&types=&edFilter=&safeSearch=on&viewHotContent=0&userNickname="
                + URLEncoder.encode(media.getJSONObject("media").getString("author"), "UTF-8")
                + "&codProfile="
                + media.getJSONObject("media").getString("codProfile") + "&q=" 
                + URLEncoder.encode(StringUtil.normalize(q).toLowerCase(), "UTF-8");
        JSONObject jsonResponse = login.getJson(url);

        while (jsonResponse.getJSONArray("list").length() < 1 && retry < envConfig().getGlobal().getRetry())
        {
            logger.warn("retry after 1s - " + url);

            TestUtil.delay(1000);
            jsonResponse = JsonRequest.get(url, 1);
            retry++;
        }

        if (!validatePageJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + url + " - " + jsonResponse + " - " + media);
            return null;
        }

        for (int i = 0; i < jsonResponse.getJSONArray("list").length(); i++)
        {
            if (!jsonResponse.getJSONArray("list").getJSONObject(i).getString("codProfile")
                    .equals(media.getJSONObject("media").getString("codProfile")))
            {
                logger.error("ERROR - codProfile not match - " + media.getJSONObject("media").getString("codProfile")
                        + " - " + jsonResponse);
                return null;
            }
        }

        if (!JsonUtil.containsTerms(jsonResponse.getJSONArray("list"), q))
        {
            logger.error("ERROR - return not match - " + url + " - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject aleatorySearch() throws Exception
    {
        int retry = 0;
        JSONObject media = getValidMedia();
        String q = getValidTerm(media.getJSONObject("media").getString("title").split(" "), 3);
        String url = "http://mais.b.uol.com.br/apiuol/index?num=12&start=1&lm=1&order=0&types=A&edFilter=&safeSearch=on&viewHotContent=0&q="
                + URLEncoder.encode(StringUtil.normalize(q).toLowerCase(), "UTF-8");
        JSONObject jsonResponse = JsonRequest.get(url, 1);

        while (jsonResponse.getJSONArray("list").length() < 1 && retry < envConfig().getGlobal().getRetry())
        {
            logger.warn("retry after 1s - " + url);

            TestUtil.delay(1000);
            jsonResponse = JsonRequest.get(url, 1);
            retry++;
        }

        if (!validatePageJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        if (!JsonUtil.containsTerms(jsonResponse.getJSONArray("list"), q))
        {
            logger.error("ERROR - return not match - " + url + " - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public String getValidTerm(String[] terms, int threshold)
    {
        String validTerm = null;

        for (String term : terms)
        {
            validTerm = term.trim();

            if (StringUtils.isNotBlank(validTerm) && validTerm.length() > threshold
                    && !STOP_WORDS.contains(StringUtil.normalize(term.trim()).toLowerCase()))
            {
                return validTerm;
            }
        }

        return "";
    }

    public JSONObject getValidMedia() throws Exception
    {
        int limit = 10;
        int start = 0;
        JSONObject jsonobject = JsonUtil.mediaPublicPaging(null, start, limit);
        JSONObject media = null;
        String term = null;

        while (jsonobject != null && jsonobject.getJSONArray("data").length() > 0)
        {
            for (int i = 0; i < jsonobject.getJSONArray("data").length(); i++)
            {
                Integer index = JsonUtil.indexOf(jsonobject, "idt_media");
                media = JsonRequest.get("http://mais.uol.com.br/apiuol/v2/media/detail?mediaId="
                        + jsonobject.getJSONArray("data").getJSONArray(i).getString(index));

                if (media.has("media"))
                {
                    term = getValidTerm(media.getJSONObject("media").getString("title").split(" "), 3);

                    if (isSearchable(term))
                    {
                        return media;
                    }
                }
            }

            start += limit;
            jsonobject = JsonUtil.mediaPublicPaging(null, start, limit);
        }

        return null;
    }

    private boolean isSearchable(String term)
    {
        if (StringUtils.isNotBlank(term) && !term.matches(".*[.,;:'\"&]+.*") && term.matches("[a-zA-Z0-9]+"))
        {
            return true;
        }

        return false;
    }

    private boolean validatePageJson(JSONObject jsonResponse) throws JSONException
    {
        try
        {
            if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") != HttpStatus.SC_OK)
            {
                return false;
            }
            jsonResponse.getJSONObject("response");
            jsonResponse.getJSONObject("response").getInt("code");
            jsonResponse.getJSONObject("response").getString("description");
            jsonResponse.getJSONObject("response").getString("originalRequest");

            jsonResponse.getJSONObject("paging");
            jsonResponse.getJSONObject("paging").getInt("currentPage");
            Boolean.parseBoolean(jsonResponse.getJSONObject("paging").getString("nextPage"));
            jsonResponse.getJSONObject("paging").getInt("pageSize");
            Boolean.parseBoolean(jsonResponse.getJSONObject("paging").getString("previousPage"));
            jsonResponse.getJSONObject("paging").getString("sort");
            jsonResponse.getJSONObject("paging").getInt("totalItems");
            jsonResponse.getJSONObject("paging").getInt("totalPages");

            jsonResponse.getJSONArray("list");

            int length = jsonResponse.getJSONArray("list").length();

            for (int i = 0; i < length; i++)
            {
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("title");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("id");
                jsonResponse.getJSONArray("list").getJSONObject(i).getLong("mediaId");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("url");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("mediaType");
                Boolean.parseBoolean(jsonResponse.getJSONArray("list").getJSONObject(i).getString("moderateNote"));
                Boolean.parseBoolean(jsonResponse.getJSONArray("list").getJSONObject(i)
                        .getString("allowAnonymousComment"));
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("allowNotes");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("edFilter");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("thumbnail");

                if (!jsonResponse.getJSONArray("list").getJSONObject(i).getString("mediaType").equals("B")
                        && !jsonResponse.getJSONArray("list").getJSONObject(i).getString("mediaType")
                                .equals("S")
                        && !jsonResponse.getJSONArray("list").getJSONObject(i).getString("mediaType")
                                .equals("L"))
                {
                    jsonResponse.getJSONArray("list").getJSONObject(i).getString("thumbSmall");
                    jsonResponse.getJSONArray("list").getJSONObject(i).getString("thumbMedium");
                    jsonResponse.getJSONArray("list").getJSONObject(i).getString("thumbLarge");
                }

                jsonResponse.getJSONArray("list").getJSONObject(i).getLong("idtSubject");

                if (jsonResponse.getJSONArray("list").getJSONObject(i).getString("mediaType").equals("V"))
                {
                    jsonResponse.getJSONArray("list").getJSONObject(i).getString("player");
                    jsonResponse.getJSONArray("list").getJSONObject(i).getString("duration");

                    if (jsonResponse.getJSONArray("list").getJSONObject(i).has("idtProductList"))
                    {
                        jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("idtProductList");

                        for (int j = 0; j < jsonResponse.getJSONArray("list").getJSONObject(i)
                                .getJSONArray("idtProductList").length(); j++)
                        {
                            jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("idtProductList").getInt(j);
                        }
                    }
                }

                if (jsonResponse.getJSONArray("list").getJSONObject(i).getString("mediaType")
                        .equals("P"))
                {
                    jsonResponse.getJSONArray("list").getJSONObject(i).getString("player");
                    jsonResponse.getJSONArray("list").getJSONObject(i).getString("duration");
                }

                if (!jsonResponse.getJSONArray("list").getJSONObject(i).getString("mediaType").equals("P")
                        && !jsonResponse.getJSONArray("list").getJSONObject(i).getString("mediaType")
                                .equals("P")
                        && !jsonResponse.getJSONArray("list").getJSONObject(i).getString("mediaType")
                                .equals("S")
                        && !jsonResponse.getJSONArray("list").getJSONObject(i).getString("mediaType")
                                .equals("L")
                        && !jsonResponse.getJSONArray("list").getJSONObject(i).getString("mediaType")
                                .equals("B"))
                {
                    jsonResponse.getJSONArray("list").getJSONObject(i).getInt("thumbVersion");
                }

                jsonResponse.getJSONArray("list").getJSONObject(i).getString("description");
                Boolean.parseBoolean(jsonResponse.getJSONArray("list").getJSONObject(i).getString("adultContent"));
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("author");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("authorPage");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("codProfile");
                jsonResponse.getJSONArray("list").getJSONObject(i).getInt("views");
                jsonResponse.getJSONArray("list").getJSONObject(i).getInt("comments");
                jsonResponse.getJSONArray("list").getJSONObject(i).getInt("favorites");
                jsonResponse.getJSONArray("list").getJSONObject(i).getDouble("rating");
                jsonResponse.getJSONArray("list").getJSONObject(i).getInt("votes");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("publishedAt");
                Boolean.parseBoolean(jsonResponse.getJSONArray("list").getJSONObject(i).getString("blockEmbed"));
                Boolean.parseBoolean(jsonResponse.getJSONArray("list").getJSONObject(i).getString("subscriberMedia"));

                int tagLength = jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("tags").length();

                for (int j = 0; j < tagLength; j++)
                {
                    jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("tags").getJSONObject(j)
                            .getLong("id");
                    jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("tags").getJSONObject(j)
                            .getString("description");
                }

                // jsonResponse.getJSONArray("list").getJSONObject(i).getString("idtTagService");

                JsonUtil.validateValueJson(jsonResponse.getJSONArray("list").getJSONObject(i),
                    new String[] { "title", "description", "fulldescription" });
            }

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - pagejson is not valid - " + e.getMessage() + " - " + jsonResponse, e);
            return false;
        }
    }

    public JSONObject getTitleNoQuotes() throws JSONException
    {
        int page = 1;
        String url = "http://mais.uol.com.br/apiuol/v2/media/list?index.currentPage=";
        JSONObject mediaList = JsonRequest.get(url + page + "&nocache=" + Math.random());

        while (mediaList.getJSONArray("list").length() > 0)
        {
            for (int i = 0; i < mediaList.getJSONArray("list").length(); i++)
            {
                if (isSearchable(mediaList.getJSONArray("list").getJSONObject(i).getString("title")))
                {
                    return mediaList.getJSONArray("list").getJSONObject(i);
                }
            }

            page++;
            mediaList = JsonRequest.get(url + page + "&nocache=" + Math.random());
        }

        return null;
    }

    private String titleTermFromParam(String param) throws JSONException
    {
        int page = 1;
        String q = null;
        String url = "http://mais.uol.com.br/apiuol/v2/media/list?" + (param != null ? param + "&" : "")
                + "index.currentPage=";
        JSONObject mediaList = JsonRequest.get(url + page + "&nocache=" + Math.random());

        while (mediaList.getJSONArray("list").length() > 0)
        {
            for (int i = 0; i < mediaList.getJSONArray("list").length(); i++)
            {
                q = getValidTerm(mediaList.getJSONArray("list").getJSONObject(i).getString("title").split(" "), 3);

                if (isSearchable(q))
                {
                    return q;
                }
            }

            page++;
            mediaList = JsonRequest.get(url + page + "&nocache=" + Math.random());
        }

        return null;
    }

    private String termFromSolrByType(String type) throws JSONException
    {
        String q = null;
        JSONObject json = JsonRequest.get(envConfig().getUrlSolrSlave() + "/solr/collection1/select?q=type%3A" + type
                + "&wt=json&_=" + System.currentTimeMillis());

        for (int i = 0; i < json.getJSONObject("response").getJSONArray("docs").length(); i++)
        {
            // para foto nao e obrigatorio titulo
            if (json.getJSONObject("response").getJSONArray("docs").getJSONObject(i).has("title"))
            {
                q = getValidTerm(json.getJSONObject("response").getJSONArray("docs").getJSONObject(i)
                        .getString("title").split(" "), 3);

                if (isSearchable(q))
                {
                    return q;
                }
            }

            // para playlist nao e obrigatorio descricao
            if (json.getJSONObject("response").getJSONArray("docs").getJSONObject(i).has("description"))
            {
                q = getValidTerm(
                    json.getJSONObject("response").getJSONArray("docs").getJSONObject(i).getString("description")
                            .split(" "), 3);

                if (isSearchable(q))
                {
                    return q;
                }
            }
        }

        return null;
    }

    public JSONObject emptyQuery() throws IOException, JSONException
    {
        String url = "http://mais.b.uol.com.br/apiuol/index?q=";
        JSONObject jsonResponse = JsonRequest.get(url);
        if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") != HttpStatus.SC_BAD_REQUEST)
        {
            logger.error("ERROR - return not valid - " + url + " - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }
}
