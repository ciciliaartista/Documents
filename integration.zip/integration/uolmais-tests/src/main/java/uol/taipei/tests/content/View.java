/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         29/05/2014 Criacao inicial
 */

package uol.taipei.tests.content;

import java.io.IOException;
import java.util.HashMap;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.http.HttpStatus;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uol.taipei.request.FacileRequest;
import uol.taipei.request.FacileResponse;
import uol.taipei.request.JsonRequest;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.LogErrorTest;
import uol.taipei.tests.util.JsonUtil;
import uol.taipei.tests.util.RequestUtil;

public class View extends AbstractTest
{
    static final Logger logger = LoggerFactory.getLogger(View.class);

    public static void main(String[] args)
    {
        if (!verifyParams(args))
        {
            return;
        }

        setUp(args[0]);

        if (envConfig().getUser() == null || envConfig().getUser().equals("") || envConfig().getPass() == null || envConfig().getPass().equals(""))
        {
            System.err.println("Invalid user " + envConfig().getUser());
            return;
        }

        logger.debug("-------------------------------------------------");
        logger.debug("tests view");

        try
        {
            View view = new View();

            view.viewErr();
            view.viewSubscriber();
            view.types();

            JSONObject media = JsonUtil.mediaDecored(10, "V", "T", false, false, false, false, false);

            view.viewShort(media);
            view.viewLong(media.getString("codProfile"), media.getString("id"));

            media = JsonUtil.mediaDecored(10, "P", "T", false, false, false, false, false);

            view.viewShort(media);
            view.viewLong(media.getString("codProfile"), media.getString("id"));

            media = JsonUtil.media(10, "V", "T", false, false, true, false, false);

            view.viewHot(media.getString("idt_media"));
        }
        catch (Exception e)
        {
            logger.error(e.getMessage());
            LogErrorTest.error(e);
        }
    }

    public boolean viewErr() throws IOException, JSONException
    {
        JSONObject jsonResponse = JsonRequest.get("http://mais.uol.com.br/view/yyy/xxx.json");

        if (!validateMessageJson(jsonResponse, 'W'))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean viewShort(JSONObject media) throws Exception
    {
        FacileRequest request = new FacileRequest();
        request.setFollowRedirects(false);
        String url = "http://mais.uol.com.br/view/" + media.getString("idt_media");
        FacileResponse response = request.get(url);

        if (response.getCode() != 302)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        if (!request.getConn().getHeaderField("Location").matches("(http:\\/\\/)?mais\\.uol\\.com\\.br\\/view\\/[a-z0-9]*\\/(.*)" + media.getString("id") + "(.*)"))
        {
            logger.error("ERROR - return not valid - " + request.getConn().getHeaderField("Location"));
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public JSONObject viewLong(String codProfile, String hashId) throws IOException, JSONException
    {
        String url = "http://mais.uol.com.br/view/" + codProfile + "/" + hashId + ".json?types=A&";
        JSONObject jsonResponse = JsonRequest.get(url);

        if (!validateJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse + " - " + url);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public boolean viewHot(String mediaId) throws Exception
    {
        FacileRequest request = new FacileRequest();
        request.setFollowRedirects(false);
        String url = "http://mais.uol.com.br/view/" + mediaId;
        FacileResponse response = request.get(url);

        if (response.getCode() != 302)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        if (!request.getConn().getHeaderField("Location").matches("(http:\\/\\/)?mais\\.uol\\.com\\.br\\/view\\/[a-z0-9]*\\/[A-Za-z0-9\\-]+(.*)"))
        {
            logger.error("ERROR - return not valid - " + request.getConn().getHeaderField("Location"));
            return false;
        }

        response = request.get(request.getConn().getHeaderField("Location"));

        if (response.getCode() != 302)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + request.getConn().getHeaderField("Location"));
            return false;
        }

        if (!request.getConn().getHeaderField("Location").matches("(http:\\/\\/)?mais\\.uol\\.com\\.br\\/sys/hotDisclaimer/show\\?(.*)"))
        {
            logger.error("ERROR - return not valid - " + request.getConn().getHeaderField("Location"));
            return false;
        }
        
        /*
           invalida a sessao para evitar:
           HTTP/1.1 302 Found
           Date: Thu, 01 Sep 2016 10:46:17 GMT
           Server: (null)
           Expires: Thu, 01 Jan 1970 00:00:00 GMT
           Location: https://acesso.uol.com.br/login.html;jsessionid=4vb2dfxn3mccr9une7e5cgyf?skin=uolmais&dest=REDIR|http://mais.uol.com.br/sys/hotDisclaimer/show?params=Vhttp%3A%2F%2Fmais.uol.com.br%2Fview%2F78oudicj60ka%2Fmachado-relata-repasses-a-henrique-alves-veja-trecho-da-delacao-040218316CD8890366%3Ftypes%253DA%2526
           Set-Cookie: JSESSIONID=4vb2dfxn3mccr9une7e5cgyf;Path=/
           Transfer-Encoding: chunked
         */
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put("Cookie", "jsessionid=;");
        headers.put("Set-Cookie", "jsessionid=;");
        
        response = request.get(request.getConn().getHeaderField("Location"), headers);
        //response = request.get(request.getConn().getHeaderField("Location"));
        
        if (response.getCode() != 302)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + request.getConn().getHeaderField("Location"));
            return false;
        }

        if (!request.getConn().getHeaderField("Location").matches("https://acesso\\.uol\\.com\\.br/login\\.html\\?skin=uolmais&dest=REDIR\\|http://mais\\.uol\\.com\\.br/sys/hotDisclaimer/show\\?(.*)"))
        {
            logger.error("ERROR - return not valid - " + request.getConn().getHeaderField("Location"));
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean viewSubscriber() throws Exception
    {
        FacileRequest request = new FacileRequest();
        request.setFollowRedirects(false);
        String mediaId = RequestUtil.mediaIdRestrict(10, "V", "T", false, true, false, false, false);
        String url = "http://mais.uol.com.br/view/" + mediaId;
        FacileResponse response = request.get(url); 

        if (response.getCode() != 302)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + url);
            return false;
        }

        if (!request.getConn().getHeaderField("Location").matches("(http:\\/\\/)?mais\\.uol\\.com\\.br\\/view\\/[a-z0-9]*\\/[A-Za-z0-9\\-]+(.*)"))
        {
            logger.error("ERROR - return not valid - " + request.getConn().getHeaderField("Location"));
            return false;
        }

        response = request.get(request.getConn().getHeaderField("Location"));

        if (response.getCode() != 302)
        {
            logger.error("ERROR - return not valid - " + response.getCode() + " - " + request.getConn().getHeaderField("Location"));
            return false;
        }

        if (!request.getConn().getHeaderField("Location").matches("https://acesso\\.uol\\.com\\.br/login\\.html\\?dest=CONTENT&COD_PRODUTO=1&url=http://mais\\.uol\\.com\\.br/view/[a-z0-9]*/[A-Za-z0-9\\-]+(.*)"))
        {
            logger.error("ERROR - return not valid - " + request.getConn().getHeaderField("Location"));
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public JSONObject types() throws IOException, JSONException
    {
        String[] arrayTypes = new String[] { "V", "P" };
        JSONObject jsonResponse = null;

        for (String type : arrayTypes)
        {
            jsonResponse = JsonUtil.mediaNoRestrict(type);
            JSONObject jsonViewResponse = JsonRequest.get("http://mais.uol.com.br/view/"
                    + jsonResponse.getString("codProfile") + "/"
                    + jsonResponse.getString("id") + ".json?types=" + type);

            if (!validateJson(jsonViewResponse))
            {
                logger.error("ERROR - return not valid - " + jsonResponse.getJSONArray("list").getJSONObject(0).getString("url")
                        + " - " + jsonViewResponse);
                return null;
            }

            if (!ArrayUtils.contains(arrayTypes, jsonViewResponse.getJSONObject("content").getJSONObject("media").getString("indMediaType")))
            {
                logger.error("ERROR - mediaType not match - mediaType " + type + " - " + jsonViewResponse);
                return null;
            }

            if (!jsonViewResponse.getJSONObject("content").getJSONObject("media").getString("indMediaType").equals(type))
            {
                logger.error("ERROR - mediaType not match - mediaType " + type + " - " + jsonViewResponse);
                return null;
            }
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    private boolean validateJson(JSONObject jsonResponse) throws JSONException
    {
        try
        {
            if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") != HttpStatus.SC_OK)
            {
                return false;
            }
            jsonResponse.getJSONObject("content");

            validateContentJson(jsonResponse.getJSONObject("content"));

            jsonResponse.getBoolean("commentFriend");

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - viewjson is not valid - " + e.getMessage() + " - " + jsonResponse);
            LogErrorTest.error(e);
            return false;
        }
    }

    private boolean validateContentJson(JSONObject jsonResponse) throws JSONException
    {
        try
        {
            jsonResponse.getJSONObject("media");
            jsonResponse.getJSONObject("media").getLong("idtMedia");
            jsonResponse.getJSONObject("media").getString("indMediaType");
            jsonResponse.getJSONObject("media").getLong("codStatus");
            jsonResponse.getJSONObject("media").getLong("datPublished");
            jsonResponse.getJSONObject("media").getString("indVisibility");
            jsonResponse.getJSONObject("media").getString("indAllowNotes");
            jsonResponse.getJSONObject("media").getString("indHot");
            jsonResponse.getJSONObject("media").getInt("flgNotifyComment");
            jsonResponse.getJSONObject("media").getLong("codProfileHash");
            jsonResponse.getJSONObject("media").getLong("idtFile");
            jsonResponse.getJSONObject("media").getInt("numTemporaryServer");
            jsonResponse.getJSONObject("media").getInt("numRetry");
            jsonResponse.getJSONObject("media").getInt("numAverageVote");
            jsonResponse.getJSONObject("media").getInt("numSumVote");
            jsonResponse.getJSONObject("media").getInt("numTotalVote");
            jsonResponse.getJSONObject("media").getInt("numViews");
            jsonResponse.getJSONObject("media").getInt("numComments");
            jsonResponse.getJSONObject("media").getInt("numFavorited");
            // jsonResponse.getJSONObject("media").getLong("datFirstViewPertime");
            jsonResponse.getJSONObject("media").getInt("numSummarizeViewsPertime");
            // jsonResponse.getJSONObject("media").getLong("datFirstViewPerday");
            jsonResponse.getJSONObject("media").getInt("numSummarizeViewsPerday");
            jsonResponse.getJSONObject("media").getInt("numHonors");
            jsonResponse.getJSONObject("media").getInt("codEditorialStatus");
            jsonResponse.getJSONObject("media").getLong("datScheduling");
            jsonResponse.getJSONObject("media").getInt("flgDraft");
            jsonResponse.getJSONObject("media").getInt("flgSendNotification");
            jsonResponse.getJSONObject("media").getInt("flgFeatured");
            jsonResponse.getJSONObject("media").getInt("flgBlockEmbed");
            jsonResponse.getJSONObject("media").getString("indAuthorizedLists");
            jsonResponse.getJSONObject("media").getLong("datLastUpdate");
            jsonResponse.getJSONObject("media").getString("url");
            jsonResponse.getJSONObject("media").getString("fileUrl");
            jsonResponse.getJSONObject("media").getString("indMediaProtection");
            jsonResponse.getJSONObject("media").getInt("flgSubscriberMedia");
            jsonResponse.getJSONObject("media").getBoolean("flgBypass");
            jsonResponse.getJSONObject("media").getInt("idtSubject");

            if (jsonResponse.getJSONObject("media").has("flgDefaultConfig"))
            {
                jsonResponse.getJSONObject("media").getInt("flgDefaultConfig");
            }

            if (jsonResponse.getJSONObject("media").has("tags"))
            {
                jsonResponse.getJSONObject("media").getString("tags");
            }

            if (jsonResponse.getJSONObject("media").has("namSubject"))
            {
                jsonResponse.getJSONObject("media").getString("namSubject");
            }

            if (jsonResponse.getJSONObject("media").has("desMedia"))
            {
                jsonResponse.getJSONObject("media").getString("desMedia");
            }

            if (jsonResponse.getJSONObject("media").has("idtTagService"))
            {
                jsonResponse.getJSONObject("media").getString("idtTagService");
            }

            if (jsonResponse.getJSONObject("media").has("desHostname"))
            {
                jsonResponse.getJSONObject("media").getString("desHostname");
            }

            if (jsonResponse.getJSONObject("media").has("codHashIn"))
            {
                jsonResponse.getJSONObject("media").getString("codHashIn");
            }

            jsonResponse.getJSONObject("file");
            jsonResponse.getJSONObject("file").getInt("numServer");
            jsonResponse.getJSONObject("file").getInt("codStatus");

            if (jsonResponse.has("tags"))
            {
                jsonResponse.getJSONArray("tags");
    
                for (int i = 0; i < jsonResponse.getJSONArray("tags").length(); i++)
                {
                    jsonResponse.getJSONArray("tags").getJSONObject(i).getLong("idtTag");
                    jsonResponse.getJSONArray("tags").getJSONObject(i).getString("desTag");
                }
            }

            if (jsonResponse.has("profileGroups"))
            {
                jsonResponse.getJSONArray("profileGroups");
    
                for (int i = 0; i < jsonResponse.getJSONArray("profileGroups").length(); i++)
                {
                    jsonResponse.getJSONArray("profileGroups").getJSONObject(i);
                }
            }

            if (jsonResponse.has("formats"))
            {
                jsonResponse.getJSONArray("formats");
    
                for (int i = 0; i < jsonResponse.getJSONArray("formats").length(); i++)
                {
                    jsonResponse.getJSONArray("formats").getInt(i);
                }
            }

            if (jsonResponse.has("productList"))
            {
                jsonResponse.getJSONArray("productList");
    
                for (int i = 0; i < jsonResponse.getJSONArray("productList").length(); i++)
                {
                    jsonResponse.getJSONArray("productList").getInt(i);
                }
            }

            jsonResponse.getJSONObject("owner");

            jsonResponse.getJSONObject("owner").getJSONObject("profile");
            jsonResponse.getJSONObject("owner").getJSONObject("profile").getLong("codProfileHash");
            jsonResponse.getJSONObject("owner").getJSONObject("profile").getLong("idtPerson");
            jsonResponse.getJSONObject("owner").getJSONObject("profile").getString("indUserProfile");
            jsonResponse.getJSONObject("owner").getJSONObject("profile").getString("namNick");
            jsonResponse.getJSONObject("owner").getJSONObject("profile").getString("desUrlProfile");
            //jsonResponse.getJSONObject("owner").getJSONObject("profile").getLong("datCreation");
            jsonResponse.getJSONObject("owner").getJSONObject("profile").getString("indStatus");
            //jsonResponse.getJSONObject("owner").getJSONObject("profile").getInt("flgHotContent");
            //jsonResponse.getJSONObject("owner").getJSONObject("profile").getInt("numAvatarVersion");
            jsonResponse.getJSONObject("owner").getJSONObject("profile").getString("namNickUnique");
            jsonResponse.getJSONObject("owner").getJSONObject("profile").getString("namLogin");

            jsonResponse.getJSONObject("owner").getJSONObject("mediaConfig");
            jsonResponse.getJSONObject("owner").getJSONObject("mediaConfig").getLong("codProfileHash");
            jsonResponse.getJSONObject("owner").getJSONObject("mediaConfig").getString("desSubject");
            jsonResponse.getJSONObject("owner").getJSONObject("mediaConfig").getString("indVisibility");
            jsonResponse.getJSONObject("owner").getJSONObject("mediaConfig").getString("indAllowNotes");
            jsonResponse.getJSONObject("owner").getJSONObject("mediaConfig").getInt("codTheme");
            jsonResponse.getJSONObject("owner").getJSONObject("mediaConfig").getString("indHot");
            jsonResponse.getJSONObject("owner").getJSONObject("mediaConfig").getInt("flgAllowVideoComment");
            jsonResponse.getJSONObject("owner").getJSONObject("mediaConfig").getInt("flgAllowAnonymousComment");
            jsonResponse.getJSONObject("owner").getJSONObject("mediaConfig").getInt("flgModerateNote");
            jsonResponse.getJSONObject("owner").getJSONObject("mediaConfig").getInt("flgNotifyComment");
            jsonResponse.getJSONObject("owner").getJSONObject("mediaConfig").getString("desHomepage");
            jsonResponse.getJSONObject("owner").getJSONObject("mediaConfig").getInt("flgBulletinRequester");
            jsonResponse.getJSONObject("owner").getJSONObject("mediaConfig").getInt("numServer");
            jsonResponse.getJSONObject("owner").getJSONObject("mediaConfig").getInt("numMedias");
            // jsonResponse.getJSONObject("owner").getJSONObject("mediaConfig").getString("codPartnerDfp");

            if (jsonResponse.getJSONObject("owner").has("flgDefaultConfig"))
            {
                jsonResponse.getJSONObject("owner").getInt("flgDefaultConfig");
            }

            if ("V".equals(jsonResponse.getJSONObject("media").getString("indMediaType")))
            {
                if (jsonResponse.getJSONObject("media").has("desExtraInformation"))
                {
                    jsonResponse.getJSONObject("media").getString("desExtraInformation");
                }

                if (jsonResponse.getJSONObject("media").has("countryList"))
                {
                    jsonResponse.getJSONObject("media").getString("countryList");
                }

                jsonResponse.getJSONObject("mediaVideo");
                jsonResponse.getJSONObject("mediaVideo").getLong("idtMedia");
                jsonResponse.getJSONObject("mediaVideo").getInt("numDuration");
                jsonResponse.getJSONObject("mediaVideo").getInt("codVideoType");
                jsonResponse.getJSONObject("mediaVideo").getInt("numThumbnailIdentifier");
                jsonResponse.getJSONObject("mediaVideo").getInt("codExtensionFile");
                jsonResponse.getJSONObject("mediaVideo").getInt("numRevision");
                jsonResponse.getJSONObject("mediaVideo").getInt("numGeneratedThumbs");
                jsonResponse.getJSONObject("mediaVideo").getInt("numViewsMobile");
                jsonResponse.getJSONObject("mediaVideo").getInt("numEncodedPreset");

                if (jsonResponse.has("mediaOutputFormatCollection"))
                {
                    jsonResponse.getJSONObject("mediaOutputFormatCollection");
                    jsonResponse.getJSONObject("mediaOutputFormatCollection").getInt("numPages");
                    jsonResponse.getJSONObject("mediaOutputFormatCollection").getInt("total");
                    jsonResponse.getJSONObject("mediaOutputFormatCollection").getString("orderName");
                    jsonResponse.getJSONObject("mediaOutputFormatCollection").getBoolean("mobileFormats");
                    jsonResponse.getJSONObject("mediaOutputFormatCollection").getBoolean("hdFormats");
                    jsonResponse.getJSONObject("mediaOutputFormatCollection").getJSONArray("mediaOutputFormats");

                    for (int i = 0; i < jsonResponse.getJSONObject("mediaOutputFormatCollection").getJSONArray(
                        "mediaOutputFormats").length(); i++)
                    {
                        jsonResponse.getJSONObject("mediaOutputFormatCollection").getJSONArray("mediaOutputFormats")
                                .getJSONObject(i).getLong("idtMedia");
                        jsonResponse.getJSONObject("mediaOutputFormatCollection").getJSONArray("mediaOutputFormats")
                                .getJSONObject(i).getInt("idtOutputFormat");
                        jsonResponse.getJSONObject("mediaOutputFormatCollection").getJSONArray("mediaOutputFormats")
                                .getJSONObject(i).getInt("codStatus");
                        jsonResponse.getJSONObject("mediaOutputFormatCollection").getJSONArray("mediaOutputFormats")
                                .getJSONObject(i).getLong("datStartEncoding");
                        jsonResponse.getJSONObject("mediaOutputFormatCollection").getJSONArray("mediaOutputFormats")
                                .getJSONObject(i).getLong("datEndEncoding");
                        jsonResponse.getJSONObject("mediaOutputFormatCollection").getJSONArray("mediaOutputFormats")
                                .getJSONObject(i).getInt("numPercEncoding");
                        jsonResponse.getJSONObject("mediaOutputFormatCollection").getJSONArray("mediaOutputFormats")
                                .getJSONObject(i).getInt("numTemporaryServer");
                        jsonResponse.getJSONObject("mediaOutputFormatCollection").getJSONArray("mediaOutputFormats")
                                .getJSONObject(i).getInt("numRetry");
                        jsonResponse.getJSONObject("mediaOutputFormatCollection").getJSONArray("mediaOutputFormats")
                                .getJSONObject(i).getInt("numWidthVideo");
                        jsonResponse.getJSONObject("mediaOutputFormatCollection").getJSONArray("mediaOutputFormats")
                                .getJSONObject(i).getInt("numHeightVideo");
                        jsonResponse.getJSONObject("mediaOutputFormatCollection").getJSONArray("mediaOutputFormats")
                                .getJSONObject(i).getBoolean("flgBypass");
                    }
                }
            }

            if ("P".equals(jsonResponse.getJSONObject("media").getString("indMediaType")))
            {
                jsonResponse.getJSONObject("mediaPodcast");
                jsonResponse.getJSONObject("mediaPodcast").getLong("idtMedia");
                jsonResponse.getJSONObject("mediaPodcast").getInt("numDuration");
                jsonResponse.getJSONObject("mediaPodcast").getInt("codExtensionFile");
                jsonResponse.getJSONObject("mediaPodcast").getInt("numRevision");
            }

            jsonResponse.getBoolean("publicContent");
            jsonResponse.getString("urlHash");

            JsonUtil.validateValueJson(jsonResponse.getJSONObject("media"), new String[] { "namSubject", "desMedia" });

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - contentjson is not valid - " + e.getMessage() + " - " + jsonResponse);
            LogErrorTest.error(e);
            return false;
        }
    }

    private boolean validateMessageJson(JSONObject json, char type)
    {
        try
        {
            json.getJSONObject("messages");

            if (type == 'S')
            {
                json.getJSONObject("messages").getJSONArray("success");

                if (json.getJSONObject("messages").getJSONArray("success").length() < 1)
                {
                    throw new Exception("no has success message");
                }

                for (int i = 0; i < json.getJSONObject("messages").getJSONArray("success").length(); i++)
                {
                    json.getJSONObject("messages").getJSONArray("success").getJSONObject(i).getString("id");
                    json.getJSONObject("messages").getJSONArray("success").getJSONObject(i).getString("description");

                    JsonUtil.validateValueJson(json.getJSONObject("messages").getJSONArray("success").getJSONObject(i), new String[] { "" });
                }
            }
            else if (type == 'E')
            {
                json.getJSONObject("messages").getJSONArray("errors");

                if (json.getJSONObject("messages").getJSONArray("errors").length() < 1)
                {
                    throw new Exception("no has error message");
                }

                for (int i = 0; i < json.getJSONObject("messages").getJSONArray("errors").length(); i++)
                {
                    json.getJSONObject("messages").getJSONArray("errors").getJSONObject(i).getString("id");
                    json.getJSONObject("messages").getJSONArray("errors").getJSONObject(i).getString("description");

                    JsonUtil.validateValueJson(json.getJSONObject("messages").getJSONArray("errors").getJSONObject(i), new String[] { "" });
                }
            }
            else if (type == 'W')
            {
                json.getJSONObject("messages").getJSONArray("warns");

                if (json.getJSONObject("messages").getJSONArray("warns").length() < 1)
                {
                    throw new Exception("no has warn message");
                }

                for (int i = 0; i < json.getJSONObject("messages").getJSONArray("warns").length(); i++)
                {
                    json.getJSONObject("messages").getJSONArray("warns").getJSONObject(i).getString("id");
                    json.getJSONObject("messages").getJSONArray("warns").getJSONObject(i).getString("description");

                    JsonUtil.validateValueJson(json.getJSONObject("messages").getJSONArray("warns").getJSONObject(i), new String[] { "" });
                }
            }
            else
            {
                json.getJSONObject("messages").getJSONArray("infos");

                if (json.getJSONObject("messages").getJSONArray("infos").length() < 1)
                {
                    throw new Exception("no has info message");
                }

                for (int i = 0; i < json.getJSONObject("messages").getJSONArray("infos").length(); i++)
                {
                    json.getJSONObject("messages").getJSONArray("infos").getJSONObject(i).getString("id");
                    json.getJSONObject("messages").getJSONArray("infos").getJSONObject(i).getString("description");

                    JsonUtil.validateValueJson(json.getJSONObject("messages").getJSONArray("infos").getJSONObject(i), new String[] { "" });
                }
            }

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - message invalid - " + e.getMessage() + " - " + json);
            LogErrorTest.error(e);
            return false;
        }
    }
}
