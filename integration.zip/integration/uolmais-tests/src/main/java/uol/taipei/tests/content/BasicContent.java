/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         30/01/2015 Criacao inicial
 */

package uol.taipei.tests.content;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uol.taipei.request.FacileRequest;
import uol.taipei.request.FacileResponse;
import uol.taipei.tests.AbstractTest;

public class BasicContent extends AbstractTest
{
    static final Logger logger = LoggerFactory.getLogger(BasicContent.class);

    public static void main(String[] args)
    {
        if (!verifyParams(args))
        {
            return;
        }

        setUp(args[0]);

        logger.debug("-------------------------------------------------");
        logger.debug("tests basic content");

        try
        {
            BasicContent basicContent = new BasicContent();
            FacileRequest request = new FacileRequest();

            basicContent.crossdomain(request);
            basicContent.uriNotFound(request);
        }
        catch (Exception e) 
        {
            logger.error(e.getMessage());            
        }
    }

    public BasicContent()
    {
        this.host = "http://" + envConfig().getGlobal().getUrlnav();
    }

    public BasicContent(String url)
    {
        this.host = url;
    }

    public boolean crossdomain(FacileRequest request) throws Exception
    {
        FacileResponse response = request.get(host + "/crossdomain.xml");

        if (response.getCode() != 200)
        {
            logger.error("ERROR - return not valid - " + response.getCode());
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }

    public boolean uriNotFound(FacileRequest request) throws Exception
    {
        FacileResponse response = request.getNoBody(host + "/x");

        if (response.getCode() != 404)
        {
            logger.error("ERROR - return not valid - " + response.getCode());
            return false;
        }

        logger.debug("SUCCESS");

        return true;
    }
}
