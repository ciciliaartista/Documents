/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         24/04/2014 Criacao inicial
 */

package uol.taipei.tests.content;

import java.io.IOException;
import java.util.HashMap;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.http.HttpStatus;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uol.taipei.request.JsonRequest;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.DateParsing;
import uol.taipei.tests.LoginCookie;
import uol.taipei.tests.util.JsonUtil;
import uol.taipei.tests.util.TestUtil;
import uol.taipei.util.StringUtil;
import uol.taipei.util.hash.HashCode;
import uol.taipei.webServiceClient.WSReturn;

public class ApiContent extends AbstractTest
{
    static final Logger logger = LoggerFactory.getLogger(ApiContent.class);

    public static void main(String[] args)
    {
        if (!verifyParams(args))
        {
            return;
        }

        setUp(args[0]);

        if (envConfig().getUser() == null || envConfig().getUser().equals("") || envConfig().getPass() == null
                || envConfig().getPass().equals(""))
        {
            System.err.println("Invalid user " + envConfig().getUser());
            return;
        }

        logger.debug("-------------------------------------------------");
        logger.debug("tests api content");

        try
        {
            ApiContent apiContent = new ApiContent();

            LoginCookie login = new LoginCookie(envConfig().getUser(), envConfig().getPass());
            JSONObject media = JsonUtil.mediaDecored(10, "V", "T",
                false, false, false, false, false);
            HashMap<String, JSONObject> mapMedias = new HashMap<String, JSONObject>();
            mapMedias.put("V", media);
            apiContent.detailQs(mapMedias.get("V").getString("idt_media"), "V");
            apiContent.detailQs(mapMedias.get("V").getString("id"), "V");
            apiContent.detailsQs(mapMedias.get("V").getString("idt_media"));
            apiContent.detailsQs(mapMedias.get("V").getString("id"));
            apiContent.detail(mapMedias.get("V").getString("idt_media"), "V");
            apiContent.detail(mapMedias.get("V").getString("id"), "V");
            apiContent.details(mapMedias.get("V").getString("idt_media"));
            apiContent.details(mapMedias.get("V").getString("id"));

            media = JsonUtil.mediaDecored(10, "P", "T", false, false,
                false, false, false);
            mapMedias.put("P", media);
            apiContent.detailQs(mapMedias.get("P").getString("idt_media"), "P");
            apiContent.detailQs(mapMedias.get("P").getString("id"), "P");
            apiContent.detailsQs(mapMedias.get("P").getString("idt_media"));
            apiContent.detailsQs(mapMedias.get("P").getString("id"));
            apiContent.detail(mapMedias.get("P").getString("idt_media"), "P");
            apiContent.detail(mapMedias.get("P").getString("id"), "P");
            apiContent.details(mapMedias.get("P").getString("idt_media"));
            apiContent.details(mapMedias.get("P").getString("id"));

            String listIds = apiContent.listId(mapMedias);
            apiContent.detailsQs(listIds);
            apiContent.details(listIds);
            listIds = apiContent.listMediaId(mapMedias);
            apiContent.detailsQs(listIds);
            apiContent.details(listIds);

            apiContent.apacheCache(mapMedias.get("V").getString("idt_media"));
            apiContent.apacheCacheQs(mapMedias.get("V").getString("idt_media"));
            apiContent.apacheCache(mapMedias.get("V").getString("id"));
            apiContent.apacheCacheQs(mapMedias.get("V").getString("id"));

            apiContent.list();
            apiContent.codProfile(login.getJsonProfile().getJSONObject("item").getString("codProfile"));
            apiContent.itemsPerPage(2);
            apiContent.currentPage(2);
            apiContent.types();
            apiContent.edFilter();
            apiContent.adultFilter();
            apiContent.related(mapMedias.get("V").getString("idt_media"));
            apiContent.subscriberMedia();
            apiContent.format();
            apiContent.tagNames("teste");
            apiContent.tagIds("1", false);
            apiContent.idtTagService("1010", false);
            apiContent.sort();
            apiContent.editorialStatus();
            apiContent.history();
            apiContent.recommended();
            apiContent.formats();
            apiContent.paging();
            apiContent.date();
            apiContent.followable();
        }
        catch (Exception e)
        {
            logger.error(e.getMessage());
        }
    }

    public JSONObject list() throws IOException, JSONException
    {
        JSONObject jsonResponse = JsonRequest.get("http://mais.uol.com.br/apiuol/v2/media/list?nocache=" + Math.random());

        if (!validatePageJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    /**
     * api de detalhes de uma midia. url em query string
     * 
     * @param mediaId
     * @param mediaType
     * @return JSONObject
     * @throws IOException
     * @throws JSONException
     */
    public JSONObject detailQs(String mediaId, String mediaType) throws IOException, JSONException
    {
        JSONObject jsonResponse = JsonRequest.get("http://mais.uol.com.br/apiuol/v2/media/detail?mediaId=" + mediaId
                + "&nocache=" + Math.random());

        if (!validateJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        if (!mediaType.equals(jsonResponse.getJSONObject("media").getString("mediaType")))
        {
            logger.error("ERROR - mediaType not match - mediaType " + mediaType + " - " + jsonResponse);
            return null;
        }

        if (StringUtil.validateNumber(mediaId))
        {
            if (jsonResponse.getJSONObject("media").getLong("mediaId") != Long.parseLong(mediaId))
            {
                logger.error("ERROR - mediaId not match - mediaId " + mediaId + " - " + jsonResponse);
                return null;
            }
        }
        else
        {
            if (!jsonResponse.getJSONObject("media").getString("id").endsWith(
                mediaId.substring(mediaId.lastIndexOf("-"))))
            {
                logger.error("ERROR - id not match - mediaId " + mediaId + " - " + jsonResponse);
                return null;
            }
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    /**
     * api de detalhes de uma lista de midias. url em query string
     * 
     * @param ids
     * @return JSONObject
     * @throws IOException
     * @throws JSONException
     */
    public JSONObject detailsQs(String ids) throws IOException, JSONException
    {
        JSONObject jsonResponse = JsonRequest.get("http://mais.uol.com.br/apiuol/v2/media/list?ids=" + ids + "&nocache="
                + Math.random());

        if (!validatePageJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        String[] paramIds = ids.split(",");

        if (paramIds.length != jsonResponse.getJSONArray("list").length())
        {
            logger.error("ERROR - num items not match - ids " + ids + " - " + jsonResponse);
            return null;
        }

        for (int i = 0; i < jsonResponse.getJSONArray("list").length(); i++)
        {
            if (StringUtil.validateNumber(paramIds[i]))
            {
                if (!JsonUtil.containsMedia(jsonResponse.getJSONArray("list"), Long.parseLong(paramIds[i])))
                {
                    logger.error("ERROR - mediaId not match - ids " + ids + " - " + jsonResponse);
                    return null;
                }
            }
            else
            {
                if (!JsonUtil.containsMedia(jsonResponse.getJSONArray("list"), paramIds[i]))
                {
                    logger.error("ERROR - id not match - ids " + ids + " - " + jsonResponse);
                    return null;
                }
            }
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    /**
     * api de detalhes de uma midia. url em rest
     * 
     * @param mediaId
     * @param mediaType
     * @return JSONObject
     * @throws IOException
     * @throws JSONException
     */
    public JSONObject detail(String mediaId, String mediaType) throws IOException, JSONException
    {
        JSONObject jsonResponse = JsonRequest.get("http://mais.uol.com.br/apiuol/v2/media/detail/" + mediaId);

        if (!validateJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        if (!mediaType.equals(jsonResponse.getJSONObject("media").getString("mediaType")))
        {
            logger.error("ERROR - mediaType not match - mediaType " + mediaType + " - " + jsonResponse);
            return null;
        }

        if (StringUtil.validateNumber(mediaId))
        {
            if (jsonResponse.getJSONObject("media").getLong("mediaId") != Long.parseLong(mediaId))
            {
                logger.error("ERROR - mediaId not match - mediaId " + mediaId + " - " + jsonResponse);
                return null;
            }
        }
        else
        {
            if (!jsonResponse.getJSONObject("media").getString("id").endsWith(
                mediaId.substring(mediaId.lastIndexOf("-"))))
            {
                logger.error("ERROR - id not match - mediaId " + mediaId + " - " + jsonResponse);
                return null;
            }
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    /**
     * api de detalhes de uma lista de midias. url em rest
     * 
     * @param ids
     * @return JSONObject
     * @throws IOException
     * @throws JSONException
     */
    public JSONObject details(String ids) throws IOException, JSONException
    {
        JSONObject jsonResponse = JsonRequest.get("http://mais.uol.com.br/apiuol/v2/media/list/" + ids);

        if (!validatePageJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        String[] paramIds = ids.split(",");

        if (paramIds.length != jsonResponse.getJSONArray("list").length())
        {
            logger.error("ERROR - num items not match - ids " + ids + " - " + jsonResponse);
            return null;
        }

        for (int i = 0; i < jsonResponse.getJSONArray("list").length(); i++)
        {
            if (StringUtil.validateNumber(paramIds[i]))
            {
                if (!JsonUtil.containsMedia(jsonResponse.getJSONArray("list"), Long.parseLong(paramIds[i])))
                {
                    logger.error("ERROR - mediaId not match - ids " + ids + " - " + jsonResponse);
                    return null;
                }
            }
            else
            {
                if (!JsonUtil.containsMedia(jsonResponse.getJSONArray("list"), paramIds[i]))
                {
                    logger.error("ERROR - id not match - ids " + ids + " - " + jsonResponse);
                    return null;
                }
            }
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    /**
     * cache de api de detalhes de uma midia. url em query string
     * 
     * @param mediaId
     * @return boolean
     */
    public boolean apacheCacheQs(String mediaId)
    {
        try
        {
            JSONObject media = JsonRequest.get("http://mais.uol.com.br/apiuol/v2/media/detail?mediaId=" + mediaId);
            String id = (StringUtil.validateNumber(mediaId) ? mediaId : String.valueOf(media.getJSONObject("media")
                    .getLong("mediaId")));

            // a alteracao valida o dono da midia, entao precisa passar o codProfileHash
            Long codProfileHash = HashCode.encode(media.getJSONObject("media").getString("codProfile"));
            String url = "http://beta.mais.uol.com.br/apiuol/media/update?variant=json&mediaId=" + id
                    + "&codProfileHash=" + codProfileHash;
            String data = TestUtil.randomString(5);

            HashMap<String, String> params = new HashMap<String, String>();
            params.put("media.namSubject",
                data
                        + " "
                        + (media.getJSONObject("media").has("title") ? media.getJSONObject("media").getString("title")
                                : ""));
            params.put("media.desMedia", data
                    + " gibraltar - "
                    + (media.getJSONObject("media").has("description") ? media.getJSONObject("media").getString(
                        "description") : ""));

            WSReturn ret = JsonUtil.wsReturn(JsonRequest.execGibraltar(url, "POST", null, null, 10000, null, params));

            if (ret.getResponseCode() != 200)
            {
                logger.error("ERROR - response not valid - " + ret.getResponseCode());
                return false;
            }

            TestUtil.delay(500);
            JSONObject mediaCache = JsonRequest.get("http://mais.uol.com.br/apiuol/v2/media/detail?mediaId=" + mediaId);

            if (!media.getJSONObject("media").getString("title").equals(
                mediaCache.getJSONObject("media").getString("title"))
                    || !media.getJSONObject("media").getString("description").equals(
                        mediaCache.getJSONObject("media").getString("description")))
            {
                logger.error("ERROR - return not valid - media " + mediaId + " is not cacheable");
                return false;
            }

            logger.debug("SUCCESS");

            // volta dados originais
            params.put("media.namSubject", media.getJSONObject("media").getString("title"));
            params.put("media.desMedia", media.getJSONObject("media").getString("description"));
            JsonRequest.execGibraltar(url, "POST", null, null, 10000, null, params);

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage() + " - " + mediaId);
            return false;
        }
    }

    /**
     * cache de api de detalhes de uma midia. url em rest
     * 
     * @param mediaId
     * @return boolean
     */
    public boolean apacheCache(String mediaId)
    {
        try
        {
            JSONObject media = JsonRequest.get("http://mais.uol.com.br/apiuol/v2/media/detail/" + mediaId);
            String id = (StringUtil.validateNumber(mediaId) ? mediaId : String.valueOf(media.getJSONObject("media")
                    .getLong("mediaId")));

            // a alteracao valida o dono da midia, entao precisa passar o codProfileHash
            Long codProfileHash = HashCode.encode(media.getJSONObject("media").getString("codProfile"));
            String url = "http://beta.mais.uol.com.br/apiuol/media/update?variant=json&mediaId=" + id
                    + "&codProfileHash=" + codProfileHash;
            String data = TestUtil.randomString(5);

            HashMap<String, String> params = new HashMap<String, String>();
            params.put("media.namSubject",
                data
                        + " "
                        + (media.getJSONObject("media").has("title") ? media.getJSONObject("media").getString("title")
                                : ""));
            params.put("media.desMedia", data
                    + " gibraltar - "
                    + (media.getJSONObject("media").has("description") ? media.getJSONObject("media").getString(
                        "description") : ""));

            WSReturn ret = JsonUtil.wsReturn(JsonRequest.execGibraltar(url, "POST", null, null, 10000, null, params));

            if (ret.getResponseCode() != 200)
            {
                logger.error("ERROR - response not valid - " + ret.getResponseCode());
                return false;
            }

            TestUtil.delay(500);
            JSONObject mediaCache = JsonRequest.get("http://mais.uol.com.br/apiuol/v2/media/detail/" + mediaId);

            if (!media.getJSONObject("media").getString("title").equals(
                mediaCache.getJSONObject("media").getString("title"))
                    || !media.getJSONObject("media").getString("description").equals(
                        mediaCache.getJSONObject("media").getString("description")))
            {
                logger.error("ERROR - return not valid - media " + mediaId + " is not cacheable");
                return false;
            }

            logger.debug("SUCCESS");

            // volta dados originais
            params.put("media.namSubject", media.getJSONObject("media").getString("title"));
            params.put("media.desMedia", media.getJSONObject("media").getString("description"));
            JsonRequest.execGibraltar(url, "POST", null, null, 10000, null, params);

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage() + " - " + mediaId);
            return false;
        }
    }

    public JSONObject codProfile(String codProfile) throws IOException, JSONException
    {
        String url = "http://mais.uol.com.br/apiuol/v2/media/list?codProfile=" + codProfile + "&nocache="
                + Math.random();
        JSONObject jsonResponse = JsonRequest.get(url);

        if (!validatePageJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + url + " - " + jsonResponse);
            return null;
        }

        for (int i = 0; i < jsonResponse.getJSONArray("list").length(); i++)
        {
            if (!jsonResponse.getJSONArray("list").getJSONObject(i).getString("codProfile").equals(codProfile))
            {
                logger.error("ERROR - codProfile not match - codProfile " + codProfile + " - " + jsonResponse);
                return null;
            }
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject itemsPerPage(int itemsPerPage) throws IOException, JSONException
    {
        String url = "http://mais.uol.com.br/apiuol/v2/media/list?index.itemsPerPage=" + itemsPerPage + "&nocache="
                + Math.random();
        JSONObject jsonResponse = JsonRequest.get(url);

        if (!validatePageJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + url + " - " + jsonResponse);
            return null;
        }

        if (jsonResponse.getJSONObject("paging").getInt("pageSize") != itemsPerPage
                || (jsonResponse.getJSONObject("paging").getInt("totalItems") >= itemsPerPage && jsonResponse
                        .getJSONArray("list").length() != itemsPerPage))
        {
            logger.error("ERROR - itemsPerPage not match - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject currentPage(int currentPage) throws IOException, JSONException
    {
        String url = "http://mais.uol.com.br/apiuol/v2/media/list?index.currentPage=" + currentPage + "&nocache="
                + Math.random();
        JSONObject jsonResponse = JsonRequest.get(url);

        if (!validatePageJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + url + " - " + jsonResponse);
            return null;
        }

        if (jsonResponse.getJSONObject("paging").getInt("currentPage") != currentPage)
        {
            logger.error("ERROR - currentPage not match - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject types() throws IOException, JSONException
    {
        String url = "http://mais.uol.com.br/apiuol/v2/media/list?types=";
        String[] arrayTypes = new String[] { "A", "V", "P" };
        JSONObject jsonResponse = null;

        for (String type : arrayTypes)
        {
            jsonResponse = JsonRequest.get(url + type + "&nocache=" + Math.random());

            if (!validatePageJson(jsonResponse))
            {
                logger.error("ERROR - return not valid - " + url + type + " - " + jsonResponse);
                return null;
            }

            for (int i = 0; i < jsonResponse.getJSONArray("list").length(); i++)
            {
                if ("A".equals(type))
                {
                    if (!ArrayUtils.contains(arrayTypes, jsonResponse.getJSONArray("list").getJSONObject(i).getString(
                        "mediaType")))
                    {
                        logger.error("ERROR - mediaType not match - mediaType " + type + " - " + jsonResponse);
                        return null;
                    }
                }
                else
                {
                    if (!jsonResponse.getJSONArray("list").getJSONObject(i).getString("mediaType").equals(type))
                    {
                        logger.error("ERROR - mediaType not match - mediaType " + type + " - " + jsonResponse);
                        return null;
                    }
                }
            }
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject edFilter() throws IOException, JSONException
    {
        String url = "http://mais.uol.com.br/apiuol/v2/media/list?edFilter=";
        JSONObject jsonResponse = null;
        String[] edFilter = new String[] { "user", "editorial", "all" };

        for (String ef : edFilter)
        {
            jsonResponse = JsonRequest.get(url + ef.toString() + "&nocache=" + Math.random());

            if (!validatePageJson(jsonResponse))
            {
                logger.error("ERROR - return not valid - " + url + ef + " - " + jsonResponse);
                return null;
            }

            for (int i = 0; i < jsonResponse.getJSONArray("list").length(); i++)
            {
                if ("all".equals(ef))
                {
                    if (!ArrayUtils.contains(edFilter, jsonResponse
                            .getJSONArray("list").getJSONObject(i).getString("edFilter")))
                    {
                        logger.error("ERROR - edFilter not match - edFilter " + ef + " - " + jsonResponse);
                        return null;
                    }
                }
                else
                {
                    if (!jsonResponse.getJSONArray("list").getJSONObject(i).getString("edFilter").equals(
                        ef))
                    {
                        logger.error("ERROR - edFilter not match - edFilter " + ef + " - " + jsonResponse);
                        return null;
                    }
                }
            }
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject adultFilter() throws IOException, JSONException
    {
        String url = "http://mais.uol.com.br/apiuol/v2/media/list?adultFilter=";
        JSONObject jsonResponse = null;
        String[] adultFilter = new String[] { "safe", "unsafe", "all" };

        for (String af : adultFilter)
        {
            jsonResponse = JsonRequest.get(url + af + "&nocache=" + Math.random());

            if (!validatePageJson(jsonResponse))
            {
                logger.error("ERROR - return not valid - " + url + af + " - " + jsonResponse);
                return null;
            }

            for (int i = 0; i < jsonResponse.getJSONArray("list").length(); i++)
            {
                Boolean hot = Boolean.parseBoolean(jsonResponse.getJSONArray("list").getJSONObject(i).getString(
                    "adultContent"));

                if ("all".equals(af))
                {
                    if (hot == null)
                    {
                        logger.error("ERROR - adultFilter not valid - adultFilter " + af + " - "
                                + jsonResponse);
                        return null;
                    }
                }
                else if ("safe".equals(af))
                {
                    if (hot)
                    {
                        logger.error("ERROR - adultFilter not match - adultFilter " + af + " - "
                                + jsonResponse);
                        return null;
                    }
                }
                else if ("unsafe".equals(af))
                {
                    if (!hot)
                    {
                        logger.error("ERROR - adultFilter not match - adultFilter " + af + " - "
                                + jsonResponse);
                        return null;
                    }
                }
                else
                {
                    logger.error("ERROR - adultFilter not valid - adultFilter " + af + " - " + jsonResponse);
                    return null;
                }
            }
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject related(String mediaId)
    {
        try
        {
            String url = "http://mais.uol.com.br/apiuol/v2/media/list?relatedList=true&mediaRelatedId=" + mediaId
                    + "&types=A";
            JSONObject jsonResponse = JsonRequest.get(url + "&nocache=" + Math.random());

            if (jsonResponse.getJSONObject("response").getInt("code") == HttpStatus.SC_NOT_FOUND)
            {
                if (!validateResponseNotOKJson(jsonResponse, HttpStatus.SC_NOT_FOUND))
                {
                    logger.error("ERROR - invalid response - " + url + " - " + jsonResponse);
                    return null;
                }
                else
                {
                    logger.debug("SUCCESS");
                    return jsonResponse;
                }
            }

            if (!validatePageJson(jsonResponse))
            {
                logger.error("ERROR - return not valid - " + url + " - " + jsonResponse);
                return null;
            }

            JSONObject media = JsonRequest.get("http://mais.uol.com.br/apiuol/v2/media/detail/" + mediaId);

            if (!isRelated(jsonResponse.getJSONArray("list"), media))
            {
                logger.error("ERROR - return not valid - there is not related - " + jsonResponse + " - " + media);
                return null;
            }

            logger.debug("SUCCESS");

            return jsonResponse;
        }
        catch (Exception e)
        {
            logger.error("ERROR - " + e.getMessage() + " - " + mediaId);
            return null;
        }
    }

    public JSONObject subscriberMedia() throws IOException, JSONException
    {
        String url = "http://mais.uol.com.br/apiuol/v2/media/list?subscriberMedia=";
        JSONObject jsonResponse = null;
        String[] subscriberFilter = new String[] { "open", "subscriber", "all" };

        for (String sf : subscriberFilter)
        {
            jsonResponse = JsonRequest.get(url + sf + "&nocache=" + Math.random());

            if (!validatePageJson(jsonResponse))
            {
                logger.error("ERROR - return not valid - " + url + sf + " - " + jsonResponse);
                return null;
            }

            for (int i = 0; i < jsonResponse.getJSONArray("list").length(); i++)
            {
                Boolean subscriber = Boolean.parseBoolean(jsonResponse.getJSONArray("list").getJSONObject(i).getString(
                    "subscriberMedia"));

                if ("all".equals(sf))
                {
                    if (subscriber == null)
                    {
                        logger.error("ERROR - subscriberMedia not valid - subscriberMedia " + sf + " - "
                                + jsonResponse);
                        return null;
                    }
                }
                else if ("open".equals(sf))
                {
                    if (subscriber)
                    {
                        logger.error("ERROR - subscriberMedia not match - subscriberMedia " + sf + " - "
                                + jsonResponse);
                        return null;
                    }
                }
                else if ("subscriber".equals(sf))
                {
                    if (!subscriber)
                    {
                        logger.error("ERROR - subscriberMedia not match - subscriberMedia " + sf + " - "
                                + jsonResponse);
                        return null;
                    }
                }
                else
                {
                    logger.error("ERROR - subscriberMedia not valid - subscriberMedia " + sf + " - "
                            + jsonResponse);
                    return null;
                }
            }
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject format() throws IOException, JSONException
    {
        String url = "http://mais.uol.com.br/apiuol/v2/media/list?format=";
        String[] arrayFormats = new String[] { "2", "5", "6", "7", "8", "9" };
        JSONObject jsonResponse = null;

        for (String format : arrayFormats)
        {
            jsonResponse = JsonRequest.get(url + format + "&nocache=" + Math.random());

            if (!validatePageJson(jsonResponse))
            {
                logger.error("ERROR - return not valid - " + url + format + " - " + jsonResponse);
                return null;
            }

            for (int i = 0; i < jsonResponse.getJSONArray("list").length(); i++)
            {
                if (!JsonUtil.contains(jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("formats"),
                    Integer.valueOf(format)))
                {
                    logger.error("ERROR - format not match - " + format + " - " + jsonResponse);
                    return null;
                }
            }
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject tagNames(String tags) throws IOException, JSONException
    {
        String url = "http://mais.uol.com.br/apiuol/v2/media/list?tagNames=" + tags + "&nocache=" + Math.random();
        JSONObject jsonResponse = JsonRequest.get(url);

        if (!validatePageJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + url + " - " + jsonResponse);
            return null;
        }

        for (int i = 0; i < jsonResponse.getJSONArray("list").length(); i++)
        {
            if (!JsonUtil
                    .containsTagName(jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("tags"), tags))
            {
                logger.error("ERROR - tagNames not match - tags " + tags + " - " + jsonResponse);
                return null;
            }
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject tagIds(String tags, boolean or) throws IOException, JSONException
    {
        boolean contains = false;
        String url = "http://mais.uol.com.br/apiuol/v2/media/list?tagIds=" + tags + (or ? "&qryTag=or" : "")
                + "&nocache=" + Math.random();
        JSONObject jsonResponse = JsonRequest.get(url);

        if (!validatePageJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + url + " - " + jsonResponse);
            return null;
        }

        for (int i = 0; i < jsonResponse.getJSONArray("list").length(); i++)
        {
            for (String tag : tags.split(","))
            {
                if (or)
                {
                    if (JsonUtil.containsTagId(jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("tags"),
                        Integer.parseInt(tag)))
                    {
                        contains = true;
                        break;
                    }
                }
                else
                {
                    if (!JsonUtil.containsTagId(
                        jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("tags"), Integer.parseInt(tag)))
                    {
                        logger.error("ERROR - tagIds not match - tags " + tags + " - " + jsonResponse);
                        return null;
                    }
                }
            }
        }

        if (or && !contains)
        {
            logger.error("ERROR - tags not match - tags " + tags + " - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject idtTagService(String tagService, boolean or) throws IOException, JSONException
    {
        boolean contains = false;
        String url = "http://mais.uol.com.br/apiuol/v2/media/list?idtTagService=" + tagService
                + (or ? "&qryServTag=or" : "") + "&nocache=" + Math.random();
        JSONObject jsonResponse = JsonRequest.get(url);

        if (!validatePageJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + url + " - " + jsonResponse);
            return null;
        }

        for (int i = 0; i < jsonResponse.getJSONArray("list").length(); i++)
        {
            for (String tag : tagService.split(";"))
            {
                if (or)
                {
                    if (ArrayUtils.contains(jsonResponse.getJSONArray("list").getJSONObject(i).getString(
                        "idtTagService").split(","), tag))
                    {
                        contains = true;
                        break;
                    }
                }
                else
                {
                    if (!ArrayUtils.contains(jsonResponse.getJSONArray("list").getJSONObject(i).getString(
                        "idtTagService").split(","), tag))
                    {
                        logger.error("ERROR - tags not match - tags " + tagService + " - " + jsonResponse);
                        return null;
                    }
                }
            }
        }

        if (or && !contains)
        {
            logger.error("ERROR - tagservice not match - tags " + tagService + " - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject sort() throws IOException, JSONException
    {
        String url = "http://mais.uol.com.br/apiuol/v2/media/list?sort=";
        JSONObject jsonResponse = null;
        String[] mediaSort = new String[] { "mostPopular", 
                                  "mostVoted", 
                                  "mostFavorited", 
                                  "mostRecent", 
                                  "alphabetic", 
                                  "profileUpdate", 
                                  "recentlyViewed",
                                  "todayViewed",
                                  "lastUpdate", 
                                  "mostRelevant" };

        for (String order : mediaSort)
        {
            jsonResponse = JsonRequest.get(url + order + "&nocache=" + Math.random());

            if (jsonResponse.getJSONObject("response").getInt("code") == HttpStatus.SC_NOT_FOUND
                    && (order.equals("recentlyViewed") || order.equals("todayViewed")))
            {
                if (!validateResponseNotOKJson(jsonResponse, HttpStatus.SC_NOT_FOUND))
                {
                    logger.error("ERROR - invalid response - " + url + order + " - " + jsonResponse);
                    return null;
                }
            }
            else if (!validatePageJson(jsonResponse))
            {
                logger.error("ERROR - return not valid - " + url + order + " - " + jsonResponse);
                return null;
            }
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject editorialStatus() throws IOException, JSONException
    {
        String url = "http://mais.uol.com.br/apiuol/v2/media/list?editorialStatus=";
        String[] editStatus = new String[] { "aproved", "xxx" };
        JSONObject jsonResponse = null;

        for (String es : editStatus)
        {
            jsonResponse = JsonRequest.get(url + es + "&nocache=" + Math.random());

            if (!validatePageJson(jsonResponse))
            {
                logger.error("ERROR - return not valid - " + url + es + " - " + jsonResponse);
                return null;
            }

            jsonResponse = JsonRequest.get("http://mais.uol.com.br/apiuol/v2/media/list.json?editorialStatus=" + es
                    + "&nocache=" + Math.random());

            for (int i = 0; i < jsonResponse.getJSONObject("mediasPage").getJSONArray("items").length(); i++)
            {
                int codEditorialStatus = jsonResponse.getJSONObject("mediasPage").getJSONArray("items")
                        .getJSONObject(i).getJSONObject("media").getInt("codEditorialStatus");

                if (es.equals("aproved") && codEditorialStatus != 2)
                {
                    logger.error("ERROR - editorialStatus not match - " + es + " - " + jsonResponse);
                    return null;
                }

                if (!es.equals("aproved") && (codEditorialStatus < 1 || codEditorialStatus > 7))
                {
                    logger.error("ERROR - editorialStatus not match - " + es + " - " + jsonResponse);
                    return null;
                }
            }
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject history() throws IOException, JSONException
    {
        JSONObject jsonResponse = JsonRequest.get("http://mais.uol.com.br/apiuol/v2/media/history?nocache="
                + Math.random());

        if (!validatePageJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject recommended() throws IOException, JSONException
    {
        JSONObject jsonResponse = JsonRequest.get("http://mais.uol.com.br/apiuol/v2/media/recommended?nocache="
                + Math.random());

        if (!validatePageJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject formats() throws IOException, JSONException
    {
        String url = "http://mais.uol.com.br/apiuol/v2/media/list?format=7&nocache=" + Math.random();
        JSONObject jsonResponse = JsonRequest.get(url);

        if (!validatePageJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + url + " - " + jsonResponse);
            return null;
        }

        JSONObject media = jsonResponse.getJSONArray("list").getJSONObject(0);
        url = "http://mais.uol.com.br/apiuol/v2/media/formats/" + media.getLong("mediaId") + ".json?nocache="
                + Math.random();
        jsonResponse = JsonRequest.get(url);

        if (!validateFormatsJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + url + " - " + jsonResponse);
            return null;
        }

        for (int i = 0; i < jsonResponse.getJSONObject("formats").getJSONArray("mediaOutputFormats").length(); i++)
        {
            if (!JsonUtil.contains(media.getJSONArray("formats"), jsonResponse.getJSONObject("formats").getJSONArray(
                "mediaOutputFormats").getJSONObject(i).getInt("idtOutputFormat")))
            {
                logger.error("ERROR - formats not match - " + media.getJSONArray("formats") + " - " + jsonResponse);
                return null;
            }
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject paging() throws IOException, JSONException
    {
        int page = 1;
        JSONObject jsonResponse = JsonRequest.get("http://mais.uol.com.br/apiuol/v2/media/list?index.currentPage=" + page
                + "&nocache=" + Math.random());
        int totalPage = jsonResponse.getJSONObject("paging").getInt("totalPages");

        while (jsonResponse.getJSONArray("list").length() > 0)
        {
            if (!validatePageJson(jsonResponse))
            {
                logger.error("ERROR - return not valid - " + jsonResponse);
                return null;
            }

            page++;
            jsonResponse = JsonRequest.get("http://mais.uol.com.br/apiuol/v2/media/list?index.currentPage=" + page
                    + "&nocache=" + Math.random());
        }

        if (totalPage != page)
        {
            logger.error("ERROR - totalPage not match - " + totalPage + " " + page + " - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject date() throws Exception
    {
        int page = 1;
        JSONObject media = JsonUtil.apiMedia("V");

        if (media == null)
        {
            logger.error("ERROR - none media found");
            return null;
        }

        DateParsing dateParsing = new DateParsing(media.getString("publishedAt"), "yyyy-MM-dd HH:mm:ss");
        String url = "http://mais.uol.com.br/apiuol/v2/media/list?date=" + dateParsing.dateString()
                + "&index.currentPage=";
        JSONObject jsonResponse = JsonRequest.get(url + page + "&nocache=" + Math.random());

        while (jsonResponse.has("list") && jsonResponse.getJSONArray("list").length() > 0)
        {
            for (int i = 0; i < jsonResponse.getJSONArray("list").length(); i++)
            {
                if (!validatePageJson(jsonResponse))
                {
                    logger.error("ERROR - json not valid from media list - " + url + " - " + jsonResponse);
                    return null;
                }

                if (!jsonResponse.getJSONArray("list").getJSONObject(i).getString("publishedAt").startsWith(
                    dateParsing.getYear() + "-"
                            + (dateParsing.getMonth() < 10 ? "0" + dateParsing.getMonth() : dateParsing.getMonth())
                            + "-" + (dateParsing.getDay() < 10 ? "0" + dateParsing.getDay() : dateParsing.getDay())))
                {
                    logger.error("ERROR - media not valid - " + media + " - "
                            + jsonResponse.getJSONArray("list").getJSONObject(i));
                    return null;
                }
            }

            page++;
            jsonResponse = JsonRequest.get(url + page + "&nocache=" + Math.random());
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject followable() throws Exception
    {
        int page = 1;
        JSONObject jsonfollowable = JsonUtil.followable();

        if (jsonfollowable == null)
        {
            logger.error("ERROR - none followable found");
            return null;
        }

        String url = "http://mais.uol.com.br/apiuol/v2/media/list?followableId="
                + jsonfollowable.getString("idt_followable") + "&index.currentPage=";
        JSONObject jsonResponse = JsonRequest.get(url + page + "&nocache=" + Math.random());

        while (jsonResponse.has("list") && jsonResponse.getJSONArray("list").length() > 0)
        {
            for (int i = 0; i < jsonResponse.getJSONArray("list").length(); i++)
            {
                if (!validatePageJson(jsonResponse))
                {
                    logger.error("ERROR - json not valid from media list - " + url + " - " + jsonResponse);
                    return null;
                }

                if (!validateFollowable(jsonfollowable, jsonResponse.getJSONArray("list").getJSONObject(i)))
                {
                    logger.error("ERROR - followable not valid - " + jsonfollowable + " - "
                            + jsonResponse.getJSONArray("list").getJSONObject(i));
                    return null;
                }
            }

            page++;
            jsonResponse = JsonRequest.get(url + page + "&nocache=" + Math.random());
        }

        logger.debug("SUCCESS");

        return jsonfollowable;
    }

    private boolean validateResponseNotOKJson(JSONObject json, int httpStatus)
    {
        try
        {
            json.getJSONObject("response");
            json.getJSONObject("response").getInt("code");
            json.getJSONObject("response").getString("description");
            json.getJSONObject("response").getString("originalRequest");

            if (!json.has("error"))
            {
                logger.error("ERROR - response invalid - no error - " + json);
                return false;
            }

            if (!json.isNull("error"))
            {
                json.getJSONObject("error");
                json.getJSONObject("error").getString("message");
            }

            if (json.getJSONObject("response").getInt("code") != httpStatus)
            {
                logger.error("ERROR - response invalid - wrong code " + json);
                return false;
            }

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - response invalid - " + e.getMessage() + " - " + json);
            return false;
        }
    }

    private boolean isRelated(JSONArray listRelated, JSONObject media) throws Exception
    {
        for (String q : media.getJSONObject("media").getString("title").split(" "))
        {
            if (JsonUtil.containsTerms(listRelated, q))
            {
                return true;
            }
        }

        for (String q : media.getJSONObject("media").getString("description").split(" "))
        {
            if (JsonUtil.containsTerms(listRelated, q))
            {
                return true;
            }
        }

        for (int j = 0; j < media.getJSONObject("media").getJSONArray("tags").length(); j++)
        {
            if (JsonUtil.containsTerms(listRelated, media.getJSONObject("media").getJSONArray("tags").getJSONObject(j)
                    .getString("description")))
            {
                return true;
            }
        }

        return false;
    }

    public String listMediaId(HashMap<String, JSONObject> mapIds) throws JSONException
    {
        StringBuilder list = new StringBuilder();

        for (JSONObject mi : mapIds.values())
        {
            list.append((list.length() > 0 ? "," : "") + mi.getString("idt_media"));
        }

        return list.toString();
    }

    public String listId(HashMap<String, JSONObject> mapIds) throws JSONException
    {
        StringBuilder list = new StringBuilder();

        for (JSONObject mi : mapIds.values())
        {
            list.append((list.length() > 0 ? "," : "") + mi.getString("id"));
        }

        return list.toString();
    }

    private boolean validateJson(JSONObject jsonResponse) throws JSONException
    {
        try
        {
            if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") != HttpStatus.SC_OK)
            {
                return false;
            }
            jsonResponse.getJSONObject("response");
            jsonResponse.getJSONObject("response").getInt("code");
            jsonResponse.getJSONObject("response").getString("description");
            jsonResponse.getJSONObject("response").getString("originalRequest");

            jsonResponse.getJSONObject("media");
            jsonResponse.getJSONObject("media").getString("title");
            jsonResponse.getJSONObject("media").getString("id");
            jsonResponse.getJSONObject("media").getLong("mediaId");
            jsonResponse.getJSONObject("media").getString("url");
            jsonResponse.getJSONObject("media").getString("mediaType");
            Boolean.parseBoolean(jsonResponse.getJSONObject("media").getString("moderateNote"));
            Boolean.parseBoolean(jsonResponse.getJSONObject("media").getString("allowAnonymousComment"));
            jsonResponse.getJSONObject("media").getString("allowNotes");
            jsonResponse.getJSONObject("media").getString("edFilter");
            jsonResponse.getJSONObject("media").getString("thumbnail");
            jsonResponse.getJSONObject("media").getString("thumbSmall");
            jsonResponse.getJSONObject("media").getString("thumbMedium");
            jsonResponse.getJSONObject("media").getString("thumbLarge");
            jsonResponse.getJSONObject("media").getLong("idtSubject");

            if (jsonResponse.getJSONObject("media").getString("mediaType").equals("V"))
            {
                jsonResponse.getJSONObject("media").getString("player");
                jsonResponse.getJSONObject("media").getString("duration");
                jsonResponse.getJSONObject("media").getString("thumbWlarge");
                jsonResponse.getJSONObject("media").getString("thumbWmedium");

                jsonResponse.getJSONObject("media").getInt("numThumbnailIdentifier");

                int formatLength = jsonResponse.getJSONObject("media").getJSONArray("formats").length();

                for (int j = 0; j < formatLength; j++)
                {
                    jsonResponse.getJSONObject("media").getJSONArray("formats").getDouble(j);
                }

                if (jsonResponse.getJSONObject("media").has("idtProductList"))
                {
                    jsonResponse.getJSONObject("media").getJSONArray("idtProductList");

                    for (int i = 0; i < jsonResponse.getJSONObject("media").getJSONArray("idtProductList").length(); i++)
                    {
                        jsonResponse.getJSONObject("media").getJSONArray("idtProductList").getInt(i);
                    }
                }

                jsonResponse.getJSONObject("media").getString("embedCode");

                jsonResponse.getJSONArray("mediaOutputFormats");

                for (int j = 0; j < jsonResponse.getJSONArray("mediaOutputFormats").length(); j++)
                {
                    jsonResponse.getJSONArray("mediaOutputFormats").getJSONObject(j).getInt("idtOutputFormat");
                    jsonResponse.getJSONArray("mediaOutputFormats").getJSONObject(j).getInt("numWidthVideo");
                    jsonResponse.getJSONArray("mediaOutputFormats").getJSONObject(j).getInt("numHeightVideo");
                }
            }

            if (jsonResponse.getJSONObject("media").getString("mediaType").equals("P"))
            {
                jsonResponse.getJSONObject("media").getString("player");
                jsonResponse.getJSONObject("media").getString("duration");
                jsonResponse.getJSONObject("media").getString("embedCode");
            }

            if (!jsonResponse.getJSONObject("media").getString("mediaType").equals("T")
                    && !jsonResponse.getJSONObject("media").getString("mediaType").equals("P")
                    && !jsonResponse.getJSONObject("media").getString("mediaType").equals("S"))
            {
                jsonResponse.getJSONObject("media").getInt("thumbVersion");
            }

            jsonResponse.getJSONObject("media").getString("description");
            Boolean.parseBoolean(jsonResponse.getJSONObject("media").getString("adultContent"));
            jsonResponse.getJSONObject("media").getString("author");
            jsonResponse.getJSONObject("media").getString("authorPage");
            jsonResponse.getJSONObject("media").getString("codProfile");
            jsonResponse.getJSONObject("media").getInt("views");
            jsonResponse.getJSONObject("media").getInt("comments");
            jsonResponse.getJSONObject("media").getInt("favorites");
            jsonResponse.getJSONObject("media").getDouble("rating");
            jsonResponse.getJSONObject("media").getInt("votes");
            jsonResponse.getJSONObject("media").getString("publishedAt");
            Boolean.parseBoolean(jsonResponse.getJSONObject("media").getString("blockEmbed"));
            Boolean.parseBoolean(jsonResponse.getJSONObject("media").getString("subscriberMedia"));

            int tagLength = jsonResponse.getJSONObject("media").getJSONArray("tags").length();

            for (int j = 0; j < tagLength; j++)
            {
                jsonResponse.getJSONObject("media").getJSONArray("tags").getJSONObject(j).getLong("id");
                jsonResponse.getJSONObject("media").getJSONArray("tags").getJSONObject(j).getString("description");
            }

            jsonResponse.getJSONObject("media").getString("idtTagService");

            JsonUtil.validateValueJson(jsonResponse.getJSONObject("media"), new String[] { "title", "description" });

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - json is not valid - " + e.getMessage() + " - " + jsonResponse);
            return false;
        }
    }

    private boolean validatePageJson(JSONObject jsonResponse) throws JSONException
    {
        try
        {
            if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") != HttpStatus.SC_OK)
            {
                return false;
            }
            jsonResponse.getJSONObject("response");
            jsonResponse.getJSONObject("response").getInt("code");
            jsonResponse.getJSONObject("response").getString("description");
            jsonResponse.getJSONObject("response").getString("originalRequest");

            jsonResponse.getJSONObject("paging");
            jsonResponse.getJSONObject("paging").getInt("currentPage");
            Boolean.parseBoolean(jsonResponse.getJSONObject("paging").getString("nextPage"));
            jsonResponse.getJSONObject("paging").getInt("pageSize");
            Boolean.parseBoolean(jsonResponse.getJSONObject("paging").getString("previousPage"));
            jsonResponse.getJSONObject("paging").getString("sort");
            jsonResponse.getJSONObject("paging").getInt("totalItems");
            jsonResponse.getJSONObject("paging").getInt("totalPages");

            jsonResponse.getJSONArray("list");

            int length = jsonResponse.getJSONArray("list").length();

            for (int i = 0; i < length; i++)
            {
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("title");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("id");
                jsonResponse.getJSONArray("list").getJSONObject(i).getLong("mediaId");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("url");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("mediaType");
                Boolean.parseBoolean(jsonResponse.getJSONArray("list").getJSONObject(i).getString("moderateNote"));
                Boolean.parseBoolean(jsonResponse.getJSONArray("list").getJSONObject(i).getString(
                    "allowAnonymousComment"));
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("allowNotes");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("edFilter");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("thumbnail");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("thumbSmall");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("thumbMedium");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("thumbLarge");
                jsonResponse.getJSONArray("list").getJSONObject(i).getLong("idtSubject");

                if (jsonResponse.getJSONArray("list").getJSONObject(i).getString("mediaType").equals("V"))
                {
                    jsonResponse.getJSONArray("list").getJSONObject(i).getString("player");
                    jsonResponse.getJSONArray("list").getJSONObject(i).getString("duration");
                    jsonResponse.getJSONArray("list").getJSONObject(i).getString("thumbWlarge");
                    jsonResponse.getJSONArray("list").getJSONObject(i).getString("thumbWmedium");

                    jsonResponse.getJSONArray("list").getJSONObject(i).getInt("numThumbnailIdentifier");

                    if (!jsonResponse.getJSONArray("list").getJSONObject(i).isNull("formats"))
                    {
                        jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("formats");

                        for (int j = 0; j < jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("formats").length(); j++)
                        {
                            jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("formats").getDouble(j);
                        }
                    }

                    if (jsonResponse.getJSONArray("list").getJSONObject(i).has("idtProductList") && 
                            !jsonResponse.getJSONArray("list").getJSONObject(i).isNull("idtProductList"))
                    {
                        jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("idtProductList");

                        for (int j = 0; j < jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray(
                            "idtProductList").length(); j++)
                        {
                            jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("idtProductList").getInt(j);
                        }
                    }

                    jsonResponse.getJSONArray("list").getJSONObject(i).getString("embedCode");
                }

                if (jsonResponse.getJSONArray("list").getJSONObject(i).getString("mediaType").equals("P"))
                {
                    jsonResponse.getJSONArray("list").getJSONObject(i).getString("player");
                    jsonResponse.getJSONArray("list").getJSONObject(i).getString("duration");
                    jsonResponse.getJSONArray("list").getJSONObject(i).getString("embedCode");
                }

                if (!jsonResponse.getJSONArray("list").getJSONObject(i).getString("mediaType").equals("T")
                        && !jsonResponse.getJSONArray("list").getJSONObject(i).getString("mediaType").equals("P")
                        && !jsonResponse.getJSONArray("list").getJSONObject(i).getString("mediaType").equals("S"))
                {
                    jsonResponse.getJSONArray("list").getJSONObject(i).getInt("thumbVersion");
                }

                jsonResponse.getJSONArray("list").getJSONObject(i).getString("description");
                Boolean.parseBoolean(jsonResponse.getJSONArray("list").getJSONObject(i).getString("adultContent"));
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("author");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("authorPage");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("codProfile");
                jsonResponse.getJSONArray("list").getJSONObject(i).getInt("views");
                jsonResponse.getJSONArray("list").getJSONObject(i).getInt("comments");
                jsonResponse.getJSONArray("list").getJSONObject(i).getInt("favorites");
                jsonResponse.getJSONArray("list").getJSONObject(i).getDouble("rating");
                jsonResponse.getJSONArray("list").getJSONObject(i).getInt("votes");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("publishedAt");
                Boolean.parseBoolean(jsonResponse.getJSONArray("list").getJSONObject(i).getString("blockEmbed"));
                Boolean.parseBoolean(jsonResponse.getJSONArray("list").getJSONObject(i).getString("subscriberMedia"));

                int tagLength = jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("tags").length();

                for (int j = 0; j < tagLength; j++)
                {
                    jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("tags").getJSONObject(j).getLong(
                        "id");
                    jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("tags").getJSONObject(j).getString(
                        "description");
                }

                jsonResponse.getJSONArray("list").getJSONObject(i).getString("idtTagService");

                JsonUtil.validateValueJson(jsonResponse.getJSONArray("list").getJSONObject(i),
                    new String[] { "title", "description", "embedCode" });
            }

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - pagejson is not valid - " + e.getMessage() + " - " + jsonResponse);
            return false;
        }
    }

    private boolean validateFormatsJson(JSONObject jsonResponse)
    {
        try
        {
            if (jsonResponse.has("formats"))
            {
                jsonResponse.getJSONObject("formats");
                jsonResponse.getJSONObject("formats").getInt("numPages");
                jsonResponse.getJSONObject("formats").getInt("total");
                jsonResponse.getJSONObject("formats").getString("orderName");
                jsonResponse.getJSONObject("formats").getBoolean("mobileFormats");
                jsonResponse.getJSONObject("formats").getBoolean("hdFormats");
                jsonResponse.getJSONObject("formats").getJSONArray("mediaOutputFormats");

                for (int i = 0; i < jsonResponse.getJSONObject("formats").getJSONArray("mediaOutputFormats").length(); i++)
                {
                    jsonResponse.getJSONObject("formats").getJSONArray("mediaOutputFormats").getJSONObject(i).getLong(
                        "idtMedia");
                    jsonResponse.getJSONObject("formats").getJSONArray("mediaOutputFormats").getJSONObject(i).getInt(
                        "idtOutputFormat");
                    jsonResponse.getJSONObject("formats").getJSONArray("mediaOutputFormats").getJSONObject(i).getInt(
                        "codStatus");
                    jsonResponse.getJSONObject("formats").getJSONArray("mediaOutputFormats").getJSONObject(i).getLong(
                        "datStartEncoding");
                    jsonResponse.getJSONObject("formats").getJSONArray("mediaOutputFormats").getJSONObject(i).getLong(
                        "datEndEncoding");
                    jsonResponse.getJSONObject("formats").getJSONArray("mediaOutputFormats").getJSONObject(i).getInt(
                        "numPercEncoding");
                    jsonResponse.getJSONObject("formats").getJSONArray("mediaOutputFormats").getJSONObject(i).getInt(
                        "numTemporaryServer");
                    jsonResponse.getJSONObject("formats").getJSONArray("mediaOutputFormats").getJSONObject(i).getInt(
                        "numRetry");
                    jsonResponse.getJSONObject("formats").getJSONArray("mediaOutputFormats").getJSONObject(i).getInt(
                        "numWidthVideo");
                    jsonResponse.getJSONObject("formats").getJSONArray("mediaOutputFormats").getJSONObject(i).getInt(
                        "numHeightVideo");
                    jsonResponse.getJSONObject("formats").getJSONArray("mediaOutputFormats").getJSONObject(i)
                            .getBoolean("flgBypass");
                }
            }

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - formatsjson is not valid - " + e.getMessage() + " - " + jsonResponse);
            return false;
        }
    }

    private boolean validateFollowable(JSONObject followable, JSONObject media) throws Exception
    {
        if (followable == null)
        {
            logger.error("ERROR - followable is null");
            return false;
        }

        if (followable.has("tags") && !followable.isNull("tags"))
        {
            if (followable.has("cod_profile_hash") && !followable.isNull("cod_profile_hash"))
            {
                if (!media.getString("codProfile").equals(
                    HashCode.decode(Long.valueOf(followable.getString("cod_profile_hash")))))
                {
                    logger.error("ERROR - followable not match user and tag");
                    return false;
                }
            }

            if (followable.has("flg_editorial") && followable.getString("flg_editorial").equals("1"))
            {
                for (String tag : followable.getString("tags").split(","))
                {
                    if (followable.has("flg_and") && followable.getString("flg_and").equals("1"))
                    {
                        if (!media.getString("idtTagService").contains(tag))
                        {
                            logger.error("ERROR - followable not match tag");
                            return false;
                        }
                    }
                    else
                    {
                        if (media.getString("idtTagService").contains(tag))
                        {
                            return true;
                        }
                    }
                }
            }
            else
            {
                for (String tag : followable.getString("tags").split(","))
                {
                    if (followable.has("flg_and") && followable.getString("flg_and").equals("1"))
                    {
                        if (!JsonUtil.containsTagId(media.getJSONArray("tags"), Integer.parseInt(tag)))
                        {
                            logger.error("ERROR - followable not match tagservice");
                            return false;
                        }
                    }
                    else
                    {
                        if (JsonUtil.containsTagId(media.getJSONArray("tags"), Integer.parseInt(tag)))
                        {
                            return true;
                        }
                    }
                }
            }
        }
        else if (followable.has("cod_profile_hash") && !followable.isNull("cod_profile_hash"))
        {
            if (!media.getString("codProfile").equals(
                HashCode.decode(Long.valueOf(followable.getString("cod_profile_hash")))))
            {
                logger.error("ERROR - followable not match user");
                return false;
            }
            else
            {
                return true;
            }
        }

        if (followable.has("idt_editor_type") && !followable.isNull("idt_editor_type"))
        {
            if (!existsEditorType(followable.getString("cod_profile_hash"), followable.getString("idt_editor_type")))
            {
                logger.error("ERROR - followable not match editorType");
                return false;
            }
            else
            {
                return true;
            }
        }

        return false;
    }

    private boolean existsEditorType(String codProfileHash, String idtEditorType) throws Exception
    {
        String query = "SELECT * FROM profile_editor_type WHERE cod_profile_hash = " + codProfileHash
                + " AND idt_editor_type = " + idtEditorType;
        JSONObject result = JsonRequest.execQuery(query);

        if (result != null && result.has("data") && result.getJSONArray("data").length() > 0)
        {
            return true;
        }

        return false;
    }
}
