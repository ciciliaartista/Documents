/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         10/07/2014 Criacao inicial
 */

package uol.taipei.tests.moderation;

import java.util.HashMap;

import org.apache.http.HttpStatus;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uol.taipei.request.UsefulRequest;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.LoginCookie;
import uol.taipei.tests.LoginRadius;

public class GroupAdm extends AbstractTest
{
    static final Logger logger = LoggerFactory.getLogger(GroupAdm.class);

    public static void main(String[] args)
    {
        if (!verifyParams(args))
        {
            return;
        }

        setUp(args[0]);

        if (envConfig().getUser() == null || envConfig().getUser().equals("") || envConfig().getPass() == null || envConfig().getPass().equals(""))
        {
            System.err.println("Invalid user " + envConfig().getUser());
            return;
        }

        logger.debug("-------------------------------------------------");
        logger.debug("tests administration group");

        try
        {
            GroupAdm groupAdm = new GroupAdm();
            LoginCookie login = new LoginCookie(envConfig().getUser(), envConfig().getPass());
            JSONObject profile = login.getJsonProfile();
            UsefulRequest loginR = new LoginRadius(envConfig().getUserRadius(), envConfig().getPassRadius());

            // String groupName = TestUtil.randomString(5);
            HashMap<String, String> group = groupAdm.getGroupMap(loginR);

            // groupAdm.create(loginR, groupName);
            groupAdm.list(loginR);

            // int type = groupAdm.getGroupId(loginR, groupName);

            // groupAdm.addUser(loginR, Integer.parseInt(group.get("idtEditorType")),
            // groupAdm.profile.getJSONObject("item").getString("codProfile"));
            groupAdm.groupsFromUser(loginR, profile.getJSONObject("item").getString("codProfile"));
            groupAdm.usersFromGroup(loginR, Integer.parseInt(group.get("idtEditorType")));
            // groupAdm.removeUser(loginR, Integer.parseInt(group.get("idtEditorType")),
            // groupAdm.profile.getJSONObject("item").getString("codProfile"));
            // groupAdm.remove(loginR, groupName);
        }
        catch (Exception e)
        {
            logger.error(e.getMessage());
        }
    }

    public JSONObject create(UsefulRequest login, String groupName) throws Exception
    {
        JSONObject jsonResponse = login.getJson("http://videos.intranet.uol.com.br/maisAdm/mediaAdmEditor?action=createGroup&groupName="
                + groupName);

        if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") != 200)
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject list(UsefulRequest login) throws Exception
    {
        JSONObject jsonResponse = login.getJson("http://videos.intranet.uol.com.br/maisAdm/mediaAdmEditor.json");

        if (!validateListJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject remove(UsefulRequest login, String groupName) throws Exception
    {
        JSONObject jsonResponse = login
                .getJson("http://videos.intranet.uol.com.br/maisAdm/mediaAdmEditor.json?action=removeGroup&groupName=" + groupName);

        if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") != 200)
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject groupsFromUser(UsefulRequest login, String codProfile) throws Exception
    {
        String url = "http://videos.intranet.uol.com.br/maisAdm/mediaAdmEditor.json?action=showTypesByUser&codProfile=" + codProfile;
        JSONObject jsonResponse = login.getJson(url);

        if (!validateGroupsJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject usersFromGroup(UsefulRequest login, int type) throws Exception
    {
        String url = "http://videos.intranet.uol.com.br/maisAdm/mediaAdmEditor.json?action=showUsersByType&type=" + type;
        JSONObject jsonResponse = login.getJson(url);

        if (!validateUsersJson(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject addUser(UsefulRequest login, int type, String codProfile) throws Exception
    {
        JSONObject jsonResponse = login
                .getJson("http://videos.intranet.uol.com.br/maisAdm/mediaAdmEditor.json?action=addUserToGroup&type=" + type
                        + "&codProfile=" + codProfile);

        if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") != 200)
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject removeUser(UsefulRequest login, int type, String codProfile) throws Exception
    {
        JSONObject jsonResponse = login
                .getJson("http://videos.intranet.uol.com.br/maisAdm/mediaAdmEditor?action=removeUserFromGroup&type=" + type
                        + "&codProfile=" + codProfile);

        if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") != 200)
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public Integer getGroupId(UsefulRequest login, String groupName) throws Exception
    {
        JSONObject jsonResponse = login.getJson("http://videos.intranet.uol.com.br/maisAdm/mediaAdmEditor.json");

        for (int i = 0; i < jsonResponse.getJSONArray("editorTypes").length(); i++)
        {
            if (jsonResponse.getJSONArray("editorTypes").getJSONObject(i).getString("desEditorType").equals(groupName))
            {
                return jsonResponse.getJSONArray("editorTypes").getJSONObject(i).getInt("idtEditorType");
            }
        }

        return null;
    }

    public HashMap<String, String> getGroupMap(UsefulRequest login) throws Exception
    {
        HashMap<String, String> group = new HashMap<String, String>();
        JSONObject profileEditorTypes = null;
        JSONObject jsonResponse = login.getJson("http://videos.intranet.uol.com.br/maisAdm/mediaAdmEditor.json");

        if (jsonResponse.getJSONArray("editorTypes").length() > 0)
        {
            for (int i = 0; i < jsonResponse.getJSONArray("editorTypes").length(); i++)
            {
                profileEditorTypes = login
                        .getJson("http://videos.intranet.uol.com.br/maisAdm/mediaAdmEditor.json?action=showUsersByType&type="
                                + jsonResponse.getJSONArray("editorTypes").getJSONObject(i).getInt("idtEditorType"));

                if (profileEditorTypes != null && !profileEditorTypes.isNull("profileEditorTypes")
                        && profileEditorTypes.getJSONArray("profileEditorTypes").length() > 0)
                {
                    group.put("idtEditorType",
                        String.valueOf(jsonResponse.getJSONArray("editorTypes").getJSONObject(i).getInt("idtEditorType")));
                    group.put("desEditorType", jsonResponse.getJSONArray("editorTypes").getJSONObject(i).getString("desEditorType"));
                }
            }

            return group;
        }

        return null;
    }

    private boolean validateGroupsJson(JSONObject jsonResponse) throws JSONException
    {
        try
        {
            if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") != HttpStatus.SC_OK)
            {
                return false;
            }
            jsonResponse.getJSONArray("profileEditorTypes");

            for (int i = 0; i < jsonResponse.getJSONArray("profileEditorTypes").length(); i++)
            {
                jsonResponse.getJSONArray("profileEditorTypes").getJSONObject(i).getLong("codProfileHash");
                jsonResponse.getJSONArray("profileEditorTypes").getJSONObject(i).getInt("idtEditorType");
                jsonResponse.getJSONArray("profileEditorTypes").getJSONObject(i).getString("desEditorType");
            }

            jsonResponse.getJSONObject("profile").getLong("codProfileHash");
            jsonResponse.getJSONObject("profile").getLong("idtPerson");
            jsonResponse.getJSONObject("profile").getString("indUserProfile");
            jsonResponse.getJSONObject("profile").getString("namNick");
            jsonResponse.getJSONObject("profile").getString("desUrlProfile");
            jsonResponse.getJSONObject("profile").getString("indStatus");
            jsonResponse.getJSONObject("profile").getString("namNickUnique");
            jsonResponse.getJSONObject("profile").getString("namLogin");

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - jsonusers is not valid - " + e.getMessage() + " - " + jsonResponse);
            return false;
        }
    }

    private boolean validateUsersJson(JSONObject jsonResponse) throws JSONException
    {
        try
        {
            if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") != HttpStatus.SC_OK)
            {
                return false;
            }
            jsonResponse.getJSONArray("profileEditorTypes");

            for (int i = 0; i < jsonResponse.getJSONArray("profileEditorTypes").length(); i++)
            {
                jsonResponse.getJSONArray("profileEditorTypes").getJSONObject(i).getLong("codProfileHash");
                jsonResponse.getJSONArray("profileEditorTypes").getJSONObject(i).getInt("idtEditorType");
                jsonResponse.getJSONArray("profileEditorTypes").getJSONObject(i).getString("desEditorType");

                jsonResponse.getJSONArray("profileEditorTypes").getJSONObject(i).getJSONObject("profile").getLong("codProfileHash");
                jsonResponse.getJSONArray("profileEditorTypes").getJSONObject(i).getJSONObject("profile").getLong("idtPerson");
                jsonResponse.getJSONArray("profileEditorTypes").getJSONObject(i).getJSONObject("profile").getString("indUserProfile");
                jsonResponse.getJSONArray("profileEditorTypes").getJSONObject(i).getJSONObject("profile").getString("namNick");
                jsonResponse.getJSONArray("profileEditorTypes").getJSONObject(i).getJSONObject("profile").getString("desUrlProfile");
                jsonResponse.getJSONArray("profileEditorTypes").getJSONObject(i).getJSONObject("profile").getString("indStatus");
                jsonResponse.getJSONArray("profileEditorTypes").getJSONObject(i).getJSONObject("profile").getString("namLogin");
            }

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - jsonusers is not valid - " + e.getMessage() + " - " + jsonResponse);
            return false;
        }
    }

    private boolean validateListJson(JSONObject jsonResponse) throws JSONException
    {
        try
        {
            if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") != HttpStatus.SC_OK)
            {
                return false;
            }
            jsonResponse.getJSONArray("editorTypes");

            for (int i = 0; i < jsonResponse.getJSONArray("editorTypes").length(); i++)
            {
                jsonResponse.getJSONArray("editorTypes").getJSONObject(i).getInt("idtEditorType");
                jsonResponse.getJSONArray("editorTypes").getJSONObject(i).getString("desEditorType");
            }

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - jsonIdentify is not valid - " + e.getMessage() + " - " + jsonResponse);
            return false;
        }
    }
}
