/*
 * Copyright (c) - UOL Inc,
 * Todos os direitos reservados
 *
 * Este arquivo e uma propriedade confidencial do Universo Online Inc.
 * Nenhuma parte do mesmo pode ser copiada, reproduzida, impressa ou
 * transmitida por qualquer meio sem autorizacao expressa e por escrito
 * de um representante legal do Universo Online Inc.
 *
 * All rights reserved
 *
 * This file is a confidential property of Universo Online Inc.
 * No part of this file may be reproduced or copied in any form or by
 * any means without written permisson from an authorized person from
 * Universo Online Inc.
 *
 * Historico de revisoes
 * Autor                             Data       Motivo
 * --------------------------------- ---------- -----------------------
 * tsardinha                         01/08/2016 Criacao inicial
 */

package uol.taipei.tests.drakkar;

import java.io.IOException;
import java.util.HashMap;

import org.apache.http.HttpStatus;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uol.taipei.request.JsonRequest;
import uol.taipei.tests.AbstractTest;
import uol.taipei.tests.util.JsonUtil;
import uol.taipei.util.StringUtil;

public class ApiContentDeprecated extends AbstractTest
{
    static final Logger logger = LoggerFactory.getLogger(ApiContentDeprecated.class);

    public static void main(String[] args)
    {
        if (!verifyParams(args))
        {
            return;
        }

        setUp(args[0]);

        if (envConfig().getUser() == null || envConfig().getUser().equals("") || envConfig().getPass() == null
                || envConfig().getPass().equals(""))
        {
            System.err.println("Invalid user " + envConfig().getUser());
            return;
        }

        logger.debug("-------------------------------------------------");
        logger.debug("tests api content deprecated");

        try
        {
            ApiContentDeprecated apiContent = new ApiContentDeprecated();

            JSONObject media;
            HashMap<String, JSONObject> mapMedias = new HashMap<String, JSONObject>();
            String hashId;
            String hashIdWithoutHyphen;
            String mediaId;

            // VIDEO
            media = JsonUtil.mediaDecored(10, "V", "T", false, false,
                false, false, false);
            mapMedias.put("V", media);

            hashId = mapMedias.get("V").getString("id");
            hashIdWithoutHyphen = hashId.substring(hashId.lastIndexOf("-") + 1);
            mediaId = mapMedias.get("V").getString("idt_media");

            apiContent.chooseContents(mediaId, "media");
            apiContent.chooseContents(hashId, "hash");
            apiContent.chooseContents(hashIdWithoutHyphen, "hash");
            apiContent.detailsQs(mediaId);
            apiContent.detailsQs(hashId);
            apiContent.detailsQs(hashIdWithoutHyphen);
            apiContent.details(mediaId);
            apiContent.details(hashId);
            apiContent.details(hashIdWithoutHyphen);

            // PODCAST
            media = JsonUtil.mediaDecored(10, "P", "T", false, false,
                false, false, false);
            mapMedias.put("P", media);

            hashId = mapMedias.get("P").getString("id");
            hashIdWithoutHyphen = hashId.substring(hashId.lastIndexOf("-") + 1);
            mediaId = mapMedias.get("P").getString("idt_media");

            apiContent.chooseContents(mediaId, "media");
            apiContent.chooseContents(hashId, "hash");
            apiContent.chooseContents(hashIdWithoutHyphen, "hash");
            apiContent.detailsQs(mediaId);
            apiContent.detailsQs(hashId);
            apiContent.detailsQs(hashIdWithoutHyphen);
            apiContent.details(mediaId);
            apiContent.details(hashId);
            apiContent.details(hashIdWithoutHyphen);

            apiContent.chooseContents(mediaId, "media");
            apiContent.chooseContents(hashId, "hash");
            apiContent.chooseContents(hashIdWithoutHyphen, "hash");
            apiContent.detailsQs(mediaId);
            apiContent.detailsQs(hashId);
            apiContent.detailsQs(hashIdWithoutHyphen);
            apiContent.details(mediaId);
            apiContent.details(hashId);
            apiContent.details(hashIdWithoutHyphen);

            String listIds = apiContent.listId(mapMedias);

            apiContent.chooseContents(listIds, "hash");
            apiContent.detailsQs(listIds);
            apiContent.details(listIds);

            listIds = apiContent.listMediaId(mapMedias);

            apiContent.chooseContents(listIds, "media");
            apiContent.detailsQs(listIds);
            apiContent.details(listIds);

            apiContent.listV1();
            apiContent.listV2();
        }
        catch (Exception e)
        {
            logger.error(e.getMessage());
        }
    }

    public JSONObject listV1() throws IOException, JSONException
    {
        JSONObject jsonResponse = JsonRequest.get("http://mais.uol.com.br/apiuol/mediasList");

        if (!validatePageJsonV1(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        jsonResponse = JsonRequest.get("http://api.mais.uol.com.br/apiuol/deprecated/v1/media/list");

        if (!validatePageJsonV1(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject listV2() throws IOException, JSONException
    {
        JSONObject jsonResponse = JsonRequest.get("http://mais.uol.com.br/apiuol/v2/media/list");

        if (!validatePageJsonV2(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        jsonResponse = JsonRequest.get("http://api.mais.uol.com.br/apiuol/deprecated/v2/media/list");

        if (!validatePageJsonV2(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject chooseContents(String ids, String queryType) throws IOException, JSONException
    {
        JSONObject jsonResponse = JsonRequest.get("http://mais.uol.com.br/apiuol/chooseContents?type=" + queryType
                + "&ids=" + ids);

        if (!validateJsonChooseContents(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        jsonResponse = JsonRequest.get("http://api.mais.uol.com.br/apiuol/deprecated/v1/chooseContents?type=" + queryType
                + "&ids=" + ids);

        if (!validateJsonChooseContents(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    public JSONObject detailsQs(String ids) throws IOException, JSONException
    {
        JSONObject jsonResponse = JsonRequest.get("http://mais.uol.com.br/apiuol/v2/media/list?ids=" + ids);

        if (!validatePageJsonV2(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        if (!hasMedia(ids, jsonResponse.getJSONArray("list")))
        {
            logger.error("ERROR - has not media");
            return null;
        }

        jsonResponse = JsonRequest.get("http://api.mais.uol.com.br/apiuol/deprecated/v2/media/list?ids=" + ids);

        if (!validatePageJsonV2(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        if (!hasMedia(ids, jsonResponse.getJSONArray("list")))
        {
            logger.error("ERROR - has not media");
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    /**
     * api de detalhes de uma lista de midias. url em rest
     * 
     * @param ids
     * @return JSONObject
     * @throws IOException
     * @throws JSONException
     */
    public JSONObject details(String ids) throws IOException, JSONException
    {
        JSONObject jsonResponse = JsonRequest.get("http://mais.uol.com.br/apiuol/v2/media/list/" + ids);

        if (!validatePageJsonV2(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        if (!hasMedia(ids, jsonResponse.getJSONArray("list")))
        {
            logger.error("ERROR - has not media");
            return null;
        }

        jsonResponse = JsonRequest.get("http://api.mais.uol.com.br/apiuol/deprecated/v2/media/list/" + ids);

        if (!validatePageJsonV2(jsonResponse))
        {
            logger.error("ERROR - return not valid - " + jsonResponse);
            return null;
        }

        if (!hasMedia(ids, jsonResponse.getJSONArray("list")))
        {
            logger.error("ERROR - has not media");
            return null;
        }

        logger.debug("SUCCESS");

        return jsonResponse;
    }

    private boolean hasMedia(String ids, JSONArray jsonArray) throws JSONException
    {
        String[] paramIds = ids.split(",");
        String typeId = null;

        for (int i = 0; i < jsonArray.length(); i++)
        {
            if (StringUtil.validateNumber(paramIds[i]))
            {
                typeId = "mediaId";

                if (JsonUtil.containsMedia(jsonArray, Long.parseLong(paramIds[i])))
                {
                    return true;
                }
            }
            else
            {
                typeId = "hashId";

                if (JsonUtil.containsMedia(jsonArray, paramIds[i]))
                {
                    return true;
                }
            }
        }

        logger.error("ERROR - " + typeId + " not match - ids " + ids + " - " + jsonArray);

        return false;
    }

    public String listMediaId(HashMap<String, JSONObject> mapIds) throws JSONException
    {
        StringBuilder list = new StringBuilder();

        for (JSONObject mi : mapIds.values())
        {
            list.append((list.length() > 0 ? "," : "") + mi.getString("idt_media"));
        }

        return list.toString();
    }

    public String listId(HashMap<String, JSONObject> mapIds) throws JSONException
    {
        StringBuilder list = new StringBuilder();

        for (JSONObject mi : mapIds.values())
        {
            list.append((list.length() > 0 ? "," : "") + mi.getString("id"));
        }

        return list.toString();
    }

    public String listIdWithoutHyphen(HashMap<String, JSONObject> mapIds) throws JSONException
    {
        StringBuilder list = new StringBuilder();

        for (JSONObject mi : mapIds.values())
        {
            String hashId = mi.getString("id");
            String hashIdWithoutHyphen = hashId.substring(hashId.lastIndexOf("-") + 1);
            list.append((list.length() > 0 ? "," : "") + hashIdWithoutHyphen);
        }

        return list.toString();
    }

    private boolean validateJsonChooseContents(JSONObject jsonResponse) throws JSONException
    {
        try
        {
            if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") != HttpStatus.SC_OK)
            {
                return false;
            }
            jsonResponse.getJSONObject("response");
            jsonResponse.getJSONObject("response").getInt("code");
            jsonResponse.getJSONObject("response").getString("description");
            jsonResponse.getJSONObject("response").getString("originalRequest");

            jsonResponse.getJSONArray("list");

            for (int i = 0; i < jsonResponse.getJSONArray("list").length(); i++)
            {
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("title");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("id");
                jsonResponse.getJSONArray("list").getJSONObject(i).getLong("mediaId");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("url");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("mediaType");
                Boolean.parseBoolean(jsonResponse.getJSONArray("list").getJSONObject(i).getString("moderateNote"));
                Boolean.parseBoolean(jsonResponse.getJSONArray("list").getJSONObject(i)
                        .getString("allowAnonymousComment"));
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("allowNotes");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("edFilter");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("thumbnail");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("thumbSmall");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("thumbMedium");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("thumbLarge");
                jsonResponse.getJSONArray("list").getJSONObject(i).getLong("idtSubject");

                if (jsonResponse.getJSONArray("list").getJSONObject(i).getString("mediaType").equals("V"))
                {
                    jsonResponse.getJSONArray("list").getJSONObject(i).getString("player");
                    jsonResponse.getJSONArray("list").getJSONObject(i).getString("duration");

                    jsonResponse.getJSONArray("list").getJSONObject(i).getInt("numThumbnailIdentifier");

                    for (int j = 0; j < jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("formats")
                            .length(); j++)
                    {
                        jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("formats").getJSONObject(j)
                                .getInt("id");
                        jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("formats").getJSONObject(j)
                                .getString("url");
                    }

                    if (jsonResponse.getJSONArray("list").getJSONObject(i).has("idtProductList"))
                    {
                        jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("idtProductList");

                        for (int j = 0; j < jsonResponse.getJSONArray("list").getJSONObject(i)
                                .getJSONArray("idtProductList").length(); j++)
                        {
                            jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("idtProductList").getInt(j);
                        }
                    }

                    jsonResponse.getJSONArray("list").getJSONObject(i).getString("embedCode");
                }

                if (jsonResponse.getJSONArray("list").getJSONObject(i).getString("mediaType").equals("P"))
                {
                    jsonResponse.getJSONArray("list").getJSONObject(i).getString("player");
                    jsonResponse.getJSONArray("list").getJSONObject(i).getString("duration");
                    jsonResponse.getJSONArray("list").getJSONObject(i).getString("embedCode");
                }

                if (!jsonResponse.getJSONArray("list").getJSONObject(i).getString("mediaType").equals("T")
                        && !jsonResponse.getJSONArray("list").getJSONObject(i).getString("mediaType").equals("P")
                        && !jsonResponse.getJSONArray("list").getJSONObject(i).getString("mediaType").equals("S"))
                {
                    jsonResponse.getJSONArray("list").getJSONObject(i).getInt("thumbVersion");
                }

                jsonResponse.getJSONArray("list").getJSONObject(i).getString("description");
                Boolean.parseBoolean(jsonResponse.getJSONArray("list").getJSONObject(i).getString("adultContent"));
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("author");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("authorPage");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("codProfile");
                jsonResponse.getJSONArray("list").getJSONObject(i).getInt("views");
                jsonResponse.getJSONArray("list").getJSONObject(i).getInt("comments");
                jsonResponse.getJSONArray("list").getJSONObject(i).getInt("favorites");
                jsonResponse.getJSONArray("list").getJSONObject(i).getDouble("rating");
                jsonResponse.getJSONArray("list").getJSONObject(i).getInt("votes");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("publishedAt");
                Boolean.parseBoolean(jsonResponse.getJSONArray("list").getJSONObject(i).getString("blockEmbed"));
                Boolean.parseBoolean(jsonResponse.getJSONArray("list").getJSONObject(i).getString("subscriberMedia"));

                for (int j = 0; j < jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("tags").length(); j++)
                {
                    jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("tags").getJSONObject(j)
                            .getLong("id");
                    jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("tags").getJSONObject(j)
                            .getString("description");
                }

                jsonResponse.getJSONArray("list").getJSONObject(i).getString("idtTagService");
            }

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - json is not valid - " + e.getMessage() + " - " + jsonResponse);
            return false;
        }
    }

    private boolean validatePageJsonV1(JSONObject jsonResponse) throws JSONException
    {
        try
        {
            if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") != HttpStatus.SC_OK)
            {
                return false;
            }
            jsonResponse.getJSONObject("response");
            jsonResponse.getJSONObject("response").getInt("code");
            jsonResponse.getJSONObject("response").getString("description");
            jsonResponse.getJSONObject("response").getString("originalRequest");

            jsonResponse.getJSONObject("paging");
            jsonResponse.getJSONObject("paging").getInt("currentPage");
            Boolean.parseBoolean(jsonResponse.getJSONObject("paging").getString("nextPage"));
            jsonResponse.getJSONObject("paging").getInt("pageSize");
            Boolean.parseBoolean(jsonResponse.getJSONObject("paging").getString("previousPage"));
            jsonResponse.getJSONObject("paging").getString("sort");
            jsonResponse.getJSONObject("paging").getInt("totalItems");
            jsonResponse.getJSONObject("paging").getInt("totalPages");

            jsonResponse.getJSONArray("list");

            for (int i = 0; i < jsonResponse.getJSONArray("list").length(); i++)
            {
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("title");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("id");
                jsonResponse.getJSONArray("list").getJSONObject(i).getLong("mediaId");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("url");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("mediaType");
                Boolean.parseBoolean(jsonResponse.getJSONArray("list").getJSONObject(i).getString("moderateNote"));
                Boolean.parseBoolean(jsonResponse.getJSONArray("list").getJSONObject(i)
                        .getString("allowAnonymousComment"));
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("allowNotes");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("edFilter");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("thumbnail");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("thumbSmall");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("thumbMedium");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("thumbLarge");
                jsonResponse.getJSONArray("list").getJSONObject(i).getLong("idtSubject");

                if (jsonResponse.getJSONArray("list").getJSONObject(i).getString("mediaType").equals("V"))
                {
                    jsonResponse.getJSONArray("list").getJSONObject(i).getString("player");
                    jsonResponse.getJSONArray("list").getJSONObject(i).getString("duration");

                    jsonResponse.getJSONArray("list").getJSONObject(i).getInt("numThumbnailIdentifier");

                    for (int j = 0; j < jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("formats")
                            .length(); j++)
                    {
                        jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("formats").getJSONObject(j)
                                .getInt("id");
                        jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("formats").getJSONObject(j)
                                .getString("url");
                    }

                    if (jsonResponse.getJSONArray("list").getJSONObject(i).has("idtProductList"))
                    {
                        jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("idtProductList");

                        for (int j = 0; j < jsonResponse.getJSONArray("list").getJSONObject(i)
                                .getJSONArray("idtProductList").length(); j++)
                        {
                            jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("idtProductList").getInt(j);
                        }
                    }

                    jsonResponse.getJSONArray("list").getJSONObject(i).getString("embedCode");
                }

                if (jsonResponse.getJSONArray("list").getJSONObject(i).getString("mediaType").equals("P"))
                {
                    jsonResponse.getJSONArray("list").getJSONObject(i).getString("player");
                    jsonResponse.getJSONArray("list").getJSONObject(i).getString("duration");
                    jsonResponse.getJSONArray("list").getJSONObject(i).getString("embedCode");
                }

                if (!jsonResponse.getJSONArray("list").getJSONObject(i).getString("mediaType").equals("T")
                        && !jsonResponse.getJSONArray("list").getJSONObject(i).getString("mediaType").equals("P")
                        && !jsonResponse.getJSONArray("list").getJSONObject(i).getString("mediaType").equals("S"))
                {
                    jsonResponse.getJSONArray("list").getJSONObject(i).getInt("thumbVersion");
                }

                jsonResponse.getJSONArray("list").getJSONObject(i).getString("description");
                Boolean.parseBoolean(jsonResponse.getJSONArray("list").getJSONObject(i).getString("adultContent"));
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("author");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("authorPage");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("codProfile");
                jsonResponse.getJSONArray("list").getJSONObject(i).getInt("views");
                jsonResponse.getJSONArray("list").getJSONObject(i).getInt("comments");
                jsonResponse.getJSONArray("list").getJSONObject(i).getInt("favorites");
                jsonResponse.getJSONArray("list").getJSONObject(i).getDouble("rating");
                jsonResponse.getJSONArray("list").getJSONObject(i).getInt("votes");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("publishedAt");
                Boolean.parseBoolean(jsonResponse.getJSONArray("list").getJSONObject(i).getString("blockEmbed"));
                Boolean.parseBoolean(jsonResponse.getJSONArray("list").getJSONObject(i).getString("subscriberMedia"));

                for (int j = 0; j < jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("tags").length(); j++)
                {
                    jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("tags").getJSONObject(j)
                            .getLong("id");
                    jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("tags").getJSONObject(j)
                            .getString("description");
                }

                jsonResponse.getJSONArray("list").getJSONObject(i).getString("idtTagService");
            }

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - pagejson is not valid - " + e.getMessage() + " - " + jsonResponse);
            return false;
        }
    }

    private boolean validatePageJsonV2(JSONObject jsonResponse) throws JSONException
    {
        try
        {
            if (jsonResponse == null || jsonResponse.getJSONObject("_response").getInt("code") != HttpStatus.SC_OK)
            {
                return false;
            }
            jsonResponse.getJSONObject("response");
            jsonResponse.getJSONObject("response").getInt("code");
            jsonResponse.getJSONObject("response").getString("description");
            jsonResponse.getJSONObject("response").getString("originalRequest");

            jsonResponse.getJSONObject("paging");
            jsonResponse.getJSONObject("paging").getInt("currentPage");
            Boolean.parseBoolean(jsonResponse.getJSONObject("paging").getString("nextPage"));
            jsonResponse.getJSONObject("paging").getInt("pageSize");
            Boolean.parseBoolean(jsonResponse.getJSONObject("paging").getString("previousPage"));
            jsonResponse.getJSONObject("paging").getString("sort");
            jsonResponse.getJSONObject("paging").getInt("totalItems");
            jsonResponse.getJSONObject("paging").getInt("totalPages");

            jsonResponse.getJSONArray("list");

            for (int i = 0; i < jsonResponse.getJSONArray("list").length(); i++)
            {
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("title");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("id");
                jsonResponse.getJSONArray("list").getJSONObject(i).getLong("mediaId");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("url");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("mediaType");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("indVisibility");
                Boolean.parseBoolean(jsonResponse.getJSONArray("list").getJSONObject(i).getString("moderateNote"));
                Boolean.parseBoolean(jsonResponse.getJSONArray("list").getJSONObject(i)
                        .getString("allowAnonymousComment"));
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("allowNotes");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("edFilter");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("thumbnail");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("thumbSmall");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("thumbMedium");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("thumbLarge");
                jsonResponse.getJSONArray("list").getJSONObject(i).getLong("idtSubject");

                if (jsonResponse.getJSONArray("list").getJSONObject(i).getString("mediaType").equals("V"))
                {
                    jsonResponse.getJSONArray("list").getJSONObject(i).getString("player");
                    jsonResponse.getJSONArray("list").getJSONObject(i).getString("duration");
                    jsonResponse.getJSONArray("list").getJSONObject(i).getString("thumbWlarge");
                    jsonResponse.getJSONArray("list").getJSONObject(i).getString("thumbWmedium");

                    jsonResponse.getJSONArray("list").getJSONObject(i).getInt("numThumbnailIdentifier");

                    for (int j = 0; j < jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("formats")
                            .length(); j++)
                    {
                        jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("formats").getDouble(j);
                    }

                    if (jsonResponse.getJSONArray("list").getJSONObject(i).has("idtProductList"))
                    {
                        jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("idtProductList");

                        for (int j = 0; j < jsonResponse.getJSONArray("list").getJSONObject(i)
                                .getJSONArray("idtProductList").length(); j++)
                        {
                            jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("idtProductList").getInt(j);
                        }
                    }

                    jsonResponse.getJSONArray("list").getJSONObject(i).getString("embedCode");
                }

                if (jsonResponse.getJSONArray("list").getJSONObject(i).getString("mediaType").equals("P"))
                {
                    jsonResponse.getJSONArray("list").getJSONObject(i).getString("player");
                    jsonResponse.getJSONArray("list").getJSONObject(i).getString("duration");
                    jsonResponse.getJSONArray("list").getJSONObject(i).getString("embedCode");
                }

                if (!jsonResponse.getJSONArray("list").getJSONObject(i).getString("mediaType").equals("T")
                        && !jsonResponse.getJSONArray("list").getJSONObject(i).getString("mediaType").equals("P")
                        && !jsonResponse.getJSONArray("list").getJSONObject(i).getString("mediaType").equals("S"))
                {
                    jsonResponse.getJSONArray("list").getJSONObject(i).getInt("thumbVersion");
                }

                jsonResponse.getJSONArray("list").getJSONObject(i).getString("description");
                Boolean.parseBoolean(jsonResponse.getJSONArray("list").getJSONObject(i).getString("adultContent"));
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("author");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("authorPage");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("codProfile");
                jsonResponse.getJSONArray("list").getJSONObject(i).getInt("views");
                jsonResponse.getJSONArray("list").getJSONObject(i).getInt("comments");
                jsonResponse.getJSONArray("list").getJSONObject(i).getInt("favorites");
                jsonResponse.getJSONArray("list").getJSONObject(i).getDouble("rating");
                jsonResponse.getJSONArray("list").getJSONObject(i).getInt("votes");
                jsonResponse.getJSONArray("list").getJSONObject(i).getString("publishedAt");
                Boolean.parseBoolean(jsonResponse.getJSONArray("list").getJSONObject(i).getString("blockEmbed"));
                Boolean.parseBoolean(jsonResponse.getJSONArray("list").getJSONObject(i).getString("subscriberMedia"));

                for (int j = 0; j < jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("tags").length(); j++)
                {
                    jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("tags").getJSONObject(j)
                            .getLong("id");
                    jsonResponse.getJSONArray("list").getJSONObject(i).getJSONArray("tags").getJSONObject(j)
                            .getString("description");
                }

                jsonResponse.getJSONArray("list").getJSONObject(i).getString("idtTagService");
            }

            return true;
        }
        catch (Exception e)
        {
            logger.error("ERROR - pagejson is not valid - " + e.getMessage() + " - " + jsonResponse);
            return false;
        }
    }
}
