#!/bin/bash
#
# executa classe com fonte do teste 

if [ $# -lt 2 ]; then
    echo "Usage: $0 <opt> <env>"
    echo "   opt   0 - Basic"
	echo "         1 - ApiAuth"
    echo "         2 - ApiComment"
    echo "         3 - ApiContent"
    echo "         4 - ApiContentErr"
    echo "         5 - ApiSearch"
    echo "         6 - BasicContent"
    echo "         7 - HealthCheckNavigation"
    echo "         8 - HealthCheckSearch"
    echo "         9 - ListResumed"
    echo "         10 - Redir"
    echo "         11 - View"
    echo "         12 - Croupier"
    echo "         13 - HealthCheckCroupier"
    echo "         14 - Videom"
    echo "         15 - HealthCheckDebugator"
    echo "         16 - ApiV3Content"
    echo "         17 - HealthCheckDrakkar"
    echo "         18 - Encoding"
    echo "         19 - HealthCheckEncoder"
    echo "         20 - ApiFavorite"
    echo "         21 - ApiCommentGibraltar"
    echo "         22 - ApiPublishGibraltar"
    echo "         23 - Indexing"
    echo "         24 - ApiMobile"
    echo "         25 - AlbumAdm"
    echo "         26 - BlacklistAdm"
    echo "         27 - GroupAdm"
    echo "         28 - HealthCheckAdm"
    echo "         29 - MediaAdm"
    echo "         30 - MediaProxy"
    echo "         31 - ProfileAdm"
    echo "         32 - PublicityAdm"
    echo "         33 - SubscriptionAdm"
    echo "         34 - NotificationsIntegration"
    echo "         35 - ApiPlayer"
    echo "         36 - Player"
    echo "         37 - ApiPlaylist"
    echo "         38 - ApiPlaylistErr"
    echo "         39 - ApiProfile"
    echo "         40 - ApiPublish"
    echo "         41 - HealthCheckPublish"
    echo "         42 - ApiRating"
    echo "         43 - ApiPlayerSsl"
    echo "         44 - BalaioSsl"
    echo "         45 - PlayerSsl"
    echo "         46 - StorageSsl"
    echo "         47 - ThumbSsl"
    echo "         48 - VideomSsl"
    echo "         49 - Balaio"
    echo "         50 - Catraca"
    echo "         51 - Storage"
    echo "         52 - Thumb"
    echo "         53 - ApiSubscription"
    echo "         54 - Token"
	echo "  env    [stg qa prod]"
    exit
fi

if [[ "$1" == "0" ]]; then
	CLASS="uol.taipei.tests.prepare.Basic"
elif [[ "$1" == "1" ]]; then
	CLASS="uol.taipei.tests.auth.ApiAuth"
elif [[ "$1" == "2" ]]; then
	CLASS="uol.taipei.tests.comment.ApiComment"
elif [[ "$1" == "3" ]]; then
	CLASS="uol.taipei.tests.content.ApiContent"
elif [[ "$1" == "4" ]]; then
	CLASS="uol.taipei.tests.content.ApiContentErr"
elif [[ "$1" == "5" ]]; then
	CLASS="uol.taipei.tests.content.ApiSearch"
elif [[ "$1" == "6" ]]; then
	CLASS="uol.taipei.tests.content.BasicContent"
elif [[ "$1" == "7" ]]; then
	CLASS="uol.taipei.tests.content.HealthCheckNavigation"
elif [[ "$1" == "8" ]]; then
	CLASS="uol.taipei.tests.content.HealthCheckSearch"
elif [[ "$1" == "9" ]]; then
	CLASS="uol.taipei.tests.content.ListResumed"
elif [[ "$1" == "10" ]]; then
	CLASS="uol.taipei.tests.content.Redir"
elif [[ "$1" == "11" ]]; then
	CLASS="uol.taipei.tests.content.View"
elif [[ "$1" == "12" ]]; then
	CLASS="uol.taipei.tests.croupier.Croupier"
elif [[ "$1" == "13" ]]; then
	CLASS="uol.taipei.tests.croupier.HealthCheckCroupier"
elif [[ "$1" == "14" ]]; then
	CLASS="uol.taipei.tests.croupier.Videom"
elif [[ "$1" == "15" ]]; then
	CLASS="uol.taipei.tests.debugator.HealthCheckDebugator"
elif [[ "$1" == "16" ]]; then
	CLASS="uol.taipei.tests.drakkar.ApiV3Content"
elif [[ "$1" == "17" ]]; then
	CLASS="uol.taipei.tests.drakkar.HealthCheckDrakkar"
elif [[ "$1" == "18" ]]; then
	CLASS="uol.taipei.tests.encoder.Encoding"
elif [[ "$1" == "19" ]]; then
	CLASS="uol.taipei.tests.encoder.HealthCheckEncoder"
elif [[ "$1" == "20" ]]; then
	CLASS="uol.taipei.tests.favorite.ApiFavorite"
elif [[ "$1" == "21" ]]; then
	CLASS="uol.taipei.tests.gibraltar.ApiCommentGibraltar"
elif [[ "$1" == "22" ]]; then
	CLASS="uol.taipei.tests.gibraltar.ApiPublishGibraltar"
elif [[ "$1" == "23" ]]; then
	CLASS="uol.taipei.tests.indexer.Indexing"
elif [[ "$1" == "24" ]]; then
	CLASS="uol.taipei.tests.mobile.ApiMobile"
elif [[ "$1" == "25" ]]; then
	CLASS="uol.taipei.tests.moderation.AlbumAdm"
elif [[ "$1" == "26" ]]; then
	CLASS="uol.taipei.tests.moderation.BlacklistAdm"
elif [[ "$1" == "27" ]]; then
	CLASS="uol.taipei.tests.moderation.GroupAdm"
elif [[ "$1" == "28" ]]; then
	CLASS="uol.taipei.tests.moderation.HealthCheckAdm"
elif [[ "$1" == "29" ]]; then
	CLASS="uol.taipei.tests.moderation.MediaAdm"
elif [[ "$1" == "30" ]]; then
	CLASS="uol.taipei.tests.moderation.MediaProxy"
elif [[ "$1" == "31" ]]; then
	CLASS="uol.taipei.tests.moderation.ProfileAdm"
elif [[ "$1" == "32" ]]; then
	CLASS="uol.taipei.tests.moderation.PublicityAdm"
elif [[ "$1" == "33" ]]; then
	CLASS="uol.taipei.tests.moderation.SubscriptionAdm"
elif [[ "$1" == "34" ]]; then
	CLASS="uol.taipei.tests.notificationsIntegration.NotificationsIntegration"
elif [[ "$1" == "35" ]]; then
	CLASS="uol.taipei.tests.player.ApiPlayer"
elif [[ "$1" == "36" ]]; then
	CLASS="uol.taipei.tests.player.Player"
elif [[ "$1" == "37" ]]; then
	CLASS="uol.taipei.tests.playlist.ApiPlaylist"
elif [[ "$1" == "38" ]]; then
	CLASS="uol.taipei.tests.playlist.ApiPlaylistErr"
elif [[ "$1" == "39" ]]; then
	CLASS="uol.taipei.tests.profile.ApiProfile"
elif [[ "$1" == "40" ]]; then
	CLASS="uol.taipei.tests.publish.ApiPublish"
elif [[ "$1" == "41" ]]; then
	CLASS="uol.taipei.tests.publish.HealthCheckPublish"
elif [[ "$1" == "42" ]]; then
	CLASS="uol.taipei.tests.rating.ApiRating"
elif [[ "$1" == "43" ]]; then
	CLASS="uol.taipei.tests.ssl.ApiPlayerSsl"
elif [[ "$1" == "44" ]]; then
	CLASS="uol.taipei.tests.ssl.BalaioSsl"
elif [[ "$1" == "45" ]]; then
	CLASS="uol.taipei.tests.ssl.PlayerSsl"
elif [[ "$1" == "46" ]]; then
	CLASS="uol.taipei.tests.ssl.StorageSsl"
elif [[ "$1" == "47" ]]; then
	CLASS="uol.taipei.tests.ssl.ThumbSsl"
elif [[ "$1" == "48" ]]; then
	CLASS="uol.taipei.tests.ssl.VideomSsl"
elif [[ "$1" == "49" ]]; then
	CLASS="uol.taipei.tests.storage.Balaio"
elif [[ "$1" == "50" ]]; then
	CLASS="uol.taipei.tests.storage.Catraca"
elif [[ "$1" == "51" ]]; then
	CLASS="uol.taipei.tests.storage.Storage"
elif [[ "$1" == "52" ]]; then
	CLASS="uol.taipei.tests.storage.Thumb"
elif [[ "$1" == "53" ]]; then
	CLASS="uol.taipei.tests.subscription.ApiSubscription"
elif [[ "$1" == "54" ]]; then
	CLASS="uol.taipei.tests.token.Token"
else
	echo "invalid option $1"
	exit
fi

VERSION=`cat ../../../pom.xml | grep -A2 "taipei-tests" | grep version | cut -d'>' -f2 | cut -d'<' -f1`
LIB_PATH=`realpath $PWD/../../../target/ | sed 's/\/cygdrive\/c//g'`
CLASS_PATH="${LIB_PATH}/taipei-tests-${VERSION}-SHADED.jar"

echo "$CLASS_PATH" $CLASS $@

$JAVA_HOME/bin/java -cp "$CLASS_PATH" $CLASS $2 $3 $4 $5

echo "verificar o log /export/logs/uolmais-tests/uolmais-tests.log"

exit