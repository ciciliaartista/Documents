# testes de integra��o
testes de m�dulos uolmais via servi�o

- compile e gera pacote de testes
mvn clean install -Dmaven.test.skip=true 
mvn clean install -Dmaven.test.skip=true -Dmaven.clean.failOnError=false

- executa todos os testes respeitando preced�ncias intraclasse
mvn test

- executa teste de classe espec�fica
mvn clean test -Dtest=className
mvn clean test -Dtest=ApiV3ContentTest

- executa teste de um m�todo de uma classe espec�fica
mvn clean test -Dtest=className#methodName
mvn clean test -Dtest=ApiV3ContentTest#sort

- executa teste de m�dulos espec�ficos
mvn integration-test -Pbalaio
mvn integration-test -Pindexing
mvn integration-test -Pencoding

- executa testes sem uso de junit
	. via script, src/main/script ./execTest.sh
	. inst�ncia a classe e executa o m�todo main

- para gerar corpo do script execTest.sh
	. no dir src/main/java
	. opcao com numerador
	i=1; for f in `find uol/taipei/tests/*/ -type f | egrep -v '(/prepare/|/util/)'`; do c=`echo "$f" | awk -F '/' '{print $5}' | sed 's/\.java$//g'`; echo "    echo \"         ${i} - ${c}\""; i=$((i+1)); done
	. numerador por classe
	i=1; for f in `find uol/taipei/tests/*/ -type f | egrep -v '(/prepare/|/util/)' | sed 's/\//\./g' | sed 's/\.java//g'`; do c=`echo "$f" | sed 's/\.\.//g'`; echo "elif [[ \"\$1\" == \"${i}\" ]]; then"; echo $'\t'"CLASS=\"${c}\""; i=$((i+1)); done



